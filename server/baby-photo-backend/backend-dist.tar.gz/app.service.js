"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AppService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("./shared/prisma/prisma.service");
const child_process_1 = require("child_process");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const net = __importStar(require("net"));
const START_TIME = new Date().toISOString();
const PKG = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf-8'));
let AppService = AppService_1 = class AppService {
    prisma;
    logger = new common_1.Logger(AppService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    getHello() {
        return '🎉 欢迎使用乖宝宝儿童影楼管理系统！';
    }
    async getHealth() {
        const currentTime = new Date().toISOString();
        const uptime = process.uptime();
        let dbStatus = 'disconnected';
        let redisStatus = 'disconnected';
        let diskStatus = {};
        try {
            await this.prisma.$queryRaw `SELECT 1`;
            dbStatus = 'connected';
        }
        catch (e) {
            this.logger.error(`数据库健康检查失败: ${e.message}`);
        }
        try {
            const host = process.env.REDIS_HOST || 'localhost';
            const port = parseInt(process.env.REDIS_PORT || '6379', 10);
            await new Promise((resolve, reject) => {
                const socket = net.createConnection(port, host, () => {
                    socket.destroy();
                    resolve();
                });
                socket.on('error', reject);
                socket.setTimeout(2000, () => {
                    socket.destroy();
                    reject(new Error('timeout'));
                });
            });
            redisStatus = 'connected';
        }
        catch (e) {
        }
        try {
            const df = (0, child_process_1.execSync)('df -k / | tail -1', { encoding: 'utf8', timeout: 3000 });
            const parts = df.trim().split(/\s+/);
            if (parts.length >= 4) {
                const totalKb = parseInt(parts[1]) || 0;
                const usedKb = parseInt(parts[2]) || 0;
                const freeKb = parseInt(parts[3]) || 0;
                diskStatus = {
                    total: `${(totalKb / 1024 / 1024).toFixed(1)}GB`,
                    used: `${(usedKb / 1024 / 1024).toFixed(1)}GB`,
                    free: `${(freeKb / 1024 / 1024).toFixed(1)}GB`,
                    usagePercent: totalKb > 0 ? Math.round((usedKb / totalKb) * 100) : 0,
                };
            }
        }
        catch (e) {
        }
        return {
            status: dbStatus === 'connected' ? 'ok' : 'degraded',
            message: dbStatus === 'connected' ? '系统运行正常' : '数据库连接异常',
            timestamp: currentTime,
            uptime: `${Math.floor(uptime)}秒`,
            version: PKG.version || '1.0.0',
            environment: process.env.NODE_ENV || 'development',
            services: {
                database: dbStatus,
                redis: redisStatus,
                disk: diskStatus,
            },
        };
    }
    getVersion() {
        return {
            name: PKG.name || '乖宝宝儿童影楼管理系统',
            version: PKG.version || '1.0.0',
            description: PKG.description || '专业的婴儿摄影工作室管理解决方案',
            startupTime: START_TIME,
            nodeVersion: process.version,
            platform: process.platform,
        };
    }
};
exports.AppService = AppService;
exports.AppService = AppService = AppService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], AppService);
//# sourceMappingURL=app.service.js.map