import { AppService } from './app.service';
export declare class AppController {
    private readonly appService;
    constructor(appService: AppService);
    getHello(): string;
    getHealth(): Promise<{
        status: string;
        message: string;
        timestamp: string;
        uptime: string;
        version: any;
        environment: string;
        services: {
            database: string;
            redis: string;
            disk: {
                total?: string;
                used?: string;
                free?: string;
                usagePercent?: number;
            };
        };
    }>;
    getVersion(): {
        name: any;
        version: any;
        description: any;
        startupTime: string;
        nodeVersion: string;
        platform: NodeJS.Platform;
    };
}
