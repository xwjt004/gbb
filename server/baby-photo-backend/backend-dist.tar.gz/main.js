"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const app_module_1 = require("./app.module");
const all_exceptions_filter_1 = require("./shared/filters/all-exceptions.filter");
const roles_service_1 = require("./modules/roles/roles.service");
const env_validator_1 = require("./shared/config/env-validator");
const Sentry = __importStar(require("@sentry/node"));
async function bootstrap() {
    (0, env_validator_1.validateEnv)();
    if (process.env.SENTRY_DSN) {
        Sentry.init({
            dsn: process.env.SENTRY_DSN,
            environment: process.env.NODE_ENV || 'development',
            tracesSampleRate: parseFloat(process.env.SENTRY_TRACES_SAMPLE_RATE || '0.1'),
        });
    }
    const logger = new common_1.Logger('Bootstrap');
    try {
        const app = await core_1.NestFactory.create(app_module_1.AppModule);
        if (process.env.NODE_ENV === 'production' &&
            (!process.env.JWT_SECRET ||
                process.env.JWT_SECRET === 'change-me-in-production' ||
                process.env.JWT_SECRET === 'your-super-secret-jwt-key-change-this-in-production')) {
            throw new Error('JWT_SECRET 仍为默认值，请在 .env 中设置一个安全的随机密钥后再启动生产环境');
        }
        const corsOrigin = process.env.CORS_ORIGIN
            ? process.env.CORS_ORIGIN.split(',').map((s) => s.trim())
            : [
                'http://localhost:3000',
                'http://localhost:3001',
                'http://127.0.0.1:3001',
                'http://localhost:8080',
            ];
        app.enableCors({
            origin: corsOrigin,
            credentials: true,
        });
        app.useGlobalFilters(new all_exceptions_filter_1.AllExceptionsFilter());
        app.useGlobalPipes(new common_1.ValidationPipe({
            whitelist: true,
            forbidNonWhitelisted: true,
            transform: true,
            disableErrorMessages: process.env.NODE_ENV === 'production',
            enableDebugMessages: process.env.NODE_ENV !== 'production',
        }));
        app.setGlobalPrefix('api/v1');
        if (process.env.NODE_ENV !== 'production') {
            const config = new swagger_1.DocumentBuilder()
                .setTitle('乖宝宝儿童影楼管理系统 API')
                .setDescription('婴儿摄影工作室管理系统的后端 API 文档')
                .setVersion('1.0.0')
                .addTag('users', '用户管理')
                .addTag('packages', '套餐管理')
                .addTag('orders', '订单管理')
                .addTag('payments', '支付管理')
                .addTag('time-slots', '时间槽管理')
                .addBearerAuth()
                .build();
            const document = swagger_1.SwaggerModule.createDocument(app, config);
            swagger_1.SwaggerModule.setup('api/docs', app, document, {
                swaggerOptions: {
                    persistAuthorization: true,
                },
            });
        }
        const rolesService = app.get(roles_service_1.RolesService);
        await rolesService.seedDefaultRoles();
        const port = process.env.PORT || 3000;
        const listenHost = '0.0.0.0';
        await app.listen(port, listenHost);
        logger.log(`服务启动成功`);
        logger.log(`服务地址: http://localhost:${port}`);
        logger.log(`监听地址: ${listenHost} (Docker + nginx 反向代理)`);
        if (process.env.NODE_ENV !== 'production') {
            logger.log(`API 文档: http://localhost:${port}/api/docs`);
        }
        logger.log(`健康检查: http://localhost:${port}/api/v1/health`);
    }
    catch (error) {
        logger.error('启动应用失败:', error);
        process.exit(1);
    }
}
void bootstrap();
//# sourceMappingURL=main.js.map