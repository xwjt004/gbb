"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const serve_static_1 = require("@nestjs/serve-static");
const schedule_1 = require("@nestjs/schedule");
const throttler_1 = require("@nestjs/throttler");
const core_1 = require("@nestjs/core");
const path_1 = require("path");
const config_1 = require("@nestjs/config");
const app_controller_1 = require("./app.controller");
const app_service_1 = require("./app.service");
const users_module_1 = require("./modules/users/users.module");
const packages_module_1 = require("./modules/packages/packages.module");
const package_categories_module_1 = require("./modules/package-categories/package-categories.module");
const orders_module_1 = require("./modules/orders/orders.module");
const payments_module_1 = require("./modules/payments/payments.module");
const time_slots_module_1 = require("./modules/time-slots/time-slots.module");
const search_module_1 = require("./modules/search/search.module");
const status_monitoring_module_1 = require("./modules/status-monitoring/status-monitoring.module");
const statistics_analysis_module_1 = require("./modules/statistics-analysis/statistics-analysis.module");
const analytics_module_1 = require("./modules/analytics/analytics.module");
const prisma_module_1 = require("./shared/prisma/prisma.module");
const files_module_1 = require("./modules/files/files.module");
const system_backup_module_1 = require("./modules/system-backup/system-backup.module");
const order_timeout_scheduler_1 = require("./shared/schedulers/order-timeout.scheduler");
const crm_scheduler_1 = require("./shared/schedulers/crm.scheduler");
const auto_status_transition_service_1 = require("./shared/services/auto-status-transition.service");
const status_change_log_service_1 = require("./shared/services/status-change-log.service");
const appointment_reminder_scheduler_1 = require("./shared/schedulers/appointment-reminder.scheduler");
const photo_pick_reminder_scheduler_1 = require("./shared/schedulers/photo-pick-reminder.scheduler");
const daily_report_scheduler_1 = require("./shared/schedulers/daily-report.scheduler");
const export_module_1 = require("./modules/export/export.module");
const stock_outbound_module_1 = require("./modules/stock-outbound/stock-outbound.module");
const stock_check_module_1 = require("./modules/stock-check/stock-check.module");
const stock_alert_module_1 = require("./modules/stock-alert/stock-alert.module");
const inventory_intelligence_module_1 = require("./modules/inventory-intelligence/inventory-intelligence.module");
const stock_transfer_module_1 = require("./modules/stock-transfer/stock-transfer.module");
const stock_transaction_module_1 = require("./modules/stock-transaction/stock-transaction.module");
const supplier_module_1 = require("./supplier/supplier.module");
const product_categories_module_1 = require("./modules/product-categories/product-categories.module");
const products_module_1 = require("./modules/products/products.module");
const service_items_module_1 = require("./modules/service-items/service-items.module");
const discount_rules_module_1 = require("./modules/discount-rules/discount-rules.module");
const diy_packages_module_1 = require("./modules/diy-packages/diy-packages.module");
const shop_info_module_1 = require("./modules/shop-info/shop-info.module");
const print_settings_module_1 = require("./modules/print-settings/print-settings.module");
const wx_auth_module_1 = require("./modules/wx-auth/wx-auth.module");
const wx_mall_module_1 = require("./modules/wx-mall/wx-mall.module");
const wx_cart_module_1 = require("./modules/wx-cart/wx-cart.module");
const wx_order_module_1 = require("./modules/wx-order/wx-order.module");
const wx_coupon_module_1 = require("./modules/wx-coupon/wx-coupon.module");
const wx_address_module_1 = require("./modules/wx-address/wx-address.module");
const notifications_module_1 = require("./modules/notifications/notifications.module");
const auth_module_1 = require("./modules/auth/auth.module");
const operation_logs_module_1 = require("./modules/operation-logs/operation-logs.module");
const roles_module_1 = require("./modules/roles/roles.module");
const crm_module_1 = require("./modules/crm/crm.module");
const seasonal_prices_module_1 = require("./modules/seasonal-prices/seasonal-prices.module");
const coupons_module_1 = require("./modules/coupons/coupons.module");
const automation_rules_module_1 = require("./modules/automation-rules/automation-rules.module");
const smart_marketing_module_1 = require("./modules/smart-marketing/smart-marketing.module");
const wx_user_module_1 = require("./modules/wx-user/wx-user.module");
const wx_favorite_module_1 = require("./modules/wx-favorite/wx-favorite.module");
const core_2 = require("@nestjs/core");
const operation_log_interceptor_1 = require("./shared/interceptors/operation-log.interceptor");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                isGlobal: true,
                envFilePath: ['.env.local', '.env'],
                cache: true,
            }),
            schedule_1.ScheduleModule.forRoot(),
            throttler_1.ThrottlerModule.forRoot([
                {
                    name: 'short',
                    ttl: 1000,
                    limit: 10,
                },
                {
                    name: 'medium',
                    ttl: 10000,
                    limit: 50,
                },
                {
                    name: 'long',
                    ttl: 60000,
                    limit: 200,
                },
            ]),
            prisma_module_1.PrismaModule,
            serve_static_1.ServeStaticModule.forRoot({
                rootPath: (0, path_1.join)(process.cwd(), process.env.UPLOAD_PATH || './uploads'),
                serveRoot: '/uploads',
            }),
            users_module_1.UsersModule,
            packages_module_1.PackagesModule,
            package_categories_module_1.PackageCategoriesModule,
            orders_module_1.OrdersModule,
            payments_module_1.PaymentsModule,
            time_slots_module_1.TimeSlotsModule,
            search_module_1.SearchModule,
            status_monitoring_module_1.StatusMonitoringModule,
            statistics_analysis_module_1.StatisticsAnalysisModule,
            analytics_module_1.AnalyticsModule,
            files_module_1.FilesModule,
            system_backup_module_1.SystemBackupModule,
            export_module_1.ExportModule,
            stock_outbound_module_1.StockOutboundModule,
            stock_check_module_1.StockCheckModule,
            stock_alert_module_1.StockAlertModule,
            stock_transfer_module_1.StockTransferModule,
            stock_transaction_module_1.StockTransactionModule,
            inventory_intelligence_module_1.InventoryIntelligenceModule,
            supplier_module_1.SupplierModule,
            product_categories_module_1.ProductCategoriesModule,
            products_module_1.ProductsModule,
            service_items_module_1.ServiceItemsModule,
            discount_rules_module_1.DiscountRulesModule,
            diy_packages_module_1.DiyPackagesModule,
            shop_info_module_1.ShopInfoModule,
            print_settings_module_1.PrintSettingsModule,
            auth_module_1.AuthModule,
            wx_auth_module_1.WxAuthModule,
            wx_mall_module_1.WxMallModule,
            wx_cart_module_1.WxCartModule,
            wx_order_module_1.WxOrderModule,
            wx_coupon_module_1.WxCouponModule,
            wx_address_module_1.WxAddressModule,
            notifications_module_1.NotificationsModule,
            operation_logs_module_1.OperationLogsModule,
            roles_module_1.RolesModule,
            crm_module_1.CrmModule,
            seasonal_prices_module_1.SeasonalPricesModule,
            coupons_module_1.CouponsModule,
            automation_rules_module_1.AutomationRulesModule,
            smart_marketing_module_1.SmartMarketingModule,
            wx_user_module_1.WxUserModule,
            wx_favorite_module_1.WxFavoriteModule,
        ],
        controllers: [app_controller_1.AppController],
        providers: [
            {
                provide: core_1.APP_GUARD,
                useClass: throttler_1.ThrottlerGuard,
            },
            {
                provide: core_2.APP_INTERCEPTOR,
                useClass: operation_log_interceptor_1.OperationLogInterceptor,
            },
            app_service_1.AppService,
            order_timeout_scheduler_1.OrderTimeoutScheduler,
            crm_scheduler_1.CrmScheduler,
            auto_status_transition_service_1.AutoStatusTransitionService,
            status_change_log_service_1.StatusChangeLogService,
            appointment_reminder_scheduler_1.AppointmentReminderScheduler,
            photo_pick_reminder_scheduler_1.PhotoPickReminderScheduler,
            daily_report_scheduler_1.DailyReportScheduler,
        ],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map