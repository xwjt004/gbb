"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var SeasonalPricesService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeasonalPricesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let SeasonalPricesService = SeasonalPricesService_1 = class SeasonalPricesService {
    prisma;
    logger = new common_1.Logger(SeasonalPricesService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(dto) {
        const data = await this.prisma.seasonalPrice.create({
            data: {
                packageId: dto.packageId,
                startDate: new Date(dto.startDate),
                endDate: new Date(dto.endDate),
                price: dto.price,
                label: dto.label,
            },
        });
        return { code: 200, message: '创建成功', data };
    }
    async findAll(query) {
        const where = {};
        if (query.packageId)
            where.packageId = query.packageId;
        const list = await this.prisma.seasonalPrice.findMany({
            where,
            orderBy: [{ packageId: 'asc' }, { startDate: 'asc' }],
        });
        return { code: 200, message: '查询成功', data: list };
    }
    async findOne(id) {
        const data = await this.prisma.seasonalPrice.findUnique({ where: { id } });
        if (!data)
            throw new common_1.NotFoundException('季节性价格不存在');
        return { code: 200, message: '查询成功', data };
    }
    async update(id, dto) {
        const existing = await this.prisma.seasonalPrice.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException('季节性价格不存在');
        const updateData = {};
        if (dto.packageId !== undefined)
            updateData.packageId = dto.packageId;
        if (dto.startDate !== undefined)
            updateData.startDate = new Date(dto.startDate);
        if (dto.endDate !== undefined)
            updateData.endDate = new Date(dto.endDate);
        if (dto.price !== undefined)
            updateData.price = dto.price;
        if (dto.label !== undefined)
            updateData.label = dto.label;
        const data = await this.prisma.seasonalPrice.update({ where: { id }, data: updateData });
        return { code: 200, message: '更新成功', data };
    }
    async remove(id) {
        const existing = await this.prisma.seasonalPrice.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException('季节性价格不存在');
        await this.prisma.seasonalPrice.delete({ where: { id } });
        return { code: 200, message: '删除成功' };
    }
};
exports.SeasonalPricesService = SeasonalPricesService;
exports.SeasonalPricesService = SeasonalPricesService = SeasonalPricesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], SeasonalPricesService);
//# sourceMappingURL=seasonal-prices.service.js.map