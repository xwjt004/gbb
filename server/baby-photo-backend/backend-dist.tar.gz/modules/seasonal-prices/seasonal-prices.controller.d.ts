import { SeasonalPricesService } from './seasonal-prices.service';
import { CreateSeasonalPriceDto } from './dto/create-seasonal-price.dto';
import { UpdateSeasonalPriceDto } from './dto/update-seasonal-price.dto';
import { QuerySeasonalPriceDto } from './dto/query-seasonal-price.dto';
export declare class SeasonalPricesController {
    private readonly service;
    constructor(service: SeasonalPricesService);
    create(dto: CreateSeasonalPriceDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            packageId: number;
            price: import("@prisma/client/runtime/library").Decimal;
            startDate: Date;
            endDate: Date;
            label: string | null;
        };
    }>;
    findAll(query: QuerySeasonalPriceDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            packageId: number;
            price: import("@prisma/client/runtime/library").Decimal;
            startDate: Date;
            endDate: Date;
            label: string | null;
        }[];
    }>;
    findOne(id: number): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            packageId: number;
            price: import("@prisma/client/runtime/library").Decimal;
            startDate: Date;
            endDate: Date;
            label: string | null;
        };
    }>;
    update(id: number, dto: UpdateSeasonalPriceDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            packageId: number;
            price: import("@prisma/client/runtime/library").Decimal;
            startDate: Date;
            endDate: Date;
            label: string | null;
        };
    }>;
    remove(id: number): Promise<{
        code: number;
        message: string;
    }>;
}
