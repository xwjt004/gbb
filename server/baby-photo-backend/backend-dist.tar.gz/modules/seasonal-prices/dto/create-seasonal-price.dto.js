"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateSeasonalPriceDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class CreateSeasonalPriceDto {
    packageId;
    startDate;
    endDate;
    price;
    label;
}
exports.CreateSeasonalPriceDto = CreateSeasonalPriceDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套餐ID' }),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CreateSeasonalPriceDto.prototype, "packageId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '开始日期', example: '2026-01-01' }),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateSeasonalPriceDto.prototype, "startDate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '结束日期', example: '2026-02-28' }),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateSeasonalPriceDto.prototype, "endDate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '价格', example: 299.00 }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateSeasonalPriceDto.prototype, "price", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '标签（如旺季、淡季）', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateSeasonalPriceDto.prototype, "label", void 0);
//# sourceMappingURL=create-seasonal-price.dto.js.map