export declare class QuerySeasonalPriceDto {
    packageId?: number;
}
