import { CreateSeasonalPriceDto } from './create-seasonal-price.dto';
declare const UpdateSeasonalPriceDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateSeasonalPriceDto>>;
export declare class UpdateSeasonalPriceDto extends UpdateSeasonalPriceDto_base {
}
export {};
