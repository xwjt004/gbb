export declare class CreateSeasonalPriceDto {
    packageId: number;
    startDate: string;
    endDate: string;
    price: number;
    label?: string;
}
