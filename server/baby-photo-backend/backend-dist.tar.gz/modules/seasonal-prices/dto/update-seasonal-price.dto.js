"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateSeasonalPriceDto = void 0;
const mapped_types_1 = require("@nestjs/mapped-types");
const create_seasonal_price_dto_1 = require("./create-seasonal-price.dto");
class UpdateSeasonalPriceDto extends (0, mapped_types_1.PartialType)(create_seasonal_price_dto_1.CreateSeasonalPriceDto) {
}
exports.UpdateSeasonalPriceDto = UpdateSeasonalPriceDto;
//# sourceMappingURL=update-seasonal-price.dto.js.map