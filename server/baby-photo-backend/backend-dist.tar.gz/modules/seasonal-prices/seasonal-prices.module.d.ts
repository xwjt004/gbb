export declare class SeasonalPricesModule {
}
