"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ShopInfoController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShopInfoController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const shop_info_service_1 = require("./shop-info.service");
const update_shop_info_dto_1 = require("./dto/update-shop-info.dto");
const multer_1 = require("multer");
const path_1 = require("path");
const fs_1 = require("fs");
let ShopInfoController = ShopInfoController_1 = class ShopInfoController {
    shopInfoService;
    logger = new common_1.Logger(ShopInfoController_1.name);
    constructor(shopInfoService) {
        this.shopInfoService = shopInfoService;
    }
    async getShopInfo() {
        return this.shopInfoService.getShopInfo();
    }
    async updateShopInfo(updateDto) {
        return this.shopInfoService.updateShopInfo(updateDto);
    }
    async uploadImage(fieldName, file) {
        if (!file) {
            throw new common_1.BadRequestException('请选择要上传的文件');
        }
        if (!['shopPhoto', 'locationMap', 'banner'].includes(fieldName)) {
            throw new common_1.BadRequestException('无效的字段名称');
        }
        const fileUrl = `/uploads/shop-info/${file.filename}`;
        this.logger.log(`上传店铺图片: ${fieldName} = ${fileUrl}`);
        if (fieldName === 'banner') {
            return { code: 200, message: '上传成功', data: { url: fileUrl } };
        }
        return this.shopInfoService.uploadShopImage(fieldName, fileUrl);
    }
};
exports.ShopInfoController = ShopInfoController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取店铺信息' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ShopInfoController.prototype, "getShopInfo", null);
__decorate([
    (0, common_1.Put)(),
    (0, swagger_1.ApiOperation)({ summary: '更新店铺信息' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [update_shop_info_dto_1.UpdateShopInfoDto]),
    __metadata("design:returntype", Promise)
], ShopInfoController.prototype, "updateShopInfo", null);
__decorate([
    (0, common_1.Post)('upload/:fieldName'),
    (0, swagger_1.ApiOperation)({ summary: '上传店铺图片' }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({
        description: '图片文件',
        required: true,
        schema: {
            type: 'object',
            properties: {
                file: {
                    type: 'string',
                    format: 'binary',
                },
            },
        },
    }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: (0, multer_1.diskStorage)({
            destination: (req, file, cb) => {
                const uploadPath = (0, path_1.join)(process.cwd(), 'uploads', 'shop-info');
                if (!(0, fs_1.existsSync)(uploadPath)) {
                    (0, fs_1.mkdirSync)(uploadPath, { recursive: true });
                }
                cb(null, uploadPath);
            },
            filename: (req, file, cb) => {
                const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
                const ext = (0, path_1.extname)(file.originalname);
                cb(null, `shop-${uniqueSuffix}${ext}`);
            },
        }),
        fileFilter: (req, file, cb) => {
            if (file.mimetype.match(/\/(jpg|jpeg|png|gif)$/)) {
                cb(null, true);
            }
            else {
                cb(new common_1.BadRequestException('只支持上传图片文件(jpg, jpeg, png, gif)'), false);
            }
        },
        limits: {
            fileSize: 5 * 1024 * 1024,
        },
    })),
    __param(0, (0, common_1.Param)('fieldName')),
    __param(1, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ShopInfoController.prototype, "uploadImage", null);
exports.ShopInfoController = ShopInfoController = ShopInfoController_1 = __decorate([
    (0, swagger_1.ApiTags)('店铺信息'),
    (0, common_1.Controller)('shop-info'),
    __metadata("design:paramtypes", [shop_info_service_1.ShopInfoService])
], ShopInfoController);
//# sourceMappingURL=shop-info.controller.js.map