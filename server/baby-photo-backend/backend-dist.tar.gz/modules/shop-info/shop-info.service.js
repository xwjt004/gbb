"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ShopInfoService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShopInfoService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let ShopInfoService = ShopInfoService_1 = class ShopInfoService {
    prisma;
    logger = new common_1.Logger(ShopInfoService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getShopInfo() {
        try {
            let shopInfo = await this.prisma.shopInfo.findFirst();
            if (!shopInfo) {
                this.logger.log('店铺信息不存在,创建默认记录');
                shopInfo = await this.prisma.shopInfo.create({
                    data: {
                        shopName: '未设置店铺名称',
                        address: '未设置地址',
                        phone: '13800138000',
                    },
                });
            }
            return {
                code: 200,
                message: '查询成功',
                data: shopInfo,
            };
        }
        catch (error) {
            this.logger.error(`获取店铺信息失败: ${error.message}`);
            throw error;
        }
    }
    async updateShopInfo(updateDto) {
        try {
            const existing = await this.prisma.shopInfo.findFirst();
            let shopInfo;
            if (existing) {
                shopInfo = await this.prisma.shopInfo.update({
                    where: { id: existing.id },
                    data: updateDto,
                });
                this.logger.log(`更新店铺信息: ID=${existing.id}`);
            }
            else {
                shopInfo = await this.prisma.shopInfo.create({
                    data: updateDto,
                });
                this.logger.log('创建店铺信息');
            }
            return {
                code: 200,
                message: '更新成功',
                data: shopInfo,
            };
        }
        catch (error) {
            this.logger.error(`更新店铺信息失败: ${error.message}`);
            throw error;
        }
    }
    async uploadShopImage(fieldName, fileUrl) {
        try {
            const existing = await this.prisma.shopInfo.findFirst();
            if (!existing) {
                throw new common_1.NotFoundException('请先设置店铺基本信息');
            }
            const updateData = {};
            updateData[fieldName] = fileUrl;
            const shopInfo = await this.prisma.shopInfo.update({
                where: { id: existing.id },
                data: updateData,
            });
            this.logger.log(`上传店铺图片成功: ${fieldName} = ${fileUrl}`);
            return {
                code: 200,
                message: '上传成功',
                data: {
                    [fieldName]: fileUrl,
                },
            };
        }
        catch (error) {
            this.logger.error(`上传店铺图片失败: ${error.message}`);
            throw error;
        }
    }
};
exports.ShopInfoService = ShopInfoService;
exports.ShopInfoService = ShopInfoService = ShopInfoService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ShopInfoService);
//# sourceMappingURL=shop-info.service.js.map