export declare class ShopInfoModule {
}
