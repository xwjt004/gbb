import { PrismaService } from '../../shared/prisma/prisma.service';
import { UpdateShopInfoDto } from './dto/update-shop-info.dto';
export declare class ShopInfoService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getShopInfo(): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            phone: string;
            description: string | null;
            address: string;
            shopName: string;
            telephone: string | null;
            shopPhoto: string | null;
            locationMap: string | null;
            businessScope: string | null;
            wechatId: string | null;
            douyinId: string | null;
            kuaishouId: string | null;
            xiaohongshuId: string | null;
            businessLicense: string | null;
            businessHours: string | null;
            banners: import("@prisma/client/runtime/library").JsonValue | null;
            bannerInterval: number | null;
        };
    }>;
    updateShopInfo(updateDto: UpdateShopInfoDto): Promise<{
        code: number;
        message: string;
        data: any;
    }>;
    uploadShopImage(fieldName: 'shopPhoto' | 'locationMap', fileUrl: string): Promise<{
        code: number;
        message: string;
        data: {
            [fieldName]: string;
        };
    }>;
}
