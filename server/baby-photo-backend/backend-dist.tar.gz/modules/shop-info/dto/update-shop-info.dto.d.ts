export declare class UpdateShopInfoDto {
    shopName: string;
    address: string;
    phone: string;
    telephone?: string;
    shopPhoto?: string;
    locationMap?: string;
    businessScope?: string;
    wechatId?: string;
    douyinId?: string;
    kuaishouId?: string;
    xiaohongshuId?: string;
    businessLicense?: string;
    businessHours?: string;
    description?: string;
    banners?: any;
    bannerInterval?: number;
}
