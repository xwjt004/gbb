"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateShopInfoDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
class UpdateShopInfoDto {
    shopName;
    address;
    phone;
    telephone;
    shopPhoto;
    locationMap;
    businessScope;
    wechatId;
    douyinId;
    kuaishouId;
    xiaohongshuId;
    businessLicense;
    businessHours;
    description;
    banners;
    bannerInterval;
}
exports.UpdateShopInfoDto = UpdateShopInfoDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '店铺名称', example: '美好时光摄影店' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: '店铺名称不能为空' }),
    (0, class_validator_1.MaxLength)(200, { message: '店铺名称不能超过200个字符' }),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "shopName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '店铺地址', example: '北京市朝阳区XX路XX号' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: '店铺地址不能为空' }),
    (0, class_validator_1.MaxLength)(500, { message: '店铺地址不能超过500个字符' }),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "address", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '手机号码', example: '13800138000' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: '手机号码不能为空' }),
    (0, class_validator_1.Matches)(/^1[3-9]\d{9}$/, { message: '手机号码格式不正确' }),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "phone", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '固定电话', example: '010-12345678' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^\d{3,4}-?\d{7,8}$/, { message: '固定电话格式不正确' }),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "telephone", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '店铺照片URL' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "shopPhoto", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '店铺位置图URL' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "locationMap", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '店铺经营项目' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "businessScope", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '微信号', example: 'wechat_123' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100, { message: '微信号不能超过100个字符' }),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "wechatId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '抖音号', example: 'douyin_123' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100, { message: '抖音号不能超过100个字符' }),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "douyinId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '快手号', example: 'kuaishou_123' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100, { message: '快手号不能超过100个字符' }),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "kuaishouId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '小红书号', example: 'xiaohongshu_123' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100, { message: '小红书号不能超过100个字符' }),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "xiaohongshuId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '营业执照号' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "businessLicense", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '营业时间', example: '周一至周日 9:00-18:00' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "businessHours", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '店铺简介' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateShopInfoDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '轮播图列表（最多5张）', type: 'array', example: [{ image: '/uploads/banner1.jpg', title: '标题', link: '/pages/packages/list' }] }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], UpdateShopInfoDto.prototype, "banners", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '轮播播放间隔（毫秒）', example: 4000 }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], UpdateShopInfoDto.prototype, "bannerInterval", void 0);
//# sourceMappingURL=update-shop-info.dto.js.map