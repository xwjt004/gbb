import { ShopInfoService } from './shop-info.service';
import { UpdateShopInfoDto } from './dto/update-shop-info.dto';
export declare class ShopInfoController {
    private readonly shopInfoService;
    private readonly logger;
    constructor(shopInfoService: ShopInfoService);
    getShopInfo(): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            phone: string;
            description: string | null;
            address: string;
            shopName: string;
            telephone: string | null;
            shopPhoto: string | null;
            locationMap: string | null;
            businessScope: string | null;
            wechatId: string | null;
            douyinId: string | null;
            kuaishouId: string | null;
            xiaohongshuId: string | null;
            businessLicense: string | null;
            businessHours: string | null;
            banners: import("@prisma/client/runtime/library").JsonValue | null;
            bannerInterval: number | null;
        };
    }>;
    updateShopInfo(updateDto: UpdateShopInfoDto): Promise<{
        code: number;
        message: string;
        data: any;
    }>;
    uploadImage(fieldName: string, file: Express.Multer.File): Promise<{
        code: number;
        message: string;
        data: {
            [fieldName]: string;
        };
    }>;
}
