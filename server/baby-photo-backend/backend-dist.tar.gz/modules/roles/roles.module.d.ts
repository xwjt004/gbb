export declare class RolesModule {
}
