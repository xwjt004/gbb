import { RolesService } from './roles.service';
import { CreateRoleDto, UpdateRoleDto } from './dto';
export declare class RolesController {
    private readonly service;
    private readonly logger;
    constructor(service: RolesService);
    create(dto: CreateRoleDto): Promise<({
        _count: {
            users: number;
        };
        permissions: {
            permission: string;
        }[];
    } & {
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        status: string;
        description: string | null;
        isSystem: boolean;
    }) | null>;
    findAll(): Promise<({
        _count: {
            users: number;
        };
    } & {
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        status: string;
        description: string | null;
        isSystem: boolean;
    })[]>;
    getPermissionTree(): Promise<{
        key: string;
        label: string;
        children: {
            key: string;
            label: string;
        }[];
    }[]>;
    findOne(id: number): Promise<({
        _count: {
            users: number;
        };
        permissions: {
            permission: string;
        }[];
    } & {
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        status: string;
        description: string | null;
        isSystem: boolean;
    }) | null>;
    update(id: number, dto: UpdateRoleDto): Promise<{
        _count: {
            users: number;
        };
        permissions: {
            permission: string;
        }[];
    } & {
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        status: string;
        description: string | null;
        isSystem: boolean;
    }>;
    remove(id: number): Promise<void>;
}
