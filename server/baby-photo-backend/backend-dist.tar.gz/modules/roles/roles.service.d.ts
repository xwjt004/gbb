import { PrismaService } from '../../shared/prisma/prisma.service';
export declare class RolesService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    create(dto: {
        name: string;
        description?: string;
        permissions?: string[];
    }): Promise<({
        _count: {
            users: number;
        };
        permissions: {
            permission: string;
        }[];
    } & {
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        status: string;
        description: string | null;
        isSystem: boolean;
    }) | null>;
    findAll(): Promise<({
        _count: {
            users: number;
        };
    } & {
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        status: string;
        description: string | null;
        isSystem: boolean;
    })[]>;
    findOne(id: number): Promise<({
        _count: {
            users: number;
        };
        permissions: {
            permission: string;
        }[];
    } & {
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        status: string;
        description: string | null;
        isSystem: boolean;
    }) | null>;
    update(id: number, dto: {
        name?: string;
        description?: string;
        status?: string;
        permissions?: string[];
    }): Promise<{
        _count: {
            users: number;
        };
        permissions: {
            permission: string;
        }[];
    } & {
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        status: string;
        description: string | null;
        isSystem: boolean;
    }>;
    remove(id: number): Promise<void>;
    getUserPermissions(userId: number): Promise<string[]>;
    seedDefaultRoles(): Promise<void>;
    getPermissionTree(): Promise<{
        key: string;
        label: string;
        children: {
            key: string;
            label: string;
        }[];
    }[]>;
}
