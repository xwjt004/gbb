"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var UsersService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const cache_service_1 = require("../../shared/cache/cache.service");
const jwt_1 = require("@nestjs/jwt");
const axios_1 = __importDefault(require("axios"));
const crypto = __importStar(require("crypto"));
let UsersService = UsersService_1 = class UsersService {
    prisma;
    cacheService;
    jwtService;
    logger = new common_1.Logger(UsersService_1.name);
    constructor(prisma, cacheService, jwtService) {
        this.prisma = prisma;
        this.cacheService = cacheService;
        this.jwtService = jwtService;
    }
    async wxLogin(wxLoginDto) {
        const { code, userInfo } = wxLoginDto;
        try {
            const openid = await this.getOpenidByCode(code);
            let user = await this.prisma.user.findUnique({
                where: { openid },
            });
            if (!user) {
                user = await this.prisma.user.create({
                    data: {
                        openid,
                        nickname: userInfo?.nickName || '微信用户',
                        avatar: userInfo?.avatarUrl || '',
                        phone: '',
                    },
                });
                this.logger.log(`创建新用户: ${openid}`);
            }
            else {
                if (userInfo) {
                    user = await this.prisma.user.update({
                        where: { openid },
                        data: {
                            nickname: userInfo.nickName || user.nickname,
                            avatar: userInfo.avatarUrl || user.avatar,
                        },
                    });
                }
                this.logger.log(`用户登录: ${openid}`);
            }
            const token = this.generateToken(user.openid);
            const cacheKey = this.cacheService.getUserCacheKey(user.openid);
            this.cacheService.set(cacheKey, user, 3600);
            return {
                code: 200,
                message: '登录成功',
                data: {
                    token,
                    user: {
                        openid: user.openid,
                        nickname: user.nickname,
                        avatar: user.avatar,
                        phone: user.phone,
                    },
                },
            };
        }
        catch (error) {
            this.logger.error(`微信登录失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('登录失败，请稍后重试');
        }
    }
    async create(createUserDto) {
        try {
            if (createUserDto.phone) {
                const existingUser = await this.prisma.user.findFirst({
                    where: { phone: createUserDto.phone },
                });
                if (existingUser) {
                    throw new common_1.ConflictException('手机号已被注册');
                }
            }
            let openid = createUserDto.openid;
            if (!openid) {
                openid = `admin-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
            }
            else {
                const existingUser = await this.prisma.user.findUnique({
                    where: { openid },
                });
                if (existingUser) {
                    throw new common_1.ConflictException('用户已存在');
                }
            }
            const user = await this.prisma.user.create({
                data: {
                    openid,
                    nickname: createUserDto.nickname,
                    avatar: createUserDto.avatar || '',
                    phone: createUserDto.phone || '',
                    status: createUserDto.status || 'ACTIVE',
                },
            });
            this.logger.log(`用户创建成功: ${user.openid}`);
            return {
                code: 200,
                message: '用户创建成功',
                data: user,
            };
        }
        catch (error) {
            if (error instanceof common_1.ConflictException) {
                throw error;
            }
            this.logger.error(`创建用户失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('创建用户失败');
        }
    }
    async findAll(searchDto) {
        const { page = 1, limit = 20, phone, nickname, wechatId, fuzzy, status, isVip, startDate, endDate, sort = 'created_at_desc', } = searchDto;
        try {
            const where = {};
            if (phone) {
                where.phone = phone;
            }
            if (nickname) {
                if (fuzzy === 'true') {
                    where.OR = [
                        {
                            nickname: {
                                contains: nickname,
                                mode: 'insensitive',
                            },
                        },
                        {
                            phone: {
                                contains: nickname,
                            },
                        },
                    ];
                }
                else {
                    where.nickname = nickname;
                }
            }
            if (wechatId) {
                if (fuzzy === 'true') {
                    if (where.OR) {
                        where.OR.push({
                            wechatId: {
                                contains: wechatId,
                                mode: 'insensitive',
                            },
                        });
                    }
                    else {
                        where.OR = [
                            {
                                wechatId: {
                                    contains: wechatId,
                                    mode: 'insensitive',
                                },
                            },
                        ];
                    }
                }
                else {
                    where.wechatId = wechatId;
                }
            }
            if (status) {
                const statusMapping = {
                    'active': 'ACTIVE',
                    'inactive': 'INACTIVE',
                    'pending': 'PENDING',
                    'deleted': 'DELETED'
                };
                const dbStatus = statusMapping[status.toLowerCase()] || status.toUpperCase();
                where.status = dbStatus;
            }
            if (startDate || endDate) {
                where.createdAt = {};
                if (startDate) {
                    where.createdAt.gte = new Date(startDate);
                }
                if (endDate) {
                    where.createdAt.lte = new Date(endDate);
                }
            }
            const orderBy = this.buildOrderBy(sort);
            const allUsers = await this.prisma.user.findMany({
                where,
                orderBy,
                select: {
                    id: true,
                    openid: true,
                    nickname: true,
                    avatar: true,
                    phone: true,
                    status: true,
                    createdAt: true,
                    updatedAt: true,
                    _count: {
                        select: { orders: true },
                    },
                },
            });
            let filteredUsers = allUsers;
            if (isVip !== undefined) {
                filteredUsers = allUsers.filter(user => {
                    const orderCount = user._count?.orders || 0;
                    const userIsVip = orderCount >= 3;
                    return userIsVip === isVip;
                });
            }
            const total = filteredUsers.length;
            const paginatedUsers = filteredUsers.slice((page - 1) * limit, page * limit);
            return {
                code: 200,
                message: '查询成功',
                data: {
                    users: paginatedUsers,
                    pagination: {
                        total,
                        page,
                        limit,
                        totalPages: Math.ceil(total / limit),
                    },
                },
            };
        }
        catch (error) {
            this.logger.error(`查询用户列表失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async findPhotographers() {
        const users = await this.prisma.user.findMany({
            where: {
                status: 'ACTIVE',
                role: {
                    name: { contains: '摄影' },
                },
            },
            select: {
                id: true,
                nickname: true,
                avatar: true,
            },
        });
        return users;
    }
    async exportUsers(searchDto) {
        try {
            const { phone, nickname, wechatId, fuzzy, status, isVip, startDate, endDate } = searchDto;
            const where = {};
            if (phone) {
                where.phone = phone;
            }
            if (nickname) {
                if (fuzzy === 'true') {
                    where.OR = [
                        {
                            nickname: {
                                contains: nickname,
                                mode: 'insensitive',
                            },
                        },
                        {
                            phone: {
                                contains: nickname,
                            },
                        },
                    ];
                }
                else {
                    where.nickname = nickname;
                }
            }
            if (wechatId) {
                if (fuzzy === 'true') {
                    if (where.OR) {
                        where.OR.push({
                            wechatId: {
                                contains: wechatId,
                                mode: 'insensitive',
                            },
                        });
                    }
                    else {
                        where.OR = [
                            {
                                wechatId: {
                                    contains: wechatId,
                                    mode: 'insensitive',
                                },
                            },
                        ];
                    }
                }
                else {
                    where.wechatId = wechatId;
                }
            }
            if (status) {
                const statusMapping = {
                    'active': 'ACTIVE',
                    'inactive': 'INACTIVE',
                    'pending': 'PENDING',
                    'deleted': 'DELETED'
                };
                const dbStatus = statusMapping[status.toLowerCase()] || status.toUpperCase();
                where.status = dbStatus;
            }
            if (startDate || endDate) {
                where.createdAt = {};
                if (startDate) {
                    where.createdAt.gte = new Date(startDate);
                }
                if (endDate) {
                    where.createdAt.lte = new Date(endDate);
                }
            }
            const allUsers = await this.prisma.user.findMany({
                where,
                select: {
                    openid: true,
                    nickname: true,
                    avatar: true,
                    phone: true,
                    status: true,
                    createdAt: true,
                    updatedAt: true,
                    _count: {
                        select: { orders: true },
                    },
                },
                orderBy: { createdAt: 'desc' },
            });
            let filteredUsers = allUsers;
            if (isVip !== undefined) {
                filteredUsers = allUsers.filter(user => {
                    const orderCount = user._count?.orders || 0;
                    const userIsVip = orderCount >= 3;
                    return userIsVip === isVip;
                });
            }
            const exportData = filteredUsers.map(user => {
                const orderCount = user._count?.orders || 0;
                const isVipUser = orderCount >= 3;
                return {
                    用户ID: user.openid,
                    手机号码: user.phone || '未设置',
                    昵称: user.nickname || '未设置',
                    微信ID: '',
                    状态: user.status,
                    VIP状态: isVipUser ? '是' : '否',
                    VIP等级: isVipUser ? '金牌会员' : '',
                    订单数量: orderCount,
                    消费总额: 0,
                    注册时间: new Date(user.createdAt).toLocaleString('zh-CN'),
                    更新时间: new Date(user.updatedAt).toLocaleString('zh-CN'),
                    最后登录: '',
                };
            });
            return {
                success: true,
                message: '导出成功',
                data: exportData,
            };
        }
        catch (error) {
            this.logger.error(`导出用户数据失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('导出失败');
        }
    }
    async findByPhone(phone) {
        try {
            const cacheKey = this.cacheService.generateKey('user-phone', phone);
            return this.cacheService.getOrSet(cacheKey, async () => {
                const users = await this.prisma.user.findMany({
                    where: { phone },
                    include: {
                        _count: {
                            select: {
                                orders: true,
                            },
                        },
                    },
                });
                if (users.length === 0) {
                    throw new common_1.NotFoundException('未找到匹配的用户');
                }
                return {
                    code: 200,
                    message: '查询成功',
                    data: users,
                };
            }, 600);
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`通过手机号查找用户失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async findByNickname(nickname, fuzzy = false) {
        try {
            const cacheKey = this.cacheService.generateKey('user-nickname', nickname, fuzzy.toString());
            return this.cacheService.getOrSet(cacheKey, async () => {
                const where = fuzzy
                    ? {
                        nickname: {
                            contains: nickname,
                            mode: 'insensitive',
                        },
                    }
                    : { nickname };
                const users = await this.prisma.user.findMany({
                    where,
                    include: {
                        _count: {
                            select: {
                                orders: true,
                            },
                        },
                    },
                    orderBy: { createdAt: 'desc' },
                });
                if (users.length === 0) {
                    throw new common_1.NotFoundException('未找到匹配的用户');
                }
                return {
                    code: 200,
                    message: '查询成功',
                    data: users,
                };
            }, 600);
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`通过昵称查找用户失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async findOne(id) {
        try {
            const cacheKey = this.cacheService.getUserCacheKey(id);
            return this.cacheService.getOrSet(cacheKey, async () => {
                const user = await this.prisma.user.findUnique({
                    where: { id: parseInt(id, 10) },
                    include: {
                        orders: {
                            take: 5,
                            orderBy: { createdAt: 'desc' },
                            include: {
                                package: {
                                    select: {
                                        name: true,
                                        price: true,
                                    },
                                },
                            },
                        },
                        _count: {
                            select: {
                                orders: true,
                            },
                        },
                    },
                });
                if (!user) {
                    throw new common_1.NotFoundException('用户不存在');
                }
                return {
                    code: 200,
                    message: '查询成功',
                    data: user,
                };
            }, 1800);
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`获取用户详情失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async update(id, updateUserDto) {
        try {
            const userId = parseInt(id, 10);
            const existingUser = await this.prisma.user.findUnique({
                where: { id: userId },
            });
            if (!existingUser) {
                throw new common_1.NotFoundException('用户不存在');
            }
            if (updateUserDto.phone && updateUserDto.phone !== existingUser.phone) {
                const phoneExists = await this.prisma.user.findFirst({
                    where: {
                        phone: updateUserDto.phone,
                        id: { not: userId },
                    },
                });
                if (phoneExists) {
                    throw new common_1.ConflictException('手机号已被其他用户使用');
                }
            }
            const user = await this.prisma.user.update({
                where: { id: userId },
                data: updateUserDto,
            });
            const cacheKey = this.cacheService.getUserCacheKey(id);
            this.cacheService.del(cacheKey);
            this.logger.log(`用户更新成功: ${id}`);
            return {
                code: 200,
                message: '更新成功',
                data: user,
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException ||
                error instanceof common_1.ConflictException) {
                throw error;
            }
            this.logger.error(`更新用户失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('更新失败');
        }
    }
    async remove(id) {
        try {
            const userId = parseInt(id, 10);
            const user = await this.prisma.user.findUnique({
                where: { id: userId },
                include: {
                    _count: {
                        select: {
                            orders: true,
                            outboundsSubmitted: true,
                            outboundsApproved: true,
                            checksCreated: true,
                            checksApproved: true,
                            alertsHandled: true,
                            transactions: true,
                            transfersSubmitted: true,
                            transfersApproved: true,
                        },
                    },
                },
            });
            if (!user) {
                throw new common_1.NotFoundException('用户不存在');
            }
            if (user.status !== 'INACTIVE') {
                throw new common_1.BadRequestException('只能删除状态为"禁用"的用户，请先禁用该用户');
            }
            if (user._count?.orders > 0) {
                throw new common_1.BadRequestException('用户有相关订单，无法删除');
            }
            const relatedRecords = [
                { name: '出库记录(提交)', count: user._count?.outboundsSubmitted },
                { name: '出库记录(审批)', count: user._count?.outboundsApproved },
                { name: '盘点记录(创建)', count: user._count?.checksCreated },
                { name: '盘点记录(审批)', count: user._count?.checksApproved },
                { name: '库存预警处理', count: user._count?.alertsHandled },
                { name: '库存流水', count: user._count?.transactions },
                { name: '调拨记录(提交)', count: user._count?.transfersSubmitted },
                { name: '调拨记录(审批)', count: user._count?.transfersApproved },
            ];
            const hasRelatedRecords = relatedRecords.filter(r => r.count > 0);
            if (hasRelatedRecords.length > 0) {
                const details = hasRelatedRecords.map(r => `${r.name}(${r.count}条)`).join('、');
                throw new common_1.BadRequestException(`用户有相关业务记录，无法删除: ${details}`);
            }
            await this.prisma.user.delete({
                where: { id: userId },
            });
            const cacheKey = this.cacheService.getUserCacheKey(id);
            this.cacheService.del(cacheKey);
            this.logger.log(`用户删除成功: ${id}`);
            return {
                code: 200,
                message: '删除成功',
                data: user,
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException ||
                error instanceof common_1.BadRequestException) {
                throw error;
            }
            this.logger.error(`删除用户失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException(`删除失败: ${error.message}`);
        }
    }
    async toggleStatus(id) {
        try {
            const userId = parseInt(id, 10);
            const user = await this.prisma.user.findUnique({ where: { id: userId } });
            if (!user) {
                throw new common_1.NotFoundException('用户不存在');
            }
            const nextStatus = user.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
            const updated = await this.prisma.user.update({
                where: { id: userId },
                data: { status: nextStatus },
                select: { id: true, status: true },
            });
            const cacheKey = this.cacheService.getUserCacheKey(id);
            this.cacheService.del(cacheKey);
            return { code: 200, message: '状态更新成功', data: updated };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException)
                throw error;
            this.logger.error(`切换用户状态失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('状态更新失败');
        }
    }
    async getUserStatistics(id) {
        try {
            const userId = parseInt(id, 10);
            const cacheKey = this.cacheService.generateKey('user-stats', id);
            return this.cacheService.getOrSet(cacheKey, async () => {
                const user = await this.prisma.user.findUnique({
                    where: { id: userId },
                    include: {
                        orders: {
                            include: {
                                payments: {
                                    where: { status: 'FULLY_PAID' },
                                },
                            },
                        },
                    },
                });
                if (!user) {
                    throw new common_1.NotFoundException('用户不存在');
                }
                const totalOrders = user.orders.length;
                const totalSpent = user.orders.reduce((sum, order) => {
                    const paidAmount = order.payments.reduce((paySum, payment) => paySum + Number(payment.amount), 0);
                    return sum + paidAmount;
                }, 0);
                const completedOrders = user.orders.filter((order) => order.orderStatus === 'COMPLETED').length;
                const averageOrderValue = totalOrders > 0 ? totalSpent / totalOrders : 0;
                const statistics = {
                    totalOrders: totalOrders,
                    completedOrders: completedOrders,
                    totalSpent: totalSpent,
                    averageOrderValue: averageOrderValue,
                    firstOrderDate: totalOrders > 0
                        ? user.orders.sort((a, b) => new Date(a.createdAt).getTime() -
                            new Date(b.createdAt).getTime())[0].createdAt
                        : null,
                    lastOrderDate: totalOrders > 0
                        ? user.orders.sort((a, b) => new Date(b.createdAt).getTime() -
                            new Date(a.createdAt).getTime())[0].createdAt
                        : null,
                    customerLoyaltyLevel: this.calculateLoyaltyLevel(totalOrders, totalSpent),
                };
                return {
                    code: 200,
                    message: '查询成功',
                    data: statistics,
                };
            }, 1800);
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`获取用户统计信息失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async getUserOrders(id, pagination) {
        const { page, limit } = pagination;
        try {
            const numericId = parseInt(id, 10);
            const whereClause = isNaN(numericId)
                ? { user: { openid: id } }
                : { userId: numericId };
            const [orders, total] = await Promise.all([
                this.prisma.order.findMany({
                    where: whereClause,
                    include: {
                        package: true,
                        timeSlot: true,
                        payments: true,
                    },
                    orderBy: { createdAt: 'desc' },
                    skip: (page - 1) * limit,
                    take: limit,
                }),
                this.prisma.order.count({
                    where: whereClause,
                }),
            ]);
            return {
                code: 200,
                message: '查询成功',
                data: {
                    orders,
                    pagination: {
                        total,
                        page,
                        limit,
                        totalPages: Math.ceil(total / limit),
                    },
                },
            };
        }
        catch (error) {
            this.logger.error(`获取用户订单历史失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async getStatistics() {
        try {
            const [total, active, inactive, todayNew] = await Promise.all([
                this.prisma.user.count(),
                this.prisma.user.count({ where: { status: 'ACTIVE' } }),
                this.prisma.user.count({ where: { status: 'INACTIVE' } }),
                this.prisma.user.count({
                    where: {
                        createdAt: {
                            gte: new Date(new Date().setHours(0, 0, 0, 0)),
                        },
                    },
                }),
            ]);
            return {
                code: 200,
                message: '统计成功',
                data: {
                    totalUsers: total,
                    activeUsers: active,
                    inactiveUsers: inactive,
                    newUsersToday: todayNew,
                    vipUsers: 0,
                    growthRate: 0,
                },
            };
        }
        catch (error) {
            this.logger.error(`获取用户总体统计失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('统计失败');
        }
    }
    async adminLogin(adminLoginDto) {
        const { username, password } = adminLoginDto;
        const expectedUsername = process.env.ADMIN_USERNAME || 'admin';
        const expectedPasswordHash = process.env.ADMIN_PASSWORD_HASH;
        if (username !== expectedUsername) {
            throw new common_1.UnauthorizedException('用户名或密码错误');
        }
        let passwordValid = false;
        if (expectedPasswordHash) {
            const [salt, storedHash] = expectedPasswordHash.split(':');
            if (salt && storedHash) {
                const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
                passwordValid = hash === storedHash;
            }
        }
        else {
            const plainPassword = process.env.ADMIN_PASSWORD || 'admin123';
            passwordValid = password === plainPassword;
        }
        if (!passwordValid) {
            throw new common_1.UnauthorizedException('用户名或密码错误');
        }
        let adminUser = await this.prisma.user.findUnique({
            where: { openid: `admin-${username}` },
        });
        if (!adminUser) {
            adminUser = await this.prisma.user.create({
                data: {
                    openid: `admin-${username}`,
                    nickname: '系统管理员',
                    phone: '18888888888',
                },
            });
        }
        const token = this.jwtService.sign({ sub: adminUser.id, openid: adminUser.openid, isAdmin: true }, { expiresIn: '24h' });
        return {
            success: true,
            message: '登录成功',
            data: {
                id: adminUser.id,
                openid: adminUser.openid,
                nickname: adminUser.nickname,
                phone: adminUser.phone,
                isAdmin: true,
                token,
            },
        };
    }
    async getOpenidByCode(code) {
        const appId = process.env.WX_APP_ID;
        const appSecret = process.env.WX_APP_SECRET;
        if (!appId || !appSecret) {
            throw new common_1.BadRequestException('微信配置未完成');
        }
        try {
            const response = await axios_1.default.get(`https://api.weixin.qq.com/sns/jscode2session`, {
                params: {
                    appid: appId,
                    secret: appSecret,
                    js_code: code,
                    grant_type: 'authorization_code',
                },
            });
            if (response.data.errcode) {
                throw new Error(response.data.errmsg);
            }
            return response.data.openid;
        }
        catch (error) {
            this.logger.error(`获取openid失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('微信登录失败');
        }
    }
    generateToken(openid) {
        return Buffer.from(`${openid}:${Date.now()}`).toString('base64');
    }
    buildOrderBy(sort) {
        switch (sort) {
            case 'created_at_asc':
                return { createdAt: 'asc' };
            case 'created_at_desc':
                return { createdAt: 'desc' };
            case 'nickname_asc':
                return { nickname: 'asc' };
            case 'nickname_desc':
                return { nickname: 'desc' };
            default:
                return { createdAt: 'desc' };
        }
    }
    calculateLoyaltyLevel(totalOrders, totalSpent) {
        if (totalOrders >= 10 && totalSpent >= 5000) {
            return 'VIP';
        }
        else if (totalOrders >= 5 && totalSpent >= 2000) {
            return '金牌客户';
        }
        else if (totalOrders >= 2 && totalSpent >= 500) {
            return '银牌客户';
        }
        else if (totalOrders >= 1) {
            return '普通客户';
        }
        else {
            return '新客户';
        }
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = UsersService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        cache_service_1.CacheService,
        jwt_1.JwtService])
], UsersService);
//# sourceMappingURL=users.service.js.map