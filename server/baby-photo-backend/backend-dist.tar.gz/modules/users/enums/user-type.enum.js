"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserType = void 0;
var UserType;
(function (UserType) {
    UserType["WECHAT"] = "wechat";
    UserType["ADMIN"] = "admin";
    UserType["PHONE"] = "phone";
})(UserType || (exports.UserType = UserType = {}));
//# sourceMappingURL=user-type.enum.js.map