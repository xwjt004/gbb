export declare enum UserType {
    WECHAT = "wechat",
    ADMIN = "admin",
    PHONE = "phone"
}
