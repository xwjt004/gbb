"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var UsersController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const users_service_1 = require("./users.service");
const create_user_dto_1 = require("./dto/create-user.dto");
const update_user_dto_1 = require("./dto/update-user.dto");
const user_search_dto_1 = require("./dto/user-search.dto");
const wx_login_dto_1 = require("./dto/wx-login.dto");
const admin_login_dto_1 = require("./dto/admin-login.dto");
let UsersController = UsersController_1 = class UsersController {
    usersService;
    logger = new common_1.Logger(UsersController_1.name);
    constructor(usersService) {
        this.usersService = usersService;
    }
    async wxLogin(wxLoginDto) {
        this.logger.log(`微信登录: ${JSON.stringify(wxLoginDto)}`);
        return this.usersService.wxLogin(wxLoginDto);
    }
    async create(createUserDto) {
        this.logger.log(`创建用户: ${JSON.stringify(createUserDto)}`);
        return this.usersService.create(createUserDto);
    }
    async exportUsers(searchDto) {
        this.logger.log(`导出用户数据: ${JSON.stringify(searchDto)}`);
        return this.usersService.exportUsers(searchDto);
    }
    async findAll(searchDto) {
        this.logger.log(`查询用户列表: ${JSON.stringify(searchDto)}`);
        return this.usersService.findAll(searchDto);
    }
    async findByPhone(phone) {
        this.logger.log(`通过手机号查找用户: ${phone}`);
        return this.usersService.findByPhone(phone);
    }
    async findByNickname(nickname, fuzzy) {
        this.logger.log(`通过昵称查找用户: ${nickname}, 模糊搜索: ${fuzzy}`);
        const isFuzzy = fuzzy === 'true';
        return this.usersService.findByNickname(nickname, isFuzzy);
    }
    async getStatistics() {
        this.logger.log('获取用户总体统计');
        return this.usersService.getStatistics();
    }
    async getUserStatistics(id) {
        this.logger.log(`获取用户统计信息: ${id}`);
        return this.usersService.getUserStatistics(id);
    }
    async getUserOrders(id, page, limit) {
        this.logger.log(`获取用户订单历史: ${id}`);
        return this.usersService.getUserOrders(id, {
            page: page ? parseInt(page, 10) : 1,
            limit: limit ? parseInt(limit, 10) : 10,
        });
    }
    async toggleStatus(id) {
        this.logger.log(`切换用户状态: ${id}`);
        return this.usersService.toggleStatus(id);
    }
    async getPhotographers() {
        const users = await this.usersService.findPhotographers();
        return {
            code: 200,
            message: '查询成功',
            data: users,
        };
    }
    async findOne(id) {
        this.logger.log(`获取用户详情: ${id}`);
        return this.usersService.findOne(id);
    }
    async update(id, updateUserDto) {
        this.logger.log(`更新用户: ${id}, 数据: ${JSON.stringify(updateUserDto)}`);
        return this.usersService.update(id, updateUserDto);
    }
    async remove(id) {
        this.logger.log(`删除用户: ${id}`);
        return this.usersService.remove(id);
    }
    async adminLogin(adminLoginDto) {
        return this.usersService.adminLogin(adminLoginDto);
    }
};
exports.UsersController = UsersController;
__decorate([
    (0, common_1.Post)('wx-login'),
    (0, swagger_1.ApiOperation)({ summary: '微信小程序登录' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wx_login_dto_1.UsersWxLoginDto]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "wxLogin", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建用户' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '用户创建成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_user_dto_1.CreateUserDto]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('export'),
    (0, swagger_1.ApiOperation)({ summary: '导出用户数据' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功导出用户数据' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_search_dto_1.UserSearchDto]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "exportUsers", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取所有用户' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_search_dto_1.UserSearchDto]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('by-phone/:phone'),
    (0, swagger_1.ApiOperation)({ summary: '根据电话号码获取用户' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取用户信息' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '用户不存在' }),
    __param(0, (0, common_1.Param)('phone')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "findByPhone", null);
__decorate([
    (0, common_1.Get)('by-nickname'),
    (0, swagger_1.ApiOperation)({ summary: '通过昵称查找用户' }),
    __param(0, (0, common_1.Query)('nickname')),
    __param(1, (0, common_1.Query)('fuzzy')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "findByNickname", null);
__decorate([
    (0, common_1.Get)('statistics/global'),
    (0, swagger_1.ApiOperation)({ summary: '获取用户总体统计' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getStatistics", null);
__decorate([
    (0, common_1.Get)(':id/statistics'),
    (0, swagger_1.ApiOperation)({ summary: '获取用户统计信息' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getUserStatistics", null);
__decorate([
    (0, common_1.Get)(':id/orders'),
    (0, swagger_1.ApiOperation)({ summary: '获取用户订单历史' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getUserOrders", null);
__decorate([
    (0, common_1.Patch)(':id/toggle-status'),
    (0, swagger_1.ApiOperation)({ summary: '切换用户启用/禁用状态' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "toggleStatus", null);
__decorate([
    (0, common_1.Get)('photographers'),
    (0, swagger_1.ApiOperation)({ summary: '获取摄影师列表' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getPhotographers", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '根据ID获取用户' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新用户信息' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_user_dto_1.UpdateUserDto]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除用户' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)('admin-login'),
    (0, swagger_1.ApiOperation)({ summary: '管理员登录' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '登录成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: '用户名或密码错误' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_login_dto_1.AdminLoginDto]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "adminLogin", null);
exports.UsersController = UsersController = UsersController_1 = __decorate([
    (0, swagger_1.ApiTags)('用户'),
    (0, common_1.Controller)('users'),
    __metadata("design:paramtypes", [users_service_1.UsersService])
], UsersController);
//# sourceMappingURL=users.controller.js.map