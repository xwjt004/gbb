export declare class UserSearchDto {
    page?: number;
    limit?: number;
    phone?: string;
    nickname?: string;
    wechatId?: string;
    fuzzy?: string;
    status?: string;
    isVip?: boolean;
    startDate?: string;
    endDate?: string;
    sort?: string;
}
