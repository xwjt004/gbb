declare class WxUserInfo {
    nickName?: string;
    avatarUrl?: string;
    gender?: string;
    country?: string;
    province?: string;
    city?: string;
    language?: string;
}
export declare class UsersWxLoginDto {
    code: string;
    userInfo?: WxUserInfo;
}
export {};
