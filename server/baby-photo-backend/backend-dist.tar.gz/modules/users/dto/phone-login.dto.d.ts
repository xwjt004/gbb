export declare class PhoneLoginDto {
    phone: string;
    code: string;
}
