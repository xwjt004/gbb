import { CreateUserDto } from './create-user.dto';
export declare enum UserStatusEnum {
    ACTIVE = "ACTIVE",
    INACTIVE = "INACTIVE"
}
declare const UpdateUserDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateUserDto>>;
export declare class UpdateUserDto extends UpdateUserDto_base {
    lastLoginAt?: Date;
    status?: UserStatusEnum;
}
export {};
