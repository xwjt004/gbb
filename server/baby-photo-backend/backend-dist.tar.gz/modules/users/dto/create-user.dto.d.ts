export declare enum UserStatusEnum {
    ACTIVE = "ACTIVE",
    INACTIVE = "INACTIVE"
}
export declare class CreateUserDto {
    openid?: string;
    nickname: string;
    avatar?: string;
    phone?: string;
    status?: UserStatusEnum;
}
