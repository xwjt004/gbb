import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UserSearchDto } from './dto/user-search.dto';
import { UsersWxLoginDto } from './dto/wx-login.dto';
import { AdminLoginDto } from './dto/admin-login.dto';
export declare class UsersController {
    private readonly usersService;
    private readonly logger;
    constructor(usersService: UsersService);
    wxLogin(wxLoginDto: UsersWxLoginDto): Promise<{
        code: number;
        message: string;
        data: {
            token: string;
            user: {
                openid: string;
                nickname: string | null;
                avatar: string | null;
                phone: string | null;
            };
        };
    }>;
    create(createUserDto: CreateUserDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            openid: string;
            nickname: string | null;
            avatar: string | null;
            phone: string | null;
            status: import("@prisma/client").$Enums.UserStatus;
            roleId: number | null;
        };
    }>;
    exportUsers(searchDto: UserSearchDto): Promise<{
        success: boolean;
        message: string;
        data: {
            用户ID: string;
            手机号码: string;
            昵称: string;
            微信ID: string;
            状态: import("@prisma/client").$Enums.UserStatus;
            VIP状态: string;
            VIP等级: string;
            订单数量: number;
            消费总额: number;
            注册时间: string;
            更新时间: string;
            最后登录: string;
        }[];
    }>;
    findAll(searchDto: UserSearchDto): Promise<{
        code: number;
        message: string;
        data: {
            users: {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                _count: {
                    orders: number;
                };
                openid: string;
                nickname: string | null;
                avatar: string | null;
                phone: string | null;
                status: import("@prisma/client").$Enums.UserStatus;
            }[];
            pagination: {
                total: number;
                page: number;
                limit: number;
                totalPages: number;
            };
        };
    }>;
    findByPhone(phone: string): Promise<{
        code: number;
        message: string;
        data: ({
            _count: {
                orders: number;
            };
        } & {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            openid: string;
            nickname: string | null;
            avatar: string | null;
            phone: string | null;
            status: import("@prisma/client").$Enums.UserStatus;
            roleId: number | null;
        })[];
    }>;
    findByNickname(nickname: string, fuzzy?: string): Promise<{
        code: number;
        message: string;
        data: ({
            _count: {
                orders: number;
            };
        } & {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            openid: string;
            nickname: string | null;
            avatar: string | null;
            phone: string | null;
            status: import("@prisma/client").$Enums.UserStatus;
            roleId: number | null;
        })[];
    }>;
    getStatistics(): Promise<{
        code: number;
        message: string;
        data: {
            totalUsers: number;
            activeUsers: number;
            inactiveUsers: number;
            newUsersToday: number;
            vipUsers: number;
            growthRate: number;
        };
    }>;
    getUserStatistics(id: string): Promise<{
        code: number;
        message: string;
        data: {
            totalOrders: number;
            completedOrders: number;
            totalSpent: number;
            averageOrderValue: number;
            firstOrderDate: Date | null;
            lastOrderDate: Date | null;
            customerLoyaltyLevel: string;
        };
    }>;
    getUserOrders(id: string, page?: string, limit?: string): Promise<{
        code: number;
        message: string;
        data: {
            orders: ({
                package: {
                    id: number;
                    createdAt: Date;
                    name: string;
                    status: import("@prisma/client").$Enums.PackageStatus;
                    description: string | null;
                    price: import("@prisma/client/runtime/library").Decimal;
                    deposit: import("@prisma/client/runtime/library").Decimal;
                    durationMinutes: number;
                    includes: string[];
                    isPopular: boolean;
                    images: string[];
                    category: string | null;
                    tags: string[];
                    categoryId: number | null;
                    packageType: string;
                    style: string | null;
                    theme: string | null;
                    detailImages: string[];
                    isOnSale: boolean;
                    salesVolume: number;
                    baseSales: number;
                    sortOrder: number;
                    videoUrl: string | null;
                    virtualSales: number;
                    promotionPrice: import("@prisma/client/runtime/library").Decimal | null;
                    promotionStart: Date | null;
                    promotionEnd: Date | null;
                    groupMinCount: number | null;
                    groupPrice: import("@prisma/client/runtime/library").Decimal | null;
                } | null;
                timeSlot: {
                    id: number;
                    notes: string | null;
                    createdAt: Date;
                    updatedAt: Date;
                    status: import("@prisma/client").$Enums.TimeSlotStatus;
                    date: Date;
                    startTime: Date;
                    endTime: Date;
                    isBooked: boolean;
                    availableCount: number | null;
                    bookedCount: number;
                    capacity: number;
                    isHoliday: boolean;
                    priceMultiplier: number;
                } | null;
                payments: {
                    id: string;
                    notes: string | null;
                    createdAt: Date;
                    updatedAt: Date;
                    status: import("@prisma/client").$Enums.PaymentStatus;
                    orderId: string;
                    amount: import("@prisma/client/runtime/library").Decimal;
                    transactionId: string | null;
                    paidAt: Date | null;
                    refundReason: string | null;
                    refundedAt: Date | null;
                    expiredAt: Date | null;
                    idempotencyKey: string | null;
                    operatorId: string | null;
                    operatorName: string | null;
                    paymentMethod: import("@prisma/client").$Enums.PaymentMethod;
                    receiptImage: string | null;
                    receiptImages: string[];
                    receiptNo: string | null;
                    paymentType: import("@prisma/client").$Enums.PaymentType;
                }[];
            } & {
                id: string;
                orderNo: string;
                appointmentDate: Date | null;
                totalAmount: import("@prisma/client/runtime/library").Decimal;
                depositAmount: import("@prisma/client/runtime/library").Decimal;
                paidAmount: import("@prisma/client/runtime/library").Decimal;
                notes: string | null;
                childrenCount: number;
                createdAt: Date;
                updatedAt: Date;
                customerName: string | null;
                customerPhone: string | null;
                couponId: string | null;
                discountAmount: import("@prisma/client/runtime/library").Decimal;
                shippingAddressId: string | null;
                shippingInfo: import("@prisma/client/runtime/library").JsonValue | null;
                source: import("@prisma/client").$Enums.OrderSource;
                deletedAt: Date | null;
                depositTimeout: Date | null;
                finalTimeout: Date | null;
                paymentMode: import("@prisma/client").$Enums.PaymentMode;
                paymentSummary: import("@prisma/client/runtime/library").JsonValue | null;
                refundedAmount: import("@prisma/client/runtime/library").Decimal;
                remainingAmount: import("@prisma/client/runtime/library").Decimal;
                paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
                orderStatus: import("@prisma/client").$Enums.OrderStatus;
                agreementAccepted: boolean | null;
                agreementVersion: string | null;
                agreementAcceptedAt: Date | null;
                checkinStatus: string;
                checkinTime: Date | null;
                reminderSentAt: Date | null;
                completedAt: Date | null;
                photoPickReminderSentAt: Date | null;
                userId: number;
                packageId: number | null;
                timeSlotId: number | null;
                diyPackageId: number | null;
                wxUserId: string | null;
                photographerId: number | null;
            })[];
            pagination: {
                total: number;
                page: number;
                limit: number;
                totalPages: number;
            };
        };
    }>;
    toggleStatus(id: string): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            status: import("@prisma/client").$Enums.UserStatus;
        };
    }>;
    getPhotographers(): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            nickname: string | null;
            avatar: string | null;
        }[];
    }>;
    findOne(id: string): Promise<{
        code: number;
        message: string;
        data: {
            _count: {
                orders: number;
            };
            orders: ({
                package: {
                    name: string;
                    price: import("@prisma/client/runtime/library").Decimal;
                } | null;
            } & {
                id: string;
                orderNo: string;
                appointmentDate: Date | null;
                totalAmount: import("@prisma/client/runtime/library").Decimal;
                depositAmount: import("@prisma/client/runtime/library").Decimal;
                paidAmount: import("@prisma/client/runtime/library").Decimal;
                notes: string | null;
                childrenCount: number;
                createdAt: Date;
                updatedAt: Date;
                customerName: string | null;
                customerPhone: string | null;
                couponId: string | null;
                discountAmount: import("@prisma/client/runtime/library").Decimal;
                shippingAddressId: string | null;
                shippingInfo: import("@prisma/client/runtime/library").JsonValue | null;
                source: import("@prisma/client").$Enums.OrderSource;
                deletedAt: Date | null;
                depositTimeout: Date | null;
                finalTimeout: Date | null;
                paymentMode: import("@prisma/client").$Enums.PaymentMode;
                paymentSummary: import("@prisma/client/runtime/library").JsonValue | null;
                refundedAmount: import("@prisma/client/runtime/library").Decimal;
                remainingAmount: import("@prisma/client/runtime/library").Decimal;
                paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
                orderStatus: import("@prisma/client").$Enums.OrderStatus;
                agreementAccepted: boolean | null;
                agreementVersion: string | null;
                agreementAcceptedAt: Date | null;
                checkinStatus: string;
                checkinTime: Date | null;
                reminderSentAt: Date | null;
                completedAt: Date | null;
                photoPickReminderSentAt: Date | null;
                userId: number;
                packageId: number | null;
                timeSlotId: number | null;
                diyPackageId: number | null;
                wxUserId: string | null;
                photographerId: number | null;
            })[];
        } & {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            openid: string;
            nickname: string | null;
            avatar: string | null;
            phone: string | null;
            status: import("@prisma/client").$Enums.UserStatus;
            roleId: number | null;
        };
    }>;
    update(id: string, updateUserDto: UpdateUserDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            openid: string;
            nickname: string | null;
            avatar: string | null;
            phone: string | null;
            status: import("@prisma/client").$Enums.UserStatus;
            roleId: number | null;
        };
    }>;
    remove(id: string): Promise<{
        code: number;
        message: string;
        data: {
            _count: {
                orders: number;
                alertsHandled: number;
                checksApproved: number;
                checksCreated: number;
                outboundsApproved: number;
                outboundsSubmitted: number;
                transactions: number;
                transfersApproved: number;
                transfersSubmitted: number;
            };
        } & {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            openid: string;
            nickname: string | null;
            avatar: string | null;
            phone: string | null;
            status: import("@prisma/client").$Enums.UserStatus;
            roleId: number | null;
        };
    }>;
    adminLogin(adminLoginDto: AdminLoginDto): Promise<{
        success: boolean;
        message: string;
        data: {
            id: number;
            openid: string;
            nickname: string | null;
            phone: string | null;
            isAdmin: boolean;
            token: string;
        };
    }>;
}
