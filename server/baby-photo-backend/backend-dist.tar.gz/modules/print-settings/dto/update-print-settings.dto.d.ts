export declare class UpdatePrintSettingsDto {
    showShopName?: boolean;
    showAddress?: boolean;
    showPhone?: boolean;
    showTelephone?: boolean;
    showWechatId?: boolean;
    showDouyinId?: boolean;
    showKuaishouId?: boolean;
    showXiaohongshuId?: boolean;
    showBusinessScope?: boolean;
    showBusinessHours?: boolean;
}
