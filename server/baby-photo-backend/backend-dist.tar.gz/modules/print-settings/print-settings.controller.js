"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintSettingsController = void 0;
const common_1 = require("@nestjs/common");
const print_settings_service_1 = require("./print-settings.service");
const update_print_settings_dto_1 = require("./dto/update-print-settings.dto");
let PrintSettingsController = class PrintSettingsController {
    printSettingsService;
    constructor(printSettingsService) {
        this.printSettingsService = printSettingsService;
    }
    async getPrintSettings() {
        try {
            const data = await this.printSettingsService.getPrintSettings();
            return {
                code: 200,
                message: '获取打印设置成功',
                data,
            };
        }
        catch (error) {
            return {
                code: 500,
                message: '获取打印设置失败: ' + error.message,
                data: null,
            };
        }
    }
    async updatePrintSettings(updateDto) {
        try {
            const data = await this.printSettingsService.updatePrintSettings(updateDto);
            return {
                code: 200,
                message: '更新打印设置成功',
                data,
            };
        }
        catch (error) {
            return {
                code: 500,
                message: '更新打印设置失败: ' + error.message,
                data: null,
            };
        }
    }
};
exports.PrintSettingsController = PrintSettingsController;
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PrintSettingsController.prototype, "getPrintSettings", null);
__decorate([
    (0, common_1.Put)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [update_print_settings_dto_1.UpdatePrintSettingsDto]),
    __metadata("design:returntype", Promise)
], PrintSettingsController.prototype, "updatePrintSettings", null);
exports.PrintSettingsController = PrintSettingsController = __decorate([
    (0, common_1.Controller)('print-settings'),
    __metadata("design:paramtypes", [print_settings_service_1.PrintSettingsService])
], PrintSettingsController);
//# sourceMappingURL=print-settings.controller.js.map