"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintSettingsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let PrintSettingsService = class PrintSettingsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getPrintSettings() {
        let settings = await this.prisma.printSettings.findFirst();
        if (!settings) {
            settings = await this.prisma.printSettings.create({
                data: {
                    showShopName: true,
                    showAddress: true,
                    showPhone: true,
                    showTelephone: false,
                    showWechatId: true,
                    showDouyinId: false,
                    showKuaishouId: false,
                    showXiaohongshuId: false,
                    showBusinessScope: true,
                    showBusinessHours: true,
                },
            });
        }
        return settings;
    }
    async updatePrintSettings(updateDto) {
        const existing = await this.getPrintSettings();
        return this.prisma.printSettings.upsert({
            where: { id: existing.id },
            update: updateDto,
            create: updateDto,
        });
    }
};
exports.PrintSettingsService = PrintSettingsService;
exports.PrintSettingsService = PrintSettingsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrintSettingsService);
//# sourceMappingURL=print-settings.service.js.map