export declare class PrintSettingsModule {
}
