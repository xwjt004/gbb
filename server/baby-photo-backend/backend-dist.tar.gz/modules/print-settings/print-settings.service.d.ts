import { PrismaService } from '../../shared/prisma/prisma.service';
import { UpdatePrintSettingsDto } from './dto/update-print-settings.dto';
export declare class PrintSettingsService {
    private prisma;
    constructor(prisma: PrismaService);
    getPrintSettings(): Promise<{
        id: number;
        createdAt: Date;
        updatedAt: Date;
        showShopName: boolean;
        showAddress: boolean;
        showPhone: boolean;
        showTelephone: boolean;
        showWechatId: boolean;
        showDouyinId: boolean;
        showKuaishouId: boolean;
        showXiaohongshuId: boolean;
        showBusinessScope: boolean;
        showBusinessHours: boolean;
        footerFontSize: number;
        footerAlign: string;
        showDivider: boolean;
        customText: string | null;
    }>;
    updatePrintSettings(updateDto: UpdatePrintSettingsDto): Promise<{
        id: number;
        createdAt: Date;
        updatedAt: Date;
        showShopName: boolean;
        showAddress: boolean;
        showPhone: boolean;
        showTelephone: boolean;
        showWechatId: boolean;
        showDouyinId: boolean;
        showKuaishouId: boolean;
        showXiaohongshuId: boolean;
        showBusinessScope: boolean;
        showBusinessHours: boolean;
        footerFontSize: number;
        footerAlign: string;
        showDivider: boolean;
        customText: string | null;
    }>;
}
