import { PrintSettingsService } from './print-settings.service';
import { UpdatePrintSettingsDto } from './dto/update-print-settings.dto';
export declare class PrintSettingsController {
    private readonly printSettingsService;
    constructor(printSettingsService: PrintSettingsService);
    getPrintSettings(): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            showShopName: boolean;
            showAddress: boolean;
            showPhone: boolean;
            showTelephone: boolean;
            showWechatId: boolean;
            showDouyinId: boolean;
            showKuaishouId: boolean;
            showXiaohongshuId: boolean;
            showBusinessScope: boolean;
            showBusinessHours: boolean;
            footerFontSize: number;
            footerAlign: string;
            showDivider: boolean;
            customText: string | null;
        };
    } | {
        code: number;
        message: string;
        data: null;
    }>;
    updatePrintSettings(updateDto: UpdatePrintSettingsDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            showShopName: boolean;
            showAddress: boolean;
            showPhone: boolean;
            showTelephone: boolean;
            showWechatId: boolean;
            showDouyinId: boolean;
            showKuaishouId: boolean;
            showXiaohongshuId: boolean;
            showBusinessScope: boolean;
            showBusinessHours: boolean;
            footerFontSize: number;
            footerAlign: string;
            showDivider: boolean;
            customText: string | null;
        };
    } | {
        code: number;
        message: string;
        data: null;
    }>;
}
