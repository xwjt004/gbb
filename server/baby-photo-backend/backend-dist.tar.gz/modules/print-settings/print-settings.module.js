"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrintSettingsModule = void 0;
const common_1 = require("@nestjs/common");
const print_settings_service_1 = require("./print-settings.service");
const print_settings_controller_1 = require("./print-settings.controller");
const prisma_module_1 = require("../../shared/prisma/prisma.module");
let PrintSettingsModule = class PrintSettingsModule {
};
exports.PrintSettingsModule = PrintSettingsModule;
exports.PrintSettingsModule = PrintSettingsModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule],
        controllers: [print_settings_controller_1.PrintSettingsController],
        providers: [print_settings_service_1.PrintSettingsService],
        exports: [print_settings_service_1.PrintSettingsService],
    })
], PrintSettingsModule);
//# sourceMappingURL=print-settings.module.js.map