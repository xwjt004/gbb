import { PrismaService } from '../../shared/prisma/prisma.service';
import { CreateCouponDto } from './dto/create-coupon.dto';
import { UpdateCouponDto } from './dto/update-coupon.dto';
export declare class CouponsService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    create(dto: CreateCouponDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            status: import("@prisma/client").$Enums.CouponStatus;
            description: string | null;
            startTime: Date;
            endTime: Date;
            minAmount: import("@prisma/client/runtime/library").Decimal | null;
            totalCount: number;
            couponCode: string;
            couponName: string;
            couponType: import("@prisma/client").$Enums.CouponType;
            discountType: import("@prisma/client").$Enums.DiscountType;
            discountValue: import("@prisma/client/runtime/library").Decimal;
            maxDiscount: import("@prisma/client/runtime/library").Decimal | null;
            usedCount: number;
            perUserLimit: number;
            applicableType: string;
            applicableIds: number[];
        };
    }>;
    findAll(query: {
        page?: number;
        pageSize?: number;
        status?: string;
    }): Promise<{
        code: number;
        message: string;
        data: {
            list: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                status: import("@prisma/client").$Enums.CouponStatus;
                description: string | null;
                startTime: Date;
                endTime: Date;
                minAmount: import("@prisma/client/runtime/library").Decimal | null;
                totalCount: number;
                couponCode: string;
                couponName: string;
                couponType: import("@prisma/client").$Enums.CouponType;
                discountType: import("@prisma/client").$Enums.DiscountType;
                discountValue: import("@prisma/client/runtime/library").Decimal;
                maxDiscount: import("@prisma/client/runtime/library").Decimal | null;
                usedCount: number;
                perUserLimit: number;
                applicableType: string;
                applicableIds: number[];
            }[];
            pagination: {
                total: number;
                page: number;
                pageSize: number;
                totalPages: number;
            };
        };
    }>;
    findOne(id: string): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            status: import("@prisma/client").$Enums.CouponStatus;
            description: string | null;
            startTime: Date;
            endTime: Date;
            minAmount: import("@prisma/client/runtime/library").Decimal | null;
            totalCount: number;
            couponCode: string;
            couponName: string;
            couponType: import("@prisma/client").$Enums.CouponType;
            discountType: import("@prisma/client").$Enums.DiscountType;
            discountValue: import("@prisma/client/runtime/library").Decimal;
            maxDiscount: import("@prisma/client/runtime/library").Decimal | null;
            usedCount: number;
            perUserLimit: number;
            applicableType: string;
            applicableIds: number[];
        };
    }>;
    update(id: string, dto: UpdateCouponDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            status: import("@prisma/client").$Enums.CouponStatus;
            description: string | null;
            startTime: Date;
            endTime: Date;
            minAmount: import("@prisma/client/runtime/library").Decimal | null;
            totalCount: number;
            couponCode: string;
            couponName: string;
            couponType: import("@prisma/client").$Enums.CouponType;
            discountType: import("@prisma/client").$Enums.DiscountType;
            discountValue: import("@prisma/client/runtime/library").Decimal;
            maxDiscount: import("@prisma/client/runtime/library").Decimal | null;
            usedCount: number;
            perUserLimit: number;
            applicableType: string;
            applicableIds: number[];
        };
    }>;
    remove(id: string): Promise<{
        code: number;
        message: string;
    }>;
}
