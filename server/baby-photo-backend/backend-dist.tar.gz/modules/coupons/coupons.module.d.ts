export declare class CouponsModule {
}
