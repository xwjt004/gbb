export declare class CreateCouponDto {
    couponCode: string;
    couponName: string;
    couponType: string;
    discountType: string;
    discountValue: number;
    minAmount?: number;
    maxDiscount?: number;
    totalCount: number;
    perUserLimit?: number;
    applicableType?: string;
    applicableIds?: number[];
    startTime: string;
    endTime: string;
    description?: string;
}
