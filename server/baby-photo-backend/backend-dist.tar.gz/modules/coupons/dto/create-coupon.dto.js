"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateCouponDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class CreateCouponDto {
    couponCode;
    couponName;
    couponType;
    discountType;
    discountValue;
    minAmount;
    maxDiscount;
    totalCount;
    perUserLimit;
    applicableType;
    applicableIds;
    startTime;
    endTime;
    description;
}
exports.CreateCouponDto = CreateCouponDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '优惠券编码' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateCouponDto.prototype, "couponCode", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '优惠券名称' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateCouponDto.prototype, "couponName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '优惠券类型', enum: ['REGISTER', 'PROMOTION', 'REBATE', 'BIRTHDAY'] }),
    (0, class_validator_1.IsEnum)(['REGISTER', 'PROMOTION', 'REBATE', 'BIRTHDAY']),
    __metadata("design:type", String)
], CreateCouponDto.prototype, "couponType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '折扣类型', enum: ['PERCENT', 'FIXED'] }),
    (0, class_validator_1.IsEnum)(['PERCENT', 'FIXED']),
    __metadata("design:type", String)
], CreateCouponDto.prototype, "discountType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '折扣值', example: 90 }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateCouponDto.prototype, "discountValue", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '最低消费金额', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateCouponDto.prototype, "minAmount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '最大折扣金额（百分比类型时）', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateCouponDto.prototype, "maxDiscount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '总数量' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateCouponDto.prototype, "totalCount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '每人限领', required: false, default: 1 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateCouponDto.prototype, "perUserLimit", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '适用类型', required: false, default: 'ALL' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateCouponDto.prototype, "applicableType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '适用商品ID列表', required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], CreateCouponDto.prototype, "applicableIds", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '开始时间' }),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateCouponDto.prototype, "startTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '结束时间' }),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateCouponDto.prototype, "endTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '描述', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateCouponDto.prototype, "description", void 0);
//# sourceMappingURL=create-coupon.dto.js.map