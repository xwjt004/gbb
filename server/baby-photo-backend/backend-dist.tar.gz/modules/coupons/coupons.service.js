"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CouponsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CouponsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let CouponsService = CouponsService_1 = class CouponsService {
    prisma;
    logger = new common_1.Logger(CouponsService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(dto) {
        const data = await this.prisma.coupon.create({
            data: {
                couponCode: dto.couponCode,
                couponName: dto.couponName,
                couponType: dto.couponType,
                discountType: dto.discountType,
                discountValue: dto.discountValue,
                minAmount: dto.minAmount,
                maxDiscount: dto.maxDiscount,
                totalCount: dto.totalCount,
                perUserLimit: dto.perUserLimit || 1,
                applicableType: dto.applicableType || 'ALL',
                applicableIds: dto.applicableIds || [],
                startTime: new Date(dto.startTime),
                endTime: new Date(dto.endTime),
                description: dto.description,
            },
        });
        return { code: 200, message: '创建成功', data };
    }
    async findAll(query) {
        const { page = 1, pageSize = 20, status } = query;
        const where = {};
        if (status)
            where.status = status;
        const [list, total] = await Promise.all([
            this.prisma.coupon.findMany({
                where,
                skip: (page - 1) * pageSize,
                take: pageSize,
                orderBy: { createdAt: 'desc' },
            }),
            this.prisma.coupon.count({ where }),
        ]);
        return {
            code: 200,
            message: '查询成功',
            data: { list, pagination: { total, page, pageSize, totalPages: Math.ceil(total / pageSize) } },
        };
    }
    async findOne(id) {
        const data = await this.prisma.coupon.findUnique({ where: { id } });
        if (!data)
            throw new common_1.NotFoundException('优惠券不存在');
        return { code: 200, message: '查询成功', data };
    }
    async update(id, dto) {
        const existing = await this.prisma.coupon.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException('优惠券不存在');
        const updateData = {};
        if (dto.couponCode !== undefined)
            updateData.couponCode = dto.couponCode;
        if (dto.couponName !== undefined)
            updateData.couponName = dto.couponName;
        if (dto.couponType !== undefined)
            updateData.couponType = dto.couponType;
        if (dto.discountType !== undefined)
            updateData.discountType = dto.discountType;
        if (dto.discountValue !== undefined)
            updateData.discountValue = dto.discountValue;
        if (dto.minAmount !== undefined)
            updateData.minAmount = dto.minAmount;
        if (dto.maxDiscount !== undefined)
            updateData.maxDiscount = dto.maxDiscount;
        if (dto.totalCount !== undefined)
            updateData.totalCount = dto.totalCount;
        if (dto.perUserLimit !== undefined)
            updateData.perUserLimit = dto.perUserLimit;
        if (dto.applicableType !== undefined)
            updateData.applicableType = dto.applicableType;
        if (dto.applicableIds !== undefined)
            updateData.applicableIds = dto.applicableIds;
        if (dto.startTime !== undefined)
            updateData.startTime = new Date(dto.startTime);
        if (dto.endTime !== undefined)
            updateData.endTime = new Date(dto.endTime);
        if (dto.description !== undefined)
            updateData.description = dto.description;
        const data = await this.prisma.coupon.update({ where: { id }, data: updateData });
        return { code: 200, message: '更新成功', data };
    }
    async remove(id) {
        const existing = await this.prisma.coupon.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException('优惠券不存在');
        await this.prisma.coupon.update({ where: { id }, data: { status: 'INACTIVE' } });
        return { code: 200, message: '删除成功' };
    }
};
exports.CouponsService = CouponsService;
exports.CouponsService = CouponsService = CouponsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], CouponsService);
//# sourceMappingURL=coupons.service.js.map