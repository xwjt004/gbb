"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const orders_service_1 = require("./orders.service");
const create_order_dto_1 = require("./dto/create-order.dto");
const update_order_dto_1 = require("./dto/update-order.dto");
const checkin_dto_1 = require("./dto/checkin.dto");
const apply_coupon_dto_1 = require("./dto/apply-coupon.dto");
const change_package_dto_1 = require("./dto/change-package.dto");
let OrdersController = class OrdersController {
    ordersService;
    constructor(ordersService) {
        this.ordersService = ordersService;
    }
    create(createOrderDto) {
        return this.ordersService.create(createOrderDto);
    }
    async findAll(page = 1, pageSize = 20, searchParams) {
        const result = await this.ordersService.findAll({
            page: Number(page),
            pageSize: Number(pageSize),
            ...searchParams,
        });
        return {
            success: true,
            data: result,
        };
    }
    async getScheduleBoard(date, photographerId) {
        const pid = photographerId ? parseInt(photographerId, 10) : undefined;
        const result = await this.ordersService.getScheduleBoard(date, pid);
        return { success: true, data: result };
    }
    async getScheduleBoardRange(startDate, endDate, photographerId) {
        const pid = photographerId ? parseInt(photographerId, 10) : undefined;
        const result = await this.ordersService.getScheduleBoardRange(startDate, endDate, pid);
        return { success: true, data: result };
    }
    async assignPhotographer(id, photographerId) {
        return this.ordersService.assignPhotographer(id, Number(photographerId));
    }
    async batchAssignPhotographer(orderIds, photographerId) {
        const pid = Number(photographerId);
        return this.ordersService.batchAssignPhotographer(orderIds, pid);
    }
    async rescheduleOrder(id, timeSlotId) {
        return this.ordersService.rescheduleOrder(id, Number(timeSlotId));
    }
    async getStats() {
        const result = await this.ordersService.getStats();
        return {
            success: true,
            data: result,
        };
    }
    async getOrderTrends(period, startDate, endDate) {
        const result = await this.ordersService.getOrderTrends(period, startDate, endDate);
        return {
            success: true,
            data: result,
        };
    }
    async getFutureOrderTrends(period, startDate, endDate) {
        const result = await this.ordersService.getFutureOrderTrends(period, startDate, endDate);
        return {
            success: true,
            data: result,
        };
    }
    async getCashFlowTrends(startDate, endDate) {
        const result = await this.ordersService.getCashFlowTrends(startDate, endDate);
        return {
            success: true,
            data: result,
        };
    }
    findByUserOpenid(userOpenid) {
        return this.ordersService.findByUserOpenid(userOpenid);
    }
    findByPhone(phone) {
        return this.ordersService.findByPhone(phone);
    }
    findByPaymentStatus(status) {
        return this.ordersService.findByPaymentStatus(status);
    }
    findByOrderNo(orderNo) {
        return this.ordersService.findByOrderNo(orderNo);
    }
    findOne(id) {
        return this.ordersService.findOne(id);
    }
    update(id, updateOrderDto) {
        return this.ordersService.update(id, updateOrderDto);
    }
    async checkin(id, dto) {
        return this.ordersService.checkin(id, dto);
    }
    async applyCoupon(id, dto) {
        return this.ordersService.applyCoupon(id, dto);
    }
    async changePackage(id, dto) {
        return this.ordersService.changePackage(id, dto);
    }
    async cancelOrder(id, body) {
        const result = await this.ordersService.cancelOrder(id, body?.reason);
        return {
            success: true,
            data: result,
            message: '订单取消成功',
        };
    }
    async confirmOrder(id) {
        const result = await this.ordersService.confirmOrder(id);
        return {
            success: true,
            data: result,
            message: '订单确认成功',
        };
    }
    async completeOrder(id) {
        const result = await this.ordersService.completeOrder(id);
        return {
            success: true,
            data: result,
            message: '订单完成成功',
        };
    }
    async batchOperate(batchDto) {
        const result = await this.ordersService.batchOperate(batchDto.operation, batchDto.orderIds);
        return {
            success: true,
            data: result,
            message: '批量操作完成',
        };
    }
    async deleteOrder(id) {
        const result = await this.ordersService.deleteOrder(id);
        return {
            success: true,
            data: result,
            message: '订单删除成功',
        };
    }
};
exports.OrdersController = OrdersController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建订单' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '订单创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '用户、套餐或时间槽不存在' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_order_dto_1.CreateOrderDto]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取所有订单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取订单列表' }),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('pageSize')),
    __param(2, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('schedule-board'),
    (0, swagger_1.ApiOperation)({ summary: '获取拍摄日程看板（按时间段分组）' }),
    __param(0, (0, common_1.Query)('date')),
    __param(1, (0, common_1.Query)('photographerId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "getScheduleBoard", null);
__decorate([
    (0, common_1.Get)('schedule-board/range'),
    (0, swagger_1.ApiOperation)({ summary: '获取拍摄日程看板（日期范围，按时间段分组）' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('photographerId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "getScheduleBoardRange", null);
__decorate([
    (0, common_1.Patch)(':id/assign-photographer'),
    (0, swagger_1.ApiOperation)({ summary: '分配摄影师' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('photographerId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "assignPhotographer", null);
__decorate([
    (0, common_1.Post)('batch-assign-photographer'),
    (0, swagger_1.ApiOperation)({ summary: '批量分配摄影师' }),
    __param(0, (0, common_1.Body)('orderIds')),
    __param(1, (0, common_1.Body)('photographerId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array, Number]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "batchAssignPhotographer", null);
__decorate([
    (0, common_1.Patch)(':id/reschedule'),
    (0, swagger_1.ApiOperation)({ summary: '调整预约时间' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('timeSlotId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "rescheduleOrder", null);
__decorate([
    (0, common_1.Get)('stats'),
    (0, swagger_1.ApiOperation)({ summary: '获取订单统计信息' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取订单统计' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)('trends'),
    (0, swagger_1.ApiOperation)({ summary: '获取订单历史趋势数据' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取订单历史趋势' }),
    __param(0, (0, common_1.Query)('period')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "getOrderTrends", null);
__decorate([
    (0, common_1.Get)('future-trends'),
    (0, swagger_1.ApiOperation)({ summary: '获取未来订单趋势数据(基于预约)' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取未来订单趋势' }),
    __param(0, (0, common_1.Query)('period')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "getFutureOrderTrends", null);
__decorate([
    (0, common_1.Get)('cashflow-trends'),
    (0, swagger_1.ApiOperation)({ summary: '获取订单资金流趋势数据' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取订单资金流趋势' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "getCashFlowTrends", null);
__decorate([
    (0, common_1.Get)('user/:userOpenid'),
    (0, swagger_1.ApiOperation)({ summary: '根据用户openid获取订单' }),
    (0, swagger_1.ApiParam)({ name: 'userOpenid', description: '用户openid' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取用户订单' }),
    __param(0, (0, common_1.Param)('userOpenid')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findByUserOpenid", null);
__decorate([
    (0, common_1.Get)('phone/:phone'),
    (0, swagger_1.ApiOperation)({ summary: '根据电话号码获取订单' }),
    (0, swagger_1.ApiParam)({ name: 'phone', description: '电话号码' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取用户订单' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '用户不存在或无订单' }),
    __param(0, (0, common_1.Param)('phone')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findByPhone", null);
__decorate([
    (0, common_1.Get)('payment-status/:status'),
    (0, swagger_1.ApiOperation)({ summary: '根据支付状态获取订单统计' }),
    (0, swagger_1.ApiParam)({
        name: 'status',
        description: '支付状态 (CREATED, PENDING, PAID, FAILED, REFUNDED)',
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取订单统计列表' }),
    __param(0, (0, common_1.Param)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findByPaymentStatus", null);
__decorate([
    (0, common_1.Get)('order-no/:orderNo'),
    (0, swagger_1.ApiOperation)({ summary: '根据订单号获取订单' }),
    (0, swagger_1.ApiParam)({ name: 'orderNo', description: '订单号' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取订单详情' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    __param(0, (0, common_1.Param)('orderNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findByOrderNo", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '根据ID获取订单详情' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '订单ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取订单详情' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新订单信息' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '订单ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '订单更新成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_order_dto_1.UpdateOrderDto]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)(':id/checkin'),
    (0, swagger_1.ApiOperation)({ summary: '签到/缺席标记' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '订单ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '签到状态更新成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '订单状态不允许操作' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, checkin_dto_1.CheckinDto]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "checkin", null);
__decorate([
    (0, common_1.Post)(':id/apply-coupon'),
    (0, swagger_1.ApiOperation)({ summary: '应用优惠券' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '订单ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '优惠券应用成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '优惠券无效或订单不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, apply_coupon_dto_1.ApplyCouponDto]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "applyCoupon", null);
__decorate([
    (0, common_1.Post)(':id/change-package'),
    (0, swagger_1.ApiOperation)({ summary: '更换套餐（升级/降级）' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '订单ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '套餐更换成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单或套餐不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, change_package_dto_1.ChangePackageDto]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "changePackage", null);
__decorate([
    (0, common_1.Post)(':id/cancel'),
    (0, swagger_1.ApiOperation)({ summary: '取消订单' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '订单ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '订单取消成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '订单状态不允许取消' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "cancelOrder", null);
__decorate([
    (0, common_1.Post)(':id/confirm'),
    (0, swagger_1.ApiOperation)({ summary: '确认订单' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '订单ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '订单确认成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '订单状态不允许确认' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "confirmOrder", null);
__decorate([
    (0, common_1.Post)(':id/complete'),
    (0, swagger_1.ApiOperation)({ summary: '完成订单' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '订单ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '订单完成成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '订单状态不允许完成' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "completeOrder", null);
__decorate([
    (0, common_1.Post)('batch'),
    (0, swagger_1.ApiOperation)({ summary: '批量操作订单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '批量操作成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "batchOperate", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除订单' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '订单ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '订单删除成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "deleteOrder", null);
exports.OrdersController = OrdersController = __decorate([
    (0, swagger_1.ApiTags)('订单管理'),
    (0, common_1.Controller)('orders'),
    __metadata("design:paramtypes", [orders_service_1.OrdersService])
], OrdersController);
//# sourceMappingURL=orders.controller.js.map