"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const order_status_validator_1 = require("../../shared/validators/order-status.validator");
const status_enum_1 = require("../../shared/enums/status.enum");
const status_change_log_service_1 = require("../../shared/services/status-change-log.service");
const packages_service_1 = require("../packages/packages.service");
const automation_rules_service_1 = require("../automation-rules/automation-rules.service");
let OrdersService = class OrdersService {
    prisma;
    statusChangeLogService;
    packagesService;
    automationRulesService;
    constructor(prisma, statusChangeLogService, packagesService, automationRulesService) {
        this.prisma = prisma;
        this.statusChangeLogService = statusChangeLogService;
        this.packagesService = packagesService;
        this.automationRulesService = automationRulesService;
    }
    async create(createOrderDto) {
        const { userOpenid, packageId, diyPackageId, timeSlotId } = createOrderDto;
        console.log('创建订单请求数据:', JSON.stringify(createOrderDto, null, 2));
        let user = await this.prisma.user.findUnique({
            where: { openid: userOpenid },
        });
        if (!user && !isNaN(Number(userOpenid))) {
            console.log('通过openid未找到用户,尝试通过ID查找:', userOpenid);
            user = await this.prisma.user.findUnique({
                where: { id: Number(userOpenid) },
            });
        }
        if (!user) {
            console.error(`用户不存在: ${userOpenid}`);
            throw new common_1.NotFoundException(`User with identifier ${userOpenid} not found`);
        }
        console.log('找到用户:', user.id, user.nickname);
        if (packageId) {
            const packageInfo = await this.prisma.package.findUnique({
                where: { id: packageId },
            });
            if (!packageInfo) {
                console.error(`套餐不存在: ${packageId}`);
                throw new common_1.NotFoundException(`Package with id ${packageId} not found`);
            }
            console.log('找到套餐:', packageInfo.id, packageInfo.name);
        }
        if (diyPackageId) {
            const diyPackageInfo = await this.prisma.diyPackage.findUnique({
                where: { id: diyPackageId },
            });
            if (!diyPackageInfo) {
                console.error(`DIY套系不存在: ${diyPackageId}`);
                throw new common_1.NotFoundException(`DiyPackage with id ${diyPackageId} not found`);
            }
            console.log('找到DIY套系:', diyPackageInfo.id, diyPackageInfo.packageName);
        }
        if (!packageId && !diyPackageId) {
            throw new common_1.BadRequestException('必须提供套餐ID或DIY套系ID');
        }
        let timeSlot = null;
        if (timeSlotId) {
            timeSlot = await this.prisma.timeSlot.findUnique({
                where: { id: timeSlotId },
                include: {
                    _count: {
                        select: { orders: true }
                    }
                }
            });
            if (!timeSlot) {
                console.error(`时间槽不存在: ${timeSlotId}`);
                throw new common_1.NotFoundException(`TimeSlot with id ${timeSlotId} not found`);
            }
            const currentBookedCount = timeSlot._count?.orders;
            if (currentBookedCount >= timeSlot.capacity) {
                console.error(`时间槽容量已满: ${timeSlotId}, 当前预订: ${currentBookedCount}, 最大容量: ${timeSlot.capacity}`);
                throw new common_1.BadRequestException(`时间槽容量已满，当前预订 ${currentBookedCount}/${timeSlot.capacity}`);
            }
            if (timeSlot.status === 'UNAVAILABLE') {
                console.error(`时间槽不可用: ${timeSlotId}`);
                throw new common_1.BadRequestException('时间槽当前不可用');
            }
            console.log('找到时间槽:', timeSlot.id, timeSlot.date, `容量: ${currentBookedCount}/${timeSlot.capacity}`);
        }
        const orderNo = this.generateOrderNo();
        let pricingInfo = null;
        const appointmentDate = createOrderDto.appointmentDate
            ? new Date(createOrderDto.appointmentDate)
            : timeSlot?.date || null;
        if (packageId && appointmentDate) {
            const calculated = await this.packagesService.calculatePrice(packageId, appointmentDate);
            pricingInfo = { ...calculated };
            if (timeSlot?.priceMultiplier && timeSlot.priceMultiplier !== 1) {
                pricingInfo.finalPrice = Math.round(pricingInfo.finalPrice * timeSlot.priceMultiplier * 100) / 100;
                pricingInfo.priceMultiplier = timeSlot.priceMultiplier;
            }
        }
        const finalTotalAmount = createOrderDto.totalAmount || (pricingInfo?.finalPrice ?? 0);
        const orderData = {
            orderNo,
            userId: user.id,
            packageId: packageId || null,
            diyPackageId: diyPackageId || null,
            totalAmount: finalTotalAmount,
            depositAmount: createOrderDto.depositAmount || 0,
            paidAmount: 0,
            paymentStatus: status_enum_1.PaymentStatus.PENDING_PAYMENT,
            orderStatus: status_enum_1.OrderStatus.PENDING,
            childrenCount: createOrderDto.childrenCount || 1,
            customerName: createOrderDto.customerName,
            customerPhone: createOrderDto.customerPhone,
            notes: createOrderDto.notes,
            couponId: createOrderDto.couponId || null,
            discountAmount: 0,
            wxUserId: createOrderDto.wxUserId || null,
            agreementAccepted: !!createOrderDto.agreementAccepted,
            agreementVersion: createOrderDto.agreementVersion || null,
            agreementAcceptedAt: createOrderDto.agreementAcceptedAt ? new Date(createOrderDto.agreementAcceptedAt) : null,
            paymentSummary: {
                ...(createOrderDto.paymentSummary || {}),
                ...(pricingInfo ? {
                    pricing: {
                        basePrice: pricingInfo.basePrice,
                        finalPrice: pricingInfo.finalPrice,
                        appliedRule: pricingInfo.appliedRule,
                        priceMultiplier: pricingInfo.priceMultiplier || 1,
                    },
                } : {}),
                agreement: {
                    accepted: !!createOrderDto.agreementAccepted,
                    version: createOrderDto.agreementVersion || null,
                    acceptedAt: createOrderDto.agreementAcceptedAt ? new Date(createOrderDto.agreementAcceptedAt) : null,
                },
            },
        };
        if (timeSlotId && timeSlot) {
            orderData.timeSlotId = timeSlotId;
        }
        else {
            console.error('timeSlotId是必需字段，但未提供或时间槽不存在');
            throw new common_1.BadRequestException('时间槽ID是必需的');
        }
        if (createOrderDto.appointmentDate) {
            orderData.appointmentDate = createOrderDto.appointmentDate;
        }
        else {
            if (timeSlot) {
                orderData.appointmentDate = timeSlot.date;
            }
            else {
                throw new common_1.BadRequestException('预约日期是必需的');
            }
        }
        console.log('准备创建的订单数据:', JSON.stringify(orderData, null, 2));
        try {
            const result = await this.prisma.$transaction(async (prisma) => {
                const order = await prisma.order.create({
                    data: orderData,
                });
                console.log('订单创建成功:', order.id);
                if (timeSlotId) {
                    const currentTimeSlot = await prisma.timeSlot.findUnique({
                        where: { id: timeSlotId },
                        include: {
                            _count: {
                                select: { orders: true }
                            }
                        }
                    });
                    if (currentTimeSlot) {
                        const newBookedCount = currentTimeSlot._count?.orders;
                        const isFullyBooked = newBookedCount >= currentTimeSlot.capacity;
                        await prisma.timeSlot.update({
                            where: { id: timeSlotId },
                            data: {
                                bookedCount: newBookedCount,
                                availableCount: Math.max(0, currentTimeSlot.capacity - newBookedCount),
                                isBooked: isFullyBooked,
                                status: isFullyBooked ? 'BOOKED' : 'AVAILABLE'
                            },
                        });
                        console.log(`时间槽状态已更新: 预订数量 ${newBookedCount}/${currentTimeSlot.capacity}, 状态: ${isFullyBooked ? 'BOOKED' : 'AVAILABLE'}`);
                    }
                }
                if (createOrderDto.couponId) {
                    const wxUserId = createOrderDto.wxUserId || order.wxUserId;
                    if (wxUserId) {
                        const couponResult = await this.redeemCouponInternal(prisma, createOrderDto.couponId, wxUserId, order.id, finalTotalAmount);
                        if (couponResult) {
                            await prisma.order.update({
                                where: { id: order.id },
                                data: {
                                    discountAmount: couponResult.discountAmount,
                                    totalAmount: couponResult.finalAmount,
                                    paymentSummary: orderData.paymentSummary
                                        ? { ...orderData.paymentSummary, coupon: couponResult }
                                        : { coupon: couponResult },
                                },
                            });
                        }
                    }
                }
                return order;
            });
            return result;
        }
        catch (error) {
            console.error('创建订单失败:', error);
            throw error;
        }
    }
    async findAll(params) {
        const { page = 1, pageSize = 20, ...searchParams } = params || {};
        const pageNum = Number(page);
        const pageSizeNum = Number(pageSize);
        const where = {};
        const validOrderStatuses = ['PENDING', 'CONFIRMED', 'REJECTED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'];
        const validPaymentStatuses = ['PENDING_PAYMENT', 'PARTIAL_PAID', 'FULLY_PAID', 'REFUNDING', 'PARTIAL_REFUNDED', 'REFUNDED', 'CANCELLED'];
        if (searchParams.orderStatus && validOrderStatuses.includes(searchParams.orderStatus)) {
            where.orderStatus = searchParams.orderStatus;
        }
        if (searchParams.status) {
            if (validOrderStatuses.includes(searchParams.status)) {
                where.orderStatus = searchParams.status;
            }
            else if (searchParams.status === 'REFUNDED') {
                where.paymentStatus = 'REFUNDED';
            }
        }
        if (searchParams.paymentStatus && validPaymentStatuses.includes(searchParams.paymentStatus)) {
            where.paymentStatus = searchParams.paymentStatus;
        }
        if (searchParams.userId) {
            where.userId = Number(searchParams.userId);
        }
        if (searchParams.packageId) {
            where.packageId = Number(searchParams.packageId);
        }
        if (searchParams.keyword) {
            where.OR = [
                {
                    orderNo: {
                        contains: searchParams.keyword,
                        mode: 'insensitive',
                    },
                },
                {
                    customerPhone: {
                        contains: searchParams.keyword,
                        mode: 'insensitive',
                    },
                },
                {
                    customerName: {
                        contains: searchParams.keyword,
                        mode: 'insensitive',
                    },
                },
                {
                    user: {
                        phone: {
                            contains: searchParams.keyword,
                            mode: 'insensitive',
                        },
                    },
                },
                {
                    user: {
                        nickname: {
                            contains: searchParams.keyword,
                            mode: 'insensitive',
                        },
                    },
                },
            ];
        }
        if (searchParams.orderNo && !searchParams.keyword) {
            where.orderNo = {
                contains: searchParams.orderNo,
                mode: 'insensitive',
            };
        }
        if (searchParams.phone && !searchParams.keyword) {
            where.OR = [
                { customerPhone: { contains: searchParams.phone, mode: 'insensitive' } },
                { user: { phone: { contains: searchParams.phone, mode: 'insensitive' } } },
            ];
        }
        if (searchParams.startDate || searchParams.endDate) {
            where.createdAt = {};
            if (searchParams.startDate) {
                where.createdAt.gte = new Date(searchParams.startDate);
            }
            if (searchParams.endDate) {
                where.createdAt.lte = new Date(searchParams.endDate);
            }
        }
        const skip = (pageNum - 1) * pageSizeNum;
        const take = pageSizeNum;
        const total = await this.prisma.order.count({ where });
        const orders = await this.prisma.order.findMany({
            where,
            include: {
                user: true,
                package: true,
                diyPackage: true,
                timeSlot: true,
                payments: true,
            },
            orderBy: {
                createdAt: 'desc',
            },
            skip,
            take,
        });
        return {
            list: orders,
            pagination: {
                current: pageNum,
                pageSize: pageSizeNum,
                total,
            },
        };
    }
    async findOne(id) {
        const order = await this.prisma.order.findUnique({
            where: { id },
            include: {
                user: true,
                package: true,
                diyPackage: true,
                timeSlot: true,
                payments: true,
            },
        });
        if (!order) {
            throw new common_1.NotFoundException(`Order with id ${id} not found`);
        }
        return order;
    }
    async findByOrderNo(orderNo) {
        const order = await this.prisma.order.findUnique({
            where: { orderNo },
            include: {
                user: true,
                package: true,
                diyPackage: true,
                timeSlot: true,
                payments: true,
            },
        });
        if (!order) {
            throw new common_1.NotFoundException(`Order with order number ${orderNo} not found`);
        }
        return order;
    }
    async findByUserOpenid(userOpenid) {
        return await this.prisma.order.findMany({
            where: {
                user: {
                    openid: userOpenid,
                },
            },
            include: {
                package: true,
                diyPackage: true,
                timeSlot: true,
                payments: true,
            },
            orderBy: { createdAt: 'desc' },
        });
    }
    async update(id, updateOrderDto) {
        const existingOrder = await this.findOne(id);
        const statusChangeLogs = [];
        const result = await this.prisma.$transaction(async (prisma) => {
            if (updateOrderDto.timeSlotId &&
                updateOrderDto.timeSlotId !== existingOrder.timeSlotId) {
                const newTimeSlot = await prisma.timeSlot.findUnique({
                    where: { id: updateOrderDto.timeSlotId },
                    include: {
                        _count: {
                            select: { orders: true }
                        }
                    }
                });
                if (!newTimeSlot) {
                    throw new common_1.NotFoundException(`TimeSlot with id ${updateOrderDto.timeSlotId} not found`);
                }
                const currentBookedCount = newTimeSlot._count?.orders;
                if (currentBookedCount >= newTimeSlot.capacity) {
                    throw new common_1.BadRequestException(`时间槽容量已满，当前预订 ${currentBookedCount}/${newTimeSlot.capacity}`);
                }
                if (newTimeSlot.status === 'UNAVAILABLE') {
                    throw new common_1.BadRequestException('时间槽当前不可用');
                }
                if (existingOrder.timeSlotId) {
                    const oldTimeSlot = await prisma.timeSlot.findUnique({
                        where: { id: existingOrder.timeSlotId },
                        include: {
                            _count: {
                                select: { orders: true }
                            }
                        }
                    });
                    if (oldTimeSlot) {
                        const oldNewBookedCount = Math.max(0, oldTimeSlot._count?.orders - 1);
                        const oldIsFullyBooked = oldNewBookedCount >= oldTimeSlot.capacity;
                        await prisma.timeSlot.update({
                            where: { id: existingOrder.timeSlotId },
                            data: {
                                bookedCount: oldNewBookedCount,
                                availableCount: Math.max(0, oldTimeSlot.capacity - oldNewBookedCount),
                                isBooked: oldIsFullyBooked,
                                status: oldIsFullyBooked ? 'BOOKED' : 'AVAILABLE'
                            },
                        });
                    }
                }
                const newNewBookedCount = currentBookedCount + 1;
                const newIsFullyBooked = newNewBookedCount >= newTimeSlot.capacity;
                await prisma.timeSlot.update({
                    where: { id: updateOrderDto.timeSlotId },
                    data: {
                        bookedCount: newNewBookedCount,
                        availableCount: Math.max(0, newTimeSlot.capacity - newNewBookedCount),
                        isBooked: newIsFullyBooked,
                        status: newIsFullyBooked ? 'BOOKED' : 'AVAILABLE'
                    },
                });
            }
            const updateData = {};
            let newOrderStatus = existingOrder.orderStatus;
            let newPaymentStatus = existingOrder.paymentStatus;
            if (updateOrderDto.orderStatus !== undefined) {
                newOrderStatus = updateOrderDto.orderStatus;
                updateData.orderStatus = updateOrderDto.orderStatus;
            }
            if (updateOrderDto.paymentStatus !== undefined) {
                newPaymentStatus = updateOrderDto.paymentStatus;
                updateData.paymentStatus = updateOrderDto.paymentStatus;
            }
            order_status_validator_1.OrderStatusValidator.validateAndThrow(newOrderStatus, newPaymentStatus, id);
            const currentOrderStatus = existingOrder.orderStatus;
            const currentPaymentStatus = existingOrder.paymentStatus;
            if (!order_status_validator_1.OrderStatusValidator.isValidTransition(currentOrderStatus, currentPaymentStatus, newOrderStatus, newPaymentStatus)) {
                throw new common_1.BadRequestException(`不允许的状态转换: ${order_status_validator_1.OrderStatusValidator.getStatusCombinationDescription(currentOrderStatus, currentPaymentStatus)} → ${order_status_validator_1.OrderStatusValidator.getStatusCombinationDescription(newOrderStatus, newPaymentStatus)}`);
            }
            if (updateOrderDto.orderStatus !== undefined && updateOrderDto.orderStatus !== existingOrder.orderStatus) {
                statusChangeLogs.push({
                    orderId: id,
                    fieldName: 'orderStatus',
                    oldValue: existingOrder.orderStatus,
                    newValue: updateOrderDto.orderStatus,
                    operator: updateOrderDto.operator || 'system',
                    reason: updateOrderDto.reason || '管理员操作',
                });
            }
            if (updateOrderDto.paymentStatus !== undefined && updateOrderDto.paymentStatus !== existingOrder.paymentStatus) {
                statusChangeLogs.push({
                    orderId: id,
                    fieldName: 'paymentStatus',
                    oldValue: existingOrder.paymentStatus,
                    newValue: updateOrderDto.paymentStatus,
                    operator: updateOrderDto.operator || 'system',
                    reason: updateOrderDto.reason || '管理员操作',
                });
            }
            if (updateOrderDto.notes !== undefined) {
                updateData.notes = updateOrderDto.notes;
            }
            if (updateOrderDto.appointmentDate !== undefined) {
                updateData.appointmentDate = new Date(updateOrderDto.appointmentDate);
            }
            if (updateOrderDto.totalAmount !== undefined) {
                updateData.totalAmount = updateOrderDto.totalAmount;
            }
            if (updateOrderDto.depositAmount !== undefined) {
                updateData.depositAmount = updateOrderDto.depositAmount;
            }
            if (updateOrderDto.paidAmount !== undefined) {
                updateData.paidAmount = updateOrderDto.paidAmount;
            }
            if (updateOrderDto.childrenCount !== undefined) {
                updateData.childrenCount = updateOrderDto.childrenCount;
            }
            if (updateOrderDto.customerName !== undefined) {
                updateData.customerName = updateOrderDto.customerName;
            }
            if (updateOrderDto.customerPhone !== undefined) {
                updateData.customerPhone = updateOrderDto.customerPhone;
            }
            if (updateOrderDto.timeSlotId !== undefined) {
                updateData.timeSlotId = updateOrderDto.timeSlotId;
            }
            const updatedOrder = await prisma.order.update({
                where: { id },
                data: updateData,
                include: {
                    user: true,
                    package: true,
                    timeSlot: true,
                    payments: true,
                },
            });
            return updatedOrder;
        });
        if (statusChangeLogs.length > 0) {
            Promise.all(statusChangeLogs.map(log => this.statusChangeLogService.logStatusChange(log))).catch(error => {
                console.error('记录状态变更日志失败:', error);
            });
        }
        return result;
    }
    async findByPhone(phone) {
        try {
            const orders = await this.prisma.order.findMany({
                where: {
                    user: {
                        phone: phone,
                    },
                },
                include: {
                    user: true,
                    package: true,
                    timeSlot: true,
                    payments: true,
                },
                orderBy: {
                    createdAt: 'desc',
                },
            });
            return orders;
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to find orders by phone: ${errorMessage}`);
        }
    }
    async findByPaymentStatus(paymentStatus) {
        try {
            const orders = await this.prisma.order.findMany({
                where: {
                    paymentStatus: paymentStatus,
                },
                include: {
                    user: true,
                    package: true,
                    timeSlot: true,
                    payments: true,
                },
                orderBy: {
                    createdAt: 'desc',
                },
            });
            const totalOrders = orders.length;
            const totalAmount = orders.reduce((sum, order) => sum + Number(order.totalAmount), 0);
            const totalPaidAmount = orders.reduce((sum, order) => sum + Number(order.paidAmount), 0);
            return {
                orders,
                statistics: {
                    totalOrders,
                    totalAmount,
                    totalPaidAmount,
                    paymentStatus,
                },
            };
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to find orders by payment status: ${errorMessage}`);
        }
    }
    async getStats() {
        try {
            const totalOrders = await this.prisma.order.count();
            const [pendingOrders, paidOrders, cancelledOrders, completedOrders] = await Promise.all([
                this.prisma.order.count({ where: { orderStatus: status_enum_1.OrderStatus.PENDING } }),
                this.prisma.order.count({ where: { orderStatus: status_enum_1.OrderStatus.COMPLETED } }),
                this.prisma.order.count({ where: { orderStatus: status_enum_1.OrderStatus.CANCELLED } }),
                this.prisma.order.count({ where: { orderStatus: status_enum_1.OrderStatus.COMPLETED } }),
            ]);
            const totalRevenue = await this.prisma.order.aggregate({
                where: { orderStatus: { not: status_enum_1.OrderStatus.CANCELLED } },
                _sum: { totalAmount: true },
            });
            const paidAmount = await this.prisma.order.aggregate({
                where: { paymentStatus: status_enum_1.PaymentStatus.FULLY_PAID },
                _sum: { paidAmount: true },
            });
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const tomorrow = new Date(today);
            tomorrow.setDate(tomorrow.getDate() + 1);
            const todayOrders = await this.prisma.order.count({
                where: {
                    createdAt: {
                        gte: today,
                        lt: tomorrow,
                    },
                },
            });
            const conversionRate = totalOrders > 0 ? (completedOrders / totalOrders) * 100 : 0;
            return {
                totalOrders,
                pendingOrders,
                confirmedOrders: paidOrders,
                completedOrders,
                cancelledOrders,
                totalRevenue: totalRevenue._sum?.totalAmount || 0,
                paidAmount: paidAmount._sum?.paidAmount || 0,
                todayOrders,
                conversionRate,
            };
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to get order statistics: ${errorMessage}`);
        }
    }
    async getOrderTrends(period, startDateParam, endDateParam) {
        try {
            let startDate;
            let endDate;
            if (startDateParam && endDateParam) {
                startDate = new Date(startDateParam);
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date(endDateParam);
                endDate.setHours(23, 59, 59, 999);
            }
            else {
                const now = new Date();
                const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
                let daysToSubtract = 6;
                switch (period) {
                    case '7d':
                        daysToSubtract = 6;
                        break;
                    case '30d':
                        daysToSubtract = 29;
                        break;
                    case '90d':
                        daysToSubtract = 89;
                        break;
                    default:
                        daysToSubtract = 6;
                }
                startDate = new Date(today);
                startDate.setDate(today.getDate() - daysToSubtract);
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date(today);
                endDate.setHours(23, 59, 59, 999);
            }
            console.log('[OrderTrends] Period:', period);
            console.log('[OrderTrends] Date Range:', startDateParam && endDateParam ? 'Custom' : period);
            console.log('[OrderTrends] Start Date:', startDate.toISOString());
            console.log('[OrderTrends] End Date:', endDate.toISOString());
            const dates = [];
            const currentDate = new Date(startDate);
            while (currentDate <= endDate) {
                const year = currentDate.getFullYear();
                const month = String(currentDate.getMonth() + 1).padStart(2, '0');
                const day = String(currentDate.getDate()).padStart(2, '0');
                const dateStr = `${year}-${month}-${day}`;
                dates.push(dateStr);
                currentDate.setDate(currentDate.getDate() + 1);
            }
            console.log('[OrderTrends] Generated dates:', dates);
            console.log('[OrderTrends] Date count:', dates.length);
            const orders = await this.prisma.order.findMany({
                where: {
                    createdAt: {
                        gte: startDate,
                        lte: endDate,
                    },
                    orderStatus: { not: 'CANCELLED' },
                },
                select: {
                    createdAt: true,
                    totalAmount: true,
                },
            });
            console.log('[OrderTrends] Found orders:', orders.length);
            const trendData = {};
            dates.forEach(date => {
                trendData[date] = { orders: 0, revenue: 0 };
            });
            orders.forEach(order => {
                const orderDate = order.createdAt;
                const year = orderDate.getFullYear();
                const month = String(orderDate.getMonth() + 1).padStart(2, '0');
                const day = String(orderDate.getDate()).padStart(2, '0');
                const date = `${year}-${month}-${day}`;
                if (trendData[date]) {
                    trendData[date].orders += 1;
                    trendData[date].revenue += Number(order.totalAmount || 0);
                }
            });
            const result = dates.map(date => ({
                date,
                orders: trendData[date].orders,
                revenue: trendData[date].revenue,
            }));
            console.log('[OrderTrends] Result summary:', result.map(r => `${r.date}: ${r.orders} orders`).join(', '));
            return result;
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to get order trends: ${errorMessage}`);
        }
    }
    async getFutureOrderTrends(period, startDateParam, endDateParam) {
        try {
            let startDate;
            let endDate;
            if (startDateParam && endDateParam) {
                startDate = new Date(startDateParam);
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date(endDateParam);
                endDate.setHours(23, 59, 59, 999);
            }
            else {
                const now = new Date();
                const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
                let daysToAdd = 6;
                switch (period) {
                    case '7d':
                        daysToAdd = 6;
                        break;
                    case '30d':
                        daysToAdd = 29;
                        break;
                    case '90d':
                        daysToAdd = 89;
                        break;
                    default:
                        daysToAdd = 6;
                }
                startDate = new Date(today);
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date(today);
                endDate.setDate(today.getDate() + daysToAdd);
                endDate.setHours(23, 59, 59, 999);
            }
            console.log('[FutureOrderTrends] Period:', period);
            console.log('[FutureOrderTrends] Date Range:', startDateParam && endDateParam ? 'Custom' : period);
            console.log('[FutureOrderTrends] Start Date:', startDate.toISOString());
            console.log('[FutureOrderTrends] End Date:', endDate.toISOString());
            const dates = [];
            const currentDate = new Date(startDate);
            while (currentDate <= endDate) {
                const year = currentDate.getFullYear();
                const month = String(currentDate.getMonth() + 1).padStart(2, '0');
                const day = String(currentDate.getDate()).padStart(2, '0');
                const dateStr = `${year}-${month}-${day}`;
                dates.push(dateStr);
                currentDate.setDate(currentDate.getDate() + 1);
            }
            console.log('[FutureOrderTrends] Generated dates:', dates);
            console.log('[FutureOrderTrends] Date count:', dates.length);
            const orders = await this.prisma.order.findMany({
                where: {
                    orderStatus: { not: 'CANCELLED' },
                    appointmentDate: {
                        gte: startDate,
                        lte: endDate,
                    },
                },
                select: {
                    totalAmount: true,
                    orderStatus: true,
                    appointmentDate: true,
                },
            });
            console.log('[FutureOrderTrends] Found future orders:', orders.length);
            console.log('[FutureOrderTrends] Order details:', orders.map(o => ({
                amount: o.totalAmount.toString(),
                status: o.orderStatus,
                appointmentDate: o.appointmentDate,
            })));
            const trendData = {};
            dates.forEach(date => {
                trendData[date] = { orders: 0, revenue: 0 };
            });
            orders.forEach(order => {
                if (order.appointmentDate) {
                    const appointmentDate = order.appointmentDate;
                    const year = appointmentDate.getFullYear();
                    const month = String(appointmentDate.getMonth() + 1).padStart(2, '0');
                    const day = String(appointmentDate.getDate()).padStart(2, '0');
                    const date = `${year}-${month}-${day}`;
                    if (trendData[date]) {
                        trendData[date].orders += 1;
                        trendData[date].revenue += Number(order.totalAmount || 0);
                    }
                }
            });
            const result = dates.map(date => ({
                date,
                orders: trendData[date].orders,
                revenue: trendData[date].revenue,
            }));
            console.log('[FutureOrderTrends] Result summary:', result.map(r => `${r.date}: ${r.orders} orders`).join(', '));
            return result;
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to get future order trends: ${errorMessage}`);
        }
    }
    async cancelOrder(id, reason) {
        const existingOrder = await this.findOne(id);
        if (existingOrder.orderStatus === 'COMPLETED') {
            throw new common_1.BadRequestException('已完成的订单不能取消');
        }
        if (existingOrder.orderStatus === 'CANCELLED') {
            throw new common_1.BadRequestException('订单已经被取消');
        }
        const result = await this.prisma.$transaction(async (prisma) => {
            if (existingOrder.timeSlotId) {
                const currentTimeSlot = await prisma.timeSlot.findUnique({
                    where: { id: existingOrder.timeSlotId },
                    include: {
                        _count: {
                            select: { orders: true }
                        }
                    }
                });
                if (currentTimeSlot) {
                    const newBookedCount = Math.max(0, currentTimeSlot._count?.orders - 1);
                    const isFullyBooked = newBookedCount >= currentTimeSlot.capacity;
                    await prisma.timeSlot.update({
                        where: { id: existingOrder.timeSlotId },
                        data: {
                            bookedCount: newBookedCount,
                            availableCount: Math.max(0, currentTimeSlot.capacity - newBookedCount),
                            isBooked: isFullyBooked,
                            status: isFullyBooked ? 'BOOKED' : 'AVAILABLE'
                        },
                    });
                }
            }
            const cancelledOrder = await prisma.order.update({
                where: { id },
                data: {
                    orderStatus: status_enum_1.OrderStatus.CANCELLED,
                    paymentStatus: status_enum_1.PaymentStatus.CANCELLED,
                    notes: reason ? `${existingOrder.notes || ''}\n取消原因: ${reason}`.trim() : existingOrder.notes
                },
                include: {
                    user: true,
                    package: true,
                    timeSlot: true,
                    payments: true,
                },
            });
            return cancelledOrder;
        });
        return result;
    }
    async confirmOrder(id) {
        const existingOrder = await this.findOne(id);
        if (existingOrder.orderStatus !== 'PENDING') {
            throw new common_1.BadRequestException('只有待确认的订单才能确认');
        }
        const confirmedOrder = await this.prisma.order.update({
            where: { id },
            data: {
                orderStatus: 'CONFIRMED'
            },
            include: {
                user: true,
                package: true,
                timeSlot: true,
                payments: true,
                wxUser: true,
            },
        });
        this.automationRulesService.evaluate('APPOINTMENT_CONFIRMED', { order: confirmedOrder, wxUser: confirmedOrder.wxUser })
            .catch((err) => console.error('自动化规则执行失败', err));
        return confirmedOrder;
    }
    async completeOrder(id) {
        const existingOrder = await this.findOne(id);
        const allowedStatuses = ['PENDING', 'CONFIRMED', 'IN_PROGRESS'];
        if (!allowedStatuses.includes(existingOrder.orderStatus)) {
            throw new common_1.BadRequestException(`订单状态为 ${existingOrder.orderStatus}，无法完成。只有待确认、已确认或进行中的订单才能完成。`);
        }
        if (existingOrder.paymentStatus === 'PENDING_PAYMENT') {
            throw new common_1.BadRequestException(`订单 ${existingOrder.orderNo} 尚未支付，无法完成。请先确认收款后再操作。`);
        }
        const completedOrder = await this.prisma.order.update({
            where: { id },
            data: {
                orderStatus: status_enum_1.OrderStatus.COMPLETED,
                completedAt: new Date(),
                checkinStatus: 'CHECKED_IN',
                checkinTime: new Date(),
            },
            include: {
                user: true,
                package: true,
                timeSlot: true,
                payments: true,
                wxUser: true,
            },
        });
        this.automationRulesService.evaluate('ORDER_COMPLETED', { order: completedOrder, wxUser: completedOrder.wxUser })
            .catch((err) => console.error('自动化规则执行失败', err));
        return completedOrder;
    }
    async batchOperate(operation, orderIds) {
        if (!orderIds || orderIds.length === 0) {
            throw new common_1.BadRequestException('请选择要操作的订单');
        }
        const results = [];
        const errors = [];
        for (const orderId of orderIds) {
            try {
                let result;
                switch (operation) {
                    case 'cancel':
                        result = await this.cancelOrder(orderId, '批量取消操作');
                        break;
                    case 'confirm':
                        result = await this.confirmOrder(orderId);
                        break;
                    case 'complete':
                        result = await this.completeOrder(orderId);
                        break;
                    default:
                        throw new common_1.BadRequestException(`不支持的操作: ${operation}`);
                }
                results.push({ orderId, success: true, data: result });
            }
            catch (error) {
                const errorMessage = error instanceof Error ? error.message : 'Unknown error';
                errors.push({ orderId, success: false, error: errorMessage });
            }
        }
        return {
            success: errors.length === 0,
            totalCount: orderIds.length,
            successCount: results.length,
            errorCount: errors.length,
            results,
            errors,
        };
    }
    async deleteOrder(id) {
        const existingOrder = await this.findOne(id);
        if (existingOrder.orderStatus !== 'CANCELLED') {
            throw new common_1.BadRequestException('只有已取消的订单才能删除');
        }
        const result = await this.prisma.$transaction(async (prisma) => {
            if (existingOrder.timeSlotId) {
                const currentTimeSlot = await prisma.timeSlot.findUnique({
                    where: { id: existingOrder.timeSlotId },
                    include: {
                        _count: {
                            select: { orders: true }
                        }
                    }
                });
                if (currentTimeSlot) {
                    const newBookedCount = Math.max(0, currentTimeSlot._count?.orders - 1);
                    const isFullyBooked = newBookedCount >= currentTimeSlot.capacity;
                    await prisma.timeSlot.update({
                        where: { id: existingOrder.timeSlotId },
                        data: {
                            bookedCount: newBookedCount,
                            availableCount: Math.max(0, currentTimeSlot.capacity - newBookedCount),
                            isBooked: isFullyBooked,
                            status: isFullyBooked ? 'BOOKED' : 'AVAILABLE'
                        },
                    });
                }
            }
            await prisma.payment.deleteMany({
                where: { orderId: id },
            });
            const deletedOrder = await prisma.order.delete({
                where: { id },
            });
            return deletedOrder;
        });
        return result;
    }
    async checkin(orderId, dto) {
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
            include: { timeSlot: true },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        if (order.checkinStatus === 'CHECKED_IN') {
            throw new common_1.BadRequestException('该订单已签到');
        }
        if (order.checkinStatus === 'NO_SHOW') {
            throw new common_1.BadRequestException('该订单已标记为缺席');
        }
        return this.prisma.$transaction(async (prisma) => {
            if (dto.status === 'NO_SHOW' && order.timeSlotId) {
                const ts = order.timeSlot;
                if (ts) {
                    const newBooked = Math.max(0, ts.bookedCount - 1);
                    await prisma.timeSlot.update({
                        where: { id: order.timeSlotId },
                        data: {
                            bookedCount: newBooked,
                            availableCount: Math.max(0, ts.capacity - newBooked),
                            isBooked: newBooked > 0,
                        },
                    });
                }
            }
            return prisma.order.update({
                where: { id: orderId },
                data: {
                    checkinStatus: dto.status,
                    checkinTime: dto.status === 'CHECKED_IN' ? new Date() : null,
                },
                select: { id: true, orderNo: true, checkinStatus: true, checkinTime: true },
            });
        });
    }
    async getScheduleBoardRange(startDate, endDate, photographerId) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        const where = {
            appointmentDate: { gte: start, lte: end },
            orderStatus: { notIn: ['CANCELLED', 'REJECTED'] },
        };
        if (photographerId)
            where.photographerId = photographerId;
        const orders = await this.prisma.order.findMany({
            where,
            include: {
                timeSlot: true,
                wxUser: { select: { nickname: true, phone: true, avatar: true } },
                package: { select: { name: true } },
                photographer: { select: { id: true, nickname: true } },
            },
            orderBy: { appointmentDate: 'asc' },
        });
        const grouped = {};
        for (const order of orders) {
            const slotId = order.timeSlotId || 0;
            if (!grouped[slotId]) {
                grouped[slotId] = { timeSlot: order.timeSlot, orders: [] };
            }
            grouped[slotId].orders.push(order);
        }
        return Object.values(grouped).sort((a, b) => {
            const aTime = a.timeSlot?.startTime?.getTime?.() || 0;
            const bTime = b.timeSlot?.startTime?.getTime?.() || 0;
            return aTime - bTime;
        });
    }
    async getScheduleBoard(date, photographerId) {
        return this.getScheduleBoardRange(date, date, photographerId);
    }
    async assignPhotographer(orderId, photographerId) {
        const order = await this.prisma.order.findUnique({ where: { id: orderId } });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        const photographer = await this.prisma.user.findUnique({ where: { id: photographerId } });
        if (!photographer)
            throw new common_1.NotFoundException('Photographer not found');
        return this.prisma.order.update({
            where: { id: orderId },
            data: { photographerId },
            select: { id: true, orderNo: true, photographerId: true },
        });
    }
    async batchAssignPhotographer(orderIds, photographerId) {
        const photographer = await this.prisma.user.findUnique({ where: { id: photographerId } });
        if (!photographer)
            throw new common_1.NotFoundException('Photographer not found');
        const result = await this.prisma.order.updateMany({
            where: { id: { in: orderIds } },
            data: { photographerId },
        });
        return { updated: result.count };
    }
    async rescheduleOrder(orderId, timeSlotId) {
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
            select: { id: true, orderNo: true, timeSlotId: true },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        const newSlot = await this.prisma.timeSlot.findUnique({
            where: { id: timeSlotId },
        });
        if (!newSlot)
            throw new common_1.NotFoundException('TimeSlot not found');
        if (newSlot.bookedCount >= newSlot.capacity) {
            throw new common_1.BadRequestException('TimeSlot is fully booked');
        }
        return this.prisma.$transaction(async (tx) => {
            if (order.timeSlotId) {
                await tx.timeSlot.update({
                    where: { id: order.timeSlotId },
                    data: { bookedCount: { decrement: 1 }, isBooked: false },
                });
            }
            await tx.timeSlot.update({
                where: { id: timeSlotId },
                data: { bookedCount: { increment: 1 }, isBooked: true },
            });
            return tx.order.update({
                where: { id: orderId },
                data: { timeSlotId, appointmentDate: newSlot.date },
                select: { id: true, orderNo: true, timeSlotId: true, appointmentDate: true },
            });
        });
    }
    generateOrderNo() {
        const date = new Date();
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const random = Math.floor(Math.random() * 10000)
            .toString()
            .padStart(4, '0');
        return `ORD${year}${month}${day}${random}`;
    }
    async getCashFlowTrends(startDateParam, endDateParam) {
        try {
            const startDate = new Date(startDateParam);
            startDate.setHours(0, 0, 0, 0);
            const endDate = new Date(endDateParam);
            endDate.setHours(23, 59, 59, 999);
            console.log('[CashFlowTrends] Start Date:', startDate.toISOString());
            console.log('[CashFlowTrends] End Date:', endDate.toISOString());
            const dates = [];
            const currentDate = new Date(startDate);
            while (currentDate <= endDate) {
                const year = currentDate.getFullYear();
                const month = String(currentDate.getMonth() + 1).padStart(2, '0');
                const day = String(currentDate.getDate()).padStart(2, '0');
                dates.push(`${year}-${month}-${day}`);
                currentDate.setDate(currentDate.getDate() + 1);
            }
            console.log('[CashFlowTrends] Generated dates:', dates);
            console.log('[CashFlowTrends] Date count:', dates.length);
            const orders = await this.prisma.order.findMany({
                where: {
                    appointmentDate: {
                        gte: startDate,
                        lte: endDate,
                    },
                },
                include: {
                    payments: true,
                },
            });
            console.log('[CashFlowTrends] Found orders:', orders.length);
            const refundRequests = await this.prisma.refundRequest.findMany({
                where: {
                    createdAt: {
                        gte: startDate,
                        lte: endDate,
                    },
                },
            });
            console.log('[CashFlowTrends] Found refund requests:', refundRequests.length);
            const cashFlowMap = new Map();
            dates.forEach(date => {
                cashFlowMap.set(date, {
                    totalAmount: 0,
                    paidAmount: 0,
                    unpaidAmount: 0,
                    refundRequested: 0,
                    refundCompleted: 0,
                });
            });
            orders.forEach(order => {
                const orderDate = order.appointmentDate ? new Date(order.appointmentDate) : new Date(order.createdAt);
                const year = orderDate.getFullYear();
                const month = String(orderDate.getMonth() + 1).padStart(2, '0');
                const day = String(orderDate.getDate()).padStart(2, '0');
                const dateKey = `${year}-${month}-${day}`;
                if (cashFlowMap.has(dateKey)) {
                    const data = cashFlowMap.get(dateKey);
                    const totalAmt = Number(order.totalAmount) || 0;
                    const paidAmt = Number(order.paidAmount) || 0;
                    data.totalAmount += totalAmt;
                    data.paidAmount += paidAmt;
                    data.unpaidAmount += Math.max(0, totalAmt - paidAmt);
                    data.refundCompleted += Number(order.refundedAmount) || 0;
                }
            });
            refundRequests.forEach(refund => {
                const refundDate = new Date(refund.createdAt);
                const year = refundDate.getFullYear();
                const month = String(refundDate.getMonth() + 1).padStart(2, '0');
                const day = String(refundDate.getDate()).padStart(2, '0');
                const dateKey = `${year}-${month}-${day}`;
                if (cashFlowMap.has(dateKey)) {
                    const data = cashFlowMap.get(dateKey);
                    data.refundRequested += Number(refund.refundAmount) || 0;
                }
            });
            const result = dates.map(date => ({
                date,
                totalAmount: cashFlowMap.get(date)?.totalAmount || 0,
                paidAmount: cashFlowMap.get(date)?.paidAmount || 0,
                unpaidAmount: cashFlowMap.get(date)?.unpaidAmount || 0,
                refundRequested: cashFlowMap.get(date)?.refundRequested || 0,
                refundCompleted: cashFlowMap.get(date)?.refundCompleted || 0,
            }));
            console.log('[CashFlowTrends] Result summary:', result.map(r => `${r.date}: 总额${r.totalAmount}, 已收${r.paidAmount}, 未收${r.unpaidAmount}`).join(', '));
            return result;
        }
        catch (error) {
            console.error('获取订单资金流趋势失败:', error);
            throw error;
        }
    }
    async changePackage(orderId, dto) {
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
            include: { payments: true },
        });
        if (!order)
            throw new common_1.NotFoundException('订单不存在');
        const newPackage = await this.prisma.package.findUnique({ where: { id: dto.newPackageId } });
        if (!newPackage)
            throw new common_1.NotFoundException('新套餐不存在');
        const paidAmount = Number(order.paidAmount);
        const appointmentDate = order.appointmentDate || new Date();
        const pricing = await this.packagesService.calculatePrice(dto.newPackageId, appointmentDate);
        const newTotalAmount = pricing.finalPrice;
        const priceDiff = Math.round((newTotalAmount - paidAmount) * 100) / 100;
        const result = await this.prisma.$transaction(async (prisma) => {
            const updated = await prisma.order.update({
                where: { id: orderId },
                data: {
                    packageId: dto.newPackageId,
                    totalAmount: newTotalAmount,
                    paymentSummary: order.paymentSummary
                        ? { ...order.paymentSummary, packageChange: { oldPackageId: order.packageId, newPackageId: dto.newPackageId, priceDiff, reason: dto.reason } }
                        : { packageChange: { oldPackageId: order.packageId, newPackageId: dto.newPackageId, priceDiff, reason: dto.reason } },
                },
            });
            if (priceDiff > 0) {
                await prisma.payment.create({
                    data: {
                        orderId,
                        amount: priceDiff,
                        paymentType: 'FULL',
                        paymentMethod: 'WECHAT_PAY',
                        status: 'PENDING_PAYMENT',
                        notes: `升级套餐补差价: ¥${priceDiff}`,
                    },
                });
            }
            else if (priceDiff < 0) {
                await prisma.refund.create({
                    data: {
                        refundRequestId: '',
                        orderId,
                        originalPaymentId: '',
                        refundAmount: Math.abs(priceDiff),
                        refundType: 'PARTIAL',
                        refundMethod: 'ORIGINAL',
                        notes: `降级套餐退差价: ¥${Math.abs(priceDiff)}`,
                    },
                });
            }
            return updated;
        });
        return { code: 200, message: priceDiff > 0 ? '升级成功，需补差价' : priceDiff < 0 ? '降级成功，将退还差价' : '套餐更换成功', data: result };
    }
    async redeemCouponInternal(prisma, couponId, wxUserId, orderId, totalAmount) {
        const userCoupon = await prisma.userCoupon.findFirst({
            where: { wxUserId, couponId, status: 'UNUSED' },
            include: { coupon: true },
        });
        if (!userCoupon)
            throw new common_1.BadRequestException('优惠券不存在或已使用');
        if (new Date() > userCoupon.expiredAt)
            throw new common_1.BadRequestException('优惠券已过期');
        const coupon = userCoupon.coupon;
        if (coupon.status !== 'ACTIVE')
            throw new common_1.BadRequestException('优惠券已失效');
        if (new Date() < coupon.startTime)
            throw new common_1.BadRequestException('优惠券尚未生效');
        if (new Date() > coupon.endTime)
            throw new common_1.BadRequestException('优惠券已过期');
        const minAmount = coupon.minAmount ? Number(coupon.minAmount) : 0;
        if (totalAmount < minAmount) {
            throw new common_1.BadRequestException(`订单金额未达到最低消费 ¥${minAmount}`);
        }
        let discountAmount = 0;
        const discountValue = Number(coupon.discountValue);
        if (coupon.discountType === 'PERCENT') {
            discountAmount = (totalAmount * discountValue) / 100;
            const maxDiscount = coupon.maxDiscount ? Number(coupon.maxDiscount) : null;
            if (maxDiscount && discountAmount > maxDiscount) {
                discountAmount = maxDiscount;
            }
        }
        else {
            discountAmount = discountValue;
        }
        discountAmount = Math.min(discountAmount, totalAmount);
        const finalAmount = Math.round((totalAmount - discountAmount) * 100) / 100;
        discountAmount = Math.round(discountAmount * 100) / 100;
        await prisma.userCoupon.update({
            where: { id: userCoupon.id },
            data: { status: 'USED', usedAt: new Date(), orderId },
        });
        await prisma.coupon.update({
            where: { id: couponId },
            data: { usedCount: { increment: 1 } },
        });
        return { discountAmount, finalAmount, couponName: coupon.couponName, discountType: coupon.discountType };
    }
    async applyCoupon(orderId, dto) {
        const order = await this.prisma.order.findUnique({ where: { id: orderId } });
        if (!order)
            throw new common_1.NotFoundException('订单不存在');
        const wxUserId = dto.wxUserId || order.wxUserId;
        if (!wxUserId)
            throw new common_1.BadRequestException('无法确定微信用户');
        const result = await this.prisma.$transaction(async (prisma) => {
            const couponResult = await this.redeemCouponInternal(prisma, dto.couponId, wxUserId, orderId, Number(order.totalAmount));
            return prisma.order.update({
                where: { id: orderId },
                data: {
                    couponId: dto.couponId,
                    discountAmount: couponResult.discountAmount,
                    totalAmount: couponResult.finalAmount,
                    paymentSummary: order.paymentSummary
                        ? { ...order.paymentSummary, coupon: couponResult }
                        : { coupon: couponResult },
                },
            });
        });
        return { code: 200, message: '优惠券应用成功', data: result };
    }
};
exports.OrdersService = OrdersService;
exports.OrdersService = OrdersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        status_change_log_service_1.StatusChangeLogService,
        packages_service_1.PackagesService,
        automation_rules_service_1.AutomationRulesService])
], OrdersService);
//# sourceMappingURL=orders.service.js.map