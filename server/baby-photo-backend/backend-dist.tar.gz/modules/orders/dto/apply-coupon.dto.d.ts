export declare class ApplyCouponDto {
    couponId: string;
    wxUserId?: string;
}
