export declare class UpdateOrderDto {
    packageId?: number;
    timeSlotId?: number;
    appointmentDate?: Date;
    totalAmount?: number;
    depositAmount?: number;
    childrenCount?: number;
    customerName?: string;
    customerPhone?: string;
    notes?: string;
    orderStatus?: string;
    paymentStatus?: string;
    paidAmount?: number;
    operator?: string;
    reason?: string;
}
