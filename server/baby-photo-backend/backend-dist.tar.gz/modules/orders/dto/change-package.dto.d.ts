export declare class ChangePackageDto {
    newPackageId: number;
    reason?: string;
}
