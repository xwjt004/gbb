export declare class CreateOrderDto {
    userOpenid: string;
    packageId?: number;
    diyPackageId?: number;
    timeSlotId?: number;
    appointmentDate?: Date;
    totalAmount: number;
    depositAmount?: number;
    childrenCount?: number;
    customerName?: string;
    customerPhone?: string;
    notes?: string;
    paymentType?: string;
    agreementAccepted?: boolean;
    agreementVersion?: string;
    agreementAcceptedAt?: Date;
    paymentSummary?: Record<string, any>;
    couponId?: string;
    wxUserId?: string;
}
