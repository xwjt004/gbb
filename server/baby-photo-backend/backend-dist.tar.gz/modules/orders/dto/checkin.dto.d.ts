export declare class CheckinDto {
    status: 'CHECKED_IN' | 'NO_SHOW';
}
