export declare class OrdersModule {
}
