export declare class AnalyticsModule {
}
