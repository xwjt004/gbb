"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var LoyaltyAnalyticsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoyaltyAnalyticsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
const cache_service_1 = require("../../../shared/cache/cache.service");
let LoyaltyAnalyticsService = LoyaltyAnalyticsService_1 = class LoyaltyAnalyticsService {
    prisma;
    cacheService;
    logger = new common_1.Logger(LoyaltyAnalyticsService_1.name);
    constructor(prisma, cacheService) {
        this.prisma = prisma;
        this.cacheService = cacheService;
    }
    async getAnalytics(query) {
        const { startDate, endDate } = query;
        try {
            const cacheKey = this.cacheService.getAnalyticsCacheKey('loyalty', `${startDate}-${endDate}`);
            return this.cacheService.getOrSet(cacheKey, async () => {
                const [customerSegmentation, repeatCustomers, loyaltyTrends] = await Promise.all([
                    this.getCustomerSegmentation(),
                    this.getRepeatCustomers(startDate, endDate),
                    this.getLoyaltyTrends(startDate, endDate),
                ]);
                return {
                    code: 200,
                    message: '获取成功',
                    data: {
                        customer_segmentation: customerSegmentation,
                        repeat_customers: repeatCustomers,
                        loyalty_trends: loyaltyTrends,
                        period: { start_date: startDate, end_date: endDate },
                    },
                };
            }, 1800);
        }
        catch (error) {
            this.logger.error(`获取忠诚度分析数据失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getOverviewStats(query) {
        this.logger.debug(`获取忠诚度概览统计数据，查询参数: ${JSON.stringify(query)}`);
        const [totalCustomers, repeatCustomerCount] = await Promise.all([
            this.prisma.user.count(),
            this.getRepeatCustomerCount(),
        ]);
        return {
            total_customers: totalCustomers,
            repeat_customer_count: repeatCustomerCount,
            loyalty_rate: totalCustomers > 0 ? (repeatCustomerCount / totalCustomers) * 100 : 0,
        };
    }
    async getCustomerSegmentation() {
        const result = await this.prisma.user.findMany({
            include: {
                orders: {
                    include: {
                        payments: {
                            where: { status: 'FULLY_PAID' },
                        },
                    },
                },
            },
        });
        const segmentation = {
            vip: 0,
            gold: 0,
            silver: 0,
            regular: 0,
            new: 0,
        };
        result.forEach((user) => {
            const orderCount = user.orders.length;
            const totalSpent = user.orders.reduce((sum, order) => {
                const paidAmount = order.payments.reduce((paySum, payment) => paySum + Number(payment.amount), 0);
                return sum + paidAmount;
            }, 0);
            if (orderCount >= 10 && totalSpent >= 5000) {
                segmentation.vip++;
            }
            else if (orderCount >= 5 && totalSpent >= 2000) {
                segmentation.gold++;
            }
            else if (orderCount >= 2 && totalSpent >= 500) {
                segmentation.silver++;
            }
            else if (orderCount >= 1) {
                segmentation.regular++;
            }
            else {
                segmentation.new++;
            }
        });
        return segmentation;
    }
    async getRepeatCustomers(startDate, endDate) {
        const where = {};
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate)
                where.createdAt.gte = new Date(startDate);
            if (endDate)
                where.createdAt.lte = new Date(endDate);
        }
        const repeatCustomers = await this.prisma.user.findMany({
            where: {
                orders: {
                    some: where,
                },
            },
            include: {
                _count: {
                    select: {
                        orders: true,
                    },
                },
            },
        });
        return repeatCustomers
            .filter((user) => user._count?.orders > 1)
            .map((user) => ({
            user_id: user.openid,
            nickname: user.nickname,
            order_count: user._count?.orders,
        }));
    }
    async getRepeatCustomerCount() {
        const result = await this.prisma.user.findMany({
            include: {
                _count: {
                    select: {
                        orders: true,
                    },
                },
            },
        });
        return result.filter((user) => user._count?.orders > 1).length;
    }
    async getLoyaltyTrends(startDate, endDate) {
        const where = {};
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate)
                where.createdAt.gte = new Date(startDate);
            if (endDate)
                where.createdAt.lte = new Date(endDate);
        }
        const totalCustomers = await this.prisma.user.count();
        const repeatCustomers = await this.getRepeatCustomerCount();
        return [
            {
                period: '本月',
                total_customers: totalCustomers,
                repeat_customers: repeatCustomers,
                loyalty_rate: totalCustomers > 0 ? (repeatCustomers / totalCustomers) * 100 : 0,
            },
        ];
    }
};
exports.LoyaltyAnalyticsService = LoyaltyAnalyticsService;
exports.LoyaltyAnalyticsService = LoyaltyAnalyticsService = LoyaltyAnalyticsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        cache_service_1.CacheService])
], LoyaltyAnalyticsService);
//# sourceMappingURL=loyalty-analytics.service.js.map