import { PrismaService } from '../../../shared/prisma/prisma.service';
import { CacheService } from '../../../shared/cache/cache.service';
export declare class BehaviorAnalyticsService {
    private readonly prisma;
    private readonly cacheService;
    private readonly logger;
    constructor(prisma: PrismaService, cacheService: CacheService);
    getAnalytics(query: any): Promise<{
        code: number;
        message: string;
        data: {
            order_trends: {
                date: string;
                order_count: number;
                total_amount: number;
            }[];
            payment_behavior: {
                total_orders: number;
                paid_orders: number;
                partial_paid_orders: number;
                payment_rate: number;
            };
            conversion_rates: {
                browse_to_order: number;
                order_to_payment: number;
            };
            period: {
                start_date: any;
                end_date: any;
            };
        };
    }>;
    getOverviewStats(query: any): Promise<{
        total_orders: number;
        total_revenue: number;
    }>;
    private buildDateFilter;
    private getOrderTrends;
    private getPaymentBehavior;
    private getConversionRates;
    private getTotalRevenue;
}
