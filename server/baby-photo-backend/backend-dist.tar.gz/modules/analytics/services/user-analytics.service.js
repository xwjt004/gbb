"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var UserAnalyticsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserAnalyticsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
const cache_service_1 = require("../../../shared/cache/cache.service");
const date_util_1 = require("../../../shared/utils/date.util");
let UserAnalyticsService = UserAnalyticsService_1 = class UserAnalyticsService {
    prisma;
    cacheService;
    logger = new common_1.Logger(UserAnalyticsService_1.name);
    constructor(prisma, cacheService) {
        this.prisma = prisma;
        this.cacheService = cacheService;
    }
    async getAnalytics(query) {
        const { startDate, endDate } = query;
        try {
            const cacheKey = this.cacheService.getAnalyticsCacheKey('user', `${startDate}-${endDate}`);
            return this.cacheService.getOrSet(cacheKey, async () => {
                const where = this.buildDateFilter(startDate, endDate);
                const [totalUsers, newUsers, activeUsers, userGrowth] = await Promise.all([
                    this.getTotalUsers(where),
                    this.getNewUsers(where),
                    this.getActiveUsers(where),
                    this.getUserGrowth(where),
                ]);
                return {
                    code: 200,
                    message: '获取成功',
                    data: {
                        total_users: totalUsers,
                        new_users: newUsers,
                        active_users: activeUsers,
                        user_growth: userGrowth,
                        period: { start_date: startDate, end_date: endDate },
                    },
                };
            }, 1800);
        }
        catch (error) {
            this.logger.error(`获取用户分析数据失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getOverviewStats(query) {
        const { startDate, endDate } = query;
        const where = this.buildDateFilter(startDate, endDate);
        const [totalUsers, newUsers] = await Promise.all([
            this.getTotalUsers({}),
            this.getNewUsers(where),
        ]);
        return {
            total_users: totalUsers,
            new_users_period: newUsers,
        };
    }
    buildDateFilter(startDate, endDate) {
        const where = {};
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate)
                where.createdAt.gte = new Date(startDate);
            if (endDate)
                where.createdAt.lte = new Date(endDate);
        }
        return where;
    }
    async getTotalUsers(where) {
        return await this.prisma.user.count({ where });
    }
    async getNewUsers(where) {
        return await this.prisma.user.count({ where });
    }
    async getActiveUsers(where) {
        return await this.prisma.user.count({
            where: {
                orders: {
                    some: where.createdAt ? { createdAt: where.createdAt } : {},
                },
            },
        });
    }
    async getUserGrowth(where) {
        const result = await this.prisma.user.groupBy({
            by: ['createdAt'],
            _count: true,
            where,
            orderBy: {
                createdAt: 'asc',
            },
        });
        return result.map((item) => ({
            date: (0, date_util_1.formatLocalDate)(item.createdAt),
            count: item._count,
        }));
    }
};
exports.UserAnalyticsService = UserAnalyticsService;
exports.UserAnalyticsService = UserAnalyticsService = UserAnalyticsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        cache_service_1.CacheService])
], UserAnalyticsService);
//# sourceMappingURL=user-analytics.service.js.map