import { PrismaService } from '../../../shared/prisma/prisma.service';
import { CacheService } from '../../../shared/cache/cache.service';
export declare class UserAnalyticsService {
    private readonly prisma;
    private readonly cacheService;
    private readonly logger;
    constructor(prisma: PrismaService, cacheService: CacheService);
    getAnalytics(query: any): Promise<{
        code: number;
        message: string;
        data: {
            total_users: number;
            new_users: number;
            active_users: number;
            user_growth: {
                date: string;
                count: number;
            }[];
            period: {
                start_date: any;
                end_date: any;
            };
        };
    }>;
    getOverviewStats(query: any): Promise<{
        total_users: number;
        new_users_period: number;
    }>;
    private buildDateFilter;
    private getTotalUsers;
    private getNewUsers;
    private getActiveUsers;
    private getUserGrowth;
}
