import { PrismaService } from '../../../shared/prisma/prisma.service';
import { CacheService } from '../../../shared/cache/cache.service';
export declare class LoyaltyAnalyticsService {
    private readonly prisma;
    private readonly cacheService;
    private readonly logger;
    constructor(prisma: PrismaService, cacheService: CacheService);
    getAnalytics(query: any): Promise<{
        code: number;
        message: string;
        data: {
            customer_segmentation: {
                vip: number;
                gold: number;
                silver: number;
                regular: number;
                new: number;
            };
            repeat_customers: {
                user_id: string;
                nickname: string | null;
                order_count: number;
            }[];
            loyalty_trends: {
                period: string;
                total_customers: number;
                repeat_customers: number;
                loyalty_rate: number;
            }[];
            period: {
                start_date: any;
                end_date: any;
            };
        };
    }>;
    getOverviewStats(query: any): Promise<{
        total_customers: number;
        repeat_customer_count: number;
        loyalty_rate: number;
    }>;
    private getCustomerSegmentation;
    private getRepeatCustomers;
    private getRepeatCustomerCount;
    private getLoyaltyTrends;
}
