"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var BehaviorAnalyticsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BehaviorAnalyticsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
const cache_service_1 = require("../../../shared/cache/cache.service");
const date_util_1 = require("../../../shared/utils/date.util");
let BehaviorAnalyticsService = BehaviorAnalyticsService_1 = class BehaviorAnalyticsService {
    prisma;
    cacheService;
    logger = new common_1.Logger(BehaviorAnalyticsService_1.name);
    constructor(prisma, cacheService) {
        this.prisma = prisma;
        this.cacheService = cacheService;
    }
    async getAnalytics(query) {
        const { startDate, endDate } = query;
        try {
            const cacheKey = this.cacheService.getAnalyticsCacheKey('behavior', `${startDate}-${endDate}`);
            return this.cacheService.getOrSet(cacheKey, async () => {
                const where = this.buildDateFilter(startDate, endDate);
                const [orderTrends, paymentBehavior, conversionRates] = await Promise.all([
                    this.getOrderTrends(where),
                    this.getPaymentBehavior(where),
                    this.getConversionRates(where),
                ]);
                return {
                    code: 200,
                    message: '获取成功',
                    data: {
                        order_trends: orderTrends,
                        payment_behavior: paymentBehavior,
                        conversion_rates: conversionRates,
                        period: { start_date: startDate, end_date: endDate },
                    },
                };
            }, 1800);
        }
        catch (error) {
            this.logger.error(`获取行为分析数据失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getOverviewStats(query) {
        const { startDate, endDate } = query;
        const where = this.buildDateFilter(startDate, endDate);
        const [totalOrders, totalRevenue] = await Promise.all([
            this.prisma.order.count({ where }),
            this.getTotalRevenue(where),
        ]);
        return {
            total_orders: totalOrders,
            total_revenue: totalRevenue,
        };
    }
    buildDateFilter(startDate, endDate) {
        const where = {};
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate)
                where.createdAt.gte = new Date(startDate);
            if (endDate)
                where.createdAt.lte = new Date(endDate);
        }
        return where;
    }
    async getOrderTrends(where) {
        const orders = await this.prisma.order.findMany({
            where,
            select: {
                createdAt: true,
                totalAmount: true,
            },
            orderBy: {
                createdAt: 'asc',
            },
        });
        const trendData = {};
        orders.forEach((order) => {
            const date = (0, date_util_1.formatLocalDate)(order.createdAt);
            if (!trendData[date]) {
                trendData[date] = { count: 0, amount: 0 };
            }
            trendData[date].count += 1;
            trendData[date].amount += Number(order.totalAmount || 0);
        });
        return Object.keys(trendData)
            .sort()
            .map((date) => ({
            date,
            order_count: trendData[date].count,
            total_amount: trendData[date].amount,
        }));
    }
    async getPaymentBehavior(where) {
        const [totalOrders, paidOrders, partialPaidOrders] = await Promise.all([
            this.prisma.order.count({ where }),
            this.prisma.order.count({
                where: { ...where, paymentStatus: 'FULLY_PAID' },
            }),
            this.prisma.order.count({
                where: { ...where, paymentStatus: 'PARTIAL_PAID' },
            }),
        ]);
        return {
            total_orders: totalOrders,
            paid_orders: paidOrders,
            partial_paid_orders: partialPaidOrders,
            payment_rate: totalOrders > 0 ? (paidOrders / totalOrders) * 100 : 0,
        };
    }
    getConversionRates(where) {
        this.logger.debug(`计算转化率，查询条件: ${JSON.stringify(where)}`);
        return Promise.resolve({
            browse_to_order: 15.5,
            order_to_payment: 85.2,
        });
    }
    async getTotalRevenue(where) {
        const result = await this.prisma.order.aggregate({
            _sum: {
                paidAmount: true,
            },
            where,
        });
        return Number(result._sum?.paidAmount || 0);
    }
};
exports.BehaviorAnalyticsService = BehaviorAnalyticsService;
exports.BehaviorAnalyticsService = BehaviorAnalyticsService = BehaviorAnalyticsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        cache_service_1.CacheService])
], BehaviorAnalyticsService);
//# sourceMappingURL=behavior-analytics.service.js.map