import { PrismaService } from '../../../shared/prisma/prisma.service';
import { CacheService } from '../../../shared/cache/cache.service';
export declare class PackageAnalyticsService {
    private readonly prisma;
    private readonly cacheService;
    private readonly logger;
    constructor(prisma: PrismaService, cacheService: CacheService);
    getAnalytics(query: any): Promise<{
        code: number;
        message: string;
        data: {
            popular_packages: {
                package_id: number | null;
                package_name: string;
                order_count: number;
                total_revenue: number;
            }[];
            package_revenue: {
                package_id: number | null;
                package_name: string;
                revenue: number;
            }[];
            package_trends: {
                package_id: number | null;
                date: string;
                order_count: number;
            }[];
            period: {
                start_date: any;
                end_date: any;
            };
        };
    }>;
    getOverviewStats(query: any): Promise<{
        total_packages: number;
        most_popular_package: {
            package_id: number;
            package_name: string;
            order_count: number;
        } | null;
    }>;
    private buildDateFilter;
    private getPopularPackages;
    private getPackageRevenue;
    private getPackageTrends;
    private getMostPopularPackage;
}
