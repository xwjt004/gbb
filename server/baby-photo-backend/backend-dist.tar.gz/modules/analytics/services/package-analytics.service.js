"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PackageAnalyticsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PackageAnalyticsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
const cache_service_1 = require("../../../shared/cache/cache.service");
const date_util_1 = require("../../../shared/utils/date.util");
let PackageAnalyticsService = PackageAnalyticsService_1 = class PackageAnalyticsService {
    prisma;
    cacheService;
    logger = new common_1.Logger(PackageAnalyticsService_1.name);
    constructor(prisma, cacheService) {
        this.prisma = prisma;
        this.cacheService = cacheService;
    }
    async getAnalytics(query) {
        const { startDate, endDate } = query;
        try {
            const cacheKey = this.cacheService.getAnalyticsCacheKey('package', `${startDate}-${endDate}`);
            return this.cacheService.getOrSet(cacheKey, async () => {
                const where = this.buildDateFilter(startDate, endDate);
                const [popularPackages, packageRevenue, packageTrends] = await Promise.all([
                    this.getPopularPackages(where),
                    this.getPackageRevenue(where),
                    this.getPackageTrends(where),
                ]);
                return {
                    code: 200,
                    message: '获取成功',
                    data: {
                        popular_packages: popularPackages,
                        package_revenue: packageRevenue,
                        package_trends: packageTrends,
                        period: { start_date: startDate, end_date: endDate },
                    },
                };
            }, 1800);
        }
        catch (error) {
            this.logger.error(`获取套餐分析数据失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getOverviewStats(query) {
        const { startDate, endDate } = query;
        const where = this.buildDateFilter(startDate, endDate);
        const [totalPackages, mostPopular] = await Promise.all([
            this.prisma.package.count(),
            this.getMostPopularPackage(where),
        ]);
        return {
            total_packages: totalPackages,
            most_popular_package: mostPopular,
        };
    }
    buildDateFilter(startDate, endDate) {
        const where = {};
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate)
                where.createdAt.gte = new Date(startDate);
            if (endDate)
                where.createdAt.lte = new Date(endDate);
        }
        return where;
    }
    async getPopularPackages(where) {
        const result = await this.prisma.order.groupBy({
            by: ['packageId'],
            _count: true,
            _sum: {
                totalAmount: true,
            },
            where,
            orderBy: {
                _count: {
                    packageId: 'desc',
                },
            },
            take: 10,
        });
        const packageIds = result.map((item) => item.packageId).filter((id) => id !== null);
        const packages = await this.prisma.package.findMany({
            where: { id: { in: packageIds } },
        });
        return result.map((item) => {
            const pkg = packages.find((p) => p.id === item.packageId);
            return {
                package_id: item.packageId,
                package_name: pkg?.name || 'Unknown',
                order_count: item._count,
                total_revenue: Number(item._sum?.totalAmount || 0),
            };
        });
    }
    async getPackageRevenue(where) {
        const result = await this.prisma.order.groupBy({
            by: ['packageId'],
            _sum: {
                paidAmount: true,
            },
            where,
            orderBy: {
                _sum: {
                    paidAmount: 'desc',
                },
            },
        });
        const packageIds = result.map((item) => item.packageId).filter((id) => id !== null);
        const packages = await this.prisma.package.findMany({
            where: { id: { in: packageIds } },
        });
        return result.map((item) => {
            const pkg = packages.find((p) => p.id === item.packageId);
            return {
                package_id: item.packageId,
                package_name: pkg?.name || 'Unknown',
                revenue: Number(item._sum?.paidAmount || 0),
            };
        });
    }
    async getPackageTrends(where) {
        const result = await this.prisma.order.groupBy({
            by: ['packageId', 'createdAt'],
            _count: true,
            where,
            orderBy: {
                createdAt: 'asc',
            },
        });
        return result.map((item) => ({
            package_id: item.packageId,
            date: (0, date_util_1.formatLocalDate)(item.createdAt),
            order_count: item._count,
        }));
    }
    async getMostPopularPackage(where) {
        const result = await this.prisma.order.groupBy({
            by: ['packageId'],
            _count: true,
            where,
            orderBy: {
                _count: {
                    packageId: 'desc',
                },
            },
            take: 1,
        });
        if (result.length === 0 || result[0].packageId === null)
            return null;
        const pkg = await this.prisma.package.findUnique({
            where: { id: result[0].packageId },
        });
        return {
            package_id: result[0].packageId,
            package_name: pkg?.name || 'Unknown',
            order_count: result[0]._count,
        };
    }
};
exports.PackageAnalyticsService = PackageAnalyticsService;
exports.PackageAnalyticsService = PackageAnalyticsService = PackageAnalyticsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        cache_service_1.CacheService])
], PackageAnalyticsService);
//# sourceMappingURL=package-analytics.service.js.map