export declare class PaginationDto {
    page?: number;
    limit?: number;
}
export declare class UserSearchDto extends PaginationDto {
    phone?: string;
    nickname?: string;
    fuzzy?: string;
}
export declare class OrderSearchDto extends PaginationDto {
    phone?: string;
    start_date?: string;
    end_date?: string;
    payment_status?: string;
    package_name?: string;
    order_status?: string;
}
export declare class PackageSearchDto extends PaginationDto {
    min_price?: number;
    max_price?: number;
    sort?: string;
}
export declare class PaymentSearchDto extends PaginationDto {
    phone?: string;
    status?: string;
    start_date?: string;
    end_date?: string;
}
export declare class AnalyticsTimeRangeDto {
    time_range?: string;
    start_date?: string;
    end_date?: string;
}
export declare class UserPackageSearchDto extends PaginationDto {
    phone?: string;
    user_id?: string;
}
