"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AnalyticsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnalyticsService = void 0;
const common_1 = require("@nestjs/common");
const user_analytics_service_1 = require("./services/user-analytics.service");
const behavior_analytics_service_1 = require("./services/behavior-analytics.service");
const package_analytics_service_1 = require("./services/package-analytics.service");
const loyalty_analytics_service_1 = require("./services/loyalty-analytics.service");
let AnalyticsService = AnalyticsService_1 = class AnalyticsService {
    userAnalyticsService;
    behaviorAnalyticsService;
    packageAnalyticsService;
    loyaltyAnalyticsService;
    logger = new common_1.Logger(AnalyticsService_1.name);
    constructor(userAnalyticsService, behaviorAnalyticsService, packageAnalyticsService, loyaltyAnalyticsService) {
        this.userAnalyticsService = userAnalyticsService;
        this.behaviorAnalyticsService = behaviorAnalyticsService;
        this.packageAnalyticsService = packageAnalyticsService;
        this.loyaltyAnalyticsService = loyaltyAnalyticsService;
    }
    async getUserAnalytics(query) {
        try {
            return await this.userAnalyticsService.getAnalytics(query);
        }
        catch (error) {
            this.logger.error(`获取用户分析数据失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getBehaviorAnalytics(query) {
        try {
            return await this.behaviorAnalyticsService.getAnalytics(query);
        }
        catch (error) {
            this.logger.error(`获取行为分析数据失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getPackageAnalytics(query) {
        try {
            return await this.packageAnalyticsService.getAnalytics(query);
        }
        catch (error) {
            this.logger.error(`获取套餐分析数据失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getLoyaltyAnalytics(query) {
        try {
            return await this.loyaltyAnalyticsService.getAnalytics(query);
        }
        catch (error) {
            this.logger.error(`获取忠诚度分析数据失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getOverviewAnalytics(query) {
        try {
            const [userStats, behaviorStats, packageStats, loyaltyStats] = await Promise.all([
                this.userAnalyticsService.getOverviewStats(query),
                this.behaviorAnalyticsService.getOverviewStats(query),
                this.packageAnalyticsService.getOverviewStats(query),
                this.loyaltyAnalyticsService.getOverviewStats(query),
            ]);
            return {
                code: 200,
                message: '获取成功',
                data: {
                    user_analytics: userStats,
                    behavior_analytics: behaviorStats,
                    package_analytics: packageStats,
                    loyalty_analytics: loyaltyStats,
                    generated_at: new Date(),
                },
            };
        }
        catch (error) {
            this.logger.error(`获取综合分析报告失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getUserConsumptionStats(phone, startDate, endDate) {
        try {
            const query = {
                type: 'consumption_stats',
                phone,
                startDate,
                endDate,
            };
            return await this.userAnalyticsService.getAnalytics(query);
        }
        catch (error) {
            this.logger.error(`获取用户消费统计失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getPackagePopularityAnalysis(timeRange = 'month', paginationDto) {
        try {
            const query = {
                type: 'popularity_analysis',
                timeRange,
                ...paginationDto,
            };
            return await this.packageAnalyticsService.getAnalytics(query);
        }
        catch (error) {
            this.logger.error(`获取套系热度分析失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getCustomAnalytics(analyticsQuery, paginationDto) {
        try {
            const query = {
                type: 'custom_analytics',
                ...analyticsQuery,
                ...paginationDto,
            };
            return await this.behaviorAnalyticsService.getAnalytics(query);
        }
        catch (error) {
            this.logger.error(`获取自定义分析失败: ${error.message}`, error.stack);
            throw error;
        }
    }
};
exports.AnalyticsService = AnalyticsService;
exports.AnalyticsService = AnalyticsService = AnalyticsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [user_analytics_service_1.UserAnalyticsService,
        behavior_analytics_service_1.BehaviorAnalyticsService,
        package_analytics_service_1.PackageAnalyticsService,
        loyalty_analytics_service_1.LoyaltyAnalyticsService])
], AnalyticsService);
//# sourceMappingURL=analytics.service.js.map