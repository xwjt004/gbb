import { AnalyticsService } from './analytics.service';
export declare class AnalyticsController {
    private readonly analyticsService;
    private readonly logger;
    constructor(analyticsService: AnalyticsService);
    getUserAnalytics(query: any): Promise<{
        code: number;
        message: string;
        data: {
            total_users: number;
            new_users: number;
            active_users: number;
            user_growth: {
                date: string;
                count: number;
            }[];
            period: {
                start_date: any;
                end_date: any;
            };
        };
    }>;
    getBehaviorAnalytics(query: any): Promise<{
        code: number;
        message: string;
        data: {
            order_trends: {
                date: string;
                order_count: number;
                total_amount: number;
            }[];
            payment_behavior: {
                total_orders: number;
                paid_orders: number;
                partial_paid_orders: number;
                payment_rate: number;
            };
            conversion_rates: {
                browse_to_order: number;
                order_to_payment: number;
            };
            period: {
                start_date: any;
                end_date: any;
            };
        };
    }>;
    getPackageAnalytics(query: any): Promise<{
        code: number;
        message: string;
        data: {
            popular_packages: {
                package_id: number | null;
                package_name: string;
                order_count: number;
                total_revenue: number;
            }[];
            package_revenue: {
                package_id: number | null;
                package_name: string;
                revenue: number;
            }[];
            package_trends: {
                package_id: number | null;
                date: string;
                order_count: number;
            }[];
            period: {
                start_date: any;
                end_date: any;
            };
        };
    }>;
    getLoyaltyAnalytics(query: any): Promise<{
        code: number;
        message: string;
        data: {
            customer_segmentation: {
                vip: number;
                gold: number;
                silver: number;
                regular: number;
                new: number;
            };
            repeat_customers: {
                user_id: string;
                nickname: string | null;
                order_count: number;
            }[];
            loyalty_trends: {
                period: string;
                total_customers: number;
                repeat_customers: number;
                loyalty_rate: number;
            }[];
            period: {
                start_date: any;
                end_date: any;
            };
        };
    }>;
    getOverviewAnalytics(query: any): Promise<{
        code: number;
        message: string;
        data: {
            user_analytics: {
                total_users: number;
                new_users_period: number;
            };
            behavior_analytics: {
                total_orders: number;
                total_revenue: number;
            };
            package_analytics: {
                total_packages: number;
                most_popular_package: {
                    package_id: number;
                    package_name: string;
                    order_count: number;
                } | null;
            };
            loyalty_analytics: {
                total_customers: number;
                repeat_customer_count: number;
                loyalty_rate: number;
            };
            generated_at: Date;
        };
    }>;
}
