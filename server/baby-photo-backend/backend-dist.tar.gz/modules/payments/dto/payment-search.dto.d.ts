export declare class PaymentSearchDto {
    page?: number;
    limit?: number;
    phone?: string;
    orderNo?: string;
    status?: string;
    paymentType?: string;
    paymentNo?: string;
    transactionId?: string;
    minAmount?: number;
    maxAmount?: number;
    includeUnpaidOrders?: boolean;
    startDate?: string;
    endDate?: string;
}
