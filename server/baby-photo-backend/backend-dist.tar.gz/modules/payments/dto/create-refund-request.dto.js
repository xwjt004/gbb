"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateRefundRequestDto = exports.RefundMethod = exports.RefundType = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
var RefundType;
(function (RefundType) {
    RefundType["FULL"] = "FULL";
    RefundType["PARTIAL"] = "PARTIAL";
})(RefundType || (exports.RefundType = RefundType = {}));
var RefundMethod;
(function (RefundMethod) {
    RefundMethod["ORIGINAL"] = "ORIGINAL";
    RefundMethod["CASH"] = "CASH";
    RefundMethod["BANK"] = "BANK";
})(RefundMethod || (exports.RefundMethod = RefundMethod = {}));
class CreateRefundRequestDto {
    orderNo;
    refundType;
    refundAmount;
    refundReason;
    refundMethod;
    applicantType;
    applicantId;
    applicantName;
    notes;
    attachments;
}
exports.CreateRefundRequestDto = CreateRefundRequestDto;
__decorate([
    (0, class_validator_1.IsNotEmpty)({ message: '订单号不能为空' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRefundRequestDto.prototype, "orderNo", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)({ message: '退款类型不能为空' }),
    (0, class_validator_1.IsEnum)(RefundType, { message: '退款类型必须是 FULL 或 PARTIAL' }),
    __metadata("design:type", String)
], CreateRefundRequestDto.prototype, "refundType", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)({ message: '退款金额不能为空' }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)({}, { message: '退款金额必须是数字' }),
    (0, class_validator_1.Min)(0.01, { message: '退款金额必须大于0' }),
    __metadata("design:type", Number)
], CreateRefundRequestDto.prototype, "refundAmount", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)({ message: '退款原因不能为空' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRefundRequestDto.prototype, "refundReason", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(RefundMethod, { message: '退款方式必须是 ORIGINAL、CASH 或 BANK' }),
    __metadata("design:type", String)
], CreateRefundRequestDto.prototype, "refundMethod", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRefundRequestDto.prototype, "applicantType", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRefundRequestDto.prototype, "applicantId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRefundRequestDto.prototype, "applicantName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRefundRequestDto.prototype, "notes", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], CreateRefundRequestDto.prototype, "attachments", void 0);
//# sourceMappingURL=create-refund-request.dto.js.map