export declare enum RefundStatus {
    PENDING = "PENDING",
    APPROVED = "APPROVED",
    REJECTED = "REJECTED",
    PROCESSING = "PROCESSING",
    COMPLETED = "COMPLETED",
    FAILED = "FAILED",
    CANCELLED = "CANCELLED"
}
export declare class RefundRequestSearchDto {
    orderNo?: string;
    refundNo?: string;
    status?: RefundStatus;
    applicantId?: string;
    startDate?: string;
    endDate?: string;
    page?: number;
    limit?: number;
}
export declare class ApproveRefundRequestDto {
    approvedBy?: string;
    notes?: string;
}
export declare class RejectRefundRequestDto {
    rejectedBy?: string;
    rejectReason: string;
}
export declare class ProcessRefundRequestDto {
    refundedBy?: string;
    transactionId?: string;
    notes?: string;
}
