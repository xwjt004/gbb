"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=balance-info.dto.js.map