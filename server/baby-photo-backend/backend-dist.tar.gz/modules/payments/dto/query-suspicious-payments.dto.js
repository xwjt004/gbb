"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuerySuspiciousPaymentsDto = exports.SuspiciousPaymentSeverity = exports.SuspiciousPaymentType = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const swagger_1 = require("@nestjs/swagger");
var SuspiciousPaymentType;
(function (SuspiciousPaymentType) {
    SuspiciousPaymentType["DUPLICATE"] = "duplicate";
    SuspiciousPaymentType["OVERPAYMENT"] = "overpayment";
    SuspiciousPaymentType["SYSTEM_ERROR"] = "system_error";
    SuspiciousPaymentType["ALL"] = "all";
})(SuspiciousPaymentType || (exports.SuspiciousPaymentType = SuspiciousPaymentType = {}));
var SuspiciousPaymentSeverity;
(function (SuspiciousPaymentSeverity) {
    SuspiciousPaymentSeverity["HIGH"] = "high";
    SuspiciousPaymentSeverity["MEDIUM"] = "medium";
    SuspiciousPaymentSeverity["LOW"] = "low";
    SuspiciousPaymentSeverity["ALL"] = "all";
})(SuspiciousPaymentSeverity || (exports.SuspiciousPaymentSeverity = SuspiciousPaymentSeverity = {}));
class QuerySuspiciousPaymentsDto {
    type = SuspiciousPaymentType.ALL;
    severity = SuspiciousPaymentSeverity.ALL;
    page = 1;
    limit = 20;
}
exports.QuerySuspiciousPaymentsDto = QuerySuspiciousPaymentsDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: '检测类型',
        enum: SuspiciousPaymentType,
        default: SuspiciousPaymentType.ALL,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(SuspiciousPaymentType, { message: '检测类型必须是 duplicate, overpayment, system_error 或 all' }),
    __metadata("design:type", String)
], QuerySuspiciousPaymentsDto.prototype, "type", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: '严重级别',
        enum: SuspiciousPaymentSeverity,
        default: SuspiciousPaymentSeverity.ALL,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(SuspiciousPaymentSeverity, { message: '严重级别必须是 high, medium, low 或 all' }),
    __metadata("design:type", String)
], QuerySuspiciousPaymentsDto.prototype, "severity", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: '页码（从1开始）',
        minimum: 1,
        default: 1,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)({ message: '页码必须是整数' }),
    (0, class_validator_1.Min)(1, { message: '页码必须大于等于1' }),
    __metadata("design:type", Number)
], QuerySuspiciousPaymentsDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: '每页条数（最大100）',
        minimum: 1,
        maximum: 100,
        default: 20,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)({ message: '每页条数必须是整数' }),
    (0, class_validator_1.Min)(1, { message: '每页条数必须大于等于1' }),
    (0, class_validator_1.Max)(100, { message: '每页条数不能超过100' }),
    __metadata("design:type", Number)
], QuerySuspiciousPaymentsDto.prototype, "limit", void 0);
//# sourceMappingURL=query-suspicious-payments.dto.js.map