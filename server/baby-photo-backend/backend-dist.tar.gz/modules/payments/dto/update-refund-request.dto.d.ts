import { CreateRefundRequestDto } from './create-refund-request.dto';
export declare enum RefundStatus {
    PENDING = "PENDING",
    APPROVED = "APPROVED",
    REJECTED = "REJECTED",
    PROCESSING = "PROCESSING",
    COMPLETED = "COMPLETED",
    FAILED = "FAILED",
    CANCELLED = "CANCELLED"
}
declare const UpdateRefundRequestDto_base: import("@nestjs/common").Type<Partial<CreateRefundRequestDto>>;
export declare class UpdateRefundRequestDto extends UpdateRefundRequestDto_base {
    status?: RefundStatus;
    approvedBy?: string;
    rejectedBy?: string;
    rejectReason?: string;
    refundedBy?: string;
    transactionId?: string;
}
export {};
