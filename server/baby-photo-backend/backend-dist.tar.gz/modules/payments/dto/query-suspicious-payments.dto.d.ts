export declare enum SuspiciousPaymentType {
    DUPLICATE = "duplicate",
    OVERPAYMENT = "overpayment",
    SYSTEM_ERROR = "system_error",
    ALL = "all"
}
export declare enum SuspiciousPaymentSeverity {
    HIGH = "high",
    MEDIUM = "medium",
    LOW = "low",
    ALL = "all"
}
export declare class QuerySuspiciousPaymentsDto {
    type?: SuspiciousPaymentType;
    severity?: SuspiciousPaymentSeverity;
    page?: number;
    limit?: number;
}
