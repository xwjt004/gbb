"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreatePaymentDto = exports.PaymentChannel = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
var PaymentChannel;
(function (PaymentChannel) {
    PaymentChannel["WECHAT"] = "WECHAT";
    PaymentChannel["ALIPAY"] = "ALIPAY";
    PaymentChannel["CASH"] = "CASH";
    PaymentChannel["BANK_TRANSFER"] = "BANK_TRANSFER";
})(PaymentChannel || (exports.PaymentChannel = PaymentChannel = {}));
class CreatePaymentDto {
    orderNo;
    paymentType;
    amount;
    description;
    idempotencyKey;
}
exports.CreatePaymentDto = CreatePaymentDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '订单编号', minLength: 1, maxLength: 100 }),
    (0, class_validator_1.IsNotEmpty)({ message: '订单编号不能为空' }),
    (0, class_validator_1.IsString)({ message: '订单编号必须是字符串' }),
    (0, class_validator_1.Length)(1, 100, { message: '订单编号长度必须在1-100之间' }),
    __metadata("design:type", String)
], CreatePaymentDto.prototype, "orderNo", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付类型',
        enum: Object.values(PaymentChannel),
        example: PaymentChannel.WECHAT,
    }),
    (0, class_validator_1.IsNotEmpty)({ message: '支付类型不能为空' }),
    (0, class_validator_1.IsEnum)(PaymentChannel, { message: '支付类型必须是 WECHAT, ALIPAY, CASH 或 BANK_TRANSFER' }),
    __metadata("design:type", String)
], CreatePaymentDto.prototype, "paymentType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付金额（免费订单可为0，其他订单必须 >= 0.01）',
        example: 299.0,
        minimum: 0,
    }),
    (0, class_validator_1.IsNotEmpty)({ message: '支付金额不能为空' }),
    (0, class_validator_1.IsNumber)({}, { message: '支付金额必须是数字' }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.ValidateIf)((o) => o.amount > 0),
    (0, class_validator_1.Min)(0.01, { message: '支付金额必须大于等于0.01（免费订单除外）' }),
    __metadata("design:type", Number)
], CreatePaymentDto.prototype, "amount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '订单描述',
        example: '这是一个测试订单',
        required: false,
        minLength: 1,
        maxLength: 200,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '订单描述必须是字符串' }),
    (0, class_validator_1.Length)(1, 200, { message: '订单描述长度必须在1-200之间' }),
    __metadata("design:type", String)
], CreatePaymentDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '幂等键（Idempotency-Key），防止重复创建。也可通过请求头传递。',
        required: false,
        minLength: 10,
        maxLength: 100,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '幂等键必须是字符串' }),
    (0, class_validator_1.Length)(10, 100, { message: '幂等键长度必须在10-100之间' }),
    __metadata("design:type", String)
], CreatePaymentDto.prototype, "idempotencyKey", void 0);
//# sourceMappingURL=create-payment.dto.js.map