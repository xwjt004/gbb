"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RefundPaymentDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
class RefundPaymentDto {
    refundAmount;
    refundReason;
}
exports.RefundPaymentDto = RefundPaymentDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '退款金额（必须大于0.01）',
        minimum: 0.01,
        example: 100.0,
    }),
    (0, class_validator_1.IsNotEmpty)({ message: '退款金额不能为空' }),
    (0, class_validator_1.IsNumber)({}, { message: '退款金额必须是数字' }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.Min)(0.01, { message: '退款金额必须大于0.01' }),
    __metadata("design:type", Number)
], RefundPaymentDto.prototype, "refundAmount", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: '退款原因',
        minLength: 1,
        maxLength: 200,
        example: '用户申请退款',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '退款原因必须是字符串' }),
    (0, class_validator_1.Length)(1, 200, { message: '退款原因长度必须在1-200之间' }),
    __metadata("design:type", String)
], RefundPaymentDto.prototype, "refundReason", void 0);
//# sourceMappingURL=refund-payment.dto.js.map