export declare enum RefundType {
    FULL = "FULL",
    PARTIAL = "PARTIAL"
}
export declare enum RefundMethod {
    ORIGINAL = "ORIGINAL",
    CASH = "CASH",
    BANK = "BANK"
}
export declare class CreateRefundRequestDto {
    orderNo: string;
    refundType: RefundType;
    refundAmount: number;
    refundReason: string;
    refundMethod?: RefundMethod;
    applicantType?: string;
    applicantId?: string;
    applicantName?: string;
    notes?: string;
    attachments?: string[];
}
