export declare enum PaymentChannel {
    WECHAT = "WECHAT",
    ALIPAY = "ALIPAY",
    CASH = "CASH",
    BANK_TRANSFER = "BANK_TRANSFER"
}
export declare class CreatePaymentDto {
    orderNo: string;
    paymentType: PaymentChannel;
    amount: number;
    description?: string;
    idempotencyKey?: string;
}
