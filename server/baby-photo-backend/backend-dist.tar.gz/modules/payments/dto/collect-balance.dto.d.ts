export declare class CollectBalanceDto {
    orderId: string;
    amount: number;
    paymentType: string;
    notes?: string;
}
export declare class BalanceInfoDto {
    totalAmount: number;
    paidAmount: number;
    remainingAmount: number;
    overpaidAmount: number;
    isFreeOrder: boolean;
    isFullyPaid: boolean;
    isOverpaid: boolean;
    paymentStatus: string;
    payments: any[];
}
