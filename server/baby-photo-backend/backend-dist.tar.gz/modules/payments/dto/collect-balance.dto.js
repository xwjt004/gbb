"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BalanceInfoDto = exports.CollectBalanceDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
class CollectBalanceDto {
    orderId;
    amount;
    paymentType;
    notes;
}
exports.CollectBalanceDto = CollectBalanceDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '订单ID' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CollectBalanceDto.prototype, "orderId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '收取金额',
        example: 88.00,
        minimum: 0.01,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0.01),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], CollectBalanceDto.prototype, "amount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付方式',
        enum: ['WECHAT', 'ALIPAY', 'CASH', 'BANK_TRANSFER'],
        example: 'CASH',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsEnum)(['WECHAT', 'ALIPAY', 'CASH', 'BANK_TRANSFER']),
    __metadata("design:type", String)
], CollectBalanceDto.prototype, "paymentType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '备注',
        example: '收取尾款',
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CollectBalanceDto.prototype, "notes", void 0);
class BalanceInfoDto {
    totalAmount;
    paidAmount;
    remainingAmount;
    overpaidAmount;
    isFreeOrder;
    isFullyPaid;
    isOverpaid;
    paymentStatus;
    payments;
}
exports.BalanceInfoDto = BalanceInfoDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '订单总额' }),
    __metadata("design:type", Number)
], BalanceInfoDto.prototype, "totalAmount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '已付金额' }),
    __metadata("design:type", Number)
], BalanceInfoDto.prototype, "paidAmount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '剩余金额' }),
    __metadata("design:type", Number)
], BalanceInfoDto.prototype, "remainingAmount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '多收款金额（已付金额超过订单总额的部分）' }),
    __metadata("design:type", Number)
], BalanceInfoDto.prototype, "overpaidAmount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否为免费订单（订单总额为0）' }),
    __metadata("design:type", Boolean)
], BalanceInfoDto.prototype, "isFreeOrder", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否已全额支付' }),
    __metadata("design:type", Boolean)
], BalanceInfoDto.prototype, "isFullyPaid", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否多收款（已付金额超过订单总额）' }),
    __metadata("design:type", Boolean)
], BalanceInfoDto.prototype, "isOverpaid", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '支付状态（PENDING/PARTIAL/PAID/FREE/OVERPAID）' }),
    __metadata("design:type", String)
], BalanceInfoDto.prototype, "paymentStatus", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '支付记录' }),
    __metadata("design:type", Array)
], BalanceInfoDto.prototype, "payments", void 0);
//# sourceMappingURL=collect-balance.dto.js.map