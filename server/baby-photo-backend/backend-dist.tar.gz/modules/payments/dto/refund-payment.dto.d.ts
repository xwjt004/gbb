export declare class RefundPaymentDto {
    refundAmount: number;
    refundReason?: string;
}
