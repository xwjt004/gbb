"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessRefundRequestDto = exports.RejectRefundRequestDto = exports.ApproveRefundRequestDto = exports.RefundRequestSearchDto = exports.RefundStatus = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const swagger_1 = require("@nestjs/swagger");
var RefundStatus;
(function (RefundStatus) {
    RefundStatus["PENDING"] = "PENDING";
    RefundStatus["APPROVED"] = "APPROVED";
    RefundStatus["REJECTED"] = "REJECTED";
    RefundStatus["PROCESSING"] = "PROCESSING";
    RefundStatus["COMPLETED"] = "COMPLETED";
    RefundStatus["FAILED"] = "FAILED";
    RefundStatus["CANCELLED"] = "CANCELLED";
})(RefundStatus || (exports.RefundStatus = RefundStatus = {}));
class RefundRequestSearchDto {
    orderNo;
    refundNo;
    status;
    applicantId;
    startDate;
    endDate;
    page = 1;
    limit = 20;
}
exports.RefundRequestSearchDto = RefundRequestSearchDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '订单号' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '订单号必须是字符串' }),
    __metadata("design:type", String)
], RefundRequestSearchDto.prototype, "orderNo", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '退款申请编号' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '退款申请编号必须是字符串' }),
    __metadata("design:type", String)
], RefundRequestSearchDto.prototype, "refundNo", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '退款状态', enum: RefundStatus }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(RefundStatus, { message: '退款状态必须是有效的枚举值' }),
    __metadata("design:type", String)
], RefundRequestSearchDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '申请人ID' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '申请人ID必须是字符串' }),
    __metadata("design:type", String)
], RefundRequestSearchDto.prototype, "applicantId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '开始日期', example: '2024-01-01' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)({}, { message: '开始日期格式必须是 ISO 8601 格式' }),
    __metadata("design:type", String)
], RefundRequestSearchDto.prototype, "startDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '结束日期', example: '2024-12-31' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)({}, { message: '结束日期格式必须是 ISO 8601 格式' }),
    __metadata("design:type", String)
], RefundRequestSearchDto.prototype, "endDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '页码（从1开始）', minimum: 1, default: 1 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)({ message: '页码必须是整数' }),
    (0, class_validator_1.Min)(1, { message: '页码必须大于等于1' }),
    __metadata("design:type", Number)
], RefundRequestSearchDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '每页数量（最大100）', minimum: 1, maximum: 100, default: 20 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)({ message: '每页数量必须是整数' }),
    (0, class_validator_1.Min)(1, { message: '每页数量必须大于等于1' }),
    (0, class_validator_1.Max)(100, { message: '每页数量不能超过100' }),
    __metadata("design:type", Number)
], RefundRequestSearchDto.prototype, "limit", void 0);
class ApproveRefundRequestDto {
    approvedBy;
    notes;
}
exports.ApproveRefundRequestDto = ApproveRefundRequestDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '审批人ID' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '审批人ID必须是字符串' }),
    __metadata("design:type", String)
], ApproveRefundRequestDto.prototype, "approvedBy", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '审批备注', maxLength: 500 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '审批备注必须是字符串' }),
    (0, class_validator_1.Length)(0, 500, { message: '审批备注不能超过500字符' }),
    __metadata("design:type", String)
], ApproveRefundRequestDto.prototype, "notes", void 0);
class RejectRefundRequestDto {
    rejectedBy;
    rejectReason;
}
exports.RejectRefundRequestDto = RejectRefundRequestDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '拒绝人ID' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '拒绝人ID必须是字符串' }),
    __metadata("design:type", String)
], RejectRefundRequestDto.prototype, "rejectedBy", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '拒绝原因（必填）', minLength: 1, maxLength: 500 }),
    (0, class_validator_1.IsNotEmpty)({ message: '拒绝原因不能为空' }),
    (0, class_validator_1.IsString)({ message: '拒绝原因必须是字符串' }),
    (0, class_validator_1.Length)(1, 500, { message: '拒绝原因长度必须在1-500之间' }),
    __metadata("design:type", String)
], RejectRefundRequestDto.prototype, "rejectReason", void 0);
class ProcessRefundRequestDto {
    refundedBy;
    transactionId;
    notes;
}
exports.ProcessRefundRequestDto = ProcessRefundRequestDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '退款操作人ID' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '退款操作人ID必须是字符串' }),
    __metadata("design:type", String)
], ProcessRefundRequestDto.prototype, "refundedBy", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '第三方退款交易号', maxLength: 200 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '第三方退款交易号必须是字符串' }),
    (0, class_validator_1.Length)(0, 200, { message: '第三方退款交易号不能超过200字符' }),
    __metadata("design:type", String)
], ProcessRefundRequestDto.prototype, "transactionId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '退款备注', maxLength: 500 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '退款备注必须是字符串' }),
    (0, class_validator_1.Length)(0, 500, { message: '退款备注不能超过500字符' }),
    __metadata("design:type", String)
], ProcessRefundRequestDto.prototype, "notes", void 0);
//# sourceMappingURL=refund-request-search.dto.js.map