"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentsModule = void 0;
const common_1 = require("@nestjs/common");
const payments_controller_1 = require("./payments.controller");
const payments_service_1 = require("./payments.service");
const prisma_module_1 = require("../../shared/prisma/prisma.module");
const cache_module_1 = require("../../shared/cache/cache.module");
const wechat_pay_service_1 = require("./wechat-pay.service");
const alipay_service_1 = require("./services/alipay.service");
const payment_notification_service_1 = require("./services/payment-notification.service");
const auto_status_transition_service_1 = require("../../shared/services/auto-status-transition.service");
const status_change_log_service_1 = require("../../shared/services/status-change-log.service");
const reconciliation_task_1 = require("./tasks/reconciliation.task");
const payment_reconciliation_scheduler_1 = require("./tasks/payment-reconciliation.scheduler");
const payment_metadata_controller_1 = require("../../payment/payment-metadata.controller");
let PaymentsModule = class PaymentsModule {
};
exports.PaymentsModule = PaymentsModule;
exports.PaymentsModule = PaymentsModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule, cache_module_1.CacheModule],
        controllers: [payments_controller_1.PaymentsController, payment_metadata_controller_1.PaymentMetadataController],
        providers: [
            payments_service_1.PaymentsService,
            wechat_pay_service_1.WechatPayService,
            alipay_service_1.AlipayService,
            payment_notification_service_1.PaymentNotificationService,
            auto_status_transition_service_1.AutoStatusTransitionService,
            status_change_log_service_1.StatusChangeLogService,
            reconciliation_task_1.ReconciliationTask,
            payment_reconciliation_scheduler_1.PaymentReconciliationScheduler,
        ],
        exports: [payments_service_1.PaymentsService, wechat_pay_service_1.WechatPayService, alipay_service_1.AlipayService],
    })
], PaymentsModule);
//# sourceMappingURL=payments.module.js.map