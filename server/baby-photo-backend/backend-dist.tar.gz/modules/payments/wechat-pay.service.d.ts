import { ConfigService } from '@nestjs/config';
export declare class WechatPayService {
    private readonly configService;
    private readonly logger;
    private readonly appId;
    private readonly mchId;
    private readonly apiV3Key;
    private readonly serialNo;
    private readonly privateKey;
    private readonly notifyUrl;
    private readonly isSandbox;
    private readonly isMock;
    private readonly baseUrl;
    constructor(configService: ConfigService);
    createJsapiOrder(params: {
        orderId: string;
        orderNo: string;
        amount: number;
        description: string;
        openid: string;
    }): Promise<{
        prepayId: string;
        timeStamp: string;
        nonceStr: string;
        package: string;
        signType: string;
        paySign: string;
        orderId: any;
        orderNo: any;
        amount: any;
        total_fee: number;
    } | {
        orderId: string;
        orderNo: string;
        amount: number;
        total_fee: number;
        timeStamp: string;
        nonceStr: string;
        package: string;
        signType: string;
        paySign: string;
        prepayId: any;
    }>;
    private buildMiniProgramPaymentParams;
    queryOrder(orderNo: string): Promise<any>;
    closeOrder(orderNo: string): Promise<{
        success: boolean;
    }>;
    verifyNotifySignature(timestamp: string, nonce: string, body: string, signature: string, serialNo: string): boolean;
    decryptNotifyData(ciphertext: string, associatedData: string, nonce: string): any;
    refund(params: {
        outTradeNo: string;
        outRefundNo: string;
        totalFee: number;
        refundFee: number;
        refundDesc?: string;
    }): Promise<{
        refundId: any;
        outRefundNo: string;
    }>;
    private request;
    private buildAuthorization;
    private sign;
    private generateNonceStr;
    private mockPaymentResponse;
}
