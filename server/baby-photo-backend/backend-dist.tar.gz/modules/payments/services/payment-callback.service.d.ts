import { PrismaService } from '../../../shared/prisma/prisma.service';
import { CacheService } from '../../../shared/cache/cache.service';
export interface WechatPayCallbackData {
    transaction_id: string;
    out_trade_no: string;
    total_amount: number;
    success_time?: string;
}
export interface PaymentCallbackResult {
    success: boolean;
    message: string;
    payment?: any;
    order?: any;
}
export declare class PaymentCallbackService {
    private readonly prisma;
    private readonly cacheService;
    private readonly logger;
    private readonly LOCK_TTL;
    private readonly CACHE_TTL;
    constructor(prisma: PrismaService, cacheService: CacheService);
    handleWechatPayCallback(callbackData: WechatPayCallbackData): Promise<PaymentCallbackResult>;
    private acquireLock;
    private releaseLock;
    private checkIdempotency;
    private cacheIdempotency;
    private calculateExpectedAmount;
    private determinePaymentType;
    private determineNewPaymentStatus;
    private updatePaymentAndOrder;
    private handleAmountMismatch;
}
