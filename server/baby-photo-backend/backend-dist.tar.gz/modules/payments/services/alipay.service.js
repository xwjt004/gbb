"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AlipayService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlipayService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const crypto = __importStar(require("crypto"));
let AlipayService = AlipayService_1 = class AlipayService {
    configService;
    logger = new common_1.Logger(AlipayService_1.name);
    appId;
    privateKey;
    alipayPublicKey;
    notifyUrl;
    gateway;
    constructor(configService) {
        this.configService = configService;
        this.appId = this.configService.get('ALIPAY_APP_ID') || '';
        this.privateKey = this.cleanKey(this.configService.get('ALIPAY_PRIVATE_KEY') || '');
        this.alipayPublicKey = this.cleanKey(this.configService.get('ALIPAY_PUBLIC_KEY') || '');
        this.notifyUrl = this.configService.get('ALIPAY_NOTIFY_URL') || '';
        this.gateway = this.configService.get('ALIPAY_GATEWAY') || 'https://openapi.alipay.com/gateway.do';
    }
    async createPayment(params) {
        this.logger.log(`准备创建支付宝支付: ${params.outTradeNo}`);
        const bizContent = {
            out_trade_no: params.outTradeNo,
            product_code: 'FAST_INSTANT_TRADE_PAY',
            subject: params.subject,
            total_amount: params.totalAmount.toFixed(2),
            buyer_id: params.buyerId,
        };
        const commonParams = {
            app_id: this.appId,
            method: 'alipay.trade.page.pay',
            format: 'JSON',
            charset: 'utf-8',
            sign_type: 'RSA2',
            timestamp: new Date().toISOString().slice(0, 19).replace('T', ' '),
            version: '1.0',
            notify_url: this.notifyUrl,
            biz_content: JSON.stringify(bizContent),
        };
        const sign = this.signParams(commonParams);
        return {
            gateway: this.gateway,
            params: commonParams,
            sign,
            sign_type: 'RSA2',
        };
    }
    async verifySignature(params) {
        try {
            const { sign, sign_type = 'RSA2' } = params;
            if (!sign) {
                this.logger.warn('支付宝回调缺少签名');
                return false;
            }
            const sorted = Object.keys(params)
                .filter((k) => k !== 'sign' && k !== 'sign_type' && params[k] !== undefined && params[k] !== '')
                .sort()
                .map((k) => `${k}=${params[k]}`)
                .join('&');
            const verifier = crypto.createVerify('RSA-SHA256');
            verifier.update(sorted, 'utf8');
            const isValid = verifier.verify(this.formatPublicKey(this.alipayPublicKey), sign, 'base64');
            if (!isValid) {
                this.logger.warn('支付宝签名验证失败');
            }
            this.logger.debug(`支付宝签名验证结果: ${isValid}`);
            return isValid;
        }
        catch (error) {
            this.logger.error(`支付宝签名验证异常: ${error.message}`, error.stack);
            return false;
        }
    }
    async refund(params) {
        this.logger.log(`模拟支付宝退款: ${params.outRefundNo}`);
        const bizContent = {
            out_trade_no: params.outTradeNo,
            out_request_no: params.outRefundNo,
            refund_amount: params.refundAmount.toFixed(2),
            refund_reason: params.refundReason || '正常退款',
        };
        const commonParams = {
            app_id: this.appId,
            method: 'alipay.trade.refund',
            format: 'JSON',
            charset: 'utf-8',
            sign_type: 'RSA2',
            timestamp: new Date().toISOString().slice(0, 19).replace('T', ' '),
            version: '1.0',
            biz_content: JSON.stringify(bizContent),
        };
        const sign = this.signParams(commonParams);
        return {
            request: commonParams,
            sign,
            mock: true,
        };
    }
    signParams(params) {
        const sorted = Object.keys(params)
            .filter((k) => params[k] !== undefined && params[k] !== '')
            .sort()
            .map((k) => `${k}=${params[k]}`)
            .join('&');
        const signer = crypto.createSign('RSA-SHA256');
        signer.update(sorted, 'utf8');
        return signer.sign(this.formatPrivateKey(this.privateKey), 'base64');
    }
    cleanKey(key) {
        return key.replace(/-----BEGIN[\s\S]*?KEY-----/g, '')
            .replace(/-----END[\s\S]*?KEY-----/g, '')
            .replace(/\r?\n|\s+/g, '');
    }
    formatPrivateKey(key) {
        if (!key)
            return '';
        const cleaned = this.cleanKey(key);
        const lines = cleaned.match(/.{1,64}/g) || [];
        return `-----BEGIN PRIVATE KEY-----\n${lines.join('\n')}\n-----END PRIVATE KEY-----`;
    }
    formatPublicKey(key) {
        if (!key)
            return '';
        const cleaned = this.cleanKey(key);
        const lines = cleaned.match(/.{1,64}/g) || [];
        return `-----BEGIN PUBLIC KEY-----\n${lines.join('\n')}\n-----END PUBLIC KEY-----`;
    }
};
exports.AlipayService = AlipayService;
exports.AlipayService = AlipayService = AlipayService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], AlipayService);
//# sourceMappingURL=alipay.service.js.map