import { PrismaService } from '../../../shared/prisma/prisma.service';
export declare class PaymentNotificationService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    sendPaymentSuccessNotification(orderNo: string): Promise<void>;
    sendRefundSuccessNotification(orderNo: string, refundAmount: number): Promise<void>;
    sendAdminNotification(params: {
        title: string;
        message: string;
        type: 'info' | 'warning' | 'error';
        data?: any;
    }): Promise<void>;
    private sendWxTemplateMessage;
}
