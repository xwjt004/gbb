"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var WxPayService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WxPayService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const crypto = __importStar(require("crypto"));
const axios_1 = __importDefault(require("axios"));
let WxPayService = WxPayService_1 = class WxPayService {
    configService;
    logger = new common_1.Logger(WxPayService_1.name);
    appId;
    mchId;
    apiKey;
    notifyUrl;
    constructor(configService) {
        this.configService = configService;
        this.appId = this.configService.get('WX_APP_ID') || '';
        this.mchId = this.configService.get('WX_MCH_ID') || '';
        this.apiKey = this.configService.get('WX_API_KEY') || '';
        this.notifyUrl = this.configService.get('WX_NOTIFY_URL') || '';
        if (!this.appId || !this.mchId || !this.apiKey) {
            this.logger.error('微信支付配置不完整: 请检查 WX_APP_ID, WX_MCH_ID, WX_API_KEY 环境变量');
        }
        if (!this.notifyUrl) {
            this.logger.warn('微信支付回调地址未配置: WX_NOTIFY_URL 为空，支付回调将无法正常工作');
        }
    }
    async createPayment(params) {
        try {
            const { outTradeNo, description, amount, openid } = params;
            const paymentParams = {
                appid: this.appId,
                mch_id: this.mchId,
                nonce_str: this.generateNonceStr(),
                body: description,
                out_trade_no: outTradeNo,
                total_fee: amount,
                spbill_create_ip: '127.0.0.1',
                notify_url: this.notifyUrl,
                trade_type: 'JSAPI',
                openid: openid,
            };
            const sign = this.generateSign(paymentParams);
            paymentParams['sign'] = sign;
            const xml = this.objectToXml(paymentParams);
            const response = await axios_1.default.post('https://api.mch.weixin.qq.com/pay/unifiedorder', xml, {
                headers: { 'Content-Type': 'application/xml' },
            });
            const result = this.xmlToObject(response.data);
            if (result.return_code !== 'SUCCESS' ||
                result.result_code !== 'SUCCESS') {
                throw new Error(`微信支付下单失败: ${result.return_msg || result.err_code_des}`);
            }
            const paySign = this.generatePaySign({
                appId: this.appId,
                timeStamp: Math.floor(Date.now() / 1000).toString(),
                nonceStr: this.generateNonceStr(),
                package: `prepay_id=${result.prepay_id}`,
                signType: 'MD5',
            });
            return {
                prepay_id: result.prepay_id,
                paySign,
                timeStamp: Math.floor(Date.now() / 1000).toString(),
                nonceStr: this.generateNonceStr(),
                signType: 'MD5',
            };
        }
        catch (error) {
            this.logger.error(`创建微信支付订单失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    verifySignature(body, headers) {
        try {
            const rawXml = body.toString();
            const data = this.xmlToObject(rawXml);
            if (!data || Object.keys(data).length === 0) {
                this.logger.warn('微信通知解析为空');
                return Promise.resolve(false);
            }
            const receivedSign = data['sign'];
            const signType = (data['sign_type'] || 'MD5').toUpperCase();
            if (!receivedSign) {
                this.logger.warn('微信通知缺少签名字段');
                return Promise.resolve(false);
            }
            const paramsForSign = { ...data };
            delete paramsForSign['sign'];
            const recalculated = this.computeV2Sign(paramsForSign, signType);
            const match = recalculated === receivedSign;
            const tsHeader = headers['Wechatpay-Timestamp'] || headers['wechatpay-timestamp'] || headers['x-timestamp'];
            const allowSkewSeconds = 300;
            let timeValid = true;
            if (tsHeader) {
                const notifyTs = Number(tsHeader);
                if (!isNaN(notifyTs)) {
                    const now = Math.floor(Date.now() / 1000);
                    const skew = Math.abs(now - notifyTs);
                    timeValid = skew <= allowSkewSeconds;
                    if (!timeValid) {
                        this.logger.warn(`微信通知时间戳偏差过大: skew=${skew}s headerTs=${notifyTs} now=${now}`);
                    }
                }
            }
            if (!match) {
                this.logger.warn(`微信签名校验失败 signType=${signType} expected=${recalculated} received=${receivedSign}`);
            }
            this.logger.debug(`微信签名校验结果 match=${match} timeValid=${timeValid} signType=${signType}`);
            return Promise.resolve(match && timeValid);
        }
        catch (error) {
            this.logger.error(`验证签名失败: ${error.message}`, error.stack);
            return Promise.resolve(false);
        }
    }
    parseNotifyData(body) {
        try {
            const xmlData = body.toString();
            return Promise.resolve(this.xmlToObject(xmlData));
        }
        catch (error) {
            this.logger.error(`解析回调数据失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async refund(params) {
        try {
            const refundParams = {
                appid: this.appId,
                mch_id: this.mchId,
                nonce_str: this.generateNonceStr(),
                out_trade_no: params.outTradeNo,
                out_refund_no: params.outRefundNo,
                total_fee: params.totalFee,
                refund_fee: params.refundFee,
                refund_desc: params.refundDesc || '退款',
            };
            const sign = this.generateSign(refundParams);
            refundParams['sign'] = sign;
            const xml = this.objectToXml(refundParams);
            const response = await axios_1.default.post('https://api.mch.weixin.qq.com/secapi/pay/refund', xml, {
                headers: { 'Content-Type': 'application/xml' },
            });
            const result = this.xmlToObject(response.data);
            if (result.return_code !== 'SUCCESS' ||
                result.result_code !== 'SUCCESS') {
                throw new Error(`微信退款失败: ${result.return_msg || result.err_code_des}`);
            }
            return result;
        }
        catch (error) {
            this.logger.error(`微信退款失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    generateNonceStr() {
        return crypto.randomBytes(16).toString('hex');
    }
    generateSign(params, signType = 'MD5') {
        const filteredParams = Object.keys(params)
            .filter((key) => params[key] !== undefined && params[key] !== '')
            .sort()
            .reduce((result, key) => {
            result[key] = params[key];
            return result;
        }, {});
        const stringA = Object.keys(filteredParams)
            .map((key) => `${key}=${filteredParams[key]}`)
            .join('&');
        const stringSignTemp = `${stringA}&key=${this.apiKey}`;
        if (signType === 'HMAC-SHA256') {
            return crypto
                .createHmac('sha256', this.apiKey)
                .update(stringSignTemp)
                .digest('hex')
                .toUpperCase();
        }
        return crypto
            .createHash('md5')
            .update(stringSignTemp)
            .digest('hex')
            .toUpperCase();
    }
    generatePaySign(params, signType = 'MD5') {
        const stringA = Object.keys(params)
            .sort()
            .map((key) => `${key}=${params[key]}`)
            .join('&');
        const stringSignTemp = `${stringA}&key=${this.apiKey}`;
        if (signType === 'HMAC-SHA256') {
            return crypto
                .createHmac('sha256', this.apiKey)
                .update(stringSignTemp)
                .digest('hex')
                .toUpperCase();
        }
        return crypto
            .createHash('md5')
            .update(stringSignTemp)
            .digest('hex')
            .toUpperCase();
    }
    computeV2Sign(params, signType) {
        const upper = signType.toUpperCase();
        if (upper !== 'MD5' && upper !== 'HMAC-SHA256') {
            this.logger.warn(`未支持的签名类型 ${signType}，使用 MD5 作为降级`);
        }
        return this.generateSign(params, upper === 'HMAC-SHA256' ? 'HMAC-SHA256' : 'MD5');
    }
    objectToXml(obj) {
        let xml = '<xml>';
        for (const key in obj) {
            if (Object.prototype.hasOwnProperty.call(obj, key)) {
                xml += `<${key}>${obj[key]}</${key}>`;
            }
        }
        xml += '</xml>';
        return xml;
    }
    xmlToObject(xml) {
        const result = {};
        const regex = /<(\w+)>([^<]*)<\/\1>/g;
        let match;
        while ((match = regex.exec(xml)) !== null) {
            result[match[1]] = match[2];
        }
        return result;
    }
};
exports.WxPayService = WxPayService;
exports.WxPayService = WxPayService = WxPayService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], WxPayService);
//# sourceMappingURL=wx-pay.service.js.map