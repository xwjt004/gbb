import { OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaService } from '../../../shared/prisma/prisma.service';
import { RefundExecutionService } from './refund-execution.service';
export declare class OrderTimeoutService implements OnModuleInit, OnModuleDestroy {
    private readonly prisma;
    private readonly refundExecutionService;
    private readonly logger;
    private isProcessing;
    private intervalId;
    constructor(prisma: PrismaService, refundExecutionService: RefundExecutionService);
    onModuleInit(): void;
    handleTimeoutOrders(): Promise<void>;
    private handleDepositTimeoutOrders;
    private handleFinalTimeoutOrders;
    private handlePaymentTimeoutRecords;
    private cancelOrder;
    private shouldRefundDepositOnTimeout;
    private refundDepositAndCancelOrder;
    manualTrigger(): Promise<{
        depositTimeout: number;
        finalTimeout: number;
        paymentTimeout: number;
    }>;
    getUpcomingTimeoutOrders(minutesBefore?: number): Promise<any[]>;
    sendTimeoutReminders(): Promise<void>;
    onModuleDestroy(): void;
}
