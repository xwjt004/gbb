"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PaymentNotificationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentNotificationService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
let PaymentNotificationService = PaymentNotificationService_1 = class PaymentNotificationService {
    prisma;
    logger = new common_1.Logger(PaymentNotificationService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async sendPaymentSuccessNotification(orderNo) {
        try {
            const order = await this.prisma.order.findUnique({
                where: { orderNo },
                include: {
                    user: true,
                    package: true,
                },
            });
            if (!order) {
                this.logger.warn(`订单不存在: ${orderNo}`);
                return;
            }
            this.sendWxTemplateMessage({
                openid: order.user.openid,
                templateId: 'payment_success_template_id',
                data: {
                    orderNo: order.orderNo,
                    packageName: order.package?.name || '套系',
                    amount: order.totalAmount.toString(),
                    appointmentDate: order.appointmentDate?.toISOString().split('T')[0] || '',
                },
            });
            this.logger.log(`支付成功通知已发送: ${orderNo}`);
        }
        catch (error) {
            this.logger.error(`发送支付成功通知失败: ${error.message}`, error.stack);
        }
    }
    async sendRefundSuccessNotification(orderNo, refundAmount) {
        try {
            const order = await this.prisma.order.findUnique({
                where: { orderNo },
                include: { user: true },
            });
            if (!order) {
                this.logger.warn(`订单不存在: ${orderNo}`);
                return;
            }
            this.sendWxTemplateMessage({
                openid: order.user.openid,
                templateId: 'refund_success_template_id',
                data: {
                    orderNo: order.orderNo,
                    refundAmount: refundAmount.toString(),
                    refundTime: new Date().toISOString(),
                },
            });
            this.logger.log(`退款成功通知已发送: ${orderNo}`);
        }
        catch (error) {
            this.logger.error(`发送退款成功通知失败: ${error.message}`, error.stack);
        }
    }
    async sendAdminNotification(params) {
        try {
            this.logger.log(`[管理员通知] ${params.type.toUpperCase()}: ${params.title}`);
            this.logger.log(`消息内容: ${params.message}`);
            if (params.data) {
                this.logger.debug(`附加数据: ${JSON.stringify(params.data, null, 2)}`);
            }
        }
        catch (error) {
            this.logger.error(`发送管理员通知失败: ${error.message}`, error.stack);
        }
    }
    sendWxTemplateMessage(params) {
        this.logger.debug(`发送模板消息: ${JSON.stringify(params)}`);
    }
};
exports.PaymentNotificationService = PaymentNotificationService;
exports.PaymentNotificationService = PaymentNotificationService = PaymentNotificationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PaymentNotificationService);
//# sourceMappingURL=payment-notification.service.js.map