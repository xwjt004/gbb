"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RefundExecutionService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RefundExecutionService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
const wechat_pay_service_1 = require("../wechat-pay.service");
const library_1 = require("@prisma/client/runtime/library");
const status_enum_1 = require("../../../shared/enums/status.enum");
let RefundExecutionService = RefundExecutionService_1 = class RefundExecutionService {
    prisma;
    wechatPayService;
    logger = new common_1.Logger(RefundExecutionService_1.name);
    MAX_RETRY_COUNT = 3;
    constructor(prisma, wechatPayService) {
        this.prisma = prisma;
        this.wechatPayService = wechatPayService;
    }
    async executeRefund(refundRequestId) {
        this.logger.log(`开始执行退�? refundRequestId=${refundRequestId}`);
        const request = await this.prisma.refundRequest.findUnique({
            where: { id: refundRequestId },
        });
        if (!request) {
            throw new common_1.NotFoundException(`退款申请不存在: ${refundRequestId}`);
        }
        if (request.status !== 'APPROVED') {
            throw new common_1.BadRequestException(`退款申请未审批: status=${request.status}`);
        }
        const order = await this.prisma.order.findUnique({
            where: { id: request.orderId },
            include: {
                payments: {
                    where: {
                        status: status_enum_1.PaymentStatus.FULLY_PAID,
                        paymentType: { in: ['DEPOSIT', 'FINAL', 'FULL'] },
                    },
                    orderBy: { paidAt: 'desc' },
                },
            },
        });
        if (!order) {
            throw new common_1.NotFoundException(`订单不存�? ${request.orderId}`);
        }
        const existingRefunds = await this.prisma.refund.findMany({
            where: { refundRequestId },
        });
        if (existingRefunds.length > 0) {
            this.logger.warn(`退款申请已处理: refundRequestId=${refundRequestId}`);
            return {
                success: true,
                message: '退款申请已处理',
                refunds: existingRefunds,
            };
        }
        const allocations = await this.allocateRefundAmount(request.refundAmount, order.payments);
        if (allocations.length === 0) {
            throw new common_1.BadRequestException('无可退款的支付记录');
        }
        const refunds = await this.createRefundRecords(refundRequestId, request.orderId, allocations);
        const processPromises = refunds.map((refund) => this.processRefund(refund.id).catch((error) => {
            this.logger.error(`退款执行失�? refundId=${refund.id}, error=${error.message}`);
            return null;
        }));
        await Promise.all(processPromises);
        this.logger.log(`退款执行完�? refundRequestId=${refundRequestId}, count=${refunds.length}`);
        return {
            success: true,
            message: '退款执行成功',
            refunds,
        };
    }
    async allocateRefundAmount(totalRefund, payments) {
        const allocations = [];
        let remaining = new library_1.Decimal(totalRefund);
        this.logger.log(`开始分配退款金�? totalRefund=${totalRefund.toString()}, paymentCount=${payments.length}`);
        for (const payment of payments) {
            if (remaining.lte(0))
                break;
            const alreadyRefunded = await this.prisma.refund.aggregate({
                where: {
                    originalPaymentId: payment.id,
                },
                _sum: { refundAmount: true },
            });
            const refundedAmount = alreadyRefunded._sum?.refundAmount
                ? new library_1.Decimal(alreadyRefunded._sum?.refundAmount)
                : new library_1.Decimal(0);
            const availableAmount = new library_1.Decimal(payment.amount).sub(refundedAmount);
            if (availableAmount.gt(0)) {
                const refundAmount = library_1.Decimal.min(remaining, availableAmount);
                allocations.push({
                    paymentId: payment.id,
                    amount: refundAmount,
                    method: payment.paymentMethod,
                    transactionId: payment.transactionId,
                });
                remaining = remaining.sub(refundAmount);
                this.logger.log(`分配退�? paymentId=${payment.id}, amount=${refundAmount.toString()}, ` +
                    `remaining=${remaining.toString()}`);
            }
        }
        if (remaining.gt(0)) {
            throw new common_1.BadRequestException(`退款金额超过可退金额: remaining=${remaining.toString()}`);
        }
        return allocations;
    }
    async createRefundRecords(refundRequestId, orderId, allocations) {
        return await this.prisma.$transaction(allocations.map((allocation) => this.prisma.refund.create({
            data: {
                refundRequestId,
                orderId,
                originalPaymentId: allocation.paymentId,
                refundAmount: allocation.amount,
                refundMethod: allocation.method,
                refundType: 'FULL',
            },
        })));
    }
    async processRefund(refundId) {
        const refund = await this.prisma.refund.findUnique({
            where: { id: refundId },
            include: {
                originalPayment: true,
                order: true,
            },
        });
        if (!refund) {
            throw new common_1.NotFoundException(`退款记录不存在: ${refundId}`);
        }
        try {
            let transactionId;
            if (refund.refundMethod === 'WECHAT_PAY') {
                transactionId = await this.executeWechatRefund(refund);
            }
            else {
                transactionId = await this.executeOfflineRefund(refund);
            }
            await this.prisma.refund.update({
                where: { id: refundId },
                data: {
                    transactionId,
                },
            });
            await this.updateOrderRefundAmount(refund.orderId, refund.refundAmount);
            if (refund.refundRequestId) {
                await this.checkAndUpdateRefundRequestStatus(refund.refundRequestId);
            }
            this.logger.log(`退款处理成功: refundId=${refundId}, transactionId=${transactionId}`);
        }
        catch (error) {
            await this.handleRefundError(refund, error);
        }
    }
    async executeWechatRefund(refund) {
        if (!refund.originalPayment?.transactionId) {
            throw new common_1.BadRequestException('原支付记录缺少交易号');
        }
        this.logger.log(`调用微信退款接�? refundId=${refund.id}, ` +
            `transactionId=${refund.originalPayment.transactionId}, ` +
            `amount=${refund.refundAmount.toString()}`);
        const result = await this.wechatPayService.refund({
            outRefundNo: refund.id,
            outTradeNo: refund.order.orderNo,
            totalFee: refund.originalPayment.amount.toNumber() * 100,
            refundFee: refund.refundAmount.toNumber() * 100,
            refundDesc: '原路退回',
        });
        return result.refundId || result.outRefundNo;
    }
    async executeOfflineRefund(refund) {
        this.logger.log(`创建线下退款任�? refundId=${refund.id}`);
        return `OFFLINE_${refund.id}`;
    }
    async updateOrderRefundAmount(orderId, refundAmount) {
        await this.prisma.order.update({
            where: { id: orderId },
            data: {
                refundedAmount: {
                    increment: refundAmount.toNumber(),
                },
                updatedAt: new Date(),
            },
        });
        this.logger.log(`更新订单退款金�? orderId=${orderId}, amount=${refundAmount.toString()}`);
    }
    async checkAndUpdateRefundRequestStatus(refundRequestId) {
        const refunds = await this.prisma.refund.findMany({
            where: { refundRequestId },
        });
        const allSuccess = false;
        const anyFailed = false;
        if (allSuccess) {
            await this.prisma.refundRequest.update({
                where: { id: refundRequestId },
                data: {
                    status: 'COMPLETED',
                    refundedAt: new Date(),
                },
            });
            this.logger.log(`退款申请完�? refundRequestId=${refundRequestId}`);
        }
        else if (anyFailed) {
            await this.prisma.refundRequest.update({
                where: { id: refundRequestId },
                data: { status: 'FAILED' },
            });
            this.logger.error(`退款申请失�? refundRequestId=${refundRequestId}`);
        }
    }
    async handleRefundError(refund, error) {
        const retryCount = refund.retryCount + 1;
        this.logger.error(`退款处理失�? refundId=${refund.id}, retryCount=${retryCount}, error=${error.message}`);
        if (retryCount < this.MAX_RETRY_COUNT) {
            await this.prisma.refund.update({
                where: { id: refund.id },
                data: {
                    retryCount,
                },
            });
            this.logger.log(`退款将重试: refundId=${refund.id}, retryCount=${retryCount}`);
            const delayMs = Math.pow(2, retryCount) * 60 * 1000;
            setTimeout(() => {
                this.processRefund(refund.id).catch((err) => {
                    this.logger.error(`退款重试失�? refundId=${refund.id}, error=${err.message}`);
                });
            }, delayMs);
        }
        else {
            await this.prisma.refund.update({
                where: { id: refund.id },
                data: {},
            });
        }
    }
    async retryFailedRefunds() {
        const failedRefunds = await this.prisma.refund.findMany({
            where: {
                transactionId: null,
            },
            take: 10,
        });
        this.logger.log(`批量重试失败的退款: count=${failedRefunds.length}`);
        for (const refund of failedRefunds) {
            await this.processRefund(refund.id).catch((error) => {
                this.logger.error(`退款重试失�? refundId=${refund.id}, error=${error.message}`);
            });
        }
    }
};
exports.RefundExecutionService = RefundExecutionService;
exports.RefundExecutionService = RefundExecutionService = RefundExecutionService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        wechat_pay_service_1.WechatPayService])
], RefundExecutionService);
//# sourceMappingURL=refund-execution.service.js.map