import { ConfigService } from '@nestjs/config';
export declare class AlipayService {
    private readonly configService;
    private readonly logger;
    private readonly appId;
    private readonly privateKey;
    private readonly alipayPublicKey;
    private readonly notifyUrl;
    private readonly gateway;
    constructor(configService: ConfigService);
    createPayment(params: {
        outTradeNo: string;
        subject: string;
        totalAmount: number;
        buyerId?: string;
    }): Promise<{
        gateway: string;
        params: Record<string, string>;
        sign: string;
        sign_type: string;
    }>;
    verifySignature(params: Record<string, string>): Promise<boolean>;
    refund(params: {
        outTradeNo: string;
        outRefundNo: string;
        refundAmount: number;
        refundReason?: string;
    }): Promise<{
        request: Record<string, string>;
        sign: string;
        mock: boolean;
    }>;
    private signParams;
    private cleanKey;
    private formatPrivateKey;
    private formatPublicKey;
}
