import { ConfigService } from '@nestjs/config';
export declare class WxPayService {
    private readonly configService;
    private readonly logger;
    private readonly appId;
    private readonly mchId;
    private readonly apiKey;
    private readonly notifyUrl;
    constructor(configService: ConfigService);
    createPayment(params: {
        outTradeNo: string;
        description: string;
        amount: number;
        openid: string;
    }): Promise<{
        prepay_id: any;
        paySign: string;
        timeStamp: string;
        nonceStr: string;
        signType: string;
    }>;
    verifySignature(body: Buffer, headers: Record<string, string>): Promise<boolean>;
    parseNotifyData(body: Buffer): Promise<any>;
    refund(params: {
        outTradeNo: string;
        outRefundNo: string;
        totalFee: number;
        refundFee: number;
        refundDesc?: string;
    }): Promise<Record<string, any>>;
    private generateNonceStr;
    private generateSign;
    private generatePaySign;
    private computeV2Sign;
    private objectToXml;
    private xmlToObject;
}
