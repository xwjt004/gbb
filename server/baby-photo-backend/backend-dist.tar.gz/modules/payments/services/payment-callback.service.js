"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PaymentCallbackService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentCallbackService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
const cache_service_1 = require("../../../shared/cache/cache.service");
const library_1 = require("@prisma/client/runtime/library");
const status_enum_1 = require("../../../shared/enums/status.enum");
let PaymentCallbackService = PaymentCallbackService_1 = class PaymentCallbackService {
    prisma;
    cacheService;
    logger = new common_1.Logger(PaymentCallbackService_1.name);
    LOCK_TTL = 10000;
    CACHE_TTL = 300;
    constructor(prisma, cacheService) {
        this.prisma = prisma;
        this.cacheService = cacheService;
    }
    async handleWechatPayCallback(callbackData) {
        const { transaction_id, out_trade_no, total_amount } = callbackData;
        this.logger.log(`接收微信支付回调: transaction_id=${transaction_id}, out_trade_no=${out_trade_no}, amount=${total_amount}`);
        const lockKey = this.cacheService.generateKey('payment-callback-lock', transaction_id);
        const lock = await this.acquireLock(lockKey);
        try {
            const cachedResult = await this.checkIdempotency(transaction_id);
            if (cachedResult) {
                this.logger.warn(`幂等性检查：支付已处�?transaction_id=${transaction_id}`);
                return cachedResult;
            }
            const existingPayment = await this.prisma.payment.findFirst({
                where: { transactionId: transaction_id },
            });
            if (existingPayment) {
                if (existingPayment.status === status_enum_1.PaymentStatus.FULLY_PAID) {
                    const result = {
                        success: true,
                        message: '支付已处理',
                        payment: existingPayment,
                    };
                    await this.cacheIdempotency(transaction_id, result);
                    return result;
                }
            }
            const order = await this.prisma.order.findUnique({
                where: { orderNo: out_trade_no },
                include: { payments: true },
            });
            if (!order) {
                throw new common_1.BadRequestException(`订单不存�? ${out_trade_no}`);
            }
            const expectedAmount = this.calculateExpectedAmount(order);
            if (Math.abs(total_amount - expectedAmount.toNumber()) > 0.01) {
                this.logger.error(`金额不匹�? expected=${expectedAmount}, actual=${total_amount}`);
                await this.handleAmountMismatch(order, total_amount, expectedAmount);
                throw new common_1.BadRequestException('支付金额不匹配');
            }
            const result = await this.updatePaymentAndOrder(order, callbackData, existingPayment);
            await this.cacheIdempotency(transaction_id, result);
            this.logger.log(`支付回调处理成功: order=${out_trade_no}, payment=${result.payment.id}`);
            return result;
        }
        finally {
            await this.releaseLock(lockKey);
        }
    }
    async acquireLock(key) {
        const maxRetries = 30;
        const retryDelay = 300;
        for (let i = 0; i < maxRetries; i++) {
            try {
                await this.cacheService.set(key, '1', this.LOCK_TTL / 1000);
                return true;
            }
            catch (error) {
            }
            await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        throw new Error(`获取分布式锁失败: ${key}`);
    }
    async releaseLock(key) {
        await this.cacheService.del(key);
    }
    async checkIdempotency(transactionId) {
        const cacheKey = this.cacheService.generateKey('payment-callback-result', transactionId);
        return await this.cacheService.get(cacheKey);
    }
    async cacheIdempotency(transactionId, result) {
        const cacheKey = this.cacheService.generateKey('payment-callback-result', transactionId);
        await this.cacheService.set(cacheKey, result, this.CACHE_TTL);
    }
    calculateExpectedAmount(order) {
        const paymentMode = order.paymentMode;
        const paidAmount = new library_1.Decimal(order.paidAmount);
        if (paymentMode.includes('DEPOSIT')) {
            if (paidAmount.toNumber() === 0) {
                return order.depositAmount;
            }
            else {
                return order.totalAmount.sub(paidAmount);
            }
        }
        else {
            return order.totalAmount.sub(paidAmount);
        }
    }
    determinePaymentType(order) {
        const paymentMode = order.paymentMode;
        const paidAmount = new library_1.Decimal(order.paidAmount);
        if (paymentMode.includes('DEPOSIT')) {
            return paidAmount.toNumber() === 0 ? 'DEPOSIT' : 'FINAL';
        }
        return 'FULL';
    }
    determineNewPaymentStatus(order, newPaidAmount) {
        if (newPaidAmount.gte(order.totalAmount)) {
            return status_enum_1.PaymentStatus.FULLY_PAID;
        }
        if (order.paymentMode.includes('DEPOSIT')) {
            return newPaidAmount.gte(order.depositAmount)
                ? status_enum_1.PaymentStatus.PARTIAL_PAID
                : status_enum_1.PaymentStatus.PENDING_PAYMENT;
        }
        return status_enum_1.PaymentStatus.PARTIAL_PAID;
    }
    async updatePaymentAndOrder(order, callbackData, existingPayment) {
        const { transaction_id, total_amount, success_time } = callbackData;
        const paymentType = this.determinePaymentType(order);
        const result = await this.prisma.$transaction(async (tx) => {
            const payment = existingPayment
                ? await tx.payment.update({
                    where: { id: existingPayment.id },
                    data: {
                        status: status_enum_1.PaymentStatus.FULLY_PAID,
                        transactionId: transaction_id,
                        paidAt: success_time ? new Date(success_time) : new Date(),
                        updatedAt: new Date(),
                    },
                })
                : await tx.payment.create({
                    data: {
                        orderId: order.id,
                        paymentType: paymentType,
                        paymentMethod: 'WECHAT_PAY',
                        amount: new library_1.Decimal(total_amount),
                        status: status_enum_1.PaymentStatus.FULLY_PAID,
                        transactionId: transaction_id,
                        idempotencyKey: transaction_id,
                        paidAt: success_time ? new Date(success_time) : new Date(),
                    },
                });
            const newPaidAmount = new library_1.Decimal(order.paidAmount).add(total_amount);
            const newRemainingAmount = new library_1.Decimal(order.totalAmount).sub(newPaidAmount);
            const newPaymentStatus = this.determineNewPaymentStatus(order, newPaidAmount);
            const updatedOrder = await tx.order.update({
                where: { id: order.id },
                data: {
                    paidAmount: newPaidAmount,
                    remainingAmount: newRemainingAmount,
                    paymentStatus: newPaymentStatus,
                    orderStatus: newPaymentStatus === status_enum_1.PaymentStatus.FULLY_PAID
                        ? status_enum_1.OrderStatus.CONFIRMED
                        : order.orderStatus,
                    updatedAt: new Date(),
                },
            });
            await tx.statusChangeLog.create({
                data: {
                    orderId: order.id,
                    fieldName: 'paymentStatus',
                    oldValue: order.paymentStatus,
                    newValue: newPaymentStatus,
                    operator: 'SYSTEM',
                    reason: '微信支付回调',
                    createdAt: new Date(),
                },
            });
            return {
                success: true,
                message: '支付处理成功',
                payment,
                order: updatedOrder,
            };
        });
        return result;
    }
    async handleAmountMismatch(order, actualAmount, expectedAmount) {
        this.logger.error(`金额不匹配告�? orderId=${order.id}, orderNo=${order.orderNo}, ` +
            `expected=${expectedAmount.toString()}, actual=${actualAmount}`);
    }
};
exports.PaymentCallbackService = PaymentCallbackService;
exports.PaymentCallbackService = PaymentCallbackService = PaymentCallbackService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        cache_service_1.CacheService])
], PaymentCallbackService);
//# sourceMappingURL=payment-callback.service.js.map