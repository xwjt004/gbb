"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var OrderTimeoutService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderTimeoutService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
const client_1 = require("@prisma/client");
const refund_execution_service_1 = require("./refund-execution.service");
let OrderTimeoutService = OrderTimeoutService_1 = class OrderTimeoutService {
    prisma;
    refundExecutionService;
    logger = new common_1.Logger(OrderTimeoutService_1.name);
    isProcessing = false;
    intervalId;
    constructor(prisma, refundExecutionService) {
        this.prisma = prisma;
        this.refundExecutionService = refundExecutionService;
    }
    onModuleInit() {
        this.logger.log('OrderTimeoutService initialized - Starting interval timer (every 5 minutes)');
        this.handleTimeoutOrders().catch(err => {
            this.logger.error('Initial timeout check failed:', err);
        });
        this.intervalId = setInterval(() => {
            this.handleTimeoutOrders().catch(err => {
                this.logger.error('Scheduled timeout check failed:', err);
            });
        }, 5 * 60 * 1000);
    }
    async handleTimeoutOrders() {
        if (this.isProcessing) {
            this.logger.warn('超时检查任务正在运行中，跳过本次执行');
            return;
        }
        this.isProcessing = true;
        const startTime = Date.now();
        try {
            this.logger.log('��ʼִ�г�ʱ������������');
            const depositTimeoutCount = await this.handleDepositTimeoutOrders();
            const finalTimeoutCount = await this.handleFinalTimeoutOrders();
            const paymentTimeoutCount = await this.handlePaymentTimeoutRecords();
            const duration = Date.now() - startTime;
            this.logger.log(`超时检查完成：depositTimeout=${depositTimeoutCount}, ` +
                `finalTimeout=${finalTimeoutCount}, paymentTimeout=${paymentTimeoutCount}, ` +
                `duration=${duration}ms`);
        }
        catch (error) {
            this.logger.error(`超时检查处理失败: ${error.message}`, error.stack);
        }
        finally {
            this.isProcessing = false;
        }
    }
    async handleDepositTimeoutOrders() {
        const now = new Date();
        const timeoutOrders = await this.prisma.order.findMany({
            where: {
                paymentStatus: client_1.PaymentStatus.PENDING_PAYMENT,
                depositTimeout: { lte: now },
                orderStatus: { not: client_1.OrderStatus.CANCELLED },
            },
            take: 100,
        });
        this.logger.log(`发现定金超时订单: count=${timeoutOrders.length}`);
        for (const order of timeoutOrders) {
            try {
                await this.cancelOrder(order.id, '定金支付超时自动取消');
            }
            catch (error) {
                this.logger.error(`取消定金超时订单失败: orderId=${order.id}, error=${error.message}`);
            }
        }
        return timeoutOrders.length;
    }
    async handleFinalTimeoutOrders() {
        const now = new Date();
        const timeoutOrders = await this.prisma.order.findMany({
            where: {
                paymentStatus: client_1.PaymentStatus.PARTIAL_PAID,
                finalTimeout: { lte: now },
                orderStatus: { not: client_1.OrderStatus.CANCELLED },
            },
            include: {
                payments: {
                    where: {
                        paymentType: { in: ['DEPOSIT', 'FINAL', 'FULL'] },
                        paidAt: { not: null },
                    },
                },
            },
            take: 100,
        });
        this.logger.log(`����β�ʱ����: count=${timeoutOrders.length}`);
        for (const order of timeoutOrders) {
            try {
                if (await this.shouldRefundDepositOnTimeout(order)) {
                    await this.refundDepositAndCancelOrder(order);
                }
                else {
                    await this.cancelOrder(order.id, 'β��֧����ʱ�Զ�ȡ���������ˣ�');
                }
            }
            catch (error) {
                this.logger.error(`����β�ʱ����ʧ��: orderId=${order.id}, error=${error.message}`);
            }
        }
        return timeoutOrders.length;
    }
    async handlePaymentTimeoutRecords() {
        const now = new Date();
        const timeoutPayments = await this.prisma.payment.findMany({
            where: {
                status: client_1.PaymentStatus.PENDING_PAYMENT,
                expiredAt: { lte: now },
            },
            take: 100,
        });
        this.logger.log(`发现支付超时记录: count=${timeoutPayments.length}`);
        for (const payment of timeoutPayments) {
            try {
                await this.prisma.payment.update({
                    where: { id: payment.id },
                    data: {
                        status: client_1.PaymentStatus.CANCELLED,
                        updatedAt: new Date(),
                    },
                });
                this.logger.log(`支付记录已超时取消: paymentId=${payment.id}`);
            }
            catch (error) {
                this.logger.error(`取消支付记录失败: paymentId=${payment.id}, error=${error.message}`);
            }
        }
        return timeoutPayments.length;
    }
    async cancelOrder(orderId, reason) {
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
        });
        if (!order) {
            throw new Error(`订单不存在: ${orderId}`);
        }
        await this.prisma.$transaction([
            this.prisma.order.update({
                where: { id: orderId },
                data: {
                    paymentStatus: client_1.PaymentStatus.CANCELLED,
                    orderStatus: client_1.OrderStatus.CANCELLED,
                    updatedAt: new Date(),
                },
            }),
            this.prisma.statusChangeLog.create({
                data: {
                    orderId,
                    fieldName: 'paymentStatus',
                    oldValue: order.paymentStatus,
                    newValue: client_1.PaymentStatus.CANCELLED,
                    operator: 'SYSTEM',
                    reason,
                },
            }),
            this.prisma.statusChangeLog.create({
                data: {
                    orderId,
                    fieldName: 'orderStatus',
                    oldValue: order.orderStatus,
                    newValue: client_1.OrderStatus.CANCELLED,
                    operator: 'SYSTEM',
                    reason,
                },
            }),
        ]);
        this.logger.log(`订单已取消: orderId=${orderId}, reason=${reason}`);
    }
    async shouldRefundDepositOnTimeout(order) {
        const now = new Date();
        const appointmentDate = new Date(order.appointmentDate);
        const daysUntilAppointment = Math.floor((appointmentDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        const shouldRefund = daysUntilAppointment > 7;
        this.logger.log(`判断是否退还定金: orderId=${order.id}, ` +
            `daysUntilAppointment=${daysUntilAppointment}, shouldRefund=${shouldRefund}`);
        return shouldRefund;
    }
    async refundDepositAndCancelOrder(order) {
        this.logger.log(`开始退还定金: orderId=${order.id}, depositAmount=${order.depositAmount}`);
        try {
            const refundRequest = await this.prisma.refundRequest.create({
                data: {
                    orderId: order.id,
                    orderNo: order.orderNo,
                    refundNo: `AUTO_${Date.now()}_${order.orderNo}`,
                    refundType: 'DEPOSIT_ONLY',
                    refundAmount: order.depositAmount,
                    refundReason: '尾款支付超时，自动退还定金',
                    refundMethod: 'ORIGINAL',
                    applicantType: 'SYSTEM',
                    status: 'APPROVED',
                    approvedBy: 'SYSTEM',
                    approvedAt: new Date(),
                },
            });
            await this.refundExecutionService.executeRefund(refundRequest.id);
            await this.cancelOrder(order.id, '尾款支付超时，已退还定金');
            this.logger.log(`定金退还成功: orderId=${order.id}, refundRequestId=${refundRequest.id}`);
        }
        catch (error) {
            this.logger.error(`定金退还失败: orderId=${order.id}, error=${error.message}`);
            throw error;
        }
    }
    async manualTrigger() {
        this.logger.log('手动触发超时检查任务');
        const depositTimeout = await this.handleDepositTimeoutOrders();
        const finalTimeout = await this.handleFinalTimeoutOrders();
        const paymentTimeout = await this.handlePaymentTimeoutRecords();
        return {
            depositTimeout,
            finalTimeout,
            paymentTimeout,
        };
    }
    async getUpcomingTimeoutOrders(minutesBefore = 60) {
        const now = new Date();
        const futureTime = new Date(now.getTime() + minutesBefore * 60 * 1000);
        const orders = await this.prisma.order.findMany({
            where: {
                OR: [
                    {
                        paymentStatus: client_1.PaymentStatus.PENDING_PAYMENT,
                        depositTimeout: {
                            gte: now,
                            lte: futureTime,
                        },
                    },
                    {
                        paymentStatus: client_1.PaymentStatus.PARTIAL_PAID,
                        finalTimeout: {
                            gte: now,
                            lte: futureTime,
                        },
                    },
                ],
                orderStatus: { not: client_1.OrderStatus.CANCELLED },
            },
            include: {
                user: true,
            },
        });
        this.logger.log(`查询即将超时订单: minutesBefore=${minutesBefore}, count=${orders.length}`);
        return orders;
    }
    async sendTimeoutReminders() {
        try {
            const orders = await this.getUpcomingTimeoutOrders(60);
            for (const order of orders) {
                this.logger.log(`发送超时提醒: orderId=${order.id}, userId=${order.userId}`);
            }
        }
        catch (error) {
            this.logger.error(`发送超时提醒失败: ${error.message}`);
        }
    }
    onModuleDestroy() {
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.logger.log('OrderTimeoutService destroyed - Interval timer cleared');
        }
    }
};
exports.OrderTimeoutService = OrderTimeoutService;
exports.OrderTimeoutService = OrderTimeoutService = OrderTimeoutService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        refund_execution_service_1.RefundExecutionService])
], OrderTimeoutService);
//# sourceMappingURL=order-timeout.service.js.map