import { PrismaService } from '../../../shared/prisma/prisma.service';
import { WechatPayService } from '../wechat-pay.service';
import { Decimal } from '@prisma/client/runtime/library';
import { PaymentMethod } from '@prisma/client';
export interface RefundAllocation {
    paymentId: string;
    amount: Decimal;
    method: PaymentMethod;
    transactionId: string | null;
}
export interface ExecuteRefundResult {
    success: boolean;
    message: string;
    refunds: any[];
}
export declare class RefundExecutionService {
    private readonly prisma;
    private readonly wechatPayService;
    private readonly logger;
    private readonly MAX_RETRY_COUNT;
    constructor(prisma: PrismaService, wechatPayService: WechatPayService);
    executeRefund(refundRequestId: string): Promise<ExecuteRefundResult>;
    private allocateRefundAmount;
    private createRefundRecords;
    processRefund(refundId: string): Promise<void>;
    private executeWechatRefund;
    private executeOfflineRefund;
    private updateOrderRefundAmount;
    private checkAndUpdateRefundRequestStatus;
    private handleRefundError;
    retryFailedRefunds(): Promise<void>;
}
