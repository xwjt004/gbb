"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PaymentReconciliationScheduler_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentReconciliationScheduler = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
const wechat_pay_service_1 = require("../wechat-pay.service");
const payments_service_1 = require("../payments.service");
let PaymentReconciliationScheduler = PaymentReconciliationScheduler_1 = class PaymentReconciliationScheduler {
    prisma;
    wechatPayService;
    paymentsService;
    logger = new common_1.Logger(PaymentReconciliationScheduler_1.name);
    constructor(prisma, wechatPayService, paymentsService) {
        this.prisma = prisma;
        this.wechatPayService = wechatPayService;
        this.paymentsService = paymentsService;
    }
    async handlePaymentReconciliation() {
        this.logger.log('开始执行支付状态对账...');
        try {
            const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
            const pendingOrders = await this.prisma.order.findMany({
                where: {
                    paymentStatus: { in: ['PENDING_PAYMENT'] },
                    createdAt: { lt: fiveMinutesAgo },
                },
                select: { id: true, orderNo: true, paymentStatus: true, source: true },
                orderBy: { createdAt: 'desc' },
                take: 50,
            });
            if (pendingOrders.length === 0) {
                return;
            }
            this.logger.log(`发现 ${pendingOrders.length} 个待支付订单，开始核对微信状态`);
            let syncedCount = 0;
            for (const order of pendingOrders) {
                try {
                    const wxResult = await this.wechatPayService.queryOrder(order.orderNo);
                    if (wxResult.trade_state === 'SUCCESS') {
                        this.logger.log(`对账发现已支付订单: ${order.orderNo}`);
                        const notifyData = {
                            out_trade_no: order.orderNo,
                            transaction_id: wxResult.transaction_id,
                            trade_state: wxResult.trade_state,
                            amount: wxResult.amount,
                        };
                        await this.paymentsService.handlePaymentResult(notifyData);
                        syncedCount++;
                    }
                }
                catch (queryErr) {
                    if (queryErr?.response?.status !== 404) {
                        this.logger.warn(`查询订单 ${order.orderNo} 状态异常: ${queryErr.message}`);
                    }
                }
            }
            if (syncedCount > 0) {
                this.logger.log(`支付对账完成: 同步了 ${syncedCount}/${pendingOrders.length} 个订单`);
            }
        }
        catch (error) {
            this.logger.error(`支付对账任务失败: ${error.message}`);
        }
    }
};
exports.PaymentReconciliationScheduler = PaymentReconciliationScheduler;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_5_MINUTES, {
        name: 'payment-reconciliation',
        timeZone: 'Asia/Shanghai',
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PaymentReconciliationScheduler.prototype, "handlePaymentReconciliation", null);
exports.PaymentReconciliationScheduler = PaymentReconciliationScheduler = PaymentReconciliationScheduler_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        wechat_pay_service_1.WechatPayService,
        payments_service_1.PaymentsService])
], PaymentReconciliationScheduler);
//# sourceMappingURL=payment-reconciliation.scheduler.js.map