import { PrismaService } from '../../../shared/prisma/prisma.service';
import { PaymentNotificationService } from '../services/payment-notification.service';
export declare class ReconciliationTask {
    private readonly prisma;
    private readonly notificationService;
    private readonly logger;
    constructor(prisma: PrismaService, notificationService: PaymentNotificationService);
    handleDailyReconciliation(): Promise<void>;
    private detectDiscrepancies;
    private markDiscrepancies;
    private sendDiscrepancyNotification;
    manualReconciliation(): Promise<void>;
}
