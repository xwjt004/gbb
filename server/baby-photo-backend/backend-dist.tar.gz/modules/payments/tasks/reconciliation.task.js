"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ReconciliationTask_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReconciliationTask = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
const payment_notification_service_1 = require("../services/payment-notification.service");
let ReconciliationTask = ReconciliationTask_1 = class ReconciliationTask {
    prisma;
    notificationService;
    logger = new common_1.Logger(ReconciliationTask_1.name);
    constructor(prisma, notificationService) {
        this.prisma = prisma;
        this.notificationService = notificationService;
    }
    async handleDailyReconciliation() {
        this.logger.log('开始执行每日对账任务...');
        const startTime = Date.now();
        try {
            const discrepancies = await this.detectDiscrepancies();
            if (discrepancies.length > 0) {
                this.logger.warn(`发现 ${discrepancies.length} 条支付差异记录`);
                await this.markDiscrepancies(discrepancies);
                await this.sendDiscrepancyNotification(discrepancies);
            }
            else {
                this.logger.log('对账完成，未发现差异');
            }
            const duration = Date.now() - startTime;
            this.logger.log(`对账任务完成，耗时 ${duration}ms`);
        }
        catch (error) {
            this.logger.error(`对账任务执行失败: ${error.message}`, error.stack);
            await this.notificationService.sendAdminNotification({
                title: '对账任务执行失败',
                message: `错误信息: ${error.message}`,
                type: 'error',
            });
        }
    }
    async detectDiscrepancies() {
        const discrepancies = [];
        const paidOrders = await this.prisma.order.findMany({
            where: {
                paymentStatus: 'FULLY_PAID',
            },
            include: {
                payments: {
                    where: {
                        status: {
                            in: ['FULLY_PAID', 'PARTIAL_PAID', 'OVERPAID'],
                        },
                    },
                },
            },
        });
        for (const order of paidOrders) {
            const totalPaid = order.payments.reduce((sum, p) => sum + Number(p.amount), 0);
            const totalAmount = Number(order.totalAmount);
            const difference = Math.abs(totalPaid - totalAmount);
            if (difference > 0.01) {
                discrepancies.push({
                    type: 'AMOUNT_MISMATCH',
                    orderId: order.id,
                    orderNo: order.orderNo,
                    orderStatus: order.orderStatus,
                    paymentStatus: order.paymentStatus,
                    totalAmount,
                    paidAmount: totalPaid,
                    expectedAmount: totalAmount,
                    difference,
                    severity: difference > 100 ? 'high' : difference > 10 ? 'medium' : 'low',
                });
            }
        }
        const partialOrders = await this.prisma.order.findMany({
            where: {
                paymentStatus: 'PARTIAL_PAID',
            },
            include: {
                payments: {
                    where: {
                        status: {
                            in: ['FULLY_PAID', 'PARTIAL_PAID', 'OVERPAID'],
                        },
                    },
                },
            },
        });
        for (const order of partialOrders) {
            const totalPaid = order.payments.reduce((sum, p) => sum + Number(p.amount), 0);
            const totalAmount = Number(order.totalAmount);
            if (totalPaid >= totalAmount) {
                discrepancies.push({
                    type: 'STATUS_INCONSISTENT',
                    orderId: order.id,
                    orderNo: order.orderNo,
                    orderStatus: order.orderStatus,
                    paymentStatus: order.paymentStatus,
                    totalAmount,
                    paidAmount: totalPaid,
                    expectedAmount: totalAmount,
                    difference: totalPaid - totalAmount,
                    severity: 'high',
                });
            }
        }
        const pendingOrdersWithPaidPayments = await this.prisma.order.findMany({
            where: {
                paymentStatus: 'PENDING_PAYMENT',
                payments: {
                    some: {
                        status: {
                            in: ['FULLY_PAID', 'PARTIAL_PAID', 'OVERPAID'],
                        },
                    },
                },
            },
            include: {
                payments: {
                    where: {
                        status: {
                            in: ['FULLY_PAID', 'PARTIAL_PAID', 'OVERPAID'],
                        },
                    },
                },
            },
        });
        for (const order of pendingOrdersWithPaidPayments) {
            const totalPaid = order.payments.reduce((sum, p) => sum + Number(p.amount), 0);
            const totalAmount = Number(order.totalAmount);
            discrepancies.push({
                type: 'PAYMENT_STATUS_MISMATCH',
                orderId: order.id,
                orderNo: order.orderNo,
                orderStatus: order.orderStatus,
                paymentStatus: order.paymentStatus,
                totalAmount,
                paidAmount: totalPaid,
                expectedAmount: totalAmount,
                difference: totalAmount - totalPaid,
                severity: 'high',
            });
        }
        return discrepancies;
    }
    async markDiscrepancies(discrepancies) {
        for (const disc of discrepancies) {
            this.logger.warn(`[对账差异] 类型=${disc.type} 订单=${disc.orderNo} ` +
                `总额=${disc.totalAmount} 已付=${disc.paidAmount} ` +
                `差额=${disc.difference} 严重级别=${disc.severity}`);
        }
    }
    async sendDiscrepancyNotification(discrepancies) {
        const highSeverity = discrepancies.filter(d => d.severity === 'high');
        const mediumSeverity = discrepancies.filter(d => d.severity === 'medium');
        const lowSeverity = discrepancies.filter(d => d.severity === 'low');
        const message = [
            `发现 ${discrepancies.length} 条支付差异：`,
            `🔴 高风险: ${highSeverity.length} 条`,
            `🟡 中风险: ${mediumSeverity.length} 条`,
            `🟢 低风险: ${lowSeverity.length} 条`,
            '',
            '请及时登录系统查看详情并处理。',
        ].join('\n');
        await this.notificationService.sendAdminNotification({
            title: '每日对账发现异常',
            message,
            type: 'warning',
            data: {
                discrepancies: discrepancies.slice(0, 10),
                totalCount: discrepancies.length,
            },
        });
    }
    async manualReconciliation() {
        this.logger.log('手动触发对账任务');
        return this.handleDailyReconciliation();
    }
};
exports.ReconciliationTask = ReconciliationTask;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_DAY_AT_3AM, {
        name: 'daily-reconciliation',
        timeZone: 'Asia/Shanghai',
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ReconciliationTask.prototype, "handleDailyReconciliation", null);
exports.ReconciliationTask = ReconciliationTask = ReconciliationTask_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        payment_notification_service_1.PaymentNotificationService])
], ReconciliationTask);
//# sourceMappingURL=reconciliation.task.js.map