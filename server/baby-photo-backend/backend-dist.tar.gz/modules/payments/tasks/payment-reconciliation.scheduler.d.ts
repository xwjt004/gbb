import { PrismaService } from '../../../shared/prisma/prisma.service';
import { WechatPayService } from '../wechat-pay.service';
import { PaymentsService } from '../payments.service';
export declare class PaymentReconciliationScheduler {
    private readonly prisma;
    private readonly wechatPayService;
    private readonly paymentsService;
    private readonly logger;
    constructor(prisma: PrismaService, wechatPayService: WechatPayService, paymentsService: PaymentsService);
    handlePaymentReconciliation(): Promise<void>;
}
