"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PaymentsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentsService = void 0;
const common_1 = require("@nestjs/common");
const crypto_1 = require("crypto");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const cache_service_1 = require("../../shared/cache/cache.service");
const wechat_pay_service_1 = require("./wechat-pay.service");
const payment_notification_service_1 = require("./services/payment-notification.service");
const create_payment_dto_1 = require("./dto/create-payment.dto");
const create_refund_request_dto_1 = require("./dto/create-refund-request.dto");
const refund_request_search_dto_1 = require("./dto/refund-request-search.dto");
const status_enum_1 = require("../../shared/enums/status.enum");
const auto_status_transition_service_1 = require("../../shared/services/auto-status-transition.service");
const date_util_1 = require("../../shared/utils/date.util");
let PaymentsService = PaymentsService_1 = class PaymentsService {
    prisma;
    cacheService;
    wechatPayService;
    notificationService;
    autoStatusTransitionService;
    logger = new common_1.Logger(PaymentsService_1.name);
    constructor(prisma, cacheService, wechatPayService, notificationService, autoStatusTransitionService) {
        this.prisma = prisma;
        this.cacheService = cacheService;
        this.wechatPayService = wechatPayService;
        this.notificationService = notificationService;
        this.autoStatusTransitionService = autoStatusTransitionService;
    }
    async create(createPaymentDto) {
        try {
            const compositeIdemKey = this.generateIdempotencyKey(createPaymentDto);
            const finalIdemKey = createPaymentDto.idempotencyKey
                ? `${createPaymentDto.idempotencyKey}:${compositeIdemKey}`
                : compositeIdemKey;
            const cacheKey = this.cacheService.generateKey('payment-idem', finalIdemKey);
            const cached = await this.cacheService.get(cacheKey);
            if (cached) {
                this.logger.warn(`幂等重复请求命中: key=${finalIdemKey}`);
                return cached;
            }
            const order = await this.prisma.order.findUnique({
                where: { orderNo: createPaymentDto.orderNo },
                include: { user: true, package: true },
            });
            if (!order) {
                throw new common_1.NotFoundException('订单不存在');
            }
            const existingPayment = await this.prisma.payment.findFirst({
                where: {
                    order: {
                        orderNo: createPaymentDto.orderNo,
                    },
                    status: status_enum_1.PaymentStatus.PENDING_PAYMENT,
                },
            });
            if (existingPayment) {
                this.logger.warn(`检测到已有待处理支付记录 order=${createPaymentDto.orderNo} payment=${existingPayment.id}`);
                const existingResponse = {
                    code: 200,
                    message: '幂等重复请求返回已有支付记录',
                    data: {
                        payment_id: existingPayment.id,
                        order_no: createPaymentDto.orderNo,
                        amount: Number(existingPayment.amount),
                        status: existingPayment.status,
                        payment_type: existingPayment.paymentType,
                        idempotency_key: finalIdemKey,
                        payment_info: null,
                    },
                };
                await this.cacheService.set(cacheKey, existingResponse, 60);
                return existingResponse;
            }
            if (order.paymentStatus === status_enum_1.PaymentStatus.FULLY_PAID) {
                throw new common_1.BadRequestException(`该订单已全额支付（支付状态: ${order.paymentStatus}），请勿重复收款`);
            }
            const existingFullPayments = await this.prisma.payment.findMany({
                where: {
                    orderId: order.id,
                    status: status_enum_1.PaymentStatus.FULLY_PAID,
                },
            });
            const totalFullyPaid = existingFullPayments.reduce((sum, p) => sum + Number(p.amount), 0);
            if (totalFullyPaid + Number(createPaymentDto.amount) > Number(order.totalAmount)) {
                throw new common_1.BadRequestException(`该订单已收款 ¥${totalFullyPaid.toFixed(2)}，本次收款 ¥${Number(createPaymentDto.amount).toFixed(2)} 将超过订单总额 ¥${Number(order.totalAmount).toFixed(2)}，请核实后操作`);
            }
            const paymentMethodMap = {
                'WECHAT': 'WECHAT_PAY',
                'ALIPAY': 'ALIPAY',
                'CASH': 'CASH',
                'BANK_TRANSFER': 'BANK_CARD'
            };
            const payment = await this.prisma.payment.create({
                data: {
                    order: {
                        connect: {
                            orderNo: createPaymentDto.orderNo,
                        },
                    },
                    amount: createPaymentDto.amount,
                    paymentType: 'FULL',
                    paymentMethod: paymentMethodMap[createPaymentDto.paymentType] || 'WECHAT_PAY',
                    status: 'PENDING_PAYMENT',
                },
            });
            let paymentResult;
            if (createPaymentDto.paymentType === 'WECHAT') {
                paymentResult = await this.wechatPayService.createJsapiOrder({
                    orderId: payment.id,
                    orderNo: createPaymentDto.orderNo,
                    description: createPaymentDto.description || `${order.package?.name || '套系'} - 支付`,
                    amount: Number(createPaymentDto.amount),
                    openid: order.user.openid,
                });
                await this.prisma.payment.update({
                    where: { id: payment.id },
                    data: {
                        status: status_enum_1.PaymentStatus.PENDING_PAYMENT,
                    },
                });
            }
            const response = {
                payment_id: payment.id,
                order_no: createPaymentDto.orderNo,
                amount: Number(createPaymentDto.amount),
                status: status_enum_1.PaymentStatus.PENDING_PAYMENT,
                idempotency_key: finalIdemKey,
                payment_info: paymentResult
                    ? {
                        prepayId: paymentResult.prepayId,
                        timeStamp: paymentResult.timeStamp,
                        nonceStr: paymentResult.nonceStr,
                        package: paymentResult.package,
                        signType: paymentResult.signType,
                        paySign: paymentResult.paySign,
                    }
                    : null,
            };
            this.logger.log(`支付订单创建成功: ${payment.id}`);
            const resultWrapper = {
                code: 200,
                message: '支付订单创建成功',
                data: response,
            };
            await this.cacheService.set(cacheKey, resultWrapper, 300);
            return resultWrapper;
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException ||
                error instanceof common_1.ConflictException) {
                throw error;
            }
            this.logger.error(`创建支付订单失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('创建支付订单失败');
        }
    }
    async getPaymentMeta() {
        const paymentStatuses = Object.values(status_enum_1.PaymentStatus);
        const orderStatuses = Object.values(status_enum_1.OrderStatus);
        const paymentChannels = Object.keys(create_payment_dto_1.PaymentChannel);
        return {
            code: 200,
            message: '支付元数据获取成功',
            data: {
                paymentStatuses,
                orderStatuses,
                paymentChannels,
                descriptions: status_enum_1.STATUS_DESCRIPTIONS,
            },
        };
    }
    generateIdempotencyKey(dto) {
        const base = `${dto.amount}|${dto.description || ''}`;
        const hash = (0, crypto_1.createHash)('sha256').update(base).digest('hex').slice(0, 16);
        return `${dto.paymentType}:${dto.orderNo}:${hash}`;
    }
    async findPendingPaymentByOrderNo(orderNo) {
        const order = await this.prisma.order.findUnique({
            where: { orderNo },
        });
        if (!order)
            return null;
        return this.prisma.payment.findFirst({
            where: {
                orderId: order.id,
                status: status_enum_1.PaymentStatus.PENDING_PAYMENT,
            },
            orderBy: { createdAt: 'desc' },
        });
    }
    async createPaymentRecord(params) {
        return this.prisma.payment.create({
            data: {
                orderId: params.orderId,
                amount: params.amount,
                paymentType: 'FULL',
                paymentMethod: params.paymentMethod,
                status: status_enum_1.PaymentStatus.PENDING_PAYMENT,
            },
        });
    }
    async handleWxPayNotify(body, headers) {
        try {
            const timestamp = headers['wechatpay-timestamp'];
            const nonce = headers['wechatpay-nonce'];
            const signature = headers['wechatpay-signature'];
            const serialNo = headers['wechatpay-serial'];
            const isValid = this.wechatPayService.verifyNotifySignature(timestamp, nonce, JSON.stringify(body), signature, serialNo);
            if (!isValid) {
                throw new common_1.BadRequestException('签名验证失败');
            }
            if (body.resource) {
                const notifyData = this.wechatPayService.decryptNotifyData(body.resource.ciphertext, body.resource.associated_data, body.resource.nonce);
                await this.handlePaymentResult(notifyData);
            }
            else {
                this.logger.warn('微信回调缺少 resource 字段', JSON.stringify(body));
            }
            return { code: 'SUCCESS', message: '成功' };
        }
        catch (error) {
            this.logger.error(`处理微信支付回调失败: ${error.message}`, error.stack);
            return { code: 'FAIL', message: error.message };
        }
    }
    async findAll(searchDto) {
        const { page = 1, limit = 20, phone, status, startDate, endDate, paymentType, orderNo, paymentNo, transactionId, minAmount, maxAmount, includeUnpaidOrders = true, } = searchDto;
        try {
            let allPaymentRecords = [];
            let totalCount = 0;
            const paymentWhere = {};
            const orderConditions = {};
            if (phone) {
                orderConditions.user = { phone };
            }
            if (orderNo) {
                orderConditions.orderNo = orderNo;
            }
            if (Object.keys(orderConditions).length > 0) {
                paymentWhere.order = orderConditions;
            }
            if (paymentNo) {
                paymentWhere.id = paymentNo;
            }
            if (transactionId) {
                paymentWhere.transactionId = { contains: transactionId, mode: 'insensitive' };
            }
            const validPaymentStatuses = ['PENDING_PAYMENT', 'PARTIAL_PAID', 'FULLY_PAID', 'REFUNDING', 'PARTIAL_REFUNDED', 'REFUNDED', 'CANCELLED'];
            const statusToPrisma = {
                'PENDING_PAYMENT': 'PENDING_PAYMENT',
                'PARTIAL_PAID': 'PARTIAL_PAID',
                'FULLY_PAID': 'FULLY_PAID',
                'PAID': 'FULLY_PAID',
                'CANCELLED': 'CANCELLED',
                'REFUNDING': 'REFUNDING',
                'REFUNDED': 'REFUNDED',
                'PROCESSING': 'PENDING_PAYMENT',
                'FAILED': 'PENDING_PAYMENT',
            };
            if (status) {
                const prismaStatus = statusToPrisma[status];
                if (prismaStatus && validPaymentStatuses.includes(prismaStatus)) {
                    paymentWhere.status = prismaStatus;
                }
            }
            const methodToPrisma = {
                'WECHAT': 'WECHAT_PAY',
                'ALIPAY': 'ALIPAY_TRANSFER',
                'CASH': 'CASH',
                'BANK_TRANSFER': 'BANK_CARD',
            };
            if (paymentType) {
                const prismaMethod = methodToPrisma[paymentType];
                if (prismaMethod) {
                    paymentWhere.paymentMethod = prismaMethod;
                }
            }
            if (minAmount !== undefined || maxAmount !== undefined) {
                paymentWhere.amount = {};
                if (minAmount !== undefined) {
                    paymentWhere.amount.gte = minAmount;
                }
                if (maxAmount !== undefined) {
                    paymentWhere.amount.lte = maxAmount;
                }
            }
            if (startDate || endDate) {
                paymentWhere.createdAt = {};
                if (startDate) {
                    const start = new Date(startDate);
                    start.setHours(0, 0, 0, 0);
                    paymentWhere.createdAt.gte = start;
                }
                if (endDate) {
                    const end = new Date(endDate);
                    end.setHours(23, 59, 59, 999);
                    paymentWhere.createdAt.lte = end;
                }
            }
            const [payments, paymentCount] = await Promise.all([
                this.prisma.payment.findMany({
                    where: paymentWhere,
                    include: {
                        order: {
                            include: {
                                user: {
                                    select: { nickname: true, phone: true, openid: true },
                                },
                                package: {
                                    select: { name: true, price: true },
                                },
                            },
                        },
                    },
                    orderBy: { createdAt: 'desc' },
                }),
                this.prisma.payment.count({ where: paymentWhere }),
            ]);
            allPaymentRecords = payments.map(payment => ({
                payment_id: payment.id,
                order_no: payment.order.orderNo,
                amount: Number(payment.amount),
                payment_type: payment.paymentType,
                payment_method: payment.paymentMethod,
                status: payment.status,
                transaction_id: payment.transactionId,
                paid_at: payment.paidAt,
                created_at: payment.createdAt,
                order_info: {
                    user: payment.order.user,
                    package: payment.order.package,
                    total_amount: Number(payment.order.totalAmount),
                    order: payment.order,
                },
                refund_amount: Number(payment.order?.refundedAmount || 0),
                refund_reason: payment.refundReason,
            }));
            if (includeUnpaidOrders && (!status || status === 'PENDING') && !paymentNo && !transactionId) {
                const unpaidOrderWhere = {
                    paymentStatus: status_enum_1.PaymentStatus.PENDING_PAYMENT,
                };
                if (phone) {
                    unpaidOrderWhere.user = { phone };
                }
                if (orderNo) {
                    if (unpaidOrderWhere.user) {
                        unpaidOrderWhere.AND = [
                            { user: unpaidOrderWhere.user },
                            { orderNo }
                        ];
                        delete unpaidOrderWhere.user;
                    }
                    else {
                        unpaidOrderWhere.orderNo = orderNo;
                    }
                }
                if (startDate || endDate) {
                    unpaidOrderWhere.createdAt = {};
                    if (startDate)
                        unpaidOrderWhere.createdAt.gte = new Date(startDate);
                    if (endDate)
                        unpaidOrderWhere.createdAt.lte = new Date(endDate);
                }
                const existingOrderNos = payments.map(p => p.order.orderNo);
                if (existingOrderNos.length > 0) {
                    if (unpaidOrderWhere.orderNo && typeof unpaidOrderWhere.orderNo === 'string') {
                        unpaidOrderWhere.AND = [
                            ...(unpaidOrderWhere.AND || []),
                            { orderNo: unpaidOrderWhere.orderNo },
                            { orderNo: { notIn: existingOrderNos } }
                        ];
                        delete unpaidOrderWhere.orderNo;
                    }
                    else {
                        unpaidOrderWhere.orderNo = { notIn: existingOrderNos };
                    }
                }
                const unpaidOrders = await this.prisma.order.findMany({
                    where: unpaidOrderWhere,
                    include: {
                        user: {
                            select: { nickname: true, phone: true, openid: true },
                        },
                        package: {
                            select: { name: true, price: true },
                        },
                    },
                    orderBy: { createdAt: 'desc' },
                    take: 100,
                });
                const unpaidPaymentRecords = unpaidOrders.map(order => ({
                    payment_id: `PENDING_${order.orderNo}`,
                    order_no: order.orderNo,
                    amount: Number(order.depositAmount || order.totalAmount),
                    payment_type: null,
                    payment_method: null,
                    status: status_enum_1.PaymentStatus.PENDING_PAYMENT,
                    transaction_id: null,
                    paid_at: null,
                    created_at: order.createdAt,
                    order_info: {
                        user: order.user,
                        package: order.package,
                        total_amount: Number(order.totalAmount),
                        order: order,
                    },
                    refund_amount: 0,
                    refund_reason: null,
                }));
                allPaymentRecords = [...allPaymentRecords, ...unpaidPaymentRecords];
                totalCount = paymentCount + unpaidOrders.length;
            }
            else {
                totalCount = paymentCount;
            }
            if (minAmount !== undefined || maxAmount !== undefined) {
                allPaymentRecords = allPaymentRecords.filter(record => {
                    const amount = Number(record.amount);
                    if (minAmount !== undefined && amount < minAmount)
                        return false;
                    if (maxAmount !== undefined && amount > maxAmount)
                        return false;
                    return true;
                });
                totalCount = allPaymentRecords.length;
            }
            allPaymentRecords.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
            const paginatedRecords = allPaymentRecords.slice((page - 1) * limit, page * limit);
            return {
                code: 200,
                message: '查询成功',
                data: {
                    payments: paginatedRecords,
                    pagination: {
                        total: totalCount,
                        page,
                        limit,
                        totalPages: Math.ceil(totalCount / limit),
                    },
                },
            };
        }
        catch (error) {
            this.logger.error(`查询支付列表失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async findByPhone(phone, pagination) {
        try {
            const cacheKey = this.cacheService.generateKey('payment-phone', phone, pagination.page.toString(), pagination.limit.toString());
            return this.cacheService.getOrSet(cacheKey, async () => {
                const { page, limit } = pagination;
                const [payments, total] = await Promise.all([
                    this.prisma.payment.findMany({
                        where: {
                            order: {
                                user: { phone },
                            },
                        },
                        include: {
                            order: {
                                include: {
                                    package: {
                                        select: { name: true, price: true },
                                    },
                                },
                            },
                        },
                        orderBy: { createdAt: 'desc' },
                        skip: (page - 1) * limit,
                        take: limit,
                    }),
                    this.prisma.payment.count({
                        where: {
                            order: {
                                user: { phone },
                            },
                        },
                    }),
                ]);
                if (total === 0) {
                    throw new common_1.NotFoundException('未找到相关支付记录');
                }
                return {
                    code: 200,
                    message: '查询成功',
                    data: {
                        payments: payments.map((payment) => ({
                            payment_id: payment.id,
                            order_no: payment.order.orderNo,
                            amount: Number(payment.amount),
                            payment_type: payment.paymentType,
                            status: payment.status,
                            transaction_id: payment.transactionId,
                            paid_at: payment.paidAt,
                            created_at: payment.createdAt,
                            package_info: payment.order.package,
                            order_amount: Number(payment.order.totalAmount),
                        })),
                        pagination: {
                            total,
                            page,
                            limit,
                            totalPages: Math.ceil(total / limit),
                        },
                    },
                };
            }, 600);
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`通过手机号查找支付记录失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async findByOrderNo(orderNo) {
        try {
            const cacheKey = this.cacheService.generateKey('payment-order', orderNo);
            return this.cacheService.getOrSet(cacheKey, async () => {
                const payments = await this.prisma.payment.findMany({
                    where: {
                        order: {
                            orderNo,
                        },
                    },
                    include: {
                        order: {
                            include: {
                                user: {
                                    select: { nickname: true, phone: true },
                                },
                                package: true,
                            },
                        },
                    },
                    orderBy: { createdAt: 'desc' },
                });
                if (payments.length === 0) {
                    throw new common_1.NotFoundException('未找到相关支付记录');
                }
                return {
                    code: 200,
                    message: '查询成功',
                    data: payments.map((payment) => ({
                        payment_id: payment.id,
                        order_no: payment.order.orderNo,
                        amount: Number(payment.amount),
                        payment_type: payment.paymentType,
                        status: payment.status,
                        transaction_id: payment.transactionId,
                        paid_at: payment.paidAt,
                        created_at: payment.createdAt,
                        order_info: payment.order,
                    })),
                };
            }, 600);
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`通过订单号查找支付记录失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async findOne(id) {
        const payment = await this.prisma.payment.findUnique({
            where: { id },
            include: { order: true },
        });
        if (!payment) {
            throw new common_1.NotFoundException(`Payment with id ${id} not found`);
        }
        return {
            ...payment,
            refund_amount: Number(payment.order?.refundedAmount || 0),
        };
    }
    async update(id, updatePaymentDto) {
        await this.findOne(id);
        const data = { ...updatePaymentDto };
        if (updatePaymentDto.paidAt) {
            data.paidAt = new Date(updatePaymentDto.paidAt);
        }
        if (updatePaymentDto.refundedAt) {
            data.refundedAt = new Date(updatePaymentDto.refundedAt);
        }
        const updatedPayment = await this.prisma.payment.update({
            where: { id },
            data,
            include: { order: true },
        });
        return updatedPayment;
    }
    async refund(id, refundPaymentDto) {
        const payment = await this.prisma.payment.findUnique({
            where: { id },
            include: { order: true },
        });
        if (!payment) {
            throw new common_1.NotFoundException(`Payment with id ${id} not found`);
        }
        const { refundAmount, refundReason } = refundPaymentDto;
        this.logger.log(`申请退款: 金额=${refundAmount}, 原因=${refundReason}`);
        await this.prisma.$transaction(async (tx) => {
            await tx.payment.update({
                where: { id },
                data: { status: 'REFUNDED' },
            });
            await tx.order.update({
                where: { id: payment.orderId },
                data: {
                    refundedAmount: {
                        increment: Number(refundAmount),
                    },
                },
            });
            await tx.refundRequest.create({
                data: {
                    orderId: payment.orderId,
                    orderNo: payment.order.orderNo,
                    refundNo: this.generateRefundNo(),
                    refundType: create_refund_request_dto_1.RefundType.PARTIAL,
                    refundAmount: refundAmount,
                    refundReason: refundReason || '管理员退款',
                    refundMethod: create_refund_request_dto_1.RefundMethod.ORIGINAL,
                    applicantType: 'ADMIN',
                    status: refund_request_search_dto_1.RefundStatus.COMPLETED,
                    approvedBy: 'SYSTEM',
                    approvedAt: new Date(),
                    refundedBy: 'SYSTEM',
                    refundedAt: new Date(),
                },
            });
        });
        return this.prisma.payment.findUnique({
            where: { id },
            include: { order: true },
        });
    }
    async cancel(id) {
        const payment = await this.prisma.payment.findUnique({
            where: { id },
        });
        if (!payment) {
            throw new common_1.NotFoundException(`Payment with id ${id} not found`);
        }
        await this.prisma.payment.update({
            where: { id },
            data: { status: status_enum_1.PaymentStatus.CANCELLED },
        });
        return this.prisma.payment.findUnique({
            where: { id },
            include: { order: true },
        });
    }
    async remove(id) {
        const payment = await this.prisma.payment.findUnique({
            where: { id },
        });
        if (!payment) {
            throw new common_1.NotFoundException(`Payment with id ${id} not found`);
        }
        await this.prisma.payment.delete({
            where: { id },
        });
        return { message: 'Payment deleted successfully' };
    }
    async getPaymentStatus(id) {
        const payment = await this.prisma.payment.findUnique({
            where: { id },
            select: { status: true, transactionId: true, paidAt: true },
        });
        if (!payment) {
            throw new common_1.NotFoundException(`Payment with id ${id} not found`);
        }
        return payment;
    }
    async getPaymentStatistics(query = {}) {
        const { startDate, endDate, paymentType } = query;
        try {
            const where = {};
            if (startDate || endDate) {
                where.createdAt = {};
                if (startDate)
                    where.createdAt.gte = new Date(startDate);
                if (endDate)
                    where.createdAt.lte = new Date(endDate);
            }
            if (paymentType) {
                where.paymentType = paymentType;
            }
            const [totalPayments, successPayments, failedPayments, pendingPayments, totalAmountResult, todayAmountResult, refundAmountResult,] = await Promise.all([
                this.prisma.payment.count({ where }),
                this.prisma.payment.count({
                    where: { ...where, status: status_enum_1.PaymentStatus.FULLY_PAID }
                }),
                this.prisma.payment.count({
                    where: { ...where, status: status_enum_1.PaymentStatus.CANCELLED }
                }),
                this.prisma.order.count({
                    where: {
                        paymentStatus: status_enum_1.PaymentStatus.PENDING_PAYMENT,
                        ...((startDate || endDate) && {
                            createdAt: {
                                ...(startDate && { gte: new Date(startDate) }),
                                ...(endDate && { lte: new Date(endDate) }),
                            }
                        })
                    }
                }),
                this.prisma.payment.aggregate({
                    where: { ...where, status: status_enum_1.PaymentStatus.FULLY_PAID },
                    _sum: { amount: true },
                }),
                this.prisma.payment.aggregate({
                    where: {
                        ...where,
                        status: status_enum_1.PaymentStatus.FULLY_PAID,
                        createdAt: {
                            gte: new Date(new Date().setHours(0, 0, 0, 0)),
                        },
                    },
                    _sum: { amount: true },
                }),
                this.prisma.order.aggregate({
                    where: {
                        payments: {
                            some: {
                                status: status_enum_1.PaymentStatus.REFUNDED,
                                ...((startDate || endDate) && {
                                    updatedAt: {
                                        ...(startDate && { gte: new Date(startDate) }),
                                        ...(endDate && { lte: new Date(endDate) }),
                                    }
                                }),
                            },
                        },
                        ...(paymentType && { payments: { some: { paymentType } } }),
                    },
                    _sum: { refundedAmount: true },
                }),
            ]);
            const totalOrdersWithPaymentAttempt = totalPayments + pendingPayments;
            const conversionRate = totalOrdersWithPaymentAttempt > 0
                ? (successPayments / totalOrdersWithPaymentAttempt) * 100
                : 0;
            return {
                code: 200,
                message: '统计查询成功',
                data: {
                    totalCount: totalPayments,
                    successCount: successPayments,
                    failedCount: failedPayments,
                    pendingCount: pendingPayments,
                    totalAmount: Number(totalAmountResult._sum?.amount || 0),
                    todayAmount: Number(todayAmountResult._sum?.amount || 0),
                    refundAmount: Number(refundAmountResult._sum?.refundedAmount || 0),
                    conversionRate: Math.round(conversionRate * 100) / 100,
                },
            };
        }
        catch (error) {
            this.logger.error(`获取支付统计失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('获取统计数据失败');
        }
    }
    async syncPaymentStatus(id) {
        if (id.startsWith('PENDING_')) {
            throw new common_1.BadRequestException('该订单尚未创建支付记录，请先确认收款');
        }
        const payment = await this.prisma.payment.findUnique({
            where: { id },
        });
        if (!payment) {
            throw new common_1.NotFoundException(`Payment with id ${id} not found`);
        }
        const newStatus = 'FULLY_PAID';
        await this.prisma.payment.update({
            where: { id },
            data: { status: newStatus },
        });
        return this.prisma.payment.findUnique({
            where: { id },
            include: { order: true },
        });
    }
    async exportPayments(searchDto) {
        try {
            const where = this.buildPaymentSearchConditions(searchDto);
            const payments = await this.prisma.payment.findMany({
                where,
                include: {
                    order: {
                        include: {
                            user: {
                                select: {
                                    nickname: true,
                                    phone: true,
                                },
                            },
                            package: {
                                select: {
                                    name: true,
                                },
                            },
                        },
                    },
                },
                orderBy: { createdAt: 'desc' },
                take: 10000,
            });
            const exportData = payments.map((payment, index) => ({
                序号: index + 1,
                支付单号: payment.id,
                关联订单: payment.order?.orderNo || '',
                用户昵称: payment.order?.user?.nickname || '',
                用户手机: payment.order?.user?.phone || '',
                套餐名称: payment.order?.package?.name || '',
                支付金额: Number(payment.amount || 0),
                支付方式: this.getPaymentMethodText(payment.paymentType),
                支付状态: this.getPaymentStatusText(payment.status),
                第三方单号: payment.transactionId || '',
                支付时间: payment.paidAt ? new Date(payment.paidAt).toLocaleString('zh-CN') : '',
                创建时间: new Date(payment.createdAt).toLocaleString('zh-CN'),
            }));
            return {
                code: 200,
                message: '导出数据获取成功',
                data: exportData,
                total: exportData.length,
            };
        }
        catch (error) {
            this.logger.error(`导出支付数据失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('导出数据失败');
        }
    }
    async getPaymentTrends(period = '7d') {
        try {
            const days = period === '30d' ? 30 : 7;
            const endDate = new Date();
            const startDate = new Date();
            startDate.setDate(startDate.getDate() - days);
            const trends = [];
            const currentDate = new Date(startDate);
            while (currentDate <= endDate) {
                const dayStart = new Date(currentDate);
                dayStart.setHours(0, 0, 0, 0);
                const dayEnd = new Date(currentDate);
                dayEnd.setHours(23, 59, 59, 999);
                const [dayPayments, dayAmount] = await Promise.all([
                    this.prisma.payment.count({
                        where: {
                            status: status_enum_1.PaymentStatus.FULLY_PAID,
                            createdAt: {
                                gte: dayStart,
                                lte: dayEnd,
                            },
                        },
                    }),
                    this.prisma.payment.aggregate({
                        where: {
                            status: status_enum_1.PaymentStatus.FULLY_PAID,
                            createdAt: {
                                gte: dayStart,
                                lte: dayEnd,
                            },
                        },
                        _sum: { amount: true },
                    }),
                ]);
                trends.push({
                    date: (0, date_util_1.formatLocalDate)(currentDate),
                    payments: dayPayments,
                    amount: Number(dayAmount._sum?.amount || 0),
                });
                currentDate.setDate(currentDate.getDate() + 1);
            }
            return {
                code: 200,
                message: '趋势数据获取成功',
                data: trends,
            };
        }
        catch (error) {
            this.logger.error(`获取支付趋势失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('获取趋势数据失败');
        }
    }
    async handlePaymentResult(notifyData) {
        const { out_trade_no, transaction_id, trade_state, amount } = notifyData;
        const order = await this.prisma.order.findUnique({
            where: { orderNo: out_trade_no },
            include: {
                payments: {
                    where: { status: { in: [status_enum_1.PaymentStatus.PENDING_PAYMENT, status_enum_1.PaymentStatus.PARTIAL_PAID, status_enum_1.PaymentStatus.FULLY_PAID] } },
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                },
            },
        });
        if (!order) {
            throw new common_1.NotFoundException(`订单不存在: ${out_trade_no}`);
        }
        let payment = order.payments?.[0] || null;
        if (payment && payment.status === status_enum_1.PaymentStatus.FULLY_PAID) {
            this.logger.warn(`幂等处理: 支付已处理 order=${out_trade_no} payment=${payment.id}`);
            return {
                success: true,
                message: '支付已处理',
                payment,
                order,
            };
        }
        let paidAmount;
        if (typeof amount === 'object' && amount !== null) {
            paidAmount = Number(amount.total) / 100;
        }
        else {
            paidAmount = Number(amount) || 0;
        }
        const paymentType = this.determinePaymentTypeFromOrder(order);
        if (!payment) {
            payment = await this.prisma.payment.create({
                data: {
                    orderId: order.id,
                    amount: paidAmount,
                    paymentType: paymentType,
                    status: status_enum_1.PaymentStatus.PENDING_PAYMENT,
                    paymentMethod: 'WECHAT_PAY',
                },
                include: { order: true },
            });
            this.logger.log(`微信支付回调自动创建支付记录: ${payment.id}`);
        }
        let status;
        let paidAt = null;
        switch (trade_state) {
            case 'SUCCESS':
                status = status_enum_1.PaymentStatus.FULLY_PAID;
                paidAt = new Date();
                break;
            case 'USERPAYING':
                status = status_enum_1.PaymentStatus.PENDING_PAYMENT;
                this.logger.log(`支付处理中: ${out_trade_no}，等待微信最终结果`);
                break;
            case 'CLOSED':
            case 'REVOKED':
                status = status_enum_1.PaymentStatus.CANCELLED;
                break;
            default:
                status = status_enum_1.PaymentStatus.CANCELLED;
        }
        await this.prisma.payment.update({
            where: { id: payment.id },
            data: {
                status: status,
                transactionId: transaction_id || payment.transactionId,
                paidAt: status === status_enum_1.PaymentStatus.FULLY_PAID ? (paidAt || new Date()) : payment.paidAt,
            },
        });
        if (status === status_enum_1.PaymentStatus.FULLY_PAID) {
            await this.updateOrderAfterPayment(order.orderNo, paidAmount);
            await this.autoStatusTransitionService.onPaymentSuccess(order.id, transaction_id);
            await this.notificationService.sendPaymentSuccessNotification(order.orderNo);
        }
        this.logger.log(`支付状态更新: ${out_trade_no} -> ${status}`);
    }
    determinePaymentTypeFromOrder(order) {
        const paymentMode = order.paymentMode || 'FULL';
        if (paymentMode.includes('DEPOSIT')) {
            const paidAmount = Number(order.paidAmount || 0);
            return paidAmount === 0 ? 'DEPOSIT' : 'FINAL';
        }
        return 'FULL';
    }
    async updateOrderAfterPayment(orderNo, paidAmount) {
        const order = await this.prisma.order.findUnique({
            where: { orderNo },
        });
        if (!order)
            return;
        const payments = await this.prisma.payment.findMany({
            where: {
                orderId: order.id,
                status: { in: ['FULLY_PAID', 'PARTIAL_PAID'] },
            },
        });
        const newPaidAmount = payments.reduce((sum, p) => sum + Number(p.amount), 0);
        const totalAmount = Number(order.totalAmount);
        let paymentStatus;
        if (newPaidAmount >= totalAmount) {
            paymentStatus = 'FULLY_PAID';
        }
        else if (newPaidAmount > 0) {
            paymentStatus = 'PARTIAL_PAID';
        }
        else {
            paymentStatus = 'PENDING_PAYMENT';
        }
        await this.prisma.order.update({
            where: { orderNo },
            data: {
                paidAmount: newPaidAmount,
                paymentStatus: paymentStatus,
            },
        });
        const cacheKeys = [
            this.cacheService.getOrderCacheKey(orderNo),
            this.cacheService.generateKey('payment-order', orderNo),
        ];
        await Promise.all(cacheKeys.map((key) => this.cacheService.del(key)));
    }
    generatePaymentId() {
        const timestamp = Date.now().toString();
        const random = Math.floor(Math.random() * 1000)
            .toString()
            .padStart(3, '0');
        return `PAY${timestamp}${random}`;
    }
    buildPaymentSearchConditions(searchDto) {
        const where = {};
        if (searchDto.paymentNo) {
            where.id = searchDto.paymentNo;
        }
        if (searchDto.orderNo) {
            where.order = {
                orderNo: { contains: searchDto.orderNo, mode: 'insensitive' },
            };
        }
        if (searchDto.phone) {
            where.order = {
                ...where.order,
                user: { phone: { contains: searchDto.phone, mode: 'insensitive' } },
            };
        }
        if (searchDto.paymentType) {
            where.paymentType = searchDto.paymentType;
        }
        if (searchDto.status) {
            where.status = searchDto.status;
        }
        if (searchDto.transactionId) {
            where.transactionId = { contains: searchDto.transactionId, mode: 'insensitive' };
        }
        if (searchDto.startDate || searchDto.endDate) {
            where.createdAt = {};
            if (searchDto.startDate) {
                where.createdAt.gte = new Date(searchDto.startDate);
            }
            if (searchDto.endDate) {
                where.createdAt.lte = new Date(searchDto.endDate);
            }
        }
        if (searchDto.minAmount || searchDto.maxAmount) {
            where.amount = {};
            if (searchDto.minAmount) {
                where.amount.gte = Number(searchDto.minAmount);
            }
            if (searchDto.maxAmount) {
                where.amount.lte = Number(searchDto.maxAmount);
            }
        }
        return where;
    }
    getPaymentMethodText(paymentType) {
        const methodMap = {
            'WECHAT': '微信支付',
            'ALIPAY': '支付宝',
            'CASH': '现金支付',
            'BANK_TRANSFER': '银行卡支付',
            'DEPOSIT': '定金支付',
            'FULL_PAYMENT': '全款支付',
        };
        return methodMap[paymentType] || paymentType;
    }
    async getOrderBalance(orderId) {
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
            include: {
                payments: {
                    orderBy: { createdAt: 'desc' },
                },
            },
        });
        if (!order) {
            throw new common_1.NotFoundException('订单不存在');
        }
        const totalAmount = Number(order.totalAmount);
        const paidPayments = order.payments.filter(payment => payment.status === 'FULLY_PAID');
        const totalPaidAmount = paidPayments.reduce((sum, payment) => sum + Number(payment.amount), 0);
        const refundedPayments = order.payments.filter(payment => payment.status === status_enum_1.OrderStatus.CANCELLED);
        const totalRefundedAmount = refundedPayments.reduce((sum, payment) => sum + Number(payment.amount), 0);
        const actualPaidAmount = totalPaidAmount - totalRefundedAmount;
        this.logger.log(`订单${orderId}余额计算:`);
        this.logger.log(`总支付记录: ${order.payments.length}`);
        this.logger.log(`已付支付记录: ${paidPayments.length}, 金额: ${totalPaidAmount}`);
        this.logger.log(`退款支付记录: ${refundedPayments.length}, 金额: ${totalRefundedAmount}`);
        this.logger.log(`实际已付金额: ${actualPaidAmount}`);
        order.payments.forEach(p => {
            this.logger.log(`支付记录: ${p.id}, 金额: ${p.amount}, 状态: ${p.status}, 类型: ${p.paymentType}`);
        });
        const remainingAmount = totalAmount - actualPaidAmount;
        const overpaidAmount = actualPaidAmount > totalAmount ? actualPaidAmount - totalAmount : 0;
        let paymentStatus;
        let isFreeOrder = false;
        if (totalAmount === 0) {
            isFreeOrder = true;
            if (actualPaidAmount > 0) {
                paymentStatus = 'OVERPAID';
            }
            else {
                paymentStatus = 'FREE';
            }
        }
        else if (actualPaidAmount > totalAmount) {
            paymentStatus = 'OVERPAID';
        }
        else if (actualPaidAmount >= totalAmount) {
            paymentStatus = 'PAID';
        }
        else if (actualPaidAmount > 0) {
            paymentStatus = 'PARTIAL';
        }
        else {
            paymentStatus = 'PENDING';
        }
        return {
            totalAmount,
            paidAmount: actualPaidAmount,
            remainingAmount: remainingAmount > 0 ? remainingAmount : 0,
            overpaidAmount,
            isFreeOrder,
            isFullyPaid: actualPaidAmount >= totalAmount && totalAmount > 0,
            isOverpaid: actualPaidAmount > totalAmount,
            paymentStatus: paymentStatus,
            payments: order.payments.map(payment => ({
                id: payment.id,
                amount: Number(payment.amount),
                paymentType: payment.paymentType,
                status: payment.status,
                createdAt: payment.createdAt,
                transactionId: payment.transactionId,
            })),
        };
    }
    async collectBalance(collectBalanceDto) {
        const { orderId, amount, paymentType, notes } = collectBalanceDto;
        try {
            this.logger.log(`开始收取尾款，订单ID: ${orderId}, 金额: ${amount}, 支付方式: ${paymentType}`);
            return await this.prisma.$transaction(async (tx) => {
                const order = await tx.order.findUnique({
                    where: { id: orderId },
                    include: { user: true, package: true },
                });
                if (!order) {
                    throw new common_1.NotFoundException('订单不存在');
                }
                this.logger.log(`找到订单: ${order.orderNo}, 总额: ${order.totalAmount}, 已付: ${order.paidAmount}`);
                if (order.orderStatus === 'CANCELLED') {
                    throw new common_1.BadRequestException('订单已取消，无法收取尾款。如需继续请先恢复订单或申请退款。');
                }
                if (order.orderStatus === status_enum_1.OrderStatus.CANCELLED) {
                    throw new common_1.BadRequestException('订单已退款，无法收取尾款。');
                }
                const totalAmount = Number(order.totalAmount);
                const paidAmount = Number(order.paidAmount);
                if (totalAmount === 0) {
                    throw new common_1.BadRequestException('该订单为免费订单（订单总额为0），不允许收款。如需收款，请先调整订单金额。');
                }
                if (paidAmount > totalAmount) {
                    const overpaid = paidAmount - totalAmount;
                    throw new common_1.BadRequestException(`该订单已多收款 ¥${overpaid.toFixed(2)}，实际已付 ¥${paidAmount}，订单总额 ¥${totalAmount}。请先处理多收款项，再进行新的收款操作。`);
                }
                const remainingAmount = totalAmount - paidAmount;
                if (amount > remainingAmount) {
                    throw new common_1.BadRequestException(`收取金额 ¥${amount} 超过剩余金额 ¥${remainingAmount}`);
                }
                if (remainingAmount <= 0) {
                    throw new common_1.BadRequestException('该订单已全额支付，无需收取尾款');
                }
                const payment = await tx.payment.create({
                    data: {
                        orderId: orderId,
                        paymentType: 'FINAL',
                        paymentMethod: paymentType,
                        amount,
                        status: status_enum_1.PaymentStatus.FULLY_PAID,
                        paidAt: new Date(),
                    },
                });
                const newPaidAmount = paidAmount + amount;
                const roundedPaidAmount = Math.round(newPaidAmount * 100) / 100;
                const roundedTotalAmount = Math.round(totalAmount * 100) / 100;
                const isFullyPaid = roundedPaidAmount >= roundedTotalAmount;
                this.logger.log(`订单 ${order.orderNo} 收款: 已付=${newPaidAmount}, 总额=${totalAmount}, ` +
                    `四舍五入后: 已付=${roundedPaidAmount}, 总额=${roundedTotalAmount}, ` +
                    `是否全额支付=${isFullyPaid}`);
                const updatedOrder = await tx.order.update({
                    where: { id: orderId },
                    data: {
                        paidAmount: newPaidAmount,
                        paymentStatus: (isFullyPaid ? 'FULLY_PAID' : 'PARTIAL_PAID'),
                        orderStatus: isFullyPaid && order.orderStatus === 'CONFIRMED'
                            ? 'IN_PROGRESS'
                            : order.orderStatus,
                        updatedAt: new Date(),
                    },
                    include: {
                        user: { select: { nickname: true, phone: true } },
                        package: { select: { name: true } },
                    },
                });
                if (isFullyPaid && order.orderStatus === 'CONFIRMED') {
                    this.logger.log(`订单 ${order.orderNo} 尾款收取完成，状态变更为进行中`);
                }
                this.logger.log(`收款成功，订单: ${order.orderNo}, 本次收款: ¥${amount}, 已付总额: ¥${newPaidAmount}`);
                return {
                    code: 200,
                    message: isFullyPaid ? '尾款收取成功，订单已全额支付' : '尾款收取成功',
                    data: {
                        paymentId: payment.id,
                        orderId: updatedOrder.id,
                        orderNo: updatedOrder.orderNo,
                        collectAmount: amount,
                        totalAmount,
                        paidAmount: newPaidAmount,
                        remainingAmount: totalAmount - newPaidAmount,
                        isFullyPaid,
                        paymentStatus: updatedOrder.paymentStatus,
                        orderStatus: updatedOrder.orderStatus,
                        payment: {
                            id: payment.id,
                            amount: Number(payment.amount),
                            paymentType: payment.paymentType,
                            status: payment.status,
                            paidAt: payment.paidAt,
                        },
                    },
                };
            });
        }
        catch (error) {
            this.logger.error(`收取尾款失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async confirmPayment(paymentId) {
        return await this.prisma.$transaction(async (tx) => {
            if (paymentId.startsWith('PENDING_')) {
                const orderNo = paymentId.replace('PENDING_', '');
                const order = await tx.order.findUnique({
                    where: { orderNo },
                    include: {
                        items: {
                            where: { itemType: 'PRODUCT' },
                            include: { product: true },
                        },
                    },
                });
                if (!order) {
                    throw new common_1.NotFoundException(`订单 ${orderNo} 不存在`);
                }
                const amount = Number(order.depositAmount || order.totalAmount);
                const newPayment = await tx.payment.create({
                    data: {
                        orderId: order.id,
                        amount,
                        paymentType: 'DEPOSIT',
                        paymentMethod: 'CASH',
                        status: status_enum_1.PaymentStatus.FULLY_PAID,
                        paidAt: new Date(),
                        notes: `现金确认收款（原虚拟记录 ${paymentId}）`,
                    },
                });
                const payments = await tx.payment.findMany({
                    where: { orderId: order.id, status: status_enum_1.PaymentStatus.FULLY_PAID },
                });
                const totalPaidAmount = payments.reduce((sum, p) => sum + Number(p.amount), 0);
                const totalAmount = Number(order.totalAmount);
                const roundedPaidAmount = Math.round(totalPaidAmount * 100) / 100;
                const roundedTotalAmount = Math.round(totalAmount * 100) / 100;
                const isFullyPaid = roundedPaidAmount >= roundedTotalAmount;
                const updatedOrder = await tx.order.update({
                    where: { id: order.id },
                    data: {
                        paidAmount: totalPaidAmount,
                        paymentStatus: (isFullyPaid ? 'FULLY_PAID' : 'PARTIAL_PAID'),
                        orderStatus: isFullyPaid && order.orderStatus === 'PENDING'
                            ? 'IN_PROGRESS'
                            : order.orderStatus,
                    },
                });
                if (isFullyPaid && order.items && order.items.length > 0) {
                    for (const item of order.items) {
                        const product = item.product;
                        if (product && product.isTrackStock) {
                            if (product.stockQuantity < item.quantity) {
                                throw new common_1.BadRequestException(`商品 ${product.name} 库存不足，当前库存：${product.stockQuantity}，需要：${item.quantity}`);
                            }
                            await tx.product.update({
                                where: { id: product.id },
                                data: { stockQuantity: { decrement: item.quantity } },
                            });
                            this.logger.log(`库存扣减: ${product.name} x${item.quantity}, 剩余: ${product.stockQuantity - item.quantity}`);
                        }
                    }
                }
                this.logger.log(`虚拟支付确认: ${paymentId} → 创建真实支付 ${newPayment.id}, 订单 ${order.orderNo}`);
                return {
                    code: 200,
                    message: isFullyPaid ? '收款成功,订单已全额支付' : '收款成功',
                    data: {
                        paymentId: newPayment.id,
                        orderId: updatedOrder.id,
                        orderNo: updatedOrder.orderNo,
                        paidAmount: totalPaidAmount,
                        totalAmount,
                        remainingAmount: totalAmount - totalPaidAmount,
                        isFullyPaid,
                        paymentStatus: updatedOrder.paymentStatus,
                        orderStatus: updatedOrder.orderStatus,
                    },
                };
            }
            const payment = await tx.payment.findUnique({
                where: { id: paymentId },
                include: { order: true },
            });
            if (!payment) {
                throw new common_1.NotFoundException('支付记录不存在');
            }
            if (payment.status === status_enum_1.PaymentStatus.FULLY_PAID) {
                throw new common_1.BadRequestException('该支付已确认,无需重复操作');
            }
            const updatedPayment = await tx.payment.update({
                where: { id: paymentId },
                data: {
                    status: status_enum_1.PaymentStatus.FULLY_PAID,
                    paidAt: new Date(),
                },
            });
            const order = await tx.order.findUnique({
                where: { id: payment.orderId },
                include: {
                    payments: true,
                    items: {
                        where: { itemType: 'PRODUCT' },
                        include: { product: true },
                    },
                },
            });
            if (!order) {
                throw new common_1.NotFoundException('关联订单不存在');
            }
            const totalPaidAmount = order.payments
                .filter(p => p.status === 'FULLY_PAID')
                .reduce((sum, p) => sum + Number(p.amount), 0);
            const totalAmount = Number(order.totalAmount);
            const roundedPaidAmount = Math.round(totalPaidAmount * 100) / 100;
            const roundedTotalAmount = Math.round(totalAmount * 100) / 100;
            const isFullyPaid = roundedPaidAmount >= roundedTotalAmount;
            this.logger.log(`确认支付 ${paymentId}, 订单 ${order.orderNo}: 已付=${totalPaidAmount}, 总额=${totalAmount}, ` +
                `四舍五入后: 已付=${roundedPaidAmount}, 总额=${roundedTotalAmount}, ` +
                `是否全额支付=${isFullyPaid}`);
            const updatedOrder = await tx.order.update({
                where: { id: order.id },
                data: {
                    paidAmount: totalPaidAmount,
                    paymentStatus: (isFullyPaid ? 'FULLY_PAID' : 'PARTIAL_PAID'),
                    orderStatus: isFullyPaid && order.orderStatus === 'PENDING'
                        ? 'IN_PROGRESS'
                        : order.orderStatus,
                },
            });
            if (isFullyPaid && order.items && order.items.length > 0) {
                for (const item of order.items) {
                    const product = item.product;
                    if (product && product.isTrackStock) {
                        if (product.stockQuantity < item.quantity) {
                            throw new common_1.BadRequestException(`商品 ${product.name} 库存不足，当前库存：${product.stockQuantity}，需要：${item.quantity}`);
                        }
                        await tx.product.update({
                            where: { id: product.id },
                            data: { stockQuantity: { decrement: item.quantity } },
                        });
                        this.logger.log(`库存扣减: ${product.name} x${item.quantity}, 剩余: ${product.stockQuantity - item.quantity}`);
                    }
                }
            }
            this.logger.log(`支付确认成功: ${paymentId}, 订单 ${order.orderNo} 已付金额: ${totalPaidAmount}`);
            return {
                code: 200,
                message: isFullyPaid ? '支付确认成功,订单已全额支付' : '支付确认成功',
                data: {
                    paymentId: updatedPayment.id,
                    orderId: updatedOrder.id,
                    orderNo: updatedOrder.orderNo,
                    paidAmount: totalPaidAmount,
                    totalAmount,
                    remainingAmount: totalAmount - totalPaidAmount,
                    isFullyPaid,
                    paymentStatus: updatedOrder.paymentStatus,
                    orderStatus: updatedOrder.orderStatus,
                },
            };
        });
    }
    async getOrderPaymentHistory(orderId) {
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
            include: {
                payments: {
                    orderBy: { createdAt: 'asc' },
                },
                user: {
                    select: { nickname: true, phone: true },
                },
                package: {
                    select: { name: true, price: true },
                },
            },
        });
        if (!order) {
            throw new common_1.NotFoundException('订单不存在');
        }
        const totalAmount = Number(order.totalAmount);
        const paidAmount = Number(order.paidAmount);
        const remainingAmount = totalAmount - paidAmount;
        return {
            code: 200,
            message: '查询成功',
            data: {
                order: {
                    id: order.id,
                    orderNo: order.orderNo,
                    totalAmount,
                    paidAmount,
                    remainingAmount,
                    isFullyPaid: remainingAmount <= 0,
                    paymentStatus: order.paymentStatus,
                    orderStatus: order.orderStatus,
                    customer: order.user,
                    package: order.package,
                },
                payments: order.payments.map((payment, index) => ({
                    id: payment.id,
                    sequence: index + 1,
                    amount: Number(payment.amount),
                    paymentType: payment.paymentType,
                    paymentMethod: payment.paymentMethod,
                    status: payment.status,
                    transactionId: payment.transactionId,
                    paidAt: payment.paidAt,
                    createdAt: payment.createdAt,
                    description: index === 0 ? '定金/首付款' : `第${index}次尾款`,
                })),
                summary: {
                    totalPayments: order.payments.length,
                    totalPaidAmount: order.payments
                        .filter(p => p.status === 'FULLY_PAID')
                        .reduce((sum, p) => sum + Number(p.amount), 0),
                    pendingAmount: remainingAmount,
                },
            },
        };
    }
    async processRefund(paymentId, reason, notes) {
        return await this.prisma.$transaction(async (tx) => {
            const payment = await tx.payment.findUnique({
                where: { id: paymentId },
                include: { order: true },
            });
            if (!payment) {
                throw new common_1.NotFoundException('支付记录不存在');
            }
            if (payment.status !== 'FULLY_PAID') {
                throw new common_1.BadRequestException('只能退款已支付成功的记录');
            }
            const refundedPayment = await tx.payment.update({
                where: { id: paymentId },
                data: {
                    status: 'REFUNDED',
                    refundedAt: new Date(),
                    refundReason: reason,
                    notes: notes ? `${payment.notes || ''}\n退款备注: ${notes}`.trim() : payment.notes,
                },
            });
            const validPayments = await tx.payment.findMany({
                where: {
                    orderId: payment.orderId,
                    status: status_enum_1.PaymentStatus.FULLY_PAID,
                },
            });
            const newPaidAmount = validPayments.reduce((sum, p) => sum + Number(p.amount), 0);
            const totalAmount = Number(payment.order.totalAmount);
            let paymentStatus;
            if (newPaidAmount >= totalAmount) {
                paymentStatus = 'FULLY_PAID';
            }
            else if (newPaidAmount > 0) {
                paymentStatus = 'PARTIAL_PAID';
            }
            else {
                paymentStatus = 'PENDING_PAYMENT';
            }
            const updatedOrder = await tx.order.update({
                where: { id: payment.orderId },
                data: {
                    paidAmount: newPaidAmount,
                    paymentStatus: paymentStatus,
                },
            });
            this.logger.log(`退款处理完成: 支付ID=${paymentId}, 金额=${payment.amount}, 原因=${reason || '无'}`);
            return {
                code: 200,
                message: '退款处理成功',
                data: {
                    refundedPayment: {
                        id: refundedPayment.id,
                        amount: Number(refundedPayment.amount),
                        paymentType: refundedPayment.paymentType,
                        status: refundedPayment.status,
                        refundedAt: refundedPayment.refundedAt,
                        refundReason: refundedPayment.refundReason,
                    },
                    order: {
                        id: updatedOrder.id,
                        orderNo: updatedOrder.orderNo,
                        totalAmount: Number(updatedOrder.totalAmount),
                        paidAmount: Number(updatedOrder.paidAmount),
                        remainingAmount: Number(updatedOrder.totalAmount) - Number(updatedOrder.paidAmount),
                        paymentStatus: updatedOrder.paymentStatus,
                    },
                },
            };
        });
    }
    getPaymentStatusText(status) {
        const statusMap = {
            PENDING: '待支付',
            PROCESSING: '处理中',
            PARTIAL: '部分支付',
            PAID: '已支付',
            OVERPAID: '多收款',
            FREE: '免费订单',
            FAILED: '支付失败',
            CANCELLED: '已取消',
            REFUNDING: '退款中',
            REFUNDED: '已退款'
        };
        return statusMap[status] || status;
    }
    generateRefundNo() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
        return `REF${year}${month}${day}${random}`;
    }
    async createRefundRequest(createDto) {
        try {
            const order = await this.prisma.order.findFirst({
                where: { orderNo: createDto.orderNo },
                include: {
                    payments: {
                        where: { status: status_enum_1.PaymentStatus.FULLY_PAID },
                    },
                },
            });
            if (!order) {
                throw new common_1.NotFoundException('订单不存在');
            }
            if (order.orderStatus === status_enum_1.OrderStatus.CANCELLED) {
                throw new common_1.BadRequestException('订单已退款，无需再次申请');
            }
            if (order.orderStatus === status_enum_1.OrderStatus.COMPLETED) {
                throw new common_1.BadRequestException('订单已完成，如需退款请联系管理员');
            }
            const paidAmount = Number(order.paidAmount);
            if (paidAmount === 0) {
                throw new common_1.BadRequestException('订单未支付，无需退款');
            }
            if (createDto.refundType === create_refund_request_dto_1.RefundType.FULL) {
                createDto.refundAmount = paidAmount;
            }
            else {
                if (createDto.refundAmount > paidAmount) {
                    throw new common_1.BadRequestException(`退款金额不能超过已支付金额 ¥${paidAmount}`);
                }
            }
            const existingRefundRequest = await this.prisma.refundRequest.findFirst({
                where: {
                    orderNo: createDto.orderNo,
                    status: {
                        in: ['PENDING', 'APPROVED', 'PROCESSING'],
                    },
                },
            });
            if (existingRefundRequest) {
                throw new common_1.ConflictException('该订单已有待处理的退款申请');
            }
            const refundRequest = await this.prisma.refundRequest.create({
                data: {
                    orderId: order.id,
                    orderNo: order.orderNo,
                    refundNo: this.generateRefundNo(),
                    refundType: createDto.refundType,
                    refundAmount: createDto.refundAmount,
                    refundReason: createDto.refundReason,
                    refundMethod: createDto.refundMethod || create_refund_request_dto_1.RefundMethod.ORIGINAL,
                    applicantType: createDto.applicantType || 'USER',
                    applicantId: createDto.applicantId,
                    applicantName: createDto.applicantName,
                    notes: createDto.notes,
                    attachments: createDto.attachments || [],
                    status: refund_request_search_dto_1.RefundStatus.PENDING,
                },
            });
            this.logger.log(`退款申请创建成功: ${refundRequest.refundNo}, 订单: ${order.orderNo}, 金额: ¥${createDto.refundAmount}`);
            return refundRequest;
        }
        catch (error) {
            this.logger.error(`创建退款申请失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async findAllRefundRequests(searchDto) {
        try {
            const { orderNo, refundNo, status, applicantId, startDate, endDate, page = 1, limit = 20, } = searchDto;
            const where = {};
            if (orderNo) {
                where.orderNo = { contains: orderNo };
            }
            if (refundNo) {
                where.refundNo = { contains: refundNo };
            }
            if (status) {
                where.status = status;
            }
            else {
                where.status = {
                    notIn: [refund_request_search_dto_1.RefundStatus.CANCELLED, refund_request_search_dto_1.RefundStatus.REJECTED],
                };
            }
            if (applicantId) {
                where.applicantId = applicantId;
            }
            if (startDate || endDate) {
                where.createdAt = {};
                if (startDate)
                    where.createdAt.gte = new Date(startDate);
                if (endDate)
                    where.createdAt.lte = new Date(endDate);
            }
            const total = await this.prisma.refundRequest.count({ where });
            const refundRequests = await this.prisma.refundRequest.findMany({
                where,
                orderBy: { createdAt: 'desc' },
                skip: (page - 1) * limit,
                take: limit,
            });
            return {
                data: refundRequests,
                total,
                page,
                limit,
                totalPages: Math.ceil(total / limit),
            };
        }
        catch (error) {
            this.logger.error(`查询退款申请列表失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async findOneRefundRequest(id) {
        const refundRequest = await this.prisma.refundRequest.findUnique({
            where: { id },
        });
        if (!refundRequest) {
            throw new common_1.NotFoundException('退款申请不存在');
        }
        return refundRequest;
    }
    async approveRefundRequest(id, approveDto) {
        try {
            const refundRequest = await this.prisma.refundRequest.findUnique({
                where: { id },
            });
            if (!refundRequest) {
                throw new common_1.NotFoundException('退款申请不存在');
            }
            if (refundRequest.status !== refund_request_search_dto_1.RefundStatus.PENDING) {
                throw new common_1.BadRequestException('只能审批待审批状态的退款申请');
            }
            const updated = await this.prisma.refundRequest.update({
                where: { id },
                data: {
                    status: refund_request_search_dto_1.RefundStatus.APPROVED,
                    approvedBy: approveDto.approvedBy || 'ADMIN',
                    approvedAt: new Date(),
                    notes: approveDto.notes || refundRequest.notes,
                },
            });
            try {
                const order = await this.prisma.order.findUnique({ where: { id: refundRequest.orderId } });
                const beforePaid = order ? Number(order.paidAmount || 0) : 0;
                await this.createRefundAudit({
                    refundRequestId: updated.id,
                    orderId: refundRequest.orderId,
                    orderNo: refundRequest.orderNo,
                    action: 'APPROVE',
                    amount: Number(updated.refundAmount),
                    beforePaid,
                    afterPaid: beforePaid,
                    operatorId: approveDto.approvedBy || 'ADMIN',
                    operatorName: approveDto.approvedBy || 'ADMIN',
                    notes: approveDto.notes || '审批通过',
                });
            }
            catch (e) {
                this.logger.error(`写入审批审计失败: ${e.message}`);
            }
            this.logger.log(`退款申请审批通过: ${refundRequest.refundNo}, 审批人: ${approveDto.approvedBy}`);
            return updated;
        }
        catch (error) {
            this.logger.error(`审批退款申请失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async rejectRefundRequest(id, rejectDto) {
        try {
            const refundRequest = await this.prisma.refundRequest.findUnique({
                where: { id },
            });
            if (!refundRequest) {
                throw new common_1.NotFoundException('退款申请不存在');
            }
            if (refundRequest.status !== refund_request_search_dto_1.RefundStatus.PENDING) {
                throw new common_1.BadRequestException('只能拒绝待审批状态的退款申请');
            }
            const updated = await this.prisma.refundRequest.update({
                where: { id },
                data: {
                    status: refund_request_search_dto_1.RefundStatus.REJECTED,
                    rejectedBy: rejectDto.rejectedBy || 'ADMIN',
                    rejectedAt: new Date(),
                    rejectReason: rejectDto.rejectReason,
                },
            });
            try {
                const order = await this.prisma.order.findUnique({ where: { id: refundRequest.orderId } });
                const beforePaid = order ? Number(order.paidAmount || 0) : 0;
                await this.createRefundAudit({
                    refundRequestId: updated.id,
                    orderId: refundRequest.orderId,
                    orderNo: refundRequest.orderNo,
                    action: 'REJECT',
                    amount: Number(updated.refundAmount),
                    beforePaid,
                    afterPaid: beforePaid,
                    operatorId: rejectDto.rejectedBy || 'ADMIN',
                    operatorName: rejectDto.rejectedBy || 'ADMIN',
                    notes: rejectDto.rejectReason || '审批拒绝',
                });
            }
            catch (e) {
                this.logger.error(`写入拒绝审计失败: ${e.message}`);
            }
            this.logger.log(`退款申请已拒绝: ${refundRequest.refundNo}, 原因: ${rejectDto.rejectReason}`);
            return updated;
        }
        catch (error) {
            this.logger.error(`拒绝退款申请失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async processRefundRequest(id, processDto) {
        try {
            const refundRequest = await this.prisma.refundRequest.findUnique({
                where: { id },
            });
            if (!refundRequest) {
                throw new common_1.NotFoundException('退款申请不存在');
            }
            if (refundRequest.status !== refund_request_search_dto_1.RefundStatus.APPROVED) {
                throw new common_1.BadRequestException('只能处理已审批的退款申请');
            }
            const result = await this.prisma.$transaction(async (tx) => {
                await tx.refundRequest.update({
                    where: { id },
                    data: {
                        status: refund_request_search_dto_1.RefundStatus.PROCESSING,
                    },
                });
                const order = await tx.order.findUnique({
                    where: { id: refundRequest.orderId },
                    include: {
                        payments: {
                            where: { status: status_enum_1.PaymentStatus.FULLY_PAID },
                            orderBy: { paidAt: 'desc' },
                        },
                    },
                });
                if (!order) {
                    throw new common_1.NotFoundException('订单不存在');
                }
                let transactionId = processDto.transactionId;
                if (refundRequest.refundMethod === create_refund_request_dto_1.RefundMethod.ORIGINAL) {
                    if (order.payments && order.payments.length > 0) {
                        const latestPayment = order.payments[0];
                        this.logger.log(`调用微信退款API: 支付ID=${latestPayment.id}, 金额=${refundRequest.refundAmount}`);
                        transactionId = `WX_REFUND_${Date.now()}`;
                    }
                }
                else {
                    this.logger.log(`手动退款: 方式=${refundRequest.refundMethod}, 金额=${refundRequest.refundAmount}`);
                }
                let paymentMethod;
                if (refundRequest.refundMethod === create_refund_request_dto_1.RefundMethod.ORIGINAL) {
                    paymentMethod = (order.payments && order.payments.length > 0)
                        ? order.payments[0].paymentMethod
                        : 'CASH';
                }
                else if (refundRequest.refundMethod === create_refund_request_dto_1.RefundMethod.CASH) {
                    paymentMethod = 'CASH';
                }
                else {
                    paymentMethod = 'BANK_CARD';
                }
                await tx.payment.create({
                    data: {
                        orderId: order.id,
                        paymentType: 'REFUND',
                        paymentMethod: paymentMethod,
                        amount: -Number(refundRequest.refundAmount),
                        status: 'REFUNDED',
                        transactionId: transactionId || refundRequest.refundNo,
                        refundReason: refundRequest.refundReason,
                        notes: processDto.notes,
                        paidAt: new Date(),
                        refundedAt: new Date(),
                    },
                });
                const newPaidAmount = Number(order.paidAmount) - Number(refundRequest.refundAmount);
                if (newPaidAmount < 0) {
                    throw new common_1.BadRequestException(`退款金额 ¥${Number(refundRequest.refundAmount).toFixed(2)} 超过订单已付金额 ¥${Number(order.paidAmount).toFixed(2)}，无法退款`);
                }
                const safePaidAmount = Math.max(0, newPaidAmount);
                await tx.order.update({
                    where: { id: order.id },
                    data: {
                        paidAmount: safePaidAmount,
                        refundedAmount: Number(order.refundedAmount || 0) + Number(refundRequest.refundAmount),
                        paymentStatus: safePaidAmount <= 0 ? status_enum_1.PaymentStatus.REFUNDED
                            : safePaidAmount >= Number(order.totalAmount) ? status_enum_1.PaymentStatus.FULLY_PAID
                                : status_enum_1.PaymentStatus.PARTIAL_PAID,
                        orderStatus: refundRequest.refundType === create_refund_request_dto_1.RefundType.FULL ? status_enum_1.OrderStatus.CANCELLED : order.orderStatus,
                    },
                });
                if (order.timeSlotId && refundRequest.refundType === create_refund_request_dto_1.RefundType.FULL) {
                    try {
                        await tx.timeSlot.update({
                            where: { id: order.timeSlotId },
                            data: {
                                bookedCount: { decrement: 1 },
                            },
                        });
                        const updatedSlot = await tx.timeSlot.findUnique({
                            where: { id: order.timeSlotId },
                        });
                        if (updatedSlot && updatedSlot.bookedCount <= 0) {
                            await tx.timeSlot.update({
                                where: { id: order.timeSlotId },
                                data: { isBooked: false, status: 'AVAILABLE' },
                            });
                        }
                    }
                    catch (e) {
                        this.logger.error(`释放预约时段失败: ${e.message}`);
                    }
                }
                const updatedRefundRequest = await tx.refundRequest.update({
                    where: { id },
                    data: {
                        status: refund_request_search_dto_1.RefundStatus.COMPLETED,
                        refundedBy: processDto.refundedBy || 'ADMIN',
                        refundedAt: new Date(),
                        transactionId: transactionId || refundRequest.refundNo,
                    },
                });
                await this.createRefundAudit({
                    refundRequestId: updatedRefundRequest.id,
                    orderId: order.id,
                    orderNo: order.orderNo,
                    action: 'PROCESS',
                    amount: Number(updatedRefundRequest.refundAmount),
                    beforePaid: Number(order.paidAmount),
                    afterPaid: newPaidAmount,
                    operatorId: processDto.refundedBy || 'ADMIN',
                    operatorName: processDto.refundedBy || 'ADMIN',
                    notes: processDto.notes || '退款执行完成',
                }, tx);
                return updatedRefundRequest;
            });
            this.logger.log(`退款处理成功: ${refundRequest.refundNo}, 金额: ¥${refundRequest.refundAmount}`);
            return result;
        }
        catch (error) {
            this.logger.error(`处理退款失败: ${error.message}`, error.stack);
            await this.prisma.refundRequest.update({
                where: { id },
                data: {
                    status: refund_request_search_dto_1.RefundStatus.FAILED,
                    notes: `退款失败: ${error.message}`,
                },
            });
            throw error;
        }
    }
    async cancelRefundRequest(id) {
        try {
            const refundRequest = await this.prisma.refundRequest.findUnique({
                where: { id },
            });
            if (!refundRequest) {
                throw new common_1.NotFoundException('退款申请不存在');
            }
            if (!['PENDING', 'APPROVED'].includes(refundRequest.status)) {
                throw new common_1.BadRequestException('只能取消待审批或已审批的退款申请');
            }
            const updated = await this.prisma.refundRequest.update({
                where: { id },
                data: {
                    status: refund_request_search_dto_1.RefundStatus.CANCELLED,
                },
            });
            await this.createRefundAuditFallback({
                refundRequestId: updated.id,
                orderId: updated.orderId,
                orderNo: updated.orderNo,
                action: 'CANCEL',
                amount: Number(updated.refundAmount),
                beforePaid: 0,
                afterPaid: 0,
                operatorId: 'SYSTEM',
                operatorName: 'SYSTEM',
                notes: '退款申请取消'
            });
            this.logger.log(`退款申请已取消: ${refundRequest.refundNo}`);
            return updated;
        }
        catch (error) {
            this.logger.error(`取消退款申请失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async createRefundAuditFallback(data) {
        try {
            await this.prisma.$executeRawUnsafe(`
        INSERT INTO "refund_audits" (
          "id", "refund_request_id", "order_id", "order_no", "action",
          "amount", "before_paid", "after_paid", "operator_id", "operator_name", "notes", "created_at"
        ) VALUES (
          gen_random_uuid(), '${data.refundRequestId}', '${data.orderId}', '${data.orderNo}', '${data.action}',
          ${data.amount}, ${data.beforePaid}, ${data.afterPaid}, ${data.operatorId ? `'${data.operatorId}'` : 'NULL'}, ${data.operatorName ? `'${data.operatorName}'` : 'NULL'}, ${data.notes ? `'${data.notes.replace(/'/g, "''")}'` : 'NULL'}, NOW()
        )
      `);
        }
        catch (e) {
            this.logger.error(`写入退款审计失败: ${e.message}`);
        }
    }
    async createRefundAudit(data, tx) {
        try {
            const client = tx || this.prisma;
            return await client.refundAudit.create({
                data: {
                    refundRequestId: data.refundRequestId,
                    orderId: data.orderId,
                    orderNo: data.orderNo,
                    action: data.action,
                    amount: data.amount,
                    beforePaid: data.beforePaid,
                    afterPaid: data.afterPaid,
                    operatorId: data.operatorId || null,
                    operatorName: data.operatorName || null,
                    notes: data.notes || null,
                },
            });
        }
        catch (e) {
            this.logger.error(`写入退款审计失败: ${e.message}`, e.stack);
            throw e;
        }
    }
    async getRefundRequestsByOrderNo(orderNo) {
        try {
            const refundRequests = await this.prisma.refundRequest.findMany({
                where: { orderNo },
                orderBy: { createdAt: 'desc' },
            });
            return refundRequests;
        }
        catch (error) {
            this.logger.error(`查询订单退款申请失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getRefundStatistics(query = {}) {
        try {
            const { startDate, endDate } = query;
            const where = {
                status: {
                    notIn: [refund_request_search_dto_1.RefundStatus.CANCELLED, refund_request_search_dto_1.RefundStatus.REJECTED],
                },
            };
            if (startDate || endDate) {
                where.createdAt = {};
                if (startDate)
                    where.createdAt.gte = new Date(startDate);
                if (endDate)
                    where.createdAt.lte = new Date(endDate);
            }
            const statusStats = await this.prisma.refundRequest.groupBy({
                by: ['status'],
                where,
                _count: { status: true },
                _sum: { refundAmount: true },
            });
            const completedRefunds = await this.prisma.refundRequest.aggregate({
                where: {
                    ...where,
                    status: refund_request_search_dto_1.RefundStatus.COMPLETED,
                },
                _sum: { refundAmount: true },
                _count: { id: true },
            });
            const pendingRefunds = await this.prisma.refundRequest.aggregate({
                where: {
                    ...where,
                    status: {
                        in: [refund_request_search_dto_1.RefundStatus.PENDING, refund_request_search_dto_1.RefundStatus.APPROVED, refund_request_search_dto_1.RefundStatus.PROCESSING],
                    },
                },
                _sum: { refundAmount: true },
                _count: { id: true },
            });
            return {
                statusStats,
                completedRefunds: {
                    amount: completedRefunds._sum?.refundAmount || 0,
                    count: completedRefunds._count?.id || 0,
                },
                pendingRefunds: {
                    amount: pendingRefunds._sum?.refundAmount || 0,
                    count: pendingRefunds._count?.id || 0,
                },
            };
        }
        catch (error) {
            this.logger.error(`获取退款统计失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getRefundAuditsByRefundRequestId(refundRequestId) {
        try {
            return await this.prisma.refundAudit.findMany({
                where: { refundRequestId },
                orderBy: { createdAt: 'desc' },
            });
        }
        catch (e) {
            this.logger.error(`查询退款审计失败: ${e.message}`, e.stack);
            throw e;
        }
    }
    async getSuspiciousPayments(params = {}) {
        const { type = 'all', severity = 'all', page = 1, limit = 20 } = params;
        try {
            const suspiciousPayments = [];
            if (type === 'duplicate' || type === 'all') {
                const duplicates = await this.findDuplicatePayments();
                suspiciousPayments.push(...duplicates);
            }
            if (type === 'overpayment' || type === 'all') {
                const overpayments = await this.findOverpayments();
                suspiciousPayments.push(...overpayments);
            }
            if (type === 'system_error' || type === 'all') {
                const systemErrors = await this.findSystemErrors();
                suspiciousPayments.push(...systemErrors);
            }
            const filtered = severity === 'all' ? suspiciousPayments : suspiciousPayments.filter(p => p.severity === severity);
            filtered.sort((a, b) => {
                const severityOrder = { high: 3, medium: 2, low: 1 };
                if (severityOrder[a.severity] !== severityOrder[b.severity]) {
                    return severityOrder[b.severity] - severityOrder[a.severity];
                }
                return b.detectedAt.getTime() - a.detectedAt.getTime();
            });
            const total = filtered.length;
            const start = (page - 1) * limit;
            const end = start + limit;
            const paginated = filtered.slice(start, end);
            return {
                success: true,
                data: paginated,
                summary: {
                    total,
                    page,
                    limit,
                    pages: Math.ceil(total / limit),
                    high: filtered.filter(p => p.severity === 'high').length,
                    medium: filtered.filter(p => p.severity === 'medium').length,
                    low: filtered.filter(p => p.severity === 'low').length,
                },
            };
        }
        catch (error) {
            this.logger.error(`检测可疑支付失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async resolveSuspiciousPayment(paymentId) {
        const payment = await this.prisma.payment.findUnique({ where: { id: paymentId }, include: { order: true } });
        if (!payment) {
            throw new common_1.NotFoundException('支付记录不存在');
        }
        const stillSuspicious = payment.status === status_enum_1.PaymentStatus.PENDING_PAYMENT;
        return {
            success: true,
            paymentId,
            resolved: true,
            resolvedAt: new Date(),
            wasSuspicious: stillSuspicious,
            message: '可疑支付标记处理完成（占位实现，后续可持久化）',
        };
    }
    async findDuplicatePayments() {
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
        const recentPayments = await this.prisma.payment.findMany({
            where: {
                createdAt: { gte: fiveMinutesAgo },
                status: status_enum_1.PaymentStatus.FULLY_PAID,
            },
            include: {
                order: {
                    include: {
                        user: {
                            select: { nickname: true, phone: true },
                        },
                    },
                },
            },
            orderBy: { createdAt: 'desc' },
        });
        const duplicates = [];
        const paymentGroups = new Map();
        recentPayments.forEach(payment => {
            const key = `${payment.orderId}_${payment.amount}`;
            const group = paymentGroups.get(key) || [];
            group.push(payment);
            paymentGroups.set(key, group);
        });
        paymentGroups.forEach((group, key) => {
            if (group.length > 1) {
                group.forEach((payment, index) => {
                    if (index > 0) {
                        duplicates.push({
                            paymentId: payment.id,
                            orderId: payment.orderId,
                            orderNo: payment.order.orderNo,
                            amount: Number(payment.amount),
                            type: 'duplicate',
                            reason: `检测到重复支付: 同一订单在5分钟内有${group.length}笔相同金额(¥${payment.amount})的支付`,
                            severity: 'high',
                            detectedAt: new Date(),
                            customerInfo: {
                                name: payment.order.user?.nickname,
                                phone: payment.order.user?.phone,
                            },
                        });
                    }
                });
            }
        });
        return duplicates;
    }
    async findOverpayments() {
        const overpayments = [];
        const payments = await this.prisma.payment.findMany({
            where: {
                status: status_enum_1.PaymentStatus.FULLY_PAID,
                createdAt: {
                    gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
                },
            },
            include: {
                order: {
                    include: {
                        user: {
                            select: { nickname: true, phone: true },
                        },
                    },
                },
            },
        });
        for (const payment of payments) {
            const order = payment.order;
            const balance = Number(order.totalAmount) - Number(order.paidAmount) + Number(payment.amount);
            if (Number(payment.amount) > balance) {
                const overage = Number(payment.amount) - balance;
                overpayments.push({
                    paymentId: payment.id,
                    orderId: payment.orderId,
                    orderNo: order.orderNo,
                    amount: Number(payment.amount),
                    type: 'overpayment',
                    reason: `支付金额(¥${payment.amount})超过应付余额(¥${balance.toFixed(2)}), 超出¥${overage.toFixed(2)}`,
                    severity: overage > 100 ? 'high' : 'medium',
                    detectedAt: new Date(),
                    customerInfo: {
                        name: order.user?.nickname,
                        phone: order.user?.phone,
                    },
                });
            }
        }
        return overpayments;
    }
    async findSystemErrors() {
        const systemErrors = [];
        const paidPayments = await this.prisma.payment.findMany({
            where: {
                status: status_enum_1.PaymentStatus.FULLY_PAID,
                paidAt: {
                    gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
                },
            },
            include: {
                order: {
                    include: {
                        payments: true,
                        user: {
                            select: { nickname: true, phone: true },
                        },
                    },
                },
            },
        });
        for (const payment of paidPayments) {
            const order = payment.order;
            const totalPaid = order.payments
                .filter(p => p.status === 'FULLY_PAID')
                .reduce((sum, p) => sum + Number(p.amount), 0);
            if (Math.abs(totalPaid - Number(order.paidAmount)) > 0.01) {
                systemErrors.push({
                    paymentId: payment.id,
                    orderId: order.id,
                    orderNo: order.orderNo,
                    amount: Number(payment.amount),
                    type: 'system_error',
                    reason: `订单已付金额(¥${order.paidAmount})与支付记录总额(¥${totalPaid.toFixed(2)})不匹配`,
                    severity: 'high',
                    detectedAt: new Date(),
                    customerInfo: {
                        name: order.user?.nickname,
                        phone: order.user?.phone,
                    },
                });
            }
            if (totalPaid >= Number(order.totalAmount) && order.paymentStatus !== 'FULLY_PAID') {
                systemErrors.push({
                    paymentId: payment.id,
                    orderId: order.id,
                    orderNo: order.orderNo,
                    amount: Number(payment.amount),
                    type: 'system_error',
                    reason: `订单已全额支付(¥${totalPaid.toFixed(2)})但支付状态为${order.paymentStatus}`,
                    severity: 'medium',
                    detectedAt: new Date(),
                    customerInfo: {
                        name: order.user?.nickname,
                        phone: order.user?.phone,
                    },
                });
            }
        }
        const inconsistentPayments = await this.prisma.payment.findMany({
            where: {
                transactionId: { not: null },
                status: { notIn: [status_enum_1.PaymentStatus.FULLY_PAID, status_enum_1.PaymentStatus.REFUNDED] },
                createdAt: {
                    gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
                },
            },
            include: {
                order: {
                    include: {
                        user: {
                            select: { nickname: true, phone: true },
                        },
                    },
                },
            },
        });
        for (const payment of inconsistentPayments) {
            systemErrors.push({
                paymentId: payment.id,
                orderId: payment.orderId,
                orderNo: payment.order.orderNo,
                amount: Number(payment.amount),
                type: 'system_error',
                reason: `存在第三方交易号(${payment.transactionId})但支付状态为${payment.status}`,
                severity: 'high',
                detectedAt: new Date(),
                customerInfo: {
                    name: payment.order.user?.nickname,
                    phone: payment.order.user?.phone,
                },
            });
        }
        return systemErrors;
    }
};
exports.PaymentsService = PaymentsService;
exports.PaymentsService = PaymentsService = PaymentsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        cache_service_1.CacheService,
        wechat_pay_service_1.WechatPayService,
        payment_notification_service_1.PaymentNotificationService,
        auto_status_transition_service_1.AutoStatusTransitionService])
], PaymentsService);
//# sourceMappingURL=payments.service.js.map