"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PaymentStateMachineService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentStateMachineService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const status_enum_1 = require("../../shared/enums/status.enum");
let PaymentStateMachineService = PaymentStateMachineService_1 = class PaymentStateMachineService {
    prisma;
    logger = new common_1.Logger(PaymentStateMachineService_1.name);
    states = {
        CREATED: { to: ['PAID', 'FAILED'] },
        PAID: { to: ['REFUNDED'] },
        FAILED: { to: ['CREATED'] },
        REFUNDED: { to: [] },
    };
    constructor(prisma) {
        this.prisma = prisma;
    }
    async transition(paymentId, fromState, toState) {
        if (!this.canTransition(fromState, toState)) {
            throw new common_1.BadRequestException(`Invalid state transition from ${fromState} to ${toState}`);
        }
        try {
            await this.prisma.$transaction(async (tx) => {
                const payment = await tx.payment.update({
                    where: { id: paymentId },
                    data: {
                        status: toState,
                        ...(toState === 'FULLY_PAID' ? { paidAt: new Date() } : {}),
                    },
                });
                if (toState === 'FULLY_PAID') {
                    const order = await tx.order.findUnique({
                        where: { id: payment.orderId },
                        select: { paidAmount: true, totalAmount: true },
                    });
                    if (order) {
                        const newPaidAmount = Number(order.paidAmount) + Number(payment.amount);
                        const paymentStatus = newPaidAmount >= Number(order.totalAmount)
                            ? 'FULLY_PAID'
                            : 'PARTIAL_PAID';
                        await tx.order.update({
                            where: { id: payment.orderId },
                            data: {
                                paidAmount: newPaidAmount,
                                paymentStatus: paymentStatus,
                                orderStatus: (paymentStatus === 'FULLY_PAID' ? status_enum_1.OrderStatus.CONFIRMED : status_enum_1.OrderStatus.PENDING),
                            },
                        });
                    }
                }
                this.logger.log(`Payment ${paymentId} transitioned from ${fromState} to ${toState}`);
            });
        }
        catch (error) {
            this.logger.error(`Payment transition error: ${error.message}`);
            throw new Error('支付状态更新失败');
        }
    }
    canTransition(fromState, toState) {
        return this.states[fromState]?.to.includes(toState) || false;
    }
};
exports.PaymentStateMachineService = PaymentStateMachineService;
exports.PaymentStateMachineService = PaymentStateMachineService = PaymentStateMachineService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PaymentStateMachineService);
//# sourceMappingURL=payment-state-machine.service.js.map