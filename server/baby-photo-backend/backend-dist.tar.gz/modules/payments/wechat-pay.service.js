"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var WechatPayService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatPayService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const crypto = __importStar(require("crypto"));
const fs = __importStar(require("fs"));
const axios_1 = __importDefault(require("axios"));
let WechatPayService = WechatPayService_1 = class WechatPayService {
    configService;
    logger = new common_1.Logger(WechatPayService_1.name);
    appId;
    mchId;
    apiV3Key;
    serialNo;
    privateKey;
    notifyUrl;
    isSandbox;
    isMock;
    baseUrl = 'https://api.mch.weixin.qq.com';
    constructor(configService) {
        this.configService = configService;
        this.appId = this.configService.get('WECHAT_APPID') || '';
        this.mchId = this.configService.get('WECHAT_MCH_ID') || '';
        this.apiV3Key = this.configService.get('WECHAT_API_V3_KEY') || '';
        this.serialNo = this.configService.get('WECHAT_SERIAL_NO') || '';
        this.notifyUrl = this.configService.get('WECHAT_NOTIFY_URL') || '';
        this.isSandbox = this.configService.get('PAYMENT_SANDBOX_MODE', 'true') === 'true';
        this.isMock = this.configService.get('PAYMENT_MOCK_MODE', 'false') === 'true';
        const privateKeyPath = this.configService.get('WECHAT_PRIVATE_KEY_PATH');
        if (privateKeyPath && fs.existsSync(privateKeyPath)) {
            this.privateKey = fs.readFileSync(privateKeyPath, 'utf-8');
            this.logger.log('✅ 微信支付商户私钥加载成功');
        }
        else {
            this.logger.warn('⚠️  微信支付商户私钥未配置或文件不存在');
            this.privateKey = '';
        }
        this.logger.log(`微信支付服务初始化完成 [沙箱模式: ${this.isSandbox}, 模拟模式: ${this.isMock}]`);
    }
    async createJsapiOrder(params) {
        this.logger.log(`创建JSAPI支付订单: ${params.orderNo}, 金额: ${params.amount}元`);
        if (this.isMock) {
            return this.mockPaymentResponse(params);
        }
        try {
            const totalAmount = Math.round(params.amount * 100);
            const requestData = {
                appid: this.appId,
                mchid: this.mchId,
                description: params.description,
                out_trade_no: params.orderNo,
                notify_url: this.notifyUrl,
                amount: {
                    total: totalAmount,
                    currency: 'CNY',
                },
                payer: {
                    openid: params.openid,
                },
            };
            this.logger.debug('微信支付请求数据:', JSON.stringify(requestData));
            const url = `${this.baseUrl}/v3/pay/transactions/jsapi`;
            const response = await this.request('POST', url, requestData);
            this.logger.log(`微信预支付订单创建成功: prepay_id=${response.prepay_id}`);
            const paymentParams = this.buildMiniProgramPaymentParams(response.prepay_id);
            return {
                prepayId: response.prepay_id,
                ...paymentParams,
                orderId: params.orderId,
                orderNo: params.orderNo,
                amount: params.amount,
                total_fee: totalAmount,
            };
        }
        catch (error) {
            this.logger.error('创建微信支付订单失败:', error);
            throw error;
        }
    }
    buildMiniProgramPaymentParams(prepayId) {
        const timestamp = Math.floor(Date.now() / 1000).toString();
        const nonceStr = this.generateNonceStr();
        const packageStr = `prepay_id=${prepayId}`;
        const signStr = [
            this.appId,
            timestamp,
            nonceStr,
            packageStr,
        ].join('\n') + '\n';
        const paySign = this.sign(signStr);
        return {
            timeStamp: timestamp,
            nonceStr: nonceStr,
            package: packageStr,
            signType: 'RSA',
            paySign: paySign,
        };
    }
    async queryOrder(orderNo) {
        this.logger.log(`查询订单支付状态: ${orderNo}`);
        if (this.isMock) {
            return {
                trade_state: 'SUCCESS',
                trade_state_desc: '支付成功',
            };
        }
        try {
            const url = `${this.baseUrl}/v3/pay/transactions/out-trade-no/${orderNo}?mchid=${this.mchId}`;
            const response = await this.request('GET', url);
            this.logger.log(`订单状态: ${response.trade_state}`);
            return response;
        }
        catch (error) {
            this.logger.error('查询订单失败:', error);
            throw error;
        }
    }
    async closeOrder(orderNo) {
        this.logger.log(`关闭订单: ${orderNo}`);
        if (this.isMock) {
            return { success: true };
        }
        try {
            const url = `${this.baseUrl}/v3/pay/transactions/out-trade-no/${orderNo}/close`;
            await this.request('POST', url, { mchid: this.mchId });
            this.logger.log(`订单已关闭: ${orderNo}`);
            return { success: true };
        }
        catch (error) {
            this.logger.error('关闭订单失败:', error);
            throw error;
        }
    }
    verifyNotifySignature(timestamp, nonce, body, signature, serialNo) {
        const signStr = `${timestamp}\n${nonce}\n${body}\n`;
        try {
            this.logger.log('验证支付回调签名');
            return true;
        }
        catch (error) {
            this.logger.error('签名验证失败:', error);
            return false;
        }
    }
    decryptNotifyData(ciphertext, associatedData, nonce) {
        try {
            this.logger.debug(`解密回调: nonce="${nonce}" nonce.length=${nonce.length} ad="${associatedData}"`);
            const cipherBuffer = Buffer.from(ciphertext, 'base64');
            const authTag = cipherBuffer.subarray(cipherBuffer.length - 16);
            const encryptedData = cipherBuffer.subarray(0, cipherBuffer.length - 16);
            this.logger.debug(`解密参数: cipherLen=${cipherBuffer.length} tagLen=${authTag.length} dataLen=${encryptedData.length}`);
            const nonceBuffer = Buffer.from(nonce, 'utf8');
            this.logger.debug(`nonceUtf8: len=${nonceBuffer.length} hex=${nonceBuffer.toString('hex')}`);
            const keyBuffer = Buffer.from(this.apiV3Key, 'utf8');
            this.logger.debug(`keyLen=${keyBuffer.length} key=${this.apiV3Key}`);
            const decipher = crypto.createDecipheriv('aes-256-gcm', keyBuffer, nonceBuffer);
            decipher.setAuthTag(authTag);
            decipher.setAAD(Buffer.from(associatedData));
            const decrypted = Buffer.concat([
                decipher.update(encryptedData),
                decipher.final(),
            ]);
            return JSON.parse(decrypted.toString('utf-8'));
        }
        catch (error) {
            this.logger.error('解密回调数据失败:', error);
            throw error;
        }
    }
    async refund(params) {
        if (this.isMock) {
            this.logger.warn('🎭 模拟退款模式');
            return { refundId: `mock_refund_${Date.now()}`, outRefundNo: params.outRefundNo };
        }
        try {
            const requestData = {
                out_trade_no: params.outTradeNo,
                out_refund_no: params.outRefundNo,
                amount: {
                    total: params.totalFee,
                    refund: params.refundFee,
                    currency: 'CNY',
                },
                reason: params.refundDesc || '退款',
            };
            const url = `${this.baseUrl}/v3/refund/domestic/refunds`;
            const response = await this.request('POST', url, requestData);
            this.logger.log(`退款创建成功: refundId=${response.refund_id}`);
            return { refundId: response.refund_id, outRefundNo: params.outRefundNo };
        }
        catch (error) {
            this.logger.error('退款失败:', error);
            throw error;
        }
    }
    async request(method, url, data) {
        const authorization = this.buildAuthorization(method, url, data);
        const config = {
            method,
            url,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'BabyPhotoSystem/1.0',
                'Authorization': authorization,
            },
            data: data ? JSON.stringify(data) : undefined,
        };
        this.logger.debug(`请求微信支付API: ${method} ${url}`);
        try {
            const response = await (0, axios_1.default)(config);
            return response.data;
        }
        catch (error) {
            const wxError = error?.response?.data;
            if (wxError) {
                this.logger.error(`微信支付API返回错误 [HTTP ${error.response.status}]: code=${wxError.code}, message=${wxError.message}`);
                if (wxError.detail)
                    this.logger.error(`错误详情: ${JSON.stringify(wxError.detail)}`);
            }
            else {
                this.logger.error(`微信支付API请求失败: ${error.message || error}`);
            }
            throw error;
        }
    }
    buildAuthorization(method, url, data) {
        const timestamp = Math.floor(Date.now() / 1000).toString();
        const nonceStr = this.generateNonceStr();
        const urlObj = new URL(url);
        const urlPath = urlObj.pathname + urlObj.search;
        let signStr = `${method}\n${urlPath}\n${timestamp}\n${nonceStr}\n`;
        if (data) {
            signStr += JSON.stringify(data) + '\n';
        }
        else {
            signStr += '\n';
        }
        const signature = this.sign(signStr);
        return `WECHATPAY2-SHA256-RSA2048 mchid="${this.mchId}",nonce_str="${nonceStr}",signature="${signature}",timestamp="${timestamp}",serial_no="${this.serialNo}"`;
    }
    sign(data) {
        if (!this.privateKey) {
            throw new Error('商户私钥未配置');
        }
        const sign = crypto.createSign('RSA-SHA256');
        sign.update(data);
        return sign.sign(this.privateKey, 'base64');
    }
    generateNonceStr(length = 32) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }
    mockPaymentResponse(params) {
        this.logger.warn('🎭 使用模拟支付模式');
        const timestamp = Math.floor(Date.now() / 1000).toString();
        const nonceStr = this.generateNonceStr(15);
        const prepayId = `mock_prepay_id_${Date.now()}`;
        const totalAmount = Math.round(params.amount * 100);
        return {
            prepayId,
            timeStamp: timestamp,
            nonceStr: nonceStr,
            package: `prepay_id=${prepayId}`,
            signType: 'RSA',
            paySign: `mock_signature_${timestamp}_${nonceStr}`,
            orderId: params.orderId,
            orderNo: params.orderNo,
            amount: params.amount,
            total_fee: totalAmount,
        };
    }
};
exports.WechatPayService = WechatPayService;
exports.WechatPayService = WechatPayService = WechatPayService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], WechatPayService);
//# sourceMappingURL=wechat-pay.service.js.map