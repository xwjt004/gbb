import { PrismaService } from '../../shared/prisma/prisma.service';
export type PaymentState = 'CREATED' | 'PAID' | 'FAILED' | 'REFUNDED';
export declare class PaymentStateMachineService {
    private readonly prisma;
    private readonly logger;
    private readonly states;
    constructor(prisma: PrismaService);
    transition(paymentId: string, fromState: PaymentState, toState: PaymentState): Promise<void>;
    private canTransition;
}
