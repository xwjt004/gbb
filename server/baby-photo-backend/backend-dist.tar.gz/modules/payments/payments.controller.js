"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var PaymentsController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const payments_service_1 = require("./payments.service");
const create_payment_dto_1 = require("./dto/create-payment.dto");
const update_payment_dto_1 = require("./dto/update-payment.dto");
const payment_search_dto_1 = require("./dto/payment-search.dto");
const refund_payment_dto_1 = require("./dto/refund-payment.dto");
const collect_balance_dto_1 = require("./dto/collect-balance.dto");
const create_refund_request_dto_1 = require("./dto/create-refund-request.dto");
const refund_request_search_dto_1 = require("./dto/refund-request-search.dto");
const query_suspicious_payments_dto_1 = require("./dto/query-suspicious-payments.dto");
const reconciliation_task_1 = require("./tasks/reconciliation.task");
let PaymentsController = PaymentsController_1 = class PaymentsController {
    paymentsService;
    reconciliationTask;
    logger = new common_1.Logger(PaymentsController_1.name);
    constructor(paymentsService, reconciliationTask) {
        this.paymentsService = paymentsService;
        this.reconciliationTask = reconciliationTask;
    }
    async create(createPaymentDto, idempotencyKey) {
        const key = idempotencyKey || createPaymentDto.idempotencyKey;
        if (key)
            this.logger.log(`收到幂等请求 Key=${key}`);
        this.logger.log(`创建支付订单: ${JSON.stringify(createPaymentDto)}`);
        return this.paymentsService.create({ ...createPaymentDto, idempotencyKey: key });
    }
    async getPaymentMeta() {
        return this.paymentsService.getPaymentMeta();
    }
    async getPaymentMethods() {
        return {
            code: 200,
            message: '渠道列表获取成功',
            data: Object.values(create_payment_dto_1.PaymentChannel),
        };
    }
    async wxPayNotify(body, headers) {
        this.logger.log('收到微信支付回调');
        return this.paymentsService.handleWxPayNotify(body, headers);
    }
    async findAll(searchDto) {
        this.logger.log(`查询支付列表: ${JSON.stringify(searchDto)}`);
        return this.paymentsService.findAll(searchDto);
    }
    async findByPhone(phone, query) {
        this.logger.log(`通过手机号查找支付记录: ${phone}`);
        const { page = 1, limit = 20 } = query;
        return this.paymentsService.findByPhone(phone, {
            page: +page,
            limit: +limit,
        });
    }
    async getPaymentStatistics(query) {
        this.logger.log('获取支付统计信息');
        return this.paymentsService.getPaymentStatistics(query);
    }
    async exportPayments(searchDto) {
        this.logger.log(`导出支付数据: ${JSON.stringify(searchDto)}`);
        return this.paymentsService.exportPayments(searchDto);
    }
    async getPaymentTrends(period = '7d') {
        this.logger.log(`获取支付趋势数据: ${period}`);
        return this.paymentsService.getPaymentTrends(period);
    }
    async getSuspiciousPayments(query) {
        this.logger.log(`检测可疑支付: type=${query.type} severity=${query.severity} page=${query.page} limit=${query.limit}`);
        return this.paymentsService.getSuspiciousPayments(query);
    }
    async resolveSuspiciousPayment(paymentId) {
        this.logger.log(`解决可疑支付: ${paymentId}`);
        return this.paymentsService.resolveSuspiciousPayment(paymentId);
    }
    async findByOrderNo(orderNo) {
        this.logger.log(`通过订单号查找支付记录: ${orderNo}`);
        return this.paymentsService.findByOrderNo(orderNo);
    }
    async createRefundRequest(createDto) {
        this.logger.log(`创建退款申请: ${createDto.orderNo}`);
        return this.paymentsService.createRefundRequest(createDto);
    }
    async findAllRefundRequests(searchDto) {
        this.logger.log(`查询退款申请列表: ${JSON.stringify(searchDto)}`);
        return this.paymentsService.findAllRefundRequests(searchDto);
    }
    async getRefundStatistics(query) {
        this.logger.log('获取退款统计信息');
        return this.paymentsService.getRefundStatistics(query);
    }
    async getRefundRequestsByOrderNo(orderNo) {
        this.logger.log(`获取订单退款申请: ${orderNo}`);
        return this.paymentsService.getRefundRequestsByOrderNo(orderNo);
    }
    async findOneRefundRequest(id) {
        this.logger.log(`获取退款申请详情: ${id}`);
        return this.paymentsService.findOneRefundRequest(id);
    }
    async getRefundAudits(id) {
        this.logger.log(`获取退款申请审计记录: ${id}`);
        return this.paymentsService.getRefundAuditsByRefundRequestId(id);
    }
    async approveRefundRequest(id, approveDto) {
        this.logger.log(`审批退款申请: ${id}`);
        return this.paymentsService.approveRefundRequest(id, approveDto);
    }
    async rejectRefundRequest(id, rejectDto) {
        this.logger.log(`拒绝退款申请: ${id}`);
        return this.paymentsService.rejectRefundRequest(id, rejectDto);
    }
    async processRefundRequest(id, processDto) {
        this.logger.log(`执行退款: ${id}`);
        return this.paymentsService.processRefundRequest(id, processDto);
    }
    async cancelRefundRequest(id) {
        this.logger.log(`取消退款申请: ${id}`);
        return this.paymentsService.cancelRefundRequest(id);
    }
    async getPaymentStatus(id) {
        this.logger.log(`查询支付状态: ${id}`);
        return this.paymentsService.getPaymentStatus(id);
    }
    async findOne(id) {
        this.logger.log(`获取支付详情: ${id}`);
        return this.paymentsService.findOne(id);
    }
    async update(id, updatePaymentDto) {
        this.logger.log(`更新支付信息: ${id}, 数据: ${JSON.stringify(updatePaymentDto)}`);
        return this.paymentsService.update(id, updatePaymentDto);
    }
    async refund(id, refundPaymentDto) {
        this.logger.log(`申请退款: ${id}, 数据: ${JSON.stringify(refundPaymentDto)}`);
        return this.paymentsService.refund(id, refundPaymentDto);
    }
    async processRefund(id, body) {
        this.logger.log(`处理退款: ${id}, 原因: ${body.reason || '无'}`);
        return this.paymentsService.processRefund(id, body.reason, body.notes);
    }
    async cancel(id) {
        this.logger.log(`取消支付: ${id}`);
        return this.paymentsService.cancel(id);
    }
    async remove(id) {
        this.logger.log(`删除支付记录: ${id}`);
        return this.paymentsService.remove(id);
    }
    async syncPaymentStatus(id) {
        this.logger.log(`手动同步支付状态: ${id}`);
        return this.paymentsService.syncPaymentStatus(id);
    }
    async getOrderBalance(orderId) {
        this.logger.log(`获取订单余额信息: ${orderId}`);
        return this.paymentsService.getOrderBalance(orderId);
    }
    async collectBalance(collectBalanceDto) {
        this.logger.log(`收取尾款: ${JSON.stringify(collectBalanceDto)}`);
        return this.paymentsService.collectBalance(collectBalanceDto);
    }
    async confirmPayment(id) {
        this.logger.log(`确认支付: ${id}`);
        return this.paymentsService.confirmPayment(id);
    }
    async getOrderPaymentHistory(orderId) {
        this.logger.log(`获取订单支付记录: ${orderId}`);
        return this.paymentsService.getOrderPaymentHistory(orderId);
    }
    async manualReconciliation() {
        this.logger.log('手动触发对账任务');
        await this.reconciliationTask.manualReconciliation();
        return {
            code: 200,
            message: '对账任务执行完成，请查看日志获取详细结果',
        };
    }
};
exports.PaymentsController = PaymentsController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建支付记录' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '支付记录创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('Idempotency-Key')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_payment_dto_1.CreatePaymentDto, String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('meta'),
    (0, swagger_1.ApiOperation)({ summary: '获取支付元数据（状态与渠道）' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getPaymentMeta", null);
__decorate([
    (0, common_1.Get)('methods'),
    (0, swagger_1.ApiOperation)({ summary: '获取可用支付渠道列表' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getPaymentMethods", null);
__decorate([
    (0, common_1.Post)('wx-notify'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "wxPayNotify", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取所有支付记录' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取支付记录列表' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [payment_search_dto_1.PaymentSearchDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('by-phone/:phone'),
    __param(0, (0, common_1.Param)('phone')),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "findByPhone", null);
__decorate([
    (0, common_1.Get)('statistics/overview'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getPaymentStatistics", null);
__decorate([
    (0, common_1.Get)('export'),
    (0, swagger_1.ApiOperation)({ summary: '导出支付数据' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [payment_search_dto_1.PaymentSearchDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "exportPayments", null);
__decorate([
    (0, common_1.Get)('trends'),
    (0, swagger_1.ApiOperation)({ summary: '获取支付趋势数据' }),
    __param(0, (0, common_1.Query)('period')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getPaymentTrends", null);
__decorate([
    (0, common_1.Get)('suspicious'),
    (0, swagger_1.ApiOperation)({ summary: '检测可疑支付（支持分页与严重性筛选）' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '检测成功，返回可疑支付列表' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_suspicious_payments_dto_1.QuerySuspiciousPaymentsDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getSuspiciousPayments", null);
__decorate([
    (0, common_1.Patch)('suspicious/:paymentId/resolve'),
    (0, swagger_1.ApiOperation)({ summary: '标记可疑支付已处理/忽略' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '处理成功' }),
    __param(0, (0, common_1.Param)('paymentId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "resolveSuspiciousPayment", null);
__decorate([
    (0, common_1.Get)('by-order/:orderNo'),
    __param(0, (0, common_1.Param)('orderNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "findByOrderNo", null);
__decorate([
    (0, common_1.Post)('refund-requests'),
    (0, swagger_1.ApiOperation)({ summary: '创建退款申请' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '退款申请创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_refund_request_dto_1.CreateRefundRequestDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "createRefundRequest", null);
__decorate([
    (0, common_1.Get)('refund-requests'),
    (0, swagger_1.ApiOperation)({ summary: '获取退款申请列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [refund_request_search_dto_1.RefundRequestSearchDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "findAllRefundRequests", null);
__decorate([
    (0, common_1.Get)('refund-requests/statistics/summary'),
    (0, swagger_1.ApiOperation)({ summary: '获取退款统计信息' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [refund_request_search_dto_1.RefundRequestSearchDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getRefundStatistics", null);
__decorate([
    (0, common_1.Get)('refund-requests/order/:orderNo'),
    (0, swagger_1.ApiOperation)({ summary: '获取订单的退款申请列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Param)('orderNo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getRefundRequestsByOrderNo", null);
__decorate([
    (0, common_1.Get)('refund-requests/:id'),
    (0, swagger_1.ApiOperation)({ summary: '获取退款申请详情' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '退款申请不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "findOneRefundRequest", null);
__decorate([
    (0, common_1.Get)('refund-requests/:id/audits'),
    (0, swagger_1.ApiOperation)({ summary: '获取退款申请审计记录' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getRefundAudits", null);
__decorate([
    (0, common_1.Put)('refund-requests/:id/approve'),
    (0, swagger_1.ApiOperation)({ summary: '审批通过退款申请' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '审批成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '状态错误' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '退款申请不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, refund_request_search_dto_1.ApproveRefundRequestDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "approveRefundRequest", null);
__decorate([
    (0, common_1.Put)('refund-requests/:id/reject'),
    (0, swagger_1.ApiOperation)({ summary: '拒绝退款申请' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '拒绝成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '状态错误' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '退款申请不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, refund_request_search_dto_1.RejectRefundRequestDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "rejectRefundRequest", null);
__decorate([
    (0, common_1.Post)('refund-requests/:id/process'),
    (0, swagger_1.ApiOperation)({ summary: '执行退款' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '退款成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '状态错误' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '退款申请不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, refund_request_search_dto_1.ProcessRefundRequestDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "processRefundRequest", null);
__decorate([
    (0, common_1.Put)('refund-requests/:id/cancel'),
    (0, swagger_1.ApiOperation)({ summary: '取消退款申请' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '取消成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '状态错误' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '退款申请不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "cancelRefundRequest", null);
__decorate([
    (0, common_1.Get)(':id/status'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getPaymentStatus", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_payment_dto_1.UpdatePaymentDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "update", null);
__decorate([
    (0, common_1.Post)(':id/refund'),
    (0, swagger_1.ApiOperation)({ summary: '申请退款' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '退款申请成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '支付记录不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, refund_payment_dto_1.RefundPaymentDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "refund", null);
__decorate([
    (0, common_1.Post)(':id/process-refund'),
    (0, swagger_1.ApiOperation)({ summary: '处理退款' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '退款处理成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '支付记录不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "processRefund", null);
__decorate([
    (0, common_1.Post)(':id/cancel'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "cancel", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)(':id/sync-status'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "syncPaymentStatus", null);
__decorate([
    (0, common_1.Get)('orders/:orderId/balance'),
    (0, swagger_1.ApiOperation)({ summary: '获取订单余额信息' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    __param(0, (0, common_1.Param)('orderId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getOrderBalance", null);
__decorate([
    (0, common_1.Post)('collect-balance'),
    (0, swagger_1.ApiOperation)({ summary: '收取尾款' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '尾款收取成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误或金额超限' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [collect_balance_dto_1.CollectBalanceDto]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "collectBalance", null);
__decorate([
    (0, common_1.Post)(':id/confirm'),
    (0, swagger_1.ApiOperation)({ summary: '确认支付(手动确认)' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '支付确认成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '支付记录不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '支付已确认或状态异常' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "confirmPayment", null);
__decorate([
    (0, common_1.Get)('orders/:orderId/history'),
    (0, swagger_1.ApiOperation)({ summary: '获取订单支付记录' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '订单不存在' }),
    __param(0, (0, common_1.Param)('orderId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "getOrderPaymentHistory", null);
__decorate([
    (0, common_1.Post)('reconciliation/manual'),
    (0, swagger_1.ApiOperation)({ summary: '手动触发对账任务（检测订单-支付差异）' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '对账完成' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "manualReconciliation", null);
exports.PaymentsController = PaymentsController = PaymentsController_1 = __decorate([
    (0, swagger_1.ApiTags)('支付管理'),
    (0, common_1.Controller)('payments'),
    __metadata("design:paramtypes", [payments_service_1.PaymentsService,
        reconciliation_task_1.ReconciliationTask])
], PaymentsController);
//# sourceMappingURL=payments.controller.js.map