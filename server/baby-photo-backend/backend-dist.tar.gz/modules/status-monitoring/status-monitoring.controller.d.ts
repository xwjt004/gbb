import { StatusMonitoringService } from './status-monitoring.service';
export declare class StatusMonitoringController {
    private readonly statusMonitoringService;
    constructor(statusMonitoringService: StatusMonitoringService);
    getStatusDistribution(): Promise<{
        summary: {
            totalOrders: number;
            validCombinations: number;
            invalidCombinations: number;
            validOrdersCount: number;
            invalidOrdersCount: number;
        };
        distribution: {
            orderStatus: import("@prisma/client").$Enums.OrderStatus;
            paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
            count: number;
            combination: string;
            isValid: boolean;
            description: string;
        }[];
        validCombinations: {
            orderStatus: import("@prisma/client").$Enums.OrderStatus;
            paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
            count: number;
            combination: string;
            isValid: boolean;
            description: string;
        }[];
        invalidCombinations: {
            orderStatus: import("@prisma/client").$Enums.OrderStatus;
            paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
            count: number;
            combination: string;
            isValid: boolean;
            description: string;
        }[];
    }>;
    getStatusTransitions(days?: string): Promise<{
        period: {
            days: number;
            startDate: Date;
            endDate: Date;
        };
        summary: {
            totalChanges: number;
            orderStatusChanges: number;
            paymentStatusChanges: number;
            changesByOperator: {
                operator: string | null;
                count: number;
            }[];
        };
        dailyTrend: {
            date: string;
            totalChanges: number;
            orderStatusChanges: number;
            paymentStatusChanges: number;
        }[];
        transitionPaths: {
            path: string;
            count: number;
        }[];
    }>;
    getAbnormalOrders(): Promise<{
        invalidStatusOrders: {
            reason: string;
            severity: string;
            user: {
                nickname: string | null;
                phone: string | null;
            };
            id: string;
            orderNo: string;
            createdAt: Date;
            updatedAt: Date;
            paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
            orderStatus: import("@prisma/client").$Enums.OrderStatus;
        }[];
        frequentChangeOrders: {
            orderId: string;
            changeCount: number;
            reason: string;
            severity: string;
        }[];
        summary: {
            totalAbnormal: number;
            invalidStatus: number;
            frequentChanges: number;
        };
    }>;
    getStatusTimeline(orderId: string): Promise<{
        order: {
            id: string;
            orderNo: string;
            createdAt: Date;
            updatedAt: Date;
            paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
            orderStatus: import("@prisma/client").$Enums.OrderStatus;
        };
        timeline: {
            id: string;
            timestamp: Date;
            fieldName: string;
            oldValue: string;
            newValue: string;
            operator: string | null;
            reason: string | null;
            description: string;
        }[];
        currentStatus: {
            orderStatus: import("@prisma/client").$Enums.OrderStatus;
            paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
            isValid: boolean;
        };
    }>;
    getDashboardStats(): Promise<{
        overview: {
            totalOrders: number;
            todayOrders: number;
            yesterdayOrders: number;
            orderGrowth: string;
        };
        statusHealth: {
            validCombinations: number;
            invalidCombinations: number;
            healthScore: string;
        };
        todayActivity: {
            totalTransitions: number;
            orderStatusChanges: number;
            paymentStatusChanges: number;
        };
        alerts: {
            abnormalOrders: number;
            invalidStatus: number;
            frequentChanges: number;
        };
    }>;
    getAlerts(): Promise<{
        alerts: {
            id: string;
            type: string;
            title: string;
            message: string;
            count: number;
            severity: string;
            createdAt: Date;
        }[];
        summary: {
            total: number;
            high: number;
            medium: number;
            low: number;
        };
    }>;
}
