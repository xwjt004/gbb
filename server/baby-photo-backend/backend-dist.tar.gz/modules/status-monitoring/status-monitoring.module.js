"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusMonitoringModule = void 0;
const common_1 = require("@nestjs/common");
const status_monitoring_controller_1 = require("./status-monitoring.controller");
const status_monitoring_service_1 = require("./status-monitoring.service");
const prisma_module_1 = require("../../shared/prisma/prisma.module");
const status_change_log_service_1 = require("../../shared/services/status-change-log.service");
let StatusMonitoringModule = class StatusMonitoringModule {
};
exports.StatusMonitoringModule = StatusMonitoringModule;
exports.StatusMonitoringModule = StatusMonitoringModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule],
        controllers: [status_monitoring_controller_1.StatusMonitoringController],
        providers: [status_monitoring_service_1.StatusMonitoringService, status_change_log_service_1.StatusChangeLogService],
        exports: [status_monitoring_service_1.StatusMonitoringService],
    })
], StatusMonitoringModule);
//# sourceMappingURL=status-monitoring.module.js.map