"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusMonitoringController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const status_monitoring_service_1 = require("./status-monitoring.service");
let StatusMonitoringController = class StatusMonitoringController {
    statusMonitoringService;
    constructor(statusMonitoringService) {
        this.statusMonitoringService = statusMonitoringService;
    }
    async getStatusDistribution() {
        return this.statusMonitoringService.getStatusDistribution();
    }
    async getStatusTransitions(days = '7') {
        const daysNum = parseInt(days, 10);
        return this.statusMonitoringService.getStatusTransitionStats(daysNum);
    }
    async getAbnormalOrders() {
        return this.statusMonitoringService.getAbnormalOrders();
    }
    async getStatusTimeline(orderId) {
        return this.statusMonitoringService.getOrderStatusTimeline(orderId);
    }
    async getDashboardStats() {
        return this.statusMonitoringService.getDashboardStats();
    }
    async getAlerts() {
        return this.statusMonitoringService.getStatusAlerts();
    }
};
exports.StatusMonitoringController = StatusMonitoringController;
__decorate([
    (0, common_1.Get)('status-distribution'),
    (0, swagger_1.ApiOperation)({ summary: '获取状态组合分布' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '状态分布数据' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusMonitoringController.prototype, "getStatusDistribution", null);
__decorate([
    (0, common_1.Get)('status-transitions'),
    (0, swagger_1.ApiOperation)({ summary: '获取状态转换统计' }),
    (0, swagger_1.ApiQuery)({ name: 'days', required: false, description: '统计天数', example: 7 }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '状态转换统计' }),
    __param(0, (0, common_1.Query)('days')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], StatusMonitoringController.prototype, "getStatusTransitions", null);
__decorate([
    (0, common_1.Get)('abnormal-orders'),
    (0, swagger_1.ApiOperation)({ summary: '获取异常状态订单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '异常订单列表' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusMonitoringController.prototype, "getAbnormalOrders", null);
__decorate([
    (0, common_1.Get)('status-timeline'),
    (0, swagger_1.ApiOperation)({ summary: '获取状态变化时间线' }),
    (0, swagger_1.ApiQuery)({ name: 'orderId', required: true, description: '订单ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '状态变化时间线' }),
    __param(0, (0, common_1.Query)('orderId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], StatusMonitoringController.prototype, "getStatusTimeline", null);
__decorate([
    (0, common_1.Get)('dashboard-stats'),
    (0, swagger_1.ApiOperation)({ summary: '获取监控仪表板统计数据' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '仪表板数据' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusMonitoringController.prototype, "getDashboardStats", null);
__decorate([
    (0, common_1.Get)('alerts'),
    (0, swagger_1.ApiOperation)({ summary: '获取状态告警信息' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '告警列表' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusMonitoringController.prototype, "getAlerts", null);
exports.StatusMonitoringController = StatusMonitoringController = __decorate([
    (0, swagger_1.ApiTags)('状态监控'),
    (0, common_1.Controller)('status-monitoring'),
    __metadata("design:paramtypes", [status_monitoring_service_1.StatusMonitoringService])
], StatusMonitoringController);
//# sourceMappingURL=status-monitoring.controller.js.map