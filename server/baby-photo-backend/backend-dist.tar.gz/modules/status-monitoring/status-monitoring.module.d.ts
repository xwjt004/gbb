export declare class StatusMonitoringModule {
}
