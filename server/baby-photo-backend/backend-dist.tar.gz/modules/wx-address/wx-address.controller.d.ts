import { WxAddressService } from './wx-address.service';
import { CreateAddressDto } from './dto/create-address.dto';
import { UpdateAddressDto } from './dto/update-address.dto';
export declare class WxAddressController {
    private readonly wxAddressService;
    constructor(wxAddressService: WxAddressService);
    findAll(req: any): Promise<{
        id: string;
        receiverName: string;
        phone: string;
        province: string;
        city: string;
        district: string;
        detail: string;
        postalCode: string | null;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }[]>;
    getDefault(req: any): Promise<{
        id: string;
        receiverName: string;
        phone: string;
        province: string;
        city: string;
        district: string;
        detail: string;
        postalCode: string | null;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    } | null>;
    findOne(req: any, id: string): Promise<{
        id: string;
        receiverName: string;
        phone: string;
        province: string;
        city: string;
        district: string;
        detail: string;
        postalCode: string | null;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    create(req: any, dto: CreateAddressDto): Promise<{
        id: string;
        receiverName: string;
        phone: string;
        province: string;
        city: string;
        district: string;
        detail: string;
        postalCode: string | null;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    update(req: any, id: string, dto: UpdateAddressDto): Promise<{
        id: string;
        receiverName: string;
        phone: string;
        province: string;
        city: string;
        district: string;
        detail: string;
        postalCode: string | null;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    remove(req: any, id: string): Promise<{
        success: boolean;
        message: string;
    }>;
    setDefault(req: any, id: string): Promise<{
        success: boolean;
        message: string;
    }>;
}
