export declare class CreateAddressDto {
    receiverName: string;
    phone: string;
    province: string;
    city: string;
    district: string;
    detail: string;
    postalCode?: string;
    isDefault?: boolean;
}
