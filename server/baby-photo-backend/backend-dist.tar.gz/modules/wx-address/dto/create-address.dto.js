"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateAddressDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
class CreateAddressDto {
    receiverName;
    phone;
    province;
    city;
    district;
    detail;
    postalCode;
    isDefault;
}
exports.CreateAddressDto = CreateAddressDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '收货人姓名',
        example: '张三',
        minLength: 2,
        maxLength: 50,
    }),
    (0, class_validator_1.IsString)({ message: '收货人姓名必须是字符串' }),
    (0, class_validator_1.IsNotEmpty)({ message: '收货人姓名不能为空' }),
    (0, class_validator_1.Length)(2, 50, { message: '收货人姓名长度必须在2-50个字符之间' }),
    __metadata("design:type", String)
], CreateAddressDto.prototype, "receiverName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '联系电话',
        example: '13800138000',
    }),
    (0, class_validator_1.IsString)({ message: '联系电话必须是字符串' }),
    (0, class_validator_1.IsNotEmpty)({ message: '联系电话不能为空' }),
    (0, class_validator_1.Matches)(/^1[3-9]\d{9}$/, { message: '手机号格式不正确' }),
    __metadata("design:type", String)
], CreateAddressDto.prototype, "phone", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '省份',
        example: '北京市',
    }),
    (0, class_validator_1.IsString)({ message: '省份必须是字符串' }),
    (0, class_validator_1.IsNotEmpty)({ message: '省份不能为空' }),
    (0, class_validator_1.Length)(2, 50, { message: '省份长度必须在2-50个字符之间' }),
    __metadata("design:type", String)
], CreateAddressDto.prototype, "province", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '城市',
        example: '北京市',
    }),
    (0, class_validator_1.IsString)({ message: '城市必须是字符串' }),
    (0, class_validator_1.IsNotEmpty)({ message: '城市不能为空' }),
    (0, class_validator_1.Length)(2, 50, { message: '城市长度必须在2-50个字符之间' }),
    __metadata("design:type", String)
], CreateAddressDto.prototype, "city", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '区县',
        example: '朝阳区',
    }),
    (0, class_validator_1.IsString)({ message: '区县必须是字符串' }),
    (0, class_validator_1.IsNotEmpty)({ message: '区县不能为空' }),
    (0, class_validator_1.Length)(2, 50, { message: '区县长度必须在2-50个字符之间' }),
    __metadata("design:type", String)
], CreateAddressDto.prototype, "district", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '详细地址',
        example: '望京街道xxx小区x号楼x单元xxx室',
    }),
    (0, class_validator_1.IsString)({ message: '详细地址必须是字符串' }),
    (0, class_validator_1.IsNotEmpty)({ message: '详细地址不能为空' }),
    (0, class_validator_1.Length)(5, 200, { message: '详细地址长度必须在5-200个字符之间' }),
    __metadata("design:type", String)
], CreateAddressDto.prototype, "detail", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: '邮政编码',
        example: '100000',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '邮政编码必须是字符串' }),
    (0, class_validator_1.Matches)(/^\d{6}$/, { message: '邮政编码格式不正确' }),
    __metadata("design:type", String)
], CreateAddressDto.prototype, "postalCode", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: '是否设为默认地址',
        example: false,
        default: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)({ message: '是否默认必须是布尔值' }),
    __metadata("design:type", Boolean)
], CreateAddressDto.prototype, "isDefault", void 0);
//# sourceMappingURL=create-address.dto.js.map