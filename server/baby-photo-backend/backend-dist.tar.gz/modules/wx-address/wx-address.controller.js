"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WxAddressController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const wx_address_service_1 = require("./wx-address.service");
const create_address_dto_1 = require("./dto/create-address.dto");
const update_address_dto_1 = require("./dto/update-address.dto");
const wx_jwt_auth_guard_1 = require("../wx-auth/guards/wx-jwt-auth.guard");
let WxAddressController = class WxAddressController {
    wxAddressService;
    constructor(wxAddressService) {
        this.wxAddressService = wxAddressService;
    }
    async findAll(req) {
        return this.wxAddressService.findAll(req.user.id);
    }
    async getDefault(req) {
        return this.wxAddressService.getDefault(req.user.id);
    }
    async findOne(req, id) {
        return this.wxAddressService.findOne(req.user.id, id);
    }
    async create(req, dto) {
        return this.wxAddressService.create(req.user.id, dto);
    }
    async update(req, id, dto) {
        return this.wxAddressService.update(req.user.id, id, dto);
    }
    async remove(req, id) {
        return this.wxAddressService.remove(req.user.id, id);
    }
    async setDefault(req, id) {
        return this.wxAddressService.setDefault(req.user.id, id);
    }
};
exports.WxAddressController = WxAddressController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取用户的所有地址' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: '获取成功，返回地址列表（默认地址在最前）',
    }),
    __param(0, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], WxAddressController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('default'),
    (0, swagger_1.ApiOperation)({ summary: '获取默认地址' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: '获取成功',
    }),
    (0, swagger_1.ApiResponse)({
        status: 404,
        description: '没有设置默认地址',
    }),
    __param(0, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], WxAddressController.prototype, "getDefault", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '获取地址详情' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: '地址ID',
        type: 'string',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: '获取成功',
    }),
    (0, swagger_1.ApiResponse)({
        status: 404,
        description: '地址不存在',
    }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], WxAddressController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建新地址' }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: '创建成功',
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: '参数验证失败',
    }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, create_address_dto_1.CreateAddressDto]),
    __metadata("design:returntype", Promise)
], WxAddressController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新地址' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: '地址ID',
        type: 'string',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: '更新成功',
    }),
    (0, swagger_1.ApiResponse)({
        status: 404,
        description: '地址不存在',
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: '参数验证失败',
    }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, update_address_dto_1.UpdateAddressDto]),
    __metadata("design:returntype", Promise)
], WxAddressController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除地址' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: '地址ID',
        type: 'string',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: '删除成功',
    }),
    (0, swagger_1.ApiResponse)({
        status: 404,
        description: '地址不存在',
    }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], WxAddressController.prototype, "remove", null);
__decorate([
    (0, common_1.Patch)(':id/default'),
    (0, swagger_1.ApiOperation)({ summary: '设置默认地址' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: '地址ID',
        type: 'string',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: '设置成功',
    }),
    (0, swagger_1.ApiResponse)({
        status: 404,
        description: '地址不存在',
    }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], WxAddressController.prototype, "setDefault", null);
exports.WxAddressController = WxAddressController = __decorate([
    (0, swagger_1.ApiTags)('微信地址管理'),
    (0, common_1.Controller)('wx-address'),
    (0, common_1.UseGuards)(wx_jwt_auth_guard_1.WxJwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [wx_address_service_1.WxAddressService])
], WxAddressController);
//# sourceMappingURL=wx-address.controller.js.map