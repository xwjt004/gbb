export declare class WxAddressModule {
}
