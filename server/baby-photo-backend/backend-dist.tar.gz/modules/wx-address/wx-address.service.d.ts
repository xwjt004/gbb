import { PrismaService } from '../../shared/prisma/prisma.service';
import { CreateAddressDto } from './dto/create-address.dto';
import { UpdateAddressDto } from './dto/update-address.dto';
export declare class WxAddressService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    findAll(wxUserId: string): Promise<{
        id: string;
        receiverName: string;
        phone: string;
        province: string;
        city: string;
        district: string;
        detail: string;
        postalCode: string | null;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }[]>;
    findOne(wxUserId: string, id: string): Promise<{
        id: string;
        receiverName: string;
        phone: string;
        province: string;
        city: string;
        district: string;
        detail: string;
        postalCode: string | null;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    create(wxUserId: string, dto: CreateAddressDto): Promise<{
        id: string;
        receiverName: string;
        phone: string;
        province: string;
        city: string;
        district: string;
        detail: string;
        postalCode: string | null;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    update(wxUserId: string, id: string, dto: UpdateAddressDto): Promise<{
        id: string;
        receiverName: string;
        phone: string;
        province: string;
        city: string;
        district: string;
        detail: string;
        postalCode: string | null;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    remove(wxUserId: string, id: string): Promise<{
        success: boolean;
        message: string;
    }>;
    setDefault(wxUserId: string, id: string): Promise<{
        success: boolean;
        message: string;
    }>;
    getDefault(wxUserId: string): Promise<{
        id: string;
        receiverName: string;
        phone: string;
        province: string;
        city: string;
        district: string;
        detail: string;
        postalCode: string | null;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    } | null>;
}
