"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WxAddressService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let WxAddressService = class WxAddressService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async findAll(wxUserId) {
        const addresses = await this.prisma.shippingAddress.findMany({
            where: { wxUserId },
            orderBy: [{ isDefault: 'desc' }, { createdAt: 'desc' }],
        });
        return addresses.map((addr) => ({
            id: addr.id,
            receiverName: addr.receiverName,
            phone: addr.phone,
            province: addr.province,
            city: addr.city,
            district: addr.district,
            detail: addr.detail,
            postalCode: addr.postalCode,
            isDefault: addr.isDefault,
            createdAt: addr.createdAt,
            updatedAt: addr.updatedAt,
        }));
    }
    async findOne(wxUserId, id) {
        const address = await this.prisma.shippingAddress.findFirst({
            where: {
                id,
                wxUserId,
            },
        });
        if (!address) {
            throw new common_1.NotFoundException('地址不存在');
        }
        return {
            id: address.id,
            receiverName: address.receiverName,
            phone: address.phone,
            province: address.province,
            city: address.city,
            district: address.district,
            detail: address.detail,
            postalCode: address.postalCode,
            isDefault: address.isDefault,
            createdAt: address.createdAt,
            updatedAt: address.updatedAt,
        };
    }
    async create(wxUserId, dto) {
        if (dto.isDefault) {
            await this.prisma.shippingAddress.updateMany({
                where: {
                    wxUserId,
                    isDefault: true,
                },
                data: {
                    isDefault: false,
                },
            });
        }
        const address = await this.prisma.shippingAddress.create({
            data: {
                wxUserId,
                receiverName: dto.receiverName,
                phone: dto.phone,
                province: dto.province,
                city: dto.city,
                district: dto.district,
                detail: dto.detail,
                postalCode: dto.postalCode,
                isDefault: dto.isDefault ?? false,
            },
        });
        return {
            id: address.id,
            receiverName: address.receiverName,
            phone: address.phone,
            province: address.province,
            city: address.city,
            district: address.district,
            detail: address.detail,
            postalCode: address.postalCode,
            isDefault: address.isDefault,
            createdAt: address.createdAt,
            updatedAt: address.updatedAt,
        };
    }
    async update(wxUserId, id, dto) {
        const existingAddress = await this.prisma.shippingAddress.findFirst({
            where: {
                id,
                wxUserId,
            },
        });
        if (!existingAddress) {
            throw new common_1.NotFoundException('地址不存在');
        }
        if (dto.isDefault && !existingAddress.isDefault) {
            await this.prisma.shippingAddress.updateMany({
                where: {
                    wxUserId,
                    isDefault: true,
                },
                data: {
                    isDefault: false,
                },
            });
        }
        const address = await this.prisma.shippingAddress.update({
            where: { id },
            data: {
                receiverName: dto.receiverName,
                phone: dto.phone,
                province: dto.province,
                city: dto.city,
                district: dto.district,
                detail: dto.detail,
                postalCode: dto.postalCode,
                isDefault: dto.isDefault,
            },
        });
        return {
            id: address.id,
            receiverName: address.receiverName,
            phone: address.phone,
            province: address.province,
            city: address.city,
            district: address.district,
            detail: address.detail,
            postalCode: address.postalCode,
            isDefault: address.isDefault,
            createdAt: address.createdAt,
            updatedAt: address.updatedAt,
        };
    }
    async remove(wxUserId, id) {
        const address = await this.prisma.shippingAddress.findFirst({
            where: {
                id,
                wxUserId,
            },
        });
        if (!address) {
            throw new common_1.NotFoundException('地址不存在');
        }
        await this.prisma.shippingAddress.delete({
            where: { id },
        });
        return {
            success: true,
            message: '地址删除成功',
        };
    }
    async setDefault(wxUserId, id) {
        const address = await this.prisma.shippingAddress.findFirst({
            where: {
                id,
                wxUserId,
            },
        });
        if (!address) {
            throw new common_1.NotFoundException('地址不存在');
        }
        if (address.isDefault) {
            return {
                success: true,
                message: '该地址已是默认地址',
            };
        }
        await this.prisma.$transaction([
            this.prisma.shippingAddress.updateMany({
                where: {
                    wxUserId,
                    isDefault: true,
                },
                data: {
                    isDefault: false,
                },
            }),
            this.prisma.shippingAddress.update({
                where: { id },
                data: {
                    isDefault: true,
                },
            }),
        ]);
        return {
            success: true,
            message: '默认地址设置成功',
        };
    }
    async getDefault(wxUserId) {
        const address = await this.prisma.shippingAddress.findFirst({
            where: {
                wxUserId,
                isDefault: true,
            },
        });
        if (!address) {
            return null;
        }
        return {
            id: address.id,
            receiverName: address.receiverName,
            phone: address.phone,
            province: address.province,
            city: address.city,
            district: address.district,
            detail: address.detail,
            postalCode: address.postalCode,
            isDefault: address.isDefault,
            createdAt: address.createdAt,
            updatedAt: address.updatedAt,
        };
    }
};
exports.WxAddressService = WxAddressService;
exports.WxAddressService = WxAddressService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], WxAddressService);
//# sourceMappingURL=wx-address.service.js.map