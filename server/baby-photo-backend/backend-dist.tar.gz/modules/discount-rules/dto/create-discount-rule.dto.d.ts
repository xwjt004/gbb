export declare class CreateDiscountRuleDto {
    name: string;
    minAmount: number;
    maxAmount: number;
    discountRate: number;
    description?: string;
    isActive?: boolean;
}
