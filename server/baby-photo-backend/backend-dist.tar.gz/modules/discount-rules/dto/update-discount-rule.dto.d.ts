import { CreateDiscountRuleDto } from './create-discount-rule.dto';
declare const UpdateDiscountRuleDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateDiscountRuleDto>>;
export declare class UpdateDiscountRuleDto extends UpdateDiscountRuleDto_base {
}
export {};
