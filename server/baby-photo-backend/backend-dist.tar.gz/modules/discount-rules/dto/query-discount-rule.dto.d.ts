export declare class QueryDiscountRuleDto {
    keyword?: string;
    isActive?: boolean;
    page?: number;
    pageSize?: number;
}
