"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var DiscountRulesService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiscountRulesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let DiscountRulesService = DiscountRulesService_1 = class DiscountRulesService {
    prisma;
    logger = new common_1.Logger(DiscountRulesService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createDto) {
        this.logger.log(`创建折扣规则: ${createDto.name}`);
        const overlapping = await this.checkOverlappingRules(createDto.minAmount, createDto.maxAmount);
        if (overlapping.length > 0) {
            throw new common_1.ConflictException(`价格区间 ${createDto.minAmount}-${createDto.maxAmount} 与现有规则重叠`);
        }
        try {
            const rule = await this.prisma.discountRule.create({
                data: {
                    name: createDto.name,
                    minAmount: createDto.minAmount,
                    maxAmount: createDto.maxAmount,
                    discountRate: createDto.discountRate,
                    description: createDto.description,
                    isActive: createDto.isActive ?? true,
                },
            });
            this.logger.log(`折扣规则创建成功: ID=${rule.id}`);
            return {
                code: 200,
                message: '创建成功',
                data: rule,
            };
        }
        catch (error) {
            this.logger.error(`创建折扣规则失败: ${error.message}`);
            throw error;
        }
    }
    async findAll(query) {
        const { keyword, isActive, page = 1, pageSize = 20 } = query;
        const where = {};
        if (keyword) {
            where.OR = [
                { name: { contains: keyword } },
                { description: { contains: keyword } },
            ];
        }
        if (isActive !== undefined)
            where.isActive = isActive;
        try {
            const [total, list] = await Promise.all([
                this.prisma.discountRule.count({ where }),
                this.prisma.discountRule.findMany({
                    where,
                    orderBy: [
                        { minAmount: 'asc' },
                        { createdAt: 'desc' },
                    ],
                    skip: (page - 1) * pageSize,
                    take: pageSize,
                }),
            ]);
            return {
                code: 200,
                message: '查询成功',
                data: {
                    list,
                    pagination: {
                        page,
                        pageSize,
                        total,
                        totalPages: Math.ceil(total / pageSize),
                    },
                },
            };
        }
        catch (error) {
            this.logger.error(`查询折扣规则列表失败: ${error.message}`);
            throw error;
        }
    }
    async findOne(id) {
        try {
            const rule = await this.prisma.discountRule.findUnique({
                where: { id },
            });
            if (!rule) {
                throw new common_1.NotFoundException(`折扣规则 ID=${id} 不存在`);
            }
            return {
                code: 200,
                message: '查询成功',
                data: rule,
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`查询折扣规则失败: ${error.message}`);
            throw error;
        }
    }
    async update(id, updateDto) {
        this.logger.log(`更新折扣规则: ID=${id}`);
        const existing = await this.prisma.discountRule.findUnique({
            where: { id },
        });
        if (!existing) {
            throw new common_1.NotFoundException(`折扣规则 ID=${id} 不存在`);
        }
        if (updateDto.minAmount !== undefined || updateDto.maxAmount !== undefined) {
            const minAmount = updateDto.minAmount ?? Number(existing.minAmount);
            const maxAmount = updateDto.maxAmount ?? Number(existing.maxAmount);
            const overlapping = await this.checkOverlappingRules(minAmount, maxAmount, id);
            if (overlapping.length > 0) {
                throw new common_1.ConflictException(`价格区间 ${minAmount}-${maxAmount} 与现有规则重叠`);
            }
        }
        try {
            const rule = await this.prisma.discountRule.update({
                where: { id },
                data: updateDto,
            });
            this.logger.log(`折扣规则更新成功: ID=${id}`);
            return {
                code: 200,
                message: '更新成功',
                data: rule,
            };
        }
        catch (error) {
            this.logger.error(`更新折扣规则失败: ${error.message}`);
            throw error;
        }
    }
    async remove(id) {
        this.logger.log(`删除折扣规则: ID=${id}`);
        const existing = await this.prisma.discountRule.findUnique({
            where: { id },
        });
        if (!existing) {
            throw new common_1.NotFoundException(`折扣规则 ID=${id} 不存在`);
        }
        try {
            await this.prisma.discountRule.delete({
                where: { id },
            });
            this.logger.log(`折扣规则删除成功: ID=${id}`);
            return {
                code: 200,
                message: '删除成功',
            };
        }
        catch (error) {
            this.logger.error(`删除折扣规则失败: ${error.message}`);
            throw error;
        }
    }
    async calculateDiscount(amount) {
        try {
            const rule = await this.prisma.discountRule.findFirst({
                where: {
                    isActive: true,
                    minAmount: { lte: amount },
                    maxAmount: { gte: amount },
                },
                orderBy: { discountRate: 'asc' },
            });
            if (!rule) {
                return {
                    code: 200,
                    message: '无适用折扣',
                    data: {
                        originalAmount: amount,
                        discountAmount: 0,
                        discountRate: 1,
                        savedAmount: 0,
                        rule: null,
                    },
                };
            }
            const finalAmount = Math.round(amount * Number(rule.discountRate) * 100) / 100;
            const discountAmount = Math.round((amount - finalAmount) * 100) / 100;
            return {
                code: 200,
                message: '计算成功',
                data: {
                    originalAmount: amount,
                    discountAmount,
                    discountRate: Number(rule.discountRate),
                    savedAmount: discountAmount,
                    rule,
                },
            };
        }
        catch (error) {
            this.logger.error(`计算折扣失败: ${error.message}`);
            throw error;
        }
    }
    async checkOverlappingRules(minAmount, maxAmount, excludeId) {
        const where = {
            isActive: true,
            OR: [
                {
                    minAmount: { lte: minAmount },
                    maxAmount: { gte: minAmount },
                },
                {
                    minAmount: { lte: maxAmount },
                    maxAmount: { gte: maxAmount },
                },
                {
                    minAmount: { gte: minAmount },
                    maxAmount: { lte: maxAmount },
                },
            ],
        };
        if (excludeId) {
            where.id = { not: excludeId };
        }
        return this.prisma.discountRule.findMany({ where });
    }
};
exports.DiscountRulesService = DiscountRulesService;
exports.DiscountRulesService = DiscountRulesService = DiscountRulesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], DiscountRulesService);
//# sourceMappingURL=discount-rules.service.js.map