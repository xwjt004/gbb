"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var DiscountRulesController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiscountRulesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const discount_rules_service_1 = require("./discount-rules.service");
const create_discount_rule_dto_1 = require("./dto/create-discount-rule.dto");
const update_discount_rule_dto_1 = require("./dto/update-discount-rule.dto");
const query_discount_rule_dto_1 = require("./dto/query-discount-rule.dto");
let DiscountRulesController = DiscountRulesController_1 = class DiscountRulesController {
    discountRulesService;
    logger = new common_1.Logger(DiscountRulesController_1.name);
    constructor(discountRulesService) {
        this.discountRulesService = discountRulesService;
    }
    create(createDto) {
        this.logger.log(`创建折扣规则: ${createDto.name}`);
        return this.discountRulesService.create(createDto);
    }
    findAll(query) {
        return this.discountRulesService.findAll(query);
    }
    calculateDiscount(amount) {
        return this.discountRulesService.calculateDiscount(amount);
    }
    findOne(id) {
        return this.discountRulesService.findOne(id);
    }
    update(id, updateDto) {
        this.logger.log(`更新折扣规则: ID=${id}`);
        return this.discountRulesService.update(id, updateDto);
    }
    remove(id) {
        this.logger.log(`删除折扣规则: ID=${id}`);
        return this.discountRulesService.remove(id);
    }
};
exports.DiscountRulesController = DiscountRulesController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建折扣规则' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '创建成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_discount_rule_dto_1.CreateDiscountRuleDto]),
    __metadata("design:returntype", void 0)
], DiscountRulesController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取折扣规则列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_discount_rule_dto_1.QueryDiscountRuleDto]),
    __metadata("design:returntype", void 0)
], DiscountRulesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('calculate/:amount'),
    (0, swagger_1.ApiOperation)({ summary: '根据金额计算折扣' }),
    (0, swagger_1.ApiParam)({ name: 'amount', description: '金额', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '计算成功' }),
    __param(0, (0, common_1.Param)('amount', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], DiscountRulesController.prototype, "calculateDiscount", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '获取折扣规则详情' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '规则ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], DiscountRulesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新折扣规则' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '规则ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, update_discount_rule_dto_1.UpdateDiscountRuleDto]),
    __metadata("design:returntype", void 0)
], DiscountRulesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除折扣规则' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '规则ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '删除成功' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], DiscountRulesController.prototype, "remove", null);
exports.DiscountRulesController = DiscountRulesController = DiscountRulesController_1 = __decorate([
    (0, swagger_1.ApiTags)('折扣规则管理'),
    (0, common_1.Controller)('discount-rules'),
    __metadata("design:paramtypes", [discount_rules_service_1.DiscountRulesService])
], DiscountRulesController);
//# sourceMappingURL=discount-rules.controller.js.map