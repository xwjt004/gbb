import { DiscountRulesService } from './discount-rules.service';
import { CreateDiscountRuleDto } from './dto/create-discount-rule.dto';
import { UpdateDiscountRuleDto } from './dto/update-discount-rule.dto';
import { QueryDiscountRuleDto } from './dto/query-discount-rule.dto';
export declare class DiscountRulesController {
    private readonly discountRulesService;
    private readonly logger;
    constructor(discountRulesService: DiscountRulesService);
    create(createDto: CreateDiscountRuleDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            discountRate: import("@prisma/client/runtime/library").Decimal;
            minAmount: import("@prisma/client/runtime/library").Decimal;
            maxAmount: import("@prisma/client/runtime/library").Decimal;
            isActive: boolean;
        };
    }>;
    findAll(query: QueryDiscountRuleDto): Promise<{
        code: number;
        message: string;
        data: {
            list: {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                description: string | null;
                discountRate: import("@prisma/client/runtime/library").Decimal;
                minAmount: import("@prisma/client/runtime/library").Decimal;
                maxAmount: import("@prisma/client/runtime/library").Decimal;
                isActive: boolean;
            }[];
            pagination: {
                page: number;
                pageSize: number;
                total: number;
                totalPages: number;
            };
        };
    }>;
    calculateDiscount(amount: number): Promise<{
        code: number;
        message: string;
        data: {
            originalAmount: number;
            discountAmount: number;
            discountRate: number;
            savedAmount: number;
            rule: null;
        };
    } | {
        code: number;
        message: string;
        data: {
            originalAmount: number;
            discountAmount: number;
            discountRate: number;
            savedAmount: number;
            rule: {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                description: string | null;
                discountRate: import("@prisma/client/runtime/library").Decimal;
                minAmount: import("@prisma/client/runtime/library").Decimal;
                maxAmount: import("@prisma/client/runtime/library").Decimal;
                isActive: boolean;
            };
        };
    }>;
    findOne(id: number): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            discountRate: import("@prisma/client/runtime/library").Decimal;
            minAmount: import("@prisma/client/runtime/library").Decimal;
            maxAmount: import("@prisma/client/runtime/library").Decimal;
            isActive: boolean;
        };
    }>;
    update(id: number, updateDto: UpdateDiscountRuleDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            discountRate: import("@prisma/client/runtime/library").Decimal;
            minAmount: import("@prisma/client/runtime/library").Decimal;
            maxAmount: import("@prisma/client/runtime/library").Decimal;
            isActive: boolean;
        };
    }>;
    remove(id: number): Promise<{
        code: number;
        message: string;
    }>;
}
