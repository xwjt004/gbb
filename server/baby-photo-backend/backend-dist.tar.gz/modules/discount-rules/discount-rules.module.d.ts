export declare class DiscountRulesModule {
}
