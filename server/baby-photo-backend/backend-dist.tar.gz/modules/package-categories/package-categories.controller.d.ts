import { PackageCategoriesService } from './package-categories.service';
import { CreatePackageCategoryDto } from './dto/create-package-category.dto';
import { UpdatePackageCategoryDto } from './dto/update-package-category.dto';
import { PackageCategoryQueryDto } from './dto/package-category-query.dto';
export declare class PackageCategoriesController {
    private readonly packageCategoriesService;
    private readonly logger;
    constructor(packageCategoriesService: PackageCategoriesService);
    create(createDto: CreatePackageCategoryDto): Promise<{
        code: number;
        message: string;
        data: {
            _count: {
                packages: number;
            };
        } & {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            status: string;
            description: string | null;
            sortOrder: number;
            icon: string | null;
            color: string | null;
        };
    }>;
    findAll(query: PackageCategoryQueryDto): Promise<{
        code: number;
        message: string;
        data: {
            items: ({
                _count: {
                    packages: number;
                };
            } & {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                status: string;
                description: string | null;
                sortOrder: number;
                icon: string | null;
                color: string | null;
            })[];
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
    }>;
    findAllActive(): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            name: string;
            description: string | null;
            sortOrder: number;
            icon: string | null;
            color: string | null;
        }[];
    }>;
    findOne(id: number): Promise<{
        code: number;
        message: string;
        data: {
            _count: {
                packages: number;
            };
            packages: {
                id: number;
                name: string;
                status: import("@prisma/client").$Enums.PackageStatus;
                price: import("@prisma/client/runtime/library").Decimal;
            }[];
        } & {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            status: string;
            description: string | null;
            sortOrder: number;
            icon: string | null;
            color: string | null;
        };
    }>;
    update(id: number, updateDto: UpdatePackageCategoryDto): Promise<{
        code: number;
        message: string;
        data: {
            _count: {
                packages: number;
            };
        } & {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            status: string;
            description: string | null;
            sortOrder: number;
            icon: string | null;
            color: string | null;
        };
    }>;
    remove(id: number): Promise<{
        code: number;
        message: string;
    }>;
    updateSortOrder(sortData: {
        id: number;
        sortOrder: number;
    }[]): Promise<{
        code: number;
        message: string;
    }>;
}
