"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PackageCategoriesService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PackageCategoriesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let PackageCategoriesService = PackageCategoriesService_1 = class PackageCategoriesService {
    prisma;
    logger = new common_1.Logger(PackageCategoriesService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createDto) {
        try {
            const existing = await this.prisma.packageCategory.findUnique({
                where: { name: createDto.name },
            });
            if (existing) {
                throw new common_1.ConflictException('分类名称已存在');
            }
            const category = await this.prisma.packageCategory.create({
                data: {
                    name: createDto.name,
                    description: createDto.description,
                    icon: createDto.icon,
                    color: createDto.color,
                    sortOrder: createDto.sortOrder ?? 0,
                    status: createDto.status ?? 'ACTIVE',
                },
                include: {
                    _count: {
                        select: { packages: true },
                    },
                },
            });
            this.logger.log(`套餐分类创建成功: ${category.id} - ${category.name}`);
            return {
                code: 200,
                message: '分类创建成功',
                data: category,
            };
        }
        catch (error) {
            if (error instanceof common_1.ConflictException) {
                throw error;
            }
            this.logger.error(`创建分类失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('创建分类失败');
        }
    }
    async findAll(query) {
        const { page = 1, limit = 20, name, status } = query;
        try {
            const where = {};
            if (name) {
                where.name = {
                    contains: name,
                    mode: 'insensitive',
                };
            }
            if (status) {
                where.status = status;
            }
            const [categories, total] = await Promise.all([
                this.prisma.packageCategory.findMany({
                    where,
                    include: {
                        _count: {
                            select: { packages: true },
                        },
                    },
                    orderBy: [
                        { sortOrder: 'asc' },
                        { createdAt: 'desc' },
                    ],
                    skip: (page - 1) * limit,
                    take: limit,
                }),
                this.prisma.packageCategory.count({ where }),
            ]);
            return {
                code: 200,
                message: '获取分类列表成功',
                data: {
                    items: categories,
                    total,
                    page,
                    limit,
                    totalPages: Math.ceil(total / limit),
                },
            };
        }
        catch (error) {
            this.logger.error(`获取分类列表失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('获取分类列表失败');
        }
    }
    async findAllActive() {
        try {
            const categories = await this.prisma.packageCategory.findMany({
                where: { status: 'ACTIVE' },
                select: {
                    id: true,
                    name: true,
                    description: true,
                    icon: true,
                    color: true,
                    sortOrder: true,
                },
                orderBy: [
                    { sortOrder: 'asc' },
                    { name: 'asc' },
                ],
            });
            return {
                code: 200,
                message: '获取启用分类成功',
                data: categories,
            };
        }
        catch (error) {
            this.logger.error(`获取启用分类失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('获取启用分类失败');
        }
    }
    async findOne(id) {
        try {
            const category = await this.prisma.packageCategory.findUnique({
                where: { id },
                include: {
                    _count: {
                        select: { packages: true },
                    },
                    packages: {
                        select: {
                            id: true,
                            name: true,
                            price: true,
                            status: true,
                        },
                        take: 10,
                    },
                },
            });
            if (!category) {
                throw new common_1.NotFoundException('分类不存在');
            }
            return {
                code: 200,
                message: '获取分类详情成功',
                data: category,
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`获取分类详情失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('获取分类详情失败');
        }
    }
    async update(id, updateDto) {
        try {
            const existing = await this.prisma.packageCategory.findUnique({
                where: { id },
            });
            if (!existing) {
                throw new common_1.NotFoundException('分类不存在');
            }
            if (updateDto.name && updateDto.name !== existing.name) {
                const nameConflict = await this.prisma.packageCategory.findUnique({
                    where: { name: updateDto.name },
                });
                if (nameConflict) {
                    throw new common_1.ConflictException('分类名称已存在');
                }
            }
            const category = await this.prisma.packageCategory.update({
                where: { id },
                data: updateDto,
                include: {
                    _count: {
                        select: { packages: true },
                    },
                },
            });
            this.logger.log(`分类更新成功: ${id} - ${category.name}`);
            return {
                code: 200,
                message: '分类更新成功',
                data: category,
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException || error instanceof common_1.ConflictException) {
                throw error;
            }
            this.logger.error(`更新分类失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('更新分类失败');
        }
    }
    async remove(id) {
        try {
            const category = await this.prisma.packageCategory.findUnique({
                where: { id },
                include: {
                    _count: {
                        select: { packages: true },
                    },
                },
            });
            if (!category) {
                throw new common_1.NotFoundException('分类不存在');
            }
            if (category._count?.packages > 0) {
                throw new common_1.BadRequestException(`该分类下有 ${category._count?.packages} 个套餐，无法删除。请先将套餐移至其他分类或删除套餐。`);
            }
            await this.prisma.packageCategory.delete({
                where: { id },
            });
            this.logger.log(`分类删除成功: ${id} - ${category.name}`);
            return {
                code: 200,
                message: '分类删除成功',
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException || error instanceof common_1.BadRequestException) {
                throw error;
            }
            this.logger.error(`删除分类失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('删除分类失败');
        }
    }
    async updateSortOrder(sortData) {
        try {
            await this.prisma.$transaction(sortData.map((item) => this.prisma.packageCategory.update({
                where: { id: item.id },
                data: { sortOrder: item.sortOrder },
            })));
            this.logger.log(`批量更新排序成功，共 ${sortData.length} 条`);
            return {
                code: 200,
                message: '排序更新成功',
            };
        }
        catch (error) {
            this.logger.error(`更新排序失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('更新排序失败');
        }
    }
};
exports.PackageCategoriesService = PackageCategoriesService;
exports.PackageCategoriesService = PackageCategoriesService = PackageCategoriesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PackageCategoriesService);
//# sourceMappingURL=package-categories.service.js.map