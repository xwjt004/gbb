export declare class PackageCategoriesModule {
}
