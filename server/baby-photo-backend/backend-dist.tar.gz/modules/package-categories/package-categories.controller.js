"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var PackageCategoriesController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PackageCategoriesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const package_categories_service_1 = require("./package-categories.service");
const create_package_category_dto_1 = require("./dto/create-package-category.dto");
const update_package_category_dto_1 = require("./dto/update-package-category.dto");
const package_category_query_dto_1 = require("./dto/package-category-query.dto");
let PackageCategoriesController = PackageCategoriesController_1 = class PackageCategoriesController {
    packageCategoriesService;
    logger = new common_1.Logger(PackageCategoriesController_1.name);
    constructor(packageCategoriesService) {
        this.packageCategoriesService = packageCategoriesService;
    }
    create(createDto) {
        this.logger.log(`创建套餐分类: ${createDto.name}`);
        return this.packageCategoriesService.create(createDto);
    }
    findAll(query) {
        return this.packageCategoriesService.findAll(query);
    }
    findAllActive() {
        return this.packageCategoriesService.findAllActive();
    }
    findOne(id) {
        return this.packageCategoriesService.findOne(id);
    }
    update(id, updateDto) {
        this.logger.log(`更新套餐分类: ${id}`);
        return this.packageCategoriesService.update(id, updateDto);
    }
    remove(id) {
        this.logger.log(`删除套餐分类: ${id}`);
        return this.packageCategoriesService.remove(id);
    }
    updateSortOrder(sortData) {
        this.logger.log(`批量更新排序，共 ${sortData.length} 条`);
        return this.packageCategoriesService.updateSortOrder(sortData);
    }
};
exports.PackageCategoriesController = PackageCategoriesController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建套餐分类' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '分类创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 409, description: '分类名称已存在' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_package_category_dto_1.CreatePackageCategoryDto]),
    __metadata("design:returntype", void 0)
], PackageCategoriesController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取套餐分类列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [package_category_query_dto_1.PackageCategoryQueryDto]),
    __metadata("design:returntype", void 0)
], PackageCategoriesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('active'),
    (0, swagger_1.ApiOperation)({ summary: '获取所有启用的分类（用于选择器）' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PackageCategoriesController.prototype, "findAllActive", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '获取分类详情' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '分类不存在' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], PackageCategoriesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新套餐分类' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '分类不存在' }),
    (0, swagger_1.ApiResponse)({ status: 409, description: '分类名称已存在' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, update_package_category_dto_1.UpdatePackageCategoryDto]),
    __metadata("design:returntype", void 0)
], PackageCategoriesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除套餐分类' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '删除成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '分类不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '分类下有套餐，无法删除' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], PackageCategoriesController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)('sort'),
    (0, swagger_1.ApiOperation)({ summary: '批量更新分类排序' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '排序更新成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", void 0)
], PackageCategoriesController.prototype, "updateSortOrder", null);
exports.PackageCategoriesController = PackageCategoriesController = PackageCategoriesController_1 = __decorate([
    (0, swagger_1.ApiTags)('package-categories'),
    (0, common_1.Controller)('package-categories'),
    __metadata("design:paramtypes", [package_categories_service_1.PackageCategoriesService])
], PackageCategoriesController);
//# sourceMappingURL=package-categories.controller.js.map