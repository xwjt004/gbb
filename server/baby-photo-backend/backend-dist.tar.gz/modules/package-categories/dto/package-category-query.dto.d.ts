export declare class PackageCategoryQueryDto {
    name?: string;
    status?: string;
    page?: number;
    limit?: number;
}
