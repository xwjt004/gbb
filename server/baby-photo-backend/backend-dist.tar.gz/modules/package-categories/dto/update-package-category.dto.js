"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdatePackageCategoryDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const create_package_category_dto_1 = require("./create-package-category.dto");
class UpdatePackageCategoryDto extends (0, swagger_1.PartialType)(create_package_category_dto_1.CreatePackageCategoryDto) {
}
exports.UpdatePackageCategoryDto = UpdatePackageCategoryDto;
//# sourceMappingURL=update-package-category.dto.js.map