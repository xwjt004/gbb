export declare class CreatePackageCategoryDto {
    name: string;
    description?: string;
    icon?: string;
    color?: string;
    sortOrder?: number;
    status?: string;
}
