import { CreatePackageCategoryDto } from './create-package-category.dto';
declare const UpdatePackageCategoryDto_base: import("@nestjs/common").Type<Partial<CreatePackageCategoryDto>>;
export declare class UpdatePackageCategoryDto extends UpdatePackageCategoryDto_base {
}
export {};
