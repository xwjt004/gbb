export declare class QueryProductCategoryDto {
    isActive?: boolean;
    page?: number;
    pageSize?: number;
}
