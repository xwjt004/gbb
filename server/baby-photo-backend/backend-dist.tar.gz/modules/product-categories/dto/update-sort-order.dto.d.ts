declare class SortItem {
    id: number;
    sortOrder: number;
}
export declare class UpdateSortOrderDto {
    items: SortItem[];
}
export {};
