"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateProductCategoryDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class CreateProductCategoryDto {
    name;
    code;
    description;
    sortOrder;
    isActive;
}
exports.CreateProductCategoryDto = CreateProductCategoryDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '分类名称', example: '相册类' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: '分类名称不能为空' }),
    (0, class_validator_1.MaxLength)(50, { message: '分类名称最长50个字符' }),
    __metadata("design:type", String)
], CreateProductCategoryDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '分类编码', example: 'ALBUM' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: '分类编码不能为空' }),
    (0, class_validator_1.MaxLength)(20, { message: '分类编码最长20个字符' }),
    __metadata("design:type", String)
], CreateProductCategoryDto.prototype, "code", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '分类描述', example: '各类相册产品', required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductCategoryDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '排序值', example: 1, required: false, default: 0 }),
    (0, class_validator_1.IsInt)({ message: '排序值必须是整数' }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateProductCategoryDto.prototype, "sortOrder", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否启用', example: true, required: false, default: true }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], CreateProductCategoryDto.prototype, "isActive", void 0);
//# sourceMappingURL=create-product-category.dto.js.map