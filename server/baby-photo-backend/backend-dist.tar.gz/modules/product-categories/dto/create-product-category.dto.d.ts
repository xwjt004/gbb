export declare class CreateProductCategoryDto {
    name: string;
    code: string;
    description?: string;
    sortOrder?: number;
    isActive?: boolean;
}
