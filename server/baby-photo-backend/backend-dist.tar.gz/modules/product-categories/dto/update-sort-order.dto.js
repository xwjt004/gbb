"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateSortOrderDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class SortItem {
    id;
    sortOrder;
}
__decorate([
    (0, swagger_1.ApiProperty)({ description: '分类ID', example: 1 }),
    (0, class_validator_1.IsInt)(),
    __metadata("design:type", Number)
], SortItem.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '排序值', example: 1 }),
    (0, class_validator_1.IsInt)(),
    __metadata("design:type", Number)
], SortItem.prototype, "sortOrder", void 0);
class UpdateSortOrderDto {
    items;
}
exports.UpdateSortOrderDto = UpdateSortOrderDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '排序数据',
        type: [SortItem],
        example: [
            { id: 1, sortOrder: 1 },
            { id: 2, sortOrder: 2 }
        ]
    }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => SortItem),
    __metadata("design:type", Array)
], UpdateSortOrderDto.prototype, "items", void 0);
//# sourceMappingURL=update-sort-order.dto.js.map