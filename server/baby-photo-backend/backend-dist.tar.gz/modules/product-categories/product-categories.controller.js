"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ProductCategoriesController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductCategoriesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const product_categories_service_1 = require("./product-categories.service");
const create_product_category_dto_1 = require("./dto/create-product-category.dto");
const update_product_category_dto_1 = require("./dto/update-product-category.dto");
const query_product_category_dto_1 = require("./dto/query-product-category.dto");
const update_sort_order_dto_1 = require("./dto/update-sort-order.dto");
let ProductCategoriesController = ProductCategoriesController_1 = class ProductCategoriesController {
    productCategoriesService;
    logger = new common_1.Logger(ProductCategoriesController_1.name);
    constructor(productCategoriesService) {
        this.productCategoriesService = productCategoriesService;
    }
    create(createDto) {
        this.logger.log(`创建商品分类: ${createDto.name}`);
        return this.productCategoriesService.create(createDto);
    }
    findAll(query) {
        return this.productCategoriesService.findAll(query);
    }
    findAllActive() {
        return this.productCategoriesService.findAllActive();
    }
    findOne(id) {
        return this.productCategoriesService.findOne(id);
    }
    updateSortOrder(updateDto) {
        return this.productCategoriesService.updateSortOrder(updateDto);
    }
    update(id, updateDto) {
        this.logger.log(`更新商品分类: ID=${id}`);
        return this.productCategoriesService.update(id, updateDto);
    }
    remove(id) {
        this.logger.log(`删除商品分类: ID=${id}`);
        return this.productCategoriesService.remove(id);
    }
};
exports.ProductCategoriesController = ProductCategoriesController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建商品分类' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '分类创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 409, description: '分类名称或编码已存在' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_product_category_dto_1.CreateProductCategoryDto]),
    __metadata("design:returntype", void 0)
], ProductCategoriesController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取商品分类列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_product_category_dto_1.QueryProductCategoryDto]),
    __metadata("design:returntype", void 0)
], ProductCategoriesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('active'),
    (0, swagger_1.ApiOperation)({ summary: '获取所有启用的分类（用于选择器）' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ProductCategoriesController.prototype, "findAllActive", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '获取分类详情' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '分类ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '分类不存在' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], ProductCategoriesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)('sort'),
    (0, swagger_1.ApiOperation)({ summary: '批量更新分类排序' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '参数错误' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [update_sort_order_dto_1.UpdateSortOrderDto]),
    __metadata("design:returntype", void 0)
], ProductCategoriesController.prototype, "updateSortOrder", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新分类' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '分类ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '分类不存在' }),
    (0, swagger_1.ApiResponse)({ status: 409, description: '分类名称或编码已存在' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, update_product_category_dto_1.UpdateProductCategoryDto]),
    __metadata("design:returntype", void 0)
], ProductCategoriesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除分类' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '分类ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '删除成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '分类不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '该分类下有商品，无法删除' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], ProductCategoriesController.prototype, "remove", null);
exports.ProductCategoriesController = ProductCategoriesController = ProductCategoriesController_1 = __decorate([
    (0, swagger_1.ApiTags)('product-categories'),
    (0, common_1.Controller)('product-categories'),
    __metadata("design:paramtypes", [product_categories_service_1.ProductCategoriesService])
], ProductCategoriesController);
//# sourceMappingURL=product-categories.controller.js.map