import { PrismaService } from '../../shared/prisma/prisma.service';
import { CreateProductCategoryDto } from './dto/create-product-category.dto';
import { UpdateProductCategoryDto } from './dto/update-product-category.dto';
import { QueryProductCategoryDto } from './dto/query-product-category.dto';
import { UpdateSortOrderDto } from './dto/update-sort-order.dto';
export declare class ProductCategoriesService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    create(createDto: CreateProductCategoryDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            sortOrder: number;
            code: string;
            isActive: boolean;
        };
    }>;
    findAll(query: QueryProductCategoryDto): Promise<{
        code: number;
        message: string;
        data: {
            list: {
                productCount: number;
                _count: {
                    products: number;
                };
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                description: string | null;
                sortOrder: number;
                code: string;
                isActive: boolean;
            }[];
            pagination: {
                page: number;
                pageSize: number;
                total: number;
                totalPages: number;
            };
        };
    }>;
    findAllActive(): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            name: string;
            sortOrder: number;
            code: string;
        }[];
    }>;
    findOne(id: number): Promise<{
        code: number;
        message: string;
        data: {
            productCount: number;
            _count: {
                products: number;
            };
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            sortOrder: number;
            code: string;
            isActive: boolean;
        };
    }>;
    update(id: number, updateDto: UpdateProductCategoryDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            sortOrder: number;
            code: string;
            isActive: boolean;
        };
    }>;
    remove(id: number): Promise<{
        code: number;
        message: string;
    }>;
    updateSortOrder(updateDto: UpdateSortOrderDto): Promise<{
        code: number;
        message: string;
    }>;
}
