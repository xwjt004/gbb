export declare class ProductCategoriesModule {
}
