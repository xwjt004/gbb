"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ProductCategoriesService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductCategoriesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let ProductCategoriesService = ProductCategoriesService_1 = class ProductCategoriesService {
    prisma;
    logger = new common_1.Logger(ProductCategoriesService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createDto) {
        this.logger.log(`创建商品分类: ${createDto.name}`);
        const existingByName = await this.prisma.productCategory.findFirst({
            where: { name: createDto.name },
        });
        if (existingByName) {
            throw new common_1.ConflictException(`分类名称 "${createDto.name}" 已存在`);
        }
        const existingByCode = await this.prisma.productCategory.findFirst({
            where: { code: createDto.code },
        });
        if (existingByCode) {
            throw new common_1.ConflictException(`分类编码 "${createDto.code}" 已存在`);
        }
        try {
            const category = await this.prisma.productCategory.create({
                data: {
                    name: createDto.name,
                    code: createDto.code,
                    description: createDto.description,
                    sortOrder: createDto.sortOrder ?? 0,
                    isActive: createDto.isActive ?? true,
                },
            });
            this.logger.log(`商品分类创建成功: ID=${category.id}`);
            return {
                code: 200,
                message: '创建成功',
                data: category,
            };
        }
        catch (error) {
            this.logger.error(`创建商品分类失败: ${error.message}`);
            throw error;
        }
    }
    async findAll(query) {
        const { isActive, page = 1, pageSize = 20 } = query;
        const where = {};
        if (isActive !== undefined) {
            where.isActive = isActive;
        }
        try {
            const [total, list] = await Promise.all([
                this.prisma.productCategory.count({ where }),
                this.prisma.productCategory.findMany({
                    where,
                    include: {
                        _count: {
                            select: { products: true },
                        },
                    },
                    orderBy: [
                        { sortOrder: 'asc' },
                        { createdAt: 'desc' },
                    ],
                    skip: (page - 1) * pageSize,
                    take: pageSize,
                }),
            ]);
            return {
                code: 200,
                message: '查询成功',
                data: {
                    list: list.map(item => ({
                        ...item,
                        productCount: item._count?.products,
                    })),
                    pagination: {
                        page,
                        pageSize,
                        total,
                        totalPages: Math.ceil(total / pageSize),
                    },
                },
            };
        }
        catch (error) {
            this.logger.error(`查询商品分类列表失败: ${error.message}`);
            throw error;
        }
    }
    async findAllActive() {
        try {
            const categories = await this.prisma.productCategory.findMany({
                where: { isActive: true },
                orderBy: [
                    { sortOrder: 'asc' },
                    { name: 'asc' },
                ],
                select: {
                    id: true,
                    name: true,
                    code: true,
                    sortOrder: true,
                },
            });
            return {
                code: 200,
                message: '查询成功',
                data: categories,
            };
        }
        catch (error) {
            this.logger.error(`查询启用分类失败: ${error.message}`);
            throw error;
        }
    }
    async findOne(id) {
        try {
            const category = await this.prisma.productCategory.findUnique({
                where: { id },
                include: {
                    _count: {
                        select: { products: true },
                    },
                },
            });
            if (!category) {
                throw new common_1.NotFoundException(`分类 ID=${id} 不存在`);
            }
            return {
                code: 200,
                message: '查询成功',
                data: {
                    ...category,
                    productCount: category._count?.products,
                },
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`查询分类详情失败: ${error.message}`);
            throw error;
        }
    }
    async update(id, updateDto) {
        this.logger.log(`更新商品分类: ID=${id}`);
        const existing = await this.prisma.productCategory.findUnique({
            where: { id },
        });
        if (!existing) {
            throw new common_1.NotFoundException(`分类 ID=${id} 不存在`);
        }
        if (updateDto.name && updateDto.name !== existing.name) {
            const duplicateName = await this.prisma.productCategory.findFirst({
                where: {
                    name: updateDto.name,
                    id: { not: id },
                },
            });
            if (duplicateName) {
                throw new common_1.ConflictException(`分类名称 "${updateDto.name}" 已存在`);
            }
        }
        if (updateDto.code && updateDto.code !== existing.code) {
            const duplicateCode = await this.prisma.productCategory.findFirst({
                where: {
                    code: updateDto.code,
                    id: { not: id },
                },
            });
            if (duplicateCode) {
                throw new common_1.ConflictException(`分类编码 "${updateDto.code}" 已存在`);
            }
        }
        try {
            const category = await this.prisma.productCategory.update({
                where: { id },
                data: updateDto,
            });
            this.logger.log(`分类更新成功: ID=${id}`);
            return {
                code: 200,
                message: '更新成功',
                data: category,
            };
        }
        catch (error) {
            this.logger.error(`更新分类失败: ${error.message}`);
            throw error;
        }
    }
    async remove(id) {
        this.logger.log(`删除商品分类: ID=${id}`);
        const existing = await this.prisma.productCategory.findUnique({
            where: { id },
            include: {
                _count: {
                    select: { products: true },
                },
            },
        });
        if (!existing) {
            throw new common_1.NotFoundException(`分类 ID=${id} 不存在`);
        }
        if (existing._count?.products > 0) {
            throw new common_1.BadRequestException(`该分类下有 ${existing._count?.products} 个商品，无法删除`);
        }
        try {
            await this.prisma.productCategory.delete({
                where: { id },
            });
            this.logger.log(`分类删除成功: ID=${id}`);
            return {
                code: 200,
                message: '删除成功',
            };
        }
        catch (error) {
            this.logger.error(`删除分类失败: ${error.message}`);
            throw error;
        }
    }
    async updateSortOrder(updateDto) {
        this.logger.log(`批量更新分类排序: ${updateDto.items.length} 个`);
        try {
            await this.prisma.$transaction(updateDto.items.map(item => this.prisma.productCategory.update({
                where: { id: item.id },
                data: { sortOrder: item.sortOrder },
            })));
            this.logger.log('分类排序更新成功');
            return {
                code: 200,
                message: '排序更新成功',
            };
        }
        catch (error) {
            this.logger.error(`更新排序失败: ${error.message}`);
            throw new common_1.BadRequestException('更新排序失败，请检查分类ID是否正确');
        }
    }
};
exports.ProductCategoriesService = ProductCategoriesService;
exports.ProductCategoriesService = ProductCategoriesService = ProductCategoriesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ProductCategoriesService);
//# sourceMappingURL=product-categories.service.js.map