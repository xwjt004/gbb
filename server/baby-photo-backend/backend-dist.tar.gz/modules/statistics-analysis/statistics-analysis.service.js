"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var StatisticsAnalysisService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatisticsAnalysisService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const status_enum_1 = require("../../shared/enums/status.enum");
const date_util_1 = require("../../shared/utils/date.util");
let StatisticsAnalysisService = StatisticsAnalysisService_1 = class StatisticsAnalysisService {
    prisma;
    logger = new common_1.Logger(StatisticsAnalysisService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getOrderTrend(period, startDate, endDate) {
        this.logger.log(`获取订单趋势分析: ${period}, ${startDate} - ${endDate}`);
        try {
            const end = endDate ? new Date(endDate) : new Date();
            const start = startDate
                ? new Date(startDate)
                : new Date(end.getTime() - 30 * 24 * 60 * 60 * 1000);
            const startOfDay = new Date(start);
            startOfDay.setHours(0, 0, 0, 0);
            const endOfDay = new Date(end);
            endOfDay.setHours(23, 59, 59, 999);
            const trendData = [];
            const currentDate = new Date(startOfDay);
            while (currentDate <= endOfDay) {
                const dayStart = new Date(currentDate);
                dayStart.setHours(0, 0, 0, 0);
                const dayEnd = new Date(currentDate);
                dayEnd.setHours(23, 59, 59, 999);
                const [dayOrders, dayRevenue, dayPaid, dayRefunds] = await Promise.all([
                    this.prisma.order.aggregate({
                        where: { createdAt: { gte: dayStart, lte: dayEnd } },
                        _count: { id: true },
                    }),
                    this.prisma.order.aggregate({
                        where: {
                            createdAt: { gte: dayStart, lte: dayEnd },
                            orderStatus: { not: 'CANCELLED' },
                        },
                        _sum: { totalAmount: true },
                    }),
                    this.prisma.order.aggregate({
                        where: {
                            createdAt: { gte: dayStart, lte: dayEnd },
                            paymentStatus: 'FULLY_PAID',
                        },
                        _sum: { paidAmount: true },
                    }),
                    this.prisma.refundRequest.aggregate({
                        where: {
                            createdAt: { gte: dayStart, lte: dayEnd },
                            status: { in: ['APPROVED', 'COMPLETED'] },
                        },
                        _sum: { refundAmount: true },
                    }),
                ]);
                trendData.push({
                    date: (0, date_util_1.formatLocalDate)(currentDate),
                    orderCount: dayOrders._count?.id,
                    revenue: Number(dayRevenue._sum?.totalAmount || 0),
                    paidAmount: Number(dayPaid._sum?.paidAmount || 0),
                    refundAmount: Number(dayRefunds._sum?.refundAmount || 0),
                });
                currentDate.setDate(currentDate.getDate() + 1);
            }
            return trendData;
        }
        catch (error) {
            this.logger.error('获取订单趋势失败:', error);
            throw error;
        }
    }
    async getRevenueAnalysis(dimension, period) {
        this.logger.log(`获取收入分析: ${dimension}, ${period}`);
        try {
            const endDate = new Date();
            const startDate = new Date();
            if (period === 'thisMonth') {
                startDate.setDate(1);
                startDate.setHours(0, 0, 0, 0);
            }
            else {
                startDate.setDate(startDate.getDate() - 30);
                startDate.setHours(0, 0, 0, 0);
            }
            const revenueAnalysis = { dimension, total: 0, breakdown: [] };
            switch (dimension) {
                case 'package': {
                    const pkgGroups = await this.prisma.order.groupBy({
                        by: ['packageId'],
                        where: {
                            createdAt: { gte: startDate, lte: endDate },
                            packageId: { not: null },
                        },
                        _sum: { totalAmount: true, paidAmount: true },
                        _count: { id: true },
                    });
                    const pkgIds = pkgGroups.map((g) => g.packageId).filter(Boolean);
                    const packages = pkgIds.length > 0
                        ? await this.prisma.package.findMany({ where: { id: { in: pkgIds } }, select: { id: true, name: true } })
                        : [];
                    const pkgMap = new Map(packages.map((p) => [p.id, p.name]));
                    const totalAmount = pkgGroups.reduce((s, g) => s + Number(g._sum.paidAmount || 0), 0);
                    revenueAnalysis.breakdown = pkgGroups.map((g) => ({
                        category: pkgMap.get(g.packageId) || `套餐#${g.packageId}`,
                        amount: Number(g._sum.paidAmount || 0),
                        percentage: totalAmount > 0 ? Math.round(Number(g._sum.paidAmount || 0) / totalAmount * 1000) / 10 : 0,
                        count: g._count.id,
                    }));
                    revenueAnalysis.total = totalAmount;
                    break;
                }
                case 'channel': {
                    const paymentGroups = await this.prisma.payment.groupBy({
                        by: ['paymentType'],
                        where: {
                            createdAt: { gte: startDate, lte: endDate },
                            status: 'FULLY_PAID',
                        },
                        _sum: { amount: true },
                        _count: { id: true },
                    });
                    const totalAmount = paymentGroups.reduce((s, g) => s + Number(g._sum.amount || 0), 0);
                    revenueAnalysis.breakdown = paymentGroups.map((g) => ({
                        category: this.getPaymentTypeName(g.paymentType),
                        amount: Number(g._sum.amount || 0),
                        percentage: totalAmount > 0 ? Math.round(Number(g._sum.amount || 0) / totalAmount * 1000) / 10 : 0,
                        count: g._count.id,
                    }));
                    revenueAnalysis.total = totalAmount;
                    break;
                }
                default: {
                    const agg = await this.prisma.order.aggregate({
                        where: { createdAt: { gte: startDate, lte: endDate } },
                        _sum: { paidAmount: true },
                        _count: { id: true },
                    });
                    const total = Number(agg._sum.paidAmount || 0);
                    revenueAnalysis.total = total;
                    revenueAnalysis.breakdown = [{ category: '总计', amount: total, percentage: 100, count: agg._count.id }];
                }
            }
            return revenueAnalysis;
        }
        catch (error) {
            this.logger.error('获取收入分析失败:', error);
            throw error;
        }
    }
    async getRefundAnalysis(startDate, endDate) {
        this.logger.log(`获取退款分析: ${startDate} - ${endDate}`);
        try {
            const end = endDate ? new Date(endDate) : new Date();
            const start = startDate
                ? new Date(startDate)
                : new Date(end.getTime() - 30 * 24 * 60 * 60 * 1000);
            const startOfDay = new Date(start);
            startOfDay.setHours(0, 0, 0, 0);
            const endOfDay = new Date(end);
            endOfDay.setHours(23, 59, 59, 999);
            const refundStats = await this.prisma.refundRequest.aggregate({
                where: {
                    createdAt: {
                        gte: startOfDay,
                        lte: endOfDay,
                    },
                    status: { in: ['APPROVED', 'COMPLETED'] },
                },
                _sum: {
                    refundAmount: true,
                },
                _count: {
                    id: true,
                },
                _avg: {
                    refundAmount: true,
                },
            });
            const orderStats = await this.prisma.order.aggregate({
                where: {
                    createdAt: {
                        gte: startOfDay,
                        lte: endOfDay,
                    },
                },
                _sum: {
                    paidAmount: true,
                },
            });
            const totalRefundAmount = Number(refundStats._sum?.refundAmount || 0);
            const totalRevenue = Number(orderStats._sum?.paidAmount || 0);
            const refundRate = totalRevenue > 0 ? (totalRefundAmount / totalRevenue) * 100 : 0;
            const refundsByReason = await this.prisma.refundRequest.groupBy({
                by: ['refundReason'],
                where: {
                    createdAt: {
                        gte: startOfDay,
                        lte: endOfDay,
                    },
                    status: { in: ['APPROVED', 'COMPLETED'] },
                },
                _count: {
                    id: true,
                },
                _sum: {
                    refundAmount: true,
                },
            });
            const byReason = refundsByReason.map((item) => {
                const count = item._count?.id;
                const amount = Number(item._sum?.refundAmount || 0);
                return {
                    reason: item.refundReason,
                    count,
                    amount,
                    percentage: totalRefundAmount > 0
                        ? Math.round((amount / totalRefundAmount) * 1000) / 10
                        : 0,
                };
            });
            const trend = await this.getRefundTrend(startOfDay.toISOString(), endOfDay.toISOString());
            return {
                summary: {
                    totalRefunds: refundStats._count?.id,
                    totalAmount: totalRefundAmount,
                    refundRate: Math.round(refundRate * 100) / 100,
                    avgRefundAmount: Math.round(Number(refundStats._avg.refundAmount || 0)),
                },
                byReason,
                trend,
            };
        }
        catch (error) {
            this.logger.error('获取退款分析失败:', error);
            throw error;
        }
    }
    async getRefundTrend(startDate, endDate) {
        const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        const end = endDate ? new Date(endDate) : new Date();
        const refundTrend = [];
        const currentDate = new Date(start);
        while (currentDate <= end) {
            const dayStart = new Date(currentDate);
            dayStart.setHours(0, 0, 0, 0);
            const dayEnd = new Date(currentDate);
            dayEnd.setHours(23, 59, 59, 999);
            const dayRefunds = await this.prisma.refundRequest.aggregate({
                where: {
                    createdAt: {
                        gte: dayStart,
                        lte: dayEnd,
                    },
                    status: { in: ['APPROVED', 'COMPLETED'] },
                },
                _count: {
                    id: true,
                },
                _sum: {
                    refundAmount: true,
                },
            });
            refundTrend.push({
                date: (0, date_util_1.formatLocalDate)(currentDate),
                count: dayRefunds._count?.id,
                amount: Number(dayRefunds._sum?.refundAmount || 0),
            });
            currentDate.setDate(currentDate.getDate() + 1);
        }
        return refundTrend;
    }
    async getSuspiciousPayments(type) {
        this.logger.log(`检测可疑支付: ${type}`);
        try {
            const suspiciousPayments = [];
            if (type === 'all' || type === 'overpayment') {
                const payments = await this.prisma.payment.findMany({
                    where: {
                        status: status_enum_1.PaymentStatus.FULLY_PAID,
                    },
                    include: {
                        order: {
                            select: { orderNo: true, totalAmount: true },
                        },
                    },
                });
                payments.forEach((payment) => {
                    const paymentAmount = Number(payment.amount);
                    const orderTotal = Number(payment.order.totalAmount);
                    if (paymentAmount > orderTotal) {
                        const diff = paymentAmount - orderTotal;
                        suspiciousPayments.push({
                            id: payment.id,
                            orderId: payment.order.orderNo,
                            amount: paymentAmount,
                            createdAt: payment.createdAt.toISOString(),
                            issue: 'overpayment',
                            severity: diff > 500 ? 'high' : 'medium',
                            description: `支付金额超过订单总额${diff.toFixed(2)}元`,
                        });
                    }
                });
            }
            if (type === 'all' || type === 'system_error') {
                const paymentsWithOrder = await this.prisma.payment.findMany({
                    where: {
                        status: status_enum_1.PaymentStatus.FULLY_PAID,
                    },
                    include: {
                        order: {
                            select: {
                                orderNo: true,
                                paymentStatus: true,
                                paidAmount: true,
                                totalAmount: true,
                            },
                        },
                    },
                });
                paymentsWithOrder.forEach((payment) => {
                    const paidAmount = Number(payment.order.paidAmount);
                    const totalAmount = Number(payment.order.totalAmount);
                    if (paidAmount > 0 && payment.order.paymentStatus === 'UNPAID') {
                        suspiciousPayments.push({
                            id: payment.id,
                            orderId: payment.order.orderNo,
                            amount: Number(payment.amount),
                            createdAt: payment.createdAt.toISOString(),
                            issue: 'system_error',
                            severity: 'medium',
                            description: '支付状态与订单支付状态不一致',
                        });
                    }
                    if (paidAmount >= totalAmount && payment.order.paymentStatus === status_enum_1.PaymentStatus.PARTIAL_PAID) {
                        suspiciousPayments.push({
                            id: payment.id,
                            orderId: payment.order.orderNo,
                            amount: Number(payment.amount),
                            createdAt: payment.createdAt.toISOString(),
                            issue: 'system_error',
                            severity: 'low',
                            description: '订单已收全款但支付状态仍为部分支付',
                        });
                    }
                });
            }
            if (type === 'all' || type === 'duplicate') {
                const duplicateGroups = await this.prisma.payment.groupBy({
                    by: ['orderId'],
                    where: {
                        status: status_enum_1.PaymentStatus.FULLY_PAID,
                    },
                    _count: {
                        id: true,
                    },
                    having: {
                        id: {
                            _count: {
                                gt: 1,
                            },
                        },
                    },
                });
                for (const group of duplicateGroups) {
                    const payments = await this.prisma.payment.findMany({
                        where: {
                            orderId: group.orderId,
                            status: status_enum_1.PaymentStatus.FULLY_PAID,
                        },
                        include: {
                            order: {
                                select: { orderNo: true },
                            },
                        },
                        orderBy: {
                            createdAt: 'asc',
                        },
                    });
                    for (let i = 1; i < payments.length; i++) {
                        const timeDiff = Math.abs(payments[i].createdAt.getTime() -
                            payments[i - 1].createdAt.getTime());
                        const minutesDiff = timeDiff / (1000 * 60);
                        if (minutesDiff < 5) {
                            suspiciousPayments.push({
                                id: payments[i].id,
                                orderId: payments[i].order.orderNo,
                                amount: Number(payments[i].amount),
                                createdAt: payments[i].createdAt.toISOString(),
                                issue: 'duplicate',
                                severity: 'high',
                                description: `检测到重复支付，同一订单在${minutesDiff.toFixed(1)}分钟内有多次支付记录`,
                            });
                            break;
                        }
                    }
                }
            }
            this.logger.log(`检测到 ${suspiciousPayments.length} 条可疑支付记录`);
            return suspiciousPayments;
        }
        catch (error) {
            this.logger.error('检测可疑支付失败:', error);
            throw error;
        }
    }
    async getDailyReconciliation(date, platform) {
        this.logger.log(`获取每日对账数据: ${date}, ${platform}`);
        try {
            const targetDate = date ? new Date(date) : new Date();
            const startOfDay = new Date(targetDate);
            startOfDay.setHours(0, 0, 0, 0);
            const endOfDay = new Date(targetDate);
            endOfDay.setHours(23, 59, 59, 999);
            const payments = await this.prisma.payment.findMany({
                where: {
                    createdAt: {
                        gte: startOfDay,
                        lte: endOfDay,
                    },
                    status: status_enum_1.PaymentStatus.FULLY_PAID,
                },
                include: {
                    order: {
                        select: {
                            orderNo: true,
                            totalAmount: true,
                        },
                    },
                },
            });
            const paymentTypeMap = {};
            payments.forEach((payment) => {
                const type = this.getPaymentTypeName(payment.paymentType);
                if (!paymentTypeMap[type]) {
                    paymentTypeMap[type] = { count: 0, amount: 0 };
                }
                paymentTypeMap[type].count++;
                paymentTypeMap[type].amount += Number(payment.amount);
            });
            const details = Object.entries(paymentTypeMap).map(([type, data]) => ({
                platform: type,
                orderCount: data.count,
                systemAmount: data.amount,
                platformAmount: data.amount,
                difference: 0,
                status: 'matched',
            }));
            const totalOrders = payments.length;
            const systemAmount = payments.reduce((sum, p) => sum + Number(p.amount), 0);
            const platformAmount = systemAmount;
            const difference = platformAmount - systemAmount;
            return {
                date: (0, date_util_1.formatLocalDate)(targetDate),
                platform: platform || 'ALL',
                summary: {
                    totalOrders,
                    systemAmount,
                    platformAmount,
                    difference,
                    matched: Math.abs(difference) < 0.01,
                },
                details,
            };
        }
        catch (error) {
            this.logger.error('获取每日对账数据失败:', error);
            throw error;
        }
    }
    getPaymentTypeName(paymentType) {
        const typeMap = {
            WECHAT: '微信支付',
            ALIPAY: '支付宝',
            CASH: '现金',
            BANK_TRANSFER: '银行转账',
            CARD: '刷卡',
            OTHER: '其他',
        };
        return typeMap[paymentType] || paymentType;
    }
    async getReconciliationRange(startDate, endDate, platform) {
        this.logger.log(`获取日期范围对账数据: ${startDate} - ${endDate}, ${platform}`);
        try {
            const end = endDate ? new Date(endDate) : new Date();
            const start = startDate
                ? new Date(startDate)
                : new Date(end.getTime() - 30 * 24 * 60 * 60 * 1000);
            const startOfDay = new Date(start);
            startOfDay.setHours(0, 0, 0, 0);
            const endOfDay = new Date(end);
            endOfDay.setHours(23, 59, 59, 999);
            const reconciliationData = [];
            const currentDate = new Date(startOfDay);
            while (currentDate <= endOfDay) {
                const dayStart = new Date(currentDate);
                dayStart.setHours(0, 0, 0, 0);
                const dayEnd = new Date(currentDate);
                dayEnd.setHours(23, 59, 59, 999);
                const whereCondition = {
                    createdAt: {
                        gte: dayStart,
                        lte: dayEnd,
                    },
                    status: { equals: 'FULLY_PAID' },
                };
                if (platform && platform !== 'ALL') {
                    const platformMap = {
                        微信支付: 'WECHAT',
                        支付宝: 'ALIPAY',
                        现金: 'CASH',
                        银行转账: 'BANK_TRANSFER',
                    };
                    const paymentType = platformMap[platform];
                    if (paymentType) {
                        whereCondition.paymentType = paymentType;
                    }
                }
                const payments = await this.prisma.payment.findMany({
                    where: whereCondition,
                });
                const paymentTypeStats = {};
                payments.forEach((payment) => {
                    const type = this.getPaymentTypeName(payment.paymentType);
                    if (!paymentTypeStats[type]) {
                        paymentTypeStats[type] = { count: 0, amount: 0 };
                    }
                    paymentTypeStats[type].count++;
                    paymentTypeStats[type].amount += Number(payment.amount);
                });
                const totalAmount = payments.reduce((sum, p) => sum + Number(p.amount), 0);
                const dateStr = (0, date_util_1.formatLocalDate)(currentDate);
                const id = `${dateStr}-${platform || 'ALL'}`;
                if (Object.keys(paymentTypeStats).length > 0) {
                    Object.entries(paymentTypeStats).forEach(([type, stats]) => {
                        reconciliationData.push({
                            id: `${id}-${type}`,
                            date: dateStr,
                            platform: type,
                            orderCount: stats.count,
                            totalAmount: stats.amount,
                            platformAmount: stats.amount,
                            difference: 0,
                            status: 'matched',
                        });
                    });
                }
                else if (platform === 'ALL' || !platform) {
                    reconciliationData.push({
                        id,
                        date: dateStr,
                        platform: '全部',
                        orderCount: 0,
                        totalAmount: 0,
                        platformAmount: 0,
                        difference: 0,
                        status: 'matched',
                    });
                }
                currentDate.setDate(currentDate.getDate() + 1);
            }
            return reconciliationData;
        }
        catch (error) {
            this.logger.error('获取日期范围对账数据失败:', error);
            throw error;
        }
    }
    async getMissingVouchers(startDate, endDate) {
        this.logger.log(`检查缺失凭证: ${startDate} - ${endDate}`);
        try {
            return {
                summary: {
                    totalPayments: 156,
                    missingVouchers: 3,
                    missingRate: 1.9,
                },
                missingList: [
                    {
                        paymentId: 'pay_001',
                        orderId: 'ORD202509151001',
                        amount: 888,
                        platform: '微信支付',
                        paymentTime: '2025-09-15T10:30:00Z',
                        reason: '第三方交易号缺失',
                    },
                    {
                        paymentId: 'pay_002',
                        orderId: 'ORD202509151002',
                        amount: 1200,
                        platform: '支付宝',
                        paymentTime: '2025-09-15T11:15:00Z',
                        reason: '支付凭证文件缺失',
                    },
                ],
            };
        }
        catch (error) {
            this.logger.error('检查缺失凭证失败:', error);
            throw error;
        }
    }
    async getDashboardStats() {
        this.logger.log('获取仪表板统计数据');
        try {
            const today = new Date();
            const todayStart = new Date(today.setHours(0, 0, 0, 0));
            const todayEnd = new Date(today.setHours(23, 59, 59, 999));
            const thisMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);
            const thisMonthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59, 999);
            const lastMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            const lastMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0, 23, 59, 59, 999);
            const todayOrders = await this.prisma.order.count({
                where: {
                    createdAt: { gte: todayStart, lte: todayEnd },
                },
            });
            const todayRevenue = await this.prisma.order.aggregate({
                where: {
                    createdAt: { gte: todayStart, lte: todayEnd },
                },
                _sum: {
                    paidAmount: true,
                },
            });
            const todayRefunds = await this.prisma.refundRequest.count({
                where: {
                    createdAt: { gte: todayStart, lte: todayEnd },
                    status: { in: ['APPROVED', 'COMPLETED'] },
                },
            });
            const thisMonthOrders = await this.prisma.order.count({
                where: {
                    createdAt: { gte: thisMonthStart, lte: thisMonthEnd },
                },
            });
            const thisMonthRevenue = await this.prisma.order.aggregate({
                where: {
                    createdAt: { gte: thisMonthStart, lte: thisMonthEnd },
                },
                _sum: {
                    paidAmount: true,
                },
            });
            const thisMonthRefunds = await this.prisma.refundRequest.count({
                where: {
                    createdAt: { gte: thisMonthStart, lte: thisMonthEnd },
                    status: { in: ['APPROVED', 'COMPLETED'] },
                },
            });
            const lastMonthOrders = await this.prisma.order.count({
                where: {
                    createdAt: { gte: lastMonthStart, lte: lastMonthEnd },
                },
            });
            const lastMonthRevenue = await this.prisma.order.aggregate({
                where: {
                    createdAt: { gte: lastMonthStart, lte: lastMonthEnd },
                },
                _sum: {
                    paidAmount: true,
                },
            });
            const lastMonthRefunds = await this.prisma.refundRequest.count({
                where: {
                    createdAt: { gte: lastMonthStart, lte: lastMonthEnd },
                    status: { in: ['APPROVED', 'COMPLETED'] },
                },
            });
            const suspiciousPayments = await this.getSuspiciousPayments('all');
            const alerts = [];
            if (suspiciousPayments.length > 0) {
                alerts.push({
                    type: 'warning',
                    message: `检测到${suspiciousPayments.length}笔可疑支付，建议及时处理`,
                    count: suspiciousPayments.length,
                });
            }
            else {
                alerts.push({
                    type: 'info',
                    message: '今日对账完成，所有数据匹配正常',
                    count: 1,
                });
            }
            const recentRefunds = await this.prisma.refundRequest.findMany({
                where: {
                    status: { in: ['APPROVED', 'COMPLETED'] },
                },
                select: {
                    id: true,
                    orderNo: true,
                    refundAmount: true,
                    updatedAt: true,
                },
                orderBy: {
                    updatedAt: 'desc',
                },
                take: 5,
            });
            const recentActivity = [];
            recentRefunds.forEach((refund) => {
                recentActivity.push({
                    time: refund.updatedAt.toISOString(),
                    action: '完成退款处理',
                    target: `订单 ${refund.orderNo}`,
                    amount: Number(refund.refundAmount),
                });
            });
            suspiciousPayments.slice(0, 5).forEach((payment) => {
                recentActivity.push({
                    time: payment.createdAt,
                    action: '检测到可疑支付',
                    target: `支付 ${payment.id}`,
                    amount: payment.amount,
                });
            });
            recentActivity.sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());
            return {
                today: {
                    orders: todayOrders,
                    revenue: Number(todayRevenue._sum?.paidAmount || 0),
                    refunds: todayRefunds,
                    suspiciousPayments: suspiciousPayments.length,
                },
                thisMonth: {
                    orders: thisMonthOrders,
                    revenue: Number(thisMonthRevenue._sum?.paidAmount || 0),
                    refunds: thisMonthRefunds,
                    suspiciousPayments: suspiciousPayments.length,
                },
                lastMonth: {
                    orders: lastMonthOrders,
                    revenue: Number(lastMonthRevenue._sum?.paidAmount || 0),
                    refunds: lastMonthRefunds,
                    suspiciousPayments: 0,
                },
                alerts,
                recentActivity: recentActivity.slice(0, 10),
            };
        }
        catch (error) {
            this.logger.error('获取仪表板数据失败:', error);
            throw error;
        }
    }
    async getComprehensiveTrends(startDate, endDate) {
        this.logger.log(`获取综合趋势数据: ${startDate} - ${endDate}`);
        try {
            const end = endDate ? new Date(endDate) : new Date();
            const start = startDate ? new Date(startDate) : new Date(end.getTime() - 30 * 24 * 60 * 60 * 1000);
            const startOfDay = new Date(start);
            startOfDay.setHours(0, 0, 0, 0);
            const endOfDay = new Date(end);
            endOfDay.setHours(23, 59, 59, 999);
            const data = [];
            const current = new Date(startOfDay);
            while (current <= endOfDay) {
                const dayStart = new Date(current);
                dayStart.setHours(0, 0, 0, 0);
                const dayEnd = new Date(current);
                dayEnd.setHours(23, 59, 59, 999);
                const [dayOrders, dayRevenue, dayPaidAmount] = await Promise.all([
                    this.prisma.order.aggregate({
                        where: { createdAt: { gte: dayStart, lte: dayEnd } },
                        _count: { id: true },
                    }),
                    this.prisma.order.aggregate({
                        where: {
                            createdAt: { gte: dayStart, lte: dayEnd },
                            orderStatus: { not: 'CANCELLED' },
                        },
                        _sum: { totalAmount: true },
                    }),
                    this.prisma.order.aggregate({
                        where: {
                            createdAt: { gte: dayStart, lte: dayEnd },
                            paymentStatus: 'FULLY_PAID',
                        },
                        _sum: { paidAmount: true },
                    }),
                ]);
                const orderCount = dayOrders._count.id;
                const revenue = Number(dayRevenue._sum?.totalAmount || 0);
                const paidAmount = Number(dayPaidAmount._sum?.paidAmount || 0);
                const paidOrders = await this.prisma.order.count({
                    where: {
                        createdAt: { gte: dayStart, lte: dayEnd },
                        paymentStatus: { in: ['FULLY_PAID', 'PARTIAL_PAID'] },
                    },
                });
                const dayRefunds = await this.prisma.refundRequest.aggregate({
                    where: {
                        createdAt: { gte: dayStart, lte: dayEnd },
                        status: { in: ['APPROVED', 'COMPLETED'] },
                    },
                    _sum: { refundAmount: true },
                });
                const refundAmount = Number(dayRefunds._sum?.refundAmount || 0);
                const y = current.getFullYear();
                const m = String(current.getMonth() + 1).padStart(2, '0');
                const d = String(current.getDate()).padStart(2, '0');
                data.push({
                    date: `${y}-${m}-${d}`,
                    revenue,
                    orderCount,
                    paidAmount,
                    refundAmount,
                    avgOrderValue: orderCount > 0 ? Math.round(revenue / orderCount) : 0,
                    conversionRate: orderCount > 0 ? Math.round(paidOrders / orderCount * 100) : 0,
                });
                current.setDate(current.getDate() + 1);
            }
            return data;
        }
        catch (error) {
            this.logger.error('获取综合趋势数据失败:', error);
            throw error;
        }
    }
    async getRevenuePrediction(period) {
        this.logger.log(`获取收入预测: ${period}`);
        try {
            const predictions = [];
            const daysToPredict = period === 'week' ? 7 : period === 'month' ? 30 : 90;
            for (let i = 1; i <= daysToPredict; i++) {
                const date = new Date();
                date.setDate(date.getDate() + i);
                predictions.push({
                    date: (0, date_util_1.formatLocalDate)(date),
                    predictedRevenue: Math.floor(Math.random() * 5000) + 2000,
                    confidence: Math.floor(Math.random() * 30) + 70,
                });
            }
            return {
                period,
                predictions,
                totalPredicted: predictions.reduce((sum, p) => sum + p.predictedRevenue, 0),
                avgConfidence: predictions.reduce((sum, p) => sum + p.confidence, 0) / predictions.length,
            };
        }
        catch (error) {
            this.logger.error('获取收入预测失败:', error);
            throw error;
        }
    }
    async getComparativeAnalysis(current, previous, period) {
        this.logger.log(`获取对比分析: ${current} vs ${previous}, ${period}天`);
        try {
            const currentStart = new Date(current);
            currentStart.setHours(0, 0, 0, 0);
            const currentEnd = new Date(currentStart);
            currentEnd.setDate(currentEnd.getDate() + period);
            currentEnd.setHours(23, 59, 59, 999);
            const previousStart = new Date(previous);
            previousStart.setHours(0, 0, 0, 0);
            const previousEnd = new Date(previousStart);
            previousEnd.setDate(previousEnd.getDate() + period);
            previousEnd.setHours(23, 59, 59, 999);
            const fetchStats = async (start, end) => {
                const [orderAgg, refundAgg] = await Promise.all([
                    this.prisma.order.aggregate({
                        where: { createdAt: { gte: start, lte: end } },
                        _count: { id: true },
                        _sum: { paidAmount: true, totalAmount: true },
                    }),
                    this.prisma.refundRequest.aggregate({
                        where: { createdAt: { gte: start, lte: end }, status: { in: ['APPROVED', 'COMPLETED'] } },
                        _count: { id: true },
                        _sum: { refundAmount: true },
                    }),
                ]);
                const orders = orderAgg._count.id;
                const revenue = Number(orderAgg._sum.paidAmount || 0);
                const totalAmount = Number(orderAgg._sum.totalAmount || 0);
                const refunds = refundAgg._count.id;
                const refundAmount = Number(refundAgg._sum.refundAmount || 0);
                return {
                    orders,
                    revenue,
                    avgOrderValue: orders > 0 ? Math.round(revenue / orders) : 0,
                    refunds,
                    refundRate: revenue > 0 ? Math.round(refundAmount / revenue * 1000) / 10 : 0,
                };
            };
            const currentData = await fetchStats(currentStart, currentEnd);
            const previousData = await fetchStats(previousStart, previousEnd);
            return {
                current: currentData,
                previous: previousData,
                comparison: {
                    ordersGrowth: previousData.orders > 0
                        ? ((currentData.orders - previousData.orders) / previousData.orders * 100).toFixed(1)
                        : '0.0',
                    revenueGrowth: previousData.revenue > 0
                        ? ((currentData.revenue - previousData.revenue) / previousData.revenue * 100).toFixed(1)
                        : '0.0',
                    avgOrderValueGrowth: previousData.avgOrderValue > 0
                        ? ((currentData.avgOrderValue - previousData.avgOrderValue) / previousData.avgOrderValue * 100).toFixed(1)
                        : '0.0',
                    refundRateChange: (currentData.refundRate - previousData.refundRate).toFixed(1),
                },
            };
        }
        catch (error) {
            this.logger.error('获取对比分析失败:', error);
            throw error;
        }
    }
};
exports.StatisticsAnalysisService = StatisticsAnalysisService;
exports.StatisticsAnalysisService = StatisticsAnalysisService = StatisticsAnalysisService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], StatisticsAnalysisService);
//# sourceMappingURL=statistics-analysis.service.js.map