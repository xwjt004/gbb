import { PrismaService } from '../../shared/prisma/prisma.service';
import { ComprehensiveTrendData } from './dto/statistics-analysis.dto';
interface TrendData {
    date: string;
    orderCount: number;
    revenue: number;
    refundAmount: number;
    paidAmount: number;
}
interface RevenueAnalysis {
    dimension: string;
    total: number;
    breakdown: Array<{
        category: string;
        amount: number;
        percentage: number;
        count: number;
    }>;
}
interface SuspiciousPayment {
    id: string;
    orderId: string;
    amount: number;
    createdAt: string;
    issue: 'duplicate' | 'overpayment' | 'system_error';
    severity: 'high' | 'medium' | 'low';
    description: string;
}
export declare class StatisticsAnalysisService {
    private prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getOrderTrend(period: 'daily' | 'weekly' | 'monthly' | 'yearly', startDate?: string, endDate?: string): Promise<TrendData[]>;
    getRevenueAnalysis(dimension: 'time' | 'package' | 'user' | 'channel', period?: string): Promise<RevenueAnalysis>;
    getRefundAnalysis(startDate?: string, endDate?: string): Promise<{
        summary: {
            totalRefunds: number;
            totalAmount: number;
            refundRate: number;
            avgRefundAmount: number;
        };
        byReason: {
            reason: string;
            count: number;
            amount: number;
            percentage: number;
        }[];
        trend: {
            date: string;
            count: number;
            amount: number;
        }[];
    }>;
    private getRefundTrend;
    getSuspiciousPayments(type: 'duplicate' | 'overpayment' | 'system_error' | 'all'): Promise<SuspiciousPayment[]>;
    getDailyReconciliation(date?: string, platform?: string): Promise<{
        date: string;
        platform: string;
        summary: {
            totalOrders: number;
            systemAmount: number;
            platformAmount: number;
            difference: number;
            matched: boolean;
        };
        details: {
            platform: string;
            orderCount: number;
            systemAmount: number;
            platformAmount: number;
            difference: number;
            status: string;
        }[];
    }>;
    private getPaymentTypeName;
    getReconciliationRange(startDate?: string, endDate?: string, platform?: string): Promise<{
        id: string;
        date: string;
        platform: string;
        orderCount: number;
        totalAmount: number;
        platformAmount: number;
        difference: number;
        status: string;
    }[]>;
    getMissingVouchers(startDate?: string, endDate?: string): Promise<{
        summary: {
            totalPayments: number;
            missingVouchers: number;
            missingRate: number;
        };
        missingList: {
            paymentId: string;
            orderId: string;
            amount: number;
            platform: string;
            paymentTime: string;
            reason: string;
        }[];
    }>;
    getDashboardStats(): Promise<{
        today: {
            orders: number;
            revenue: number;
            refunds: number;
            suspiciousPayments: number;
        };
        thisMonth: {
            orders: number;
            revenue: number;
            refunds: number;
            suspiciousPayments: number;
        };
        lastMonth: {
            orders: number;
            revenue: number;
            refunds: number;
            suspiciousPayments: number;
        };
        alerts: {
            type: "warning" | "info" | "error";
            message: string;
            count: number;
        }[];
        recentActivity: {
            time: string;
            action: string;
            target: string;
            amount: number;
        }[];
    }>;
    getComprehensiveTrends(startDate?: string, endDate?: string): Promise<ComprehensiveTrendData[]>;
    getRevenuePrediction(period: 'week' | 'month' | 'quarter'): Promise<{
        period: "week" | "month" | "quarter";
        predictions: {
            date: string;
            predictedRevenue: number;
            confidence: number;
        }[];
        totalPredicted: number;
        avgConfidence: number;
    }>;
    getComparativeAnalysis(current: string, previous: string, period: number): Promise<{
        current: {
            orders: number;
            revenue: number;
            avgOrderValue: number;
            refunds: number;
            refundRate: number;
        };
        previous: {
            orders: number;
            revenue: number;
            avgOrderValue: number;
            refunds: number;
            refundRate: number;
        };
        comparison: {
            ordersGrowth: string;
            revenueGrowth: string;
            avgOrderValueGrowth: string;
            refundRateChange: string;
        };
    }>;
}
export {};
