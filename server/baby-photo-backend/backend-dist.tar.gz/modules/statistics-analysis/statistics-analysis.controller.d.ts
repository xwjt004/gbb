import { StatisticsAnalysisService } from './statistics-analysis.service';
import { TrendData, RevenueAnalysis, SuspiciousPayment, RefundAnalysis, DailyReconciliation, MissingVouchers, DashboardStats, RevenuePrediction, ComparativeAnalysis, ComprehensiveTrendData } from './dto/statistics-analysis.dto';
export declare class StatisticsAnalysisController {
    private readonly statisticsAnalysisService;
    constructor(statisticsAnalysisService: StatisticsAnalysisService);
    getOrderTrend(period?: 'daily' | 'weekly' | 'monthly' | 'yearly', startDate?: string, endDate?: string): Promise<TrendData[]>;
    getRevenueAnalysis(dimension: 'time' | 'package' | 'user' | 'channel', period?: string): Promise<RevenueAnalysis>;
    getRefundAnalysis(startDate?: string, endDate?: string): Promise<RefundAnalysis>;
    getSuspiciousPayments(type?: 'duplicate' | 'overpayment' | 'system_error' | 'all'): Promise<SuspiciousPayment[]>;
    getDailyReconciliation(date?: string, platform?: string): Promise<DailyReconciliation>;
    getReconciliationRange(startDate?: string, endDate?: string, platform?: string): Promise<{
        id: string;
        date: string;
        platform: string;
        orderCount: number;
        totalAmount: number;
        platformAmount: number;
        difference: number;
        status: string;
    }[]>;
    getMissingVouchers(startDate?: string, endDate?: string): Promise<MissingVouchers>;
    getDashboardStats(): Promise<DashboardStats>;
    getRevenuePrediction(period?: 'week' | 'month' | 'quarter'): Promise<RevenuePrediction>;
    getComprehensiveTrends(startDate?: string, endDate?: string): Promise<ComprehensiveTrendData[]>;
    getComparativeAnalysis(current: string, previous: string, period: number): Promise<ComparativeAnalysis>;
}
