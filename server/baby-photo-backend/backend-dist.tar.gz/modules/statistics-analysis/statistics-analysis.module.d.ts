export declare class StatisticsAnalysisModule {
}
