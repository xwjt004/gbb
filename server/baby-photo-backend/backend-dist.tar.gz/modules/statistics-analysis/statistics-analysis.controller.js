"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatisticsAnalysisController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const statistics_analysis_service_1 = require("./statistics-analysis.service");
let StatisticsAnalysisController = class StatisticsAnalysisController {
    statisticsAnalysisService;
    constructor(statisticsAnalysisService) {
        this.statisticsAnalysisService = statisticsAnalysisService;
    }
    async getOrderTrend(period = 'daily', startDate, endDate) {
        return this.statisticsAnalysisService.getOrderTrend(period, startDate, endDate);
    }
    async getRevenueAnalysis(dimension, period) {
        return this.statisticsAnalysisService.getRevenueAnalysis(dimension, period);
    }
    async getRefundAnalysis(startDate, endDate) {
        return this.statisticsAnalysisService.getRefundAnalysis(startDate, endDate);
    }
    async getSuspiciousPayments(type = 'all') {
        return this.statisticsAnalysisService.getSuspiciousPayments(type);
    }
    async getDailyReconciliation(date, platform) {
        return this.statisticsAnalysisService.getDailyReconciliation(date, platform);
    }
    async getReconciliationRange(startDate, endDate, platform) {
        return this.statisticsAnalysisService.getReconciliationRange(startDate, endDate, platform);
    }
    async getMissingVouchers(startDate, endDate) {
        return this.statisticsAnalysisService.getMissingVouchers(startDate, endDate);
    }
    async getDashboardStats() {
        return this.statisticsAnalysisService.getDashboardStats();
    }
    async getRevenuePrediction(period = 'month') {
        return this.statisticsAnalysisService.getRevenuePrediction(period);
    }
    async getComprehensiveTrends(startDate, endDate) {
        return this.statisticsAnalysisService.getComprehensiveTrends(startDate, endDate);
    }
    async getComparativeAnalysis(current, previous, period) {
        return this.statisticsAnalysisService.getComparativeAnalysis(current, previous, period);
    }
};
exports.StatisticsAnalysisController = StatisticsAnalysisController;
__decorate([
    (0, common_1.Get)('orders/trend'),
    (0, swagger_1.ApiOperation)({ summary: '订单趋势分析' }),
    (0, swagger_1.ApiQuery)({ name: 'period', description: '时间周期', enum: ['daily', 'weekly', 'monthly', 'yearly'] }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', description: '开始日期', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', description: '结束日期', required: false }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '订单趋势数据' }),
    __param(0, (0, common_1.Query)('period')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getOrderTrend", null);
__decorate([
    (0, common_1.Get)('revenue/analysis'),
    (0, swagger_1.ApiOperation)({ summary: '收入分析' }),
    (0, swagger_1.ApiQuery)({ name: 'dimension', description: '分析维度', enum: ['time', 'package', 'user', 'channel'] }),
    (0, swagger_1.ApiQuery)({ name: 'period', description: '时间周期', required: false }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '收入分析数据' }),
    __param(0, (0, common_1.Query)('dimension')),
    __param(1, (0, common_1.Query)('period')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getRevenueAnalysis", null);
__decorate([
    (0, common_1.Get)('refunds/analysis'),
    (0, swagger_1.ApiOperation)({ summary: '退款分析' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', description: '开始日期', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', description: '结束日期', required: false }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '退款分析数据' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getRefundAnalysis", null);
__decorate([
    (0, common_1.Get)('payments/suspicious'),
    (0, swagger_1.ApiOperation)({ summary: '可疑支付检测' }),
    (0, swagger_1.ApiQuery)({ name: 'type', description: '检测类型', enum: ['duplicate', 'overpayment', 'system_error', 'all'] }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '可疑支付记录' }),
    __param(0, (0, common_1.Query)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getSuspiciousPayments", null);
__decorate([
    (0, common_1.Get)('reconciliation/daily'),
    (0, swagger_1.ApiOperation)({ summary: '每日对账数据' }),
    (0, swagger_1.ApiQuery)({ name: 'date', description: '对账日期', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'platform', description: '支付平台', required: false }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '每日对账数据' }),
    __param(0, (0, common_1.Query)('date')),
    __param(1, (0, common_1.Query)('platform')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getDailyReconciliation", null);
__decorate([
    (0, common_1.Get)('reconciliation/range'),
    (0, swagger_1.ApiOperation)({ summary: '日期范围对账数据' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', description: '开始日期', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', description: '结束日期', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'platform', description: '支付平台', required: false }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '日期范围对账数据' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('platform')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getReconciliationRange", null);
__decorate([
    (0, common_1.Get)('vouchers/missing'),
    (0, swagger_1.ApiOperation)({ summary: '缺失凭证检查' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', description: '开始日期', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', description: '结束日期', required: false }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '缺失凭证列表' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getMissingVouchers", null);
__decorate([
    (0, common_1.Get)('dashboard/stats'),
    (0, swagger_1.ApiOperation)({ summary: '仪表板统计数据' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '仪表板数据' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getDashboardStats", null);
__decorate([
    (0, common_1.Get)('predictions/revenue'),
    (0, swagger_1.ApiOperation)({ summary: '收入预测分析' }),
    (0, swagger_1.ApiQuery)({ name: 'period', description: '预测周期', enum: ['week', 'month', 'quarter'] }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '收入预测数据' }),
    __param(0, (0, common_1.Query)('period')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getRevenuePrediction", null);
__decorate([
    (0, common_1.Get)('trends/comprehensive'),
    (0, swagger_1.ApiOperation)({ summary: '综合趋势数据（营收/订单量/客单价/转化率）' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', description: '开始日期', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', description: '结束日期', required: false }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '综合趋势数据' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getComprehensiveTrends", null);
__decorate([
    (0, common_1.Get)('comparative/analysis'),
    (0, swagger_1.ApiOperation)({ summary: '对比分析' }),
    (0, swagger_1.ApiQuery)({ name: 'current', description: '当前周期开始日期' }),
    (0, swagger_1.ApiQuery)({ name: 'previous', description: '对比周期开始日期' }),
    (0, swagger_1.ApiQuery)({ name: 'period', description: '周期长度(天)' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '对比分析数据' }),
    __param(0, (0, common_1.Query)('current')),
    __param(1, (0, common_1.Query)('previous')),
    __param(2, (0, common_1.Query)('period')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Number]),
    __metadata("design:returntype", Promise)
], StatisticsAnalysisController.prototype, "getComparativeAnalysis", null);
exports.StatisticsAnalysisController = StatisticsAnalysisController = __decorate([
    (0, swagger_1.ApiTags)('统计分析'),
    (0, common_1.Controller)('statistics-analysis'),
    __metadata("design:paramtypes", [statistics_analysis_service_1.StatisticsAnalysisService])
], StatisticsAnalysisController);
//# sourceMappingURL=statistics-analysis.controller.js.map