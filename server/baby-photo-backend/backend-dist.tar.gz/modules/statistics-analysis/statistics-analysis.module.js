"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatisticsAnalysisModule = void 0;
const common_1 = require("@nestjs/common");
const statistics_analysis_controller_1 = require("./statistics-analysis.controller");
const statistics_analysis_service_1 = require("./statistics-analysis.service");
const prisma_module_1 = require("../../shared/prisma/prisma.module");
let StatisticsAnalysisModule = class StatisticsAnalysisModule {
};
exports.StatisticsAnalysisModule = StatisticsAnalysisModule;
exports.StatisticsAnalysisModule = StatisticsAnalysisModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule],
        controllers: [statistics_analysis_controller_1.StatisticsAnalysisController],
        providers: [statistics_analysis_service_1.StatisticsAnalysisService],
        exports: [statistics_analysis_service_1.StatisticsAnalysisService],
    })
], StatisticsAnalysisModule);
//# sourceMappingURL=statistics-analysis.module.js.map