"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockOutboundService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const library_1 = require("@prisma/client/runtime/library");
let StockOutboundService = class StockOutboundService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async generateOutboundNo() {
        const today = new Date();
        const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
        const count = await this.prisma.stockOutbound.count({
            where: {
                createdAt: {
                    gte: new Date(today.setHours(0, 0, 0, 0)),
                    lt: new Date(today.setHours(23, 59, 59, 999))
                }
            }
        });
        const sequence = String(count + 1).padStart(4, '0');
        return `OUT-${dateStr}-${sequence}`;
    }
    async generateTransactionNo() {
        const today = new Date();
        const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
        const count = await this.prisma.stockTransaction.count({
            where: {
                createdAt: {
                    gte: new Date(today.setHours(0, 0, 0, 0)),
                    lt: new Date(today.setHours(23, 59, 59, 999))
                }
            }
        });
        const sequence = String(count + 1).padStart(6, '0');
        return `TXN-${dateStr}-${sequence}`;
    }
    async create(userId, createOutboundDto) {
        const dto = createOutboundDto;
        let validUserId = userId;
        if (userId) {
            const user = await this.prisma.user.findUnique({ where: { id: userId } });
            if (!user) {
                const tempUser = await this.prisma.user.create({
                    data: {
                        openid: 'admin_temp_' + Date.now(),
                        nickname: '系统管理员',
                        phone: '13800138000',
                        status: 'ACTIVE'
                    }
                });
                validUserId = tempUser.id;
            }
        }
        const validTypes = ['ORDER', 'DAMAGE', 'TRANSFER', 'OTHER'];
        if (!validTypes.includes(dto.outboundType)) {
            throw new common_1.BadRequestException('无效的出库类型');
        }
        if (dto.outboundType === 'ORDER' && dto.orderId) {
            const order = await this.prisma.order.findUnique({
                where: { id: dto.orderId }
            });
            if (!order) {
                throw new common_1.NotFoundException('订单不存在');
            }
        }
        let totalQuantity = 0;
        let totalAmount = new library_1.Decimal(0);
        const itemsData = [];
        for (const item of dto.items) {
            const product = await this.prisma.product.findUnique({
                where: { id: item.productId }
            });
            if (!product) {
                throw new common_1.NotFoundException(`商品ID ${item.productId} 不存在`);
            }
            if (!product.isActive) {
                throw new common_1.BadRequestException(`商品 ${product.name} 已停用`);
            }
            const unitPrice = product.costPrice;
            const amount = new library_1.Decimal(unitPrice).mul(item.quantity);
            totalQuantity += item.quantity;
            totalAmount = totalAmount.add(amount);
            itemsData.push({
                productId: item.productId,
                quantity: item.quantity,
                unitPrice,
                amount,
                remark: item.remark
            });
        }
        const outboundNo = await this.generateOutboundNo();
        const outbound = await this.prisma.stockOutbound.create({
            data: {
                outboundNo,
                outboundType: dto.outboundType,
                outboundDate: new Date(dto.outboundDate),
                status: 'PENDING',
                totalQuantity,
                totalAmount,
                remark: dto.remark,
                submitterId: validUserId,
                orderId: dto.orderId,
                items: {
                    create: itemsData
                }
            },
            include: {
                items: {
                    include: {
                        product: true
                    }
                },
                submitter: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                order: true
            }
        });
        return {
            code: 200,
            message: '创建出库单成功',
            data: outbound
        };
    }
    async findAll(query) {
        const { page = 1, pageSize = 20, status, outboundType, startDate, endDate, keyword } = query;
        const skip = (page - 1) * pageSize;
        const where = {};
        if (status) {
            where.status = status;
        }
        if (outboundType) {
            where.outboundType = outboundType;
        }
        if (startDate || endDate) {
            where.outboundDate = {};
            if (startDate) {
                where.outboundDate.gte = new Date(startDate);
            }
            if (endDate) {
                where.outboundDate.lte = new Date(endDate);
            }
        }
        if (keyword) {
            where.OR = [
                { outboundNo: { contains: keyword } },
                { remark: { contains: keyword } }
            ];
        }
        const [total, items] = await Promise.all([
            this.prisma.stockOutbound.count({ where }),
            this.prisma.stockOutbound.findMany({
                where,
                skip,
                take: pageSize,
                include: {
                    items: {
                        include: {
                            product: true
                        }
                    },
                    submitter: {
                        select: {
                            id: true,
                            nickname: true
                        }
                    },
                    approver: {
                        select: {
                            id: true,
                            nickname: true
                        }
                    },
                    order: true
                },
                orderBy: {
                    createdAt: 'desc'
                }
            })
        ]);
        return {
            code: 200,
            message: '查询成功',
            data: {
                items,
                total,
                page,
                pageSize,
                totalPages: Math.ceil(total / pageSize)
            }
        };
    }
    async findOne(id) {
        const outbound = await this.prisma.stockOutbound.findUnique({
            where: { id },
            include: {
                items: {
                    include: {
                        product: true
                    }
                },
                submitter: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                approver: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                order: true,
                transactions: true
            }
        });
        if (!outbound) {
            throw new common_1.NotFoundException('出库单不存在');
        }
        return {
            code: 200,
            message: '查询成功',
            data: outbound
        };
    }
    async update(id, updateOutboundDto) {
        const dto = updateOutboundDto;
        const existingOutbound = await this.prisma.stockOutbound.findUnique({
            where: { id },
            include: {
                items: true
            }
        });
        if (!existingOutbound) {
            throw new common_1.NotFoundException('出库单不存在');
        }
        if (existingOutbound.status !== 'PENDING') {
            throw new common_1.BadRequestException('只有待审批状态的出库单可以修改');
        }
        let totalQuantity = existingOutbound.totalQuantity;
        let totalAmount = existingOutbound.totalAmount;
        const itemsData = [];
        if (dto.items && dto.items.length > 0) {
            totalQuantity = 0;
            totalAmount = new library_1.Decimal(0);
            for (const item of dto.items) {
                const product = await this.prisma.product.findUnique({
                    where: { id: item.productId }
                });
                if (!product) {
                    throw new common_1.NotFoundException(`商品ID ${item.productId} 不存在`);
                }
                if (!product.isActive) {
                    throw new common_1.BadRequestException(`商品 ${product.name} 已停用`);
                }
                const unitPrice = product.costPrice;
                const amount = new library_1.Decimal(unitPrice).mul(item.quantity);
                totalQuantity += item.quantity;
                totalAmount = totalAmount.add(amount);
                itemsData.push({
                    productId: item.productId,
                    quantity: item.quantity,
                    unitPrice,
                    amount,
                    remark: item.remark
                });
            }
            const outbound = await this.prisma.$transaction(async (tx) => {
                await tx.stockOutboundItem.deleteMany({
                    where: { outboundId: id }
                });
                return await tx.stockOutbound.update({
                    where: { id },
                    data: {
                        outboundType: dto.outboundType,
                        outboundDate: dto.outboundDate ? new Date(dto.outboundDate) : undefined,
                        totalQuantity,
                        totalAmount,
                        remark: dto.remark,
                        orderId: dto.orderId,
                        items: {
                            create: itemsData
                        }
                    },
                    include: {
                        items: {
                            include: {
                                product: true
                            }
                        },
                        submitter: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        }
                    }
                });
            });
            return {
                code: 200,
                message: '更新出库单成功',
                data: outbound
            };
        }
        else {
            const outbound = await this.prisma.stockOutbound.update({
                where: { id },
                data: {
                    outboundType: dto.outboundType,
                    outboundDate: dto.outboundDate ? new Date(dto.outboundDate) : undefined,
                    remark: dto.remark,
                    orderId: dto.orderId
                },
                include: {
                    items: {
                        include: {
                            product: true
                        }
                    },
                    submitter: {
                        select: {
                            id: true,
                            nickname: true
                        }
                    }
                }
            });
            return {
                code: 200,
                message: '更新出库单成功',
                data: outbound
            };
        }
    }
    async remove(id) {
        const outbound = await this.prisma.stockOutbound.findUnique({
            where: { id }
        });
        if (!outbound) {
            throw new common_1.NotFoundException('出库单不存在');
        }
        if (outbound.status !== 'PENDING') {
            throw new common_1.BadRequestException('只有待审批状态的出库单可以删除');
        }
        await this.prisma.stockOutbound.delete({
            where: { id }
        });
        return {
            code: 200,
            message: '删除出库单成功'
        };
    }
    async approve(id, userId, approved, note) {
        let validUserId = userId;
        if (userId) {
            const user = await this.prisma.user.findUnique({ where: { id: userId } });
            if (!user) {
                const tempUser = await this.prisma.user.create({
                    data: {
                        openid: 'admin_temp_' + Date.now(),
                        nickname: '系统管理员',
                        phone: '13800138000',
                        status: 'ACTIVE'
                    }
                });
                validUserId = tempUser.id;
            }
        }
        return await this.prisma.$transaction(async (tx) => {
            const outbound = await tx.stockOutbound.findUnique({
                where: { id },
                include: {
                    items: {
                        include: {
                            product: true
                        }
                    }
                }
            });
            if (!outbound) {
                throw new common_1.NotFoundException('出库单不存在');
            }
            if (outbound.status !== 'PENDING') {
                throw new common_1.BadRequestException('出库单已审批，不能重复审批');
            }
            if (approved) {
                for (const item of outbound.items) {
                    if (!item.product.isTrackStock) {
                        continue;
                    }
                    if (item.product.stockQuantity < item.quantity) {
                        throw new common_1.BadRequestException(`商品 ${item.product.name} 库存不足，当前库存：${item.product.stockQuantity}，需要：${item.quantity}`);
                    }
                    await tx.product.update({
                        where: { id: item.productId },
                        data: {
                            stockQuantity: {
                                decrement: item.quantity
                            }
                        }
                    });
                    const transactionNo = await this.generateTransactionNo();
                    await tx.stockTransaction.create({
                        data: {
                            transactionNo,
                            transactionType: 'OUTBOUND',
                            productId: item.productId,
                            quantity: -item.quantity,
                            beforeStock: item.product.stockQuantity,
                            afterStock: item.product.stockQuantity - item.quantity,
                            refType: 'OUTBOUND',
                            refId: outbound.id,
                            outboundId: outbound.id,
                            remark: `出库单：${outbound.outboundNo} - ${item.remark || ''}`,
                            operatorId: validUserId
                        }
                    });
                }
                return await tx.stockOutbound.update({
                    where: { id },
                    data: {
                        status: 'APPROVED',
                        approverId: validUserId,
                        approvedAt: new Date(),
                        approvalNote: note
                    },
                    include: {
                        items: {
                            include: {
                                product: true
                            }
                        },
                        submitter: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        },
                        approver: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        }
                    }
                });
            }
            else {
                return await tx.stockOutbound.update({
                    where: { id },
                    data: {
                        status: 'REJECTED',
                        approverId: validUserId,
                        approvedAt: new Date(),
                        approvalNote: note
                    },
                    include: {
                        items: {
                            include: {
                                product: true
                            }
                        },
                        submitter: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        },
                        approver: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        }
                    }
                });
            }
        });
    }
    async statistics(startDate, endDate, groupBy) {
        const where = {};
        if (startDate || endDate) {
            where.outboundDate = {};
            if (startDate) {
                where.outboundDate.gte = new Date(startDate);
            }
            if (endDate) {
                where.outboundDate.lte = new Date(endDate);
            }
        }
        where.status = 'APPROVED';
        const aggregation = await this.prisma.stockOutbound.aggregate({
            where,
            _sum: {
                totalQuantity: true,
                totalAmount: true
            },
            _count: {
                id: true
            }
        });
        const result = {
            totalCount: aggregation._count?.id || 0,
            totalQuantity: aggregation._sum?.totalQuantity || 0,
            totalAmount: aggregation._sum?.totalAmount || 0,
            groups: []
        };
        if (groupBy === 'type') {
            const byType = await Promise.all(['ORDER', 'DAMAGE', 'TRANSFER', 'OTHER'].map(async (type) => {
                const agg = await this.prisma.stockOutbound.aggregate({
                    where: {
                        ...where,
                        outboundType: type
                    },
                    _sum: {
                        totalQuantity: true,
                        totalAmount: true
                    },
                    _count: {
                        id: true
                    }
                });
                return {
                    type,
                    count: agg._count?.id || 0,
                    quantity: agg._sum?.totalQuantity || 0,
                    amount: agg._sum?.totalAmount || 0
                };
            }));
            result.groups = byType;
        }
        return {
            code: 200,
            message: '统计成功',
            data: result
        };
    }
};
exports.StockOutboundService = StockOutboundService;
exports.StockOutboundService = StockOutboundService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], StockOutboundService);
//# sourceMappingURL=stock-outbound.service.js.map