export declare class ApproveOutboundDto {
    approved: boolean;
    note?: string;
}
