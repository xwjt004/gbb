export declare class CreateOutboundItemDto {
    productId: number;
    quantity: number;
    remark?: string;
}
export declare class CreateOutboundDto {
    outboundType: string;
    outboundDate: string;
    orderId?: string;
    items: CreateOutboundItemDto[];
    remark?: string;
}
