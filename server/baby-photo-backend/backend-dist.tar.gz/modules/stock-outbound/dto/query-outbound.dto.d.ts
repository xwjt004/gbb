export declare class QueryOutboundDto {
    page?: number;
    pageSize?: number;
    status?: string;
    outboundType?: string;
    startDate?: string;
    endDate?: string;
    keyword?: string;
}
