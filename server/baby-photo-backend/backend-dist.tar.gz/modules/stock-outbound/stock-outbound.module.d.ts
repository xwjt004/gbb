export declare class StockOutboundModule {
}
