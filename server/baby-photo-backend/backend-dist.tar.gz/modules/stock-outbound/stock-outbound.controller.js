"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockOutboundController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const stock_outbound_service_1 = require("./stock-outbound.service");
const create_outbound_dto_1 = require("./dto/create-outbound.dto");
const update_outbound_dto_1 = require("./dto/update-outbound.dto");
const approve_outbound_dto_1 = require("./dto/approve-outbound.dto");
const query_outbound_dto_1 = require("./dto/query-outbound.dto");
let StockOutboundController = class StockOutboundController {
    stockOutboundService;
    constructor(stockOutboundService) {
        this.stockOutboundService = stockOutboundService;
    }
    create(createOutboundDto) {
        const userId = 1;
        return this.stockOutboundService.create(userId, createOutboundDto);
    }
    findAll(query) {
        return this.stockOutboundService.findAll(query);
    }
    statistics(startDate, endDate, groupBy) {
        return this.stockOutboundService.statistics(startDate, endDate, groupBy);
    }
    findOne(id) {
        return this.stockOutboundService.findOne(id);
    }
    update(id, updateOutboundDto) {
        return this.stockOutboundService.update(id, updateOutboundDto);
    }
    remove(id) {
        return this.stockOutboundService.remove(id);
    }
    approve(id, approveDto) {
        const userId = 1;
        return this.stockOutboundService.approve(id, userId, approveDto.approved, approveDto.note);
    }
};
exports.StockOutboundController = StockOutboundController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建出库单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '参数错误' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_outbound_dto_1.CreateOutboundDto]),
    __metadata("design:returntype", void 0)
], StockOutboundController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '查询出库单列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_outbound_dto_1.QueryOutboundDto]),
    __metadata("design:returntype", void 0)
], StockOutboundController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('statistics'),
    (0, swagger_1.ApiOperation)({ summary: '出库统计' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '统计成功' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('groupBy')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], StockOutboundController.prototype, "statistics", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '查询出库单详情' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '出库单不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], StockOutboundController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新出库单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '出库单不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '只能修改待审批状态的出库单' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_outbound_dto_1.UpdateOutboundDto]),
    __metadata("design:returntype", void 0)
], StockOutboundController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除出库单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '删除成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '出库单不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '只能删除待审批状态的出库单' }),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], StockOutboundController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)(':id/approve'),
    (0, swagger_1.ApiOperation)({ summary: '审批出库单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '审批成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '出库单不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '该出库单已审批或库存不足' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, approve_outbound_dto_1.ApproveOutboundDto]),
    __metadata("design:returntype", void 0)
], StockOutboundController.prototype, "approve", null);
exports.StockOutboundController = StockOutboundController = __decorate([
    (0, swagger_1.ApiTags)('库存管理 - 出库管理'),
    (0, common_1.Controller)('stock-outbound'),
    __metadata("design:paramtypes", [stock_outbound_service_1.StockOutboundService])
], StockOutboundController);
//# sourceMappingURL=stock-outbound.controller.js.map