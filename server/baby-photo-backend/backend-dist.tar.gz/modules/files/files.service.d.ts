export declare class FilesService {
    getFilePath(filename: string): string;
    getPublicUrl(filename: string): string;
}
