export declare class FilesModule {
}
