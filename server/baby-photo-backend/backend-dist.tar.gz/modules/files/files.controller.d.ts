import { FilesService } from './files.service';
import { Response } from 'express';
export declare class FilesController {
    private readonly filesService;
    constructor(filesService: FilesService);
    uploadFile(file: Express.Multer.File): Promise<{
        success: boolean;
        message: string;
        data: {
            filename: string;
            url: string;
        };
    }>;
    serveFile(filename: string, res: Response): Promise<void>;
}
