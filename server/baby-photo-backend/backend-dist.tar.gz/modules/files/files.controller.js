"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FilesController = void 0;
const common_1 = require("@nestjs/common");
const throttler_1 = require("@nestjs/throttler");
const platform_express_1 = require("@nestjs/platform-express");
const multer_1 = require("multer");
const files_service_1 = require("./files.service");
const path_1 = require("path");
const crypto_1 = require("crypto");
const ALLOWED_MIMETYPES = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/bmp',
    'image/svg+xml',
    'application/pdf',
];
const MAX_FILE_SIZE = parseInt(process.env.MAX_FILE_SIZE || String(10 * 1024 * 1024), 10);
let FilesController = class FilesController {
    filesService;
    constructor(filesService) {
        this.filesService = filesService;
    }
    async uploadFile(file) {
        if (!file)
            throw new common_1.HttpException('No file uploaded', 400);
        if (file.size > MAX_FILE_SIZE) {
            throw new common_1.HttpException(`文件大小不能超过 ${MAX_FILE_SIZE / 1024 / 1024}MB`, 400);
        }
        const publicUrl = this.filesService.getPublicUrl(file.filename);
        return { success: true, message: '上传成功', data: { filename: file.filename, url: publicUrl } };
    }
    async serveFile(filename, res) {
        const path = this.filesService.getFilePath(filename);
        return res.sendFile(path, { root: '.' });
    }
};
exports.FilesController = FilesController;
__decorate([
    (0, common_1.Post)('upload'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: (0, multer_1.diskStorage)({
            destination: (req, file, cb) => cb(null, process.env.UPLOAD_PATH || './uploads'),
            filename: (req, file, cb) => {
                const ext = (0, path_1.extname)(file.originalname).toLowerCase();
                const name = `${(0, crypto_1.randomUUID)()}${ext}`;
                cb(null, name);
            },
        }),
        fileFilter: (req, file, cb) => {
            if (!ALLOWED_MIMETYPES.includes(file.mimetype)) {
                return cb(new common_1.BadRequestException(`不支持的文件类型: ${file.mimetype}，仅允许图片和 PDF 文件`), false);
            }
            cb(null, true);
        },
        limits: { fileSize: MAX_FILE_SIZE },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], FilesController.prototype, "uploadFile", null);
__decorate([
    (0, throttler_1.SkipThrottle)(),
    (0, common_1.Get)(':filename'),
    __param(0, (0, common_1.Param)('filename')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], FilesController.prototype, "serveFile", null);
exports.FilesController = FilesController = __decorate([
    (0, common_1.Controller)('files'),
    __metadata("design:paramtypes", [files_service_1.FilesService])
], FilesController);
//# sourceMappingURL=files.controller.js.map