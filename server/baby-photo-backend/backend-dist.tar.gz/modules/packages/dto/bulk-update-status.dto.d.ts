export declare class BulkUpdateStatusDto {
    ids: number[];
    status: 'ACTIVE' | 'INACTIVE';
}
