export declare class CreatePackageDto {
    name: string;
    description?: string;
    price: number;
    deposit?: number;
    durationMinutes: number;
    includes?: string[];
    images?: string[];
    category?: string;
    categoryId?: number;
    isPopular?: boolean;
    tags?: string[];
    status?: string;
    promotionPrice?: number;
    promotionStart?: Date;
    promotionEnd?: Date;
    groupMinCount?: number;
    groupPrice?: number;
}
