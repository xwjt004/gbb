export declare class PackageSearchDto {
    page?: number;
    limit?: number;
    name?: string;
    status?: 'ACTIVE' | 'INACTIVE';
    isPopular?: string;
    minPrice?: number;
    maxPrice?: number;
    sort?: string;
    category?: string;
    categoryId?: number;
    tags?: string;
}
