"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PackageSearchDto = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const swagger_1 = require("@nestjs/swagger");
class PackageSearchDto {
    page = 1;
    limit = 20;
    name;
    status;
    isPopular;
    minPrice;
    maxPrice;
    sort = 'created_at_desc';
    category;
    categoryId;
    tags;
}
exports.PackageSearchDto = PackageSearchDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '页码', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => parseInt(value)),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], PackageSearchDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '每页数量', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => parseInt(value)),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(100),
    __metadata("design:type", Number)
], PackageSearchDto.prototype, "limit", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套餐名称', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PackageSearchDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '状态过滤 (ACTIVE/INACTIVE)', required: false, enum: ['ACTIVE', 'INACTIVE'] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['ACTIVE', 'INACTIVE']),
    __metadata("design:type", String)
], PackageSearchDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否热门', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => (value === 'true' || value === true ? 'true' : value === 'false' ? 'false' : undefined)),
    __metadata("design:type", String)
], PackageSearchDto.prototype, "isPopular", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '最低价格', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => parseFloat(value)),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PackageSearchDto.prototype, "minPrice", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '最高价格', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => parseFloat(value)),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PackageSearchDto.prototype, "maxPrice", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '排序方式',
        enum: [
            'price_asc',
            'price_desc',
            'name_asc',
            'name_desc',
            'created_at_asc',
            'created_at_desc',
            'popularity',
        ],
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)([
        'price_asc',
        'price_desc',
        'name_asc',
        'name_desc',
        'created_at_asc',
        'created_at_desc',
        'popularity',
    ]),
    __metadata("design:type", String)
], PackageSearchDto.prototype, "sort", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套餐分类', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PackageSearchDto.prototype, "category", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套餐分类ID', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => parseInt(value)),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], PackageSearchDto.prototype, "categoryId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套餐标签（用逗号分隔）', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PackageSearchDto.prototype, "tags", void 0);
//# sourceMappingURL=package-search.dto.js.map