import { Response } from 'express';
import { PrismaService } from '../../shared/prisma/prisma.service';
import { CacheService } from '../../shared/cache/cache.service';
import { CreatePackageDto } from './dto/create-package.dto';
import { UpdatePackageDto } from './dto/update-package.dto';
import { PackageSearchDto } from './dto/package-search.dto';
import { BulkUpdateStatusDto } from './dto/bulk-update-status.dto';
export declare class PackagesService {
    private readonly prisma;
    private readonly cacheService;
    private readonly logger;
    constructor(prisma: PrismaService, cacheService: CacheService);
    create(createPackageDto: CreatePackageDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            name: string;
            status: import("@prisma/client").$Enums.PackageStatus;
            description: string | null;
            price: import("@prisma/client/runtime/library").Decimal;
            deposit: import("@prisma/client/runtime/library").Decimal;
            durationMinutes: number;
            includes: string[];
            isPopular: boolean;
            images: string[];
            category: string | null;
            tags: string[];
            categoryId: number | null;
            packageType: string;
            style: string | null;
            theme: string | null;
            detailImages: string[];
            isOnSale: boolean;
            salesVolume: number;
            baseSales: number;
            sortOrder: number;
            videoUrl: string | null;
            virtualSales: number;
            promotionPrice: import("@prisma/client/runtime/library").Decimal | null;
            promotionStart: Date | null;
            promotionEnd: Date | null;
            groupMinCount: number | null;
            groupPrice: import("@prisma/client/runtime/library").Decimal | null;
        };
    }>;
    findAll(searchDto: PackageSearchDto): Promise<{
        code: number;
        message: string;
        data: {
            packages: any;
            pagination: {
                total: number;
                page: number;
                limit: number;
                totalPages: number;
            };
        };
    }>;
    findByPriceRange(minPrice?: number, maxPrice?: number, sort?: string): Promise<{
        code: number;
        message: string;
        data: {
            packages: {
                id: any;
                name: any;
                description: any;
                price: number;
                deposit: number;
                duration_minutes: any;
                includes: any;
                category: any;
                tags: any;
                is_popular: any;
                status: any;
                order_count: any;
                created_at: any;
            }[];
            search_criteria: {
                min_price: number | undefined;
                max_price: number | undefined;
                sort: string;
            };
        };
    }>;
    findByName(name: string, fuzzy?: boolean): Promise<{
        code: number;
        message: string;
        data: {
            id: any;
            name: any;
            description: any;
            price: number;
            deposit: number;
            duration_minutes: any;
            includes: any;
            category: any;
            tags: any;
            is_popular: any;
            status: any;
            order_count: any;
            created_at: any;
        }[];
    }>;
    getPopularPackages(limit?: number): Promise<{
        code: number;
        message: string;
        data: {
            id: any;
            name: any;
            description: any;
            price: number;
            deposit: number;
            duration_minutes: any;
            includes: any;
            category: any;
            tags: any;
            is_popular: any;
            order_count: any;
            popularity_score: number;
            status: any;
            created_at: any;
        }[];
    }>;
    findOne(id: number): Promise<{
        code: number;
        message: string;
        data: {
            id: any;
            name: any;
            description: any;
            price: number;
            deposit: number;
            duration_minutes: any;
            includes: any;
            images: any;
            category: any;
            categoryId: any;
            packageCategory: any;
            tags: any;
            is_popular: any;
            status: any;
            order_count: any;
            recent_orders: any;
            created_at: any;
        };
    }>;
    update(id: number, updatePackageDto: UpdatePackageDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            name: string;
            status: import("@prisma/client").$Enums.PackageStatus;
            description: string | null;
            price: import("@prisma/client/runtime/library").Decimal;
            deposit: import("@prisma/client/runtime/library").Decimal;
            durationMinutes: number;
            includes: string[];
            isPopular: boolean;
            images: string[];
            category: string | null;
            tags: string[];
            categoryId: number | null;
            packageType: string;
            style: string | null;
            theme: string | null;
            detailImages: string[];
            isOnSale: boolean;
            salesVolume: number;
            baseSales: number;
            sortOrder: number;
            videoUrl: string | null;
            virtualSales: number;
            promotionPrice: import("@prisma/client/runtime/library").Decimal | null;
            promotionStart: Date | null;
            promotionEnd: Date | null;
            groupMinCount: number | null;
            groupPrice: import("@prisma/client/runtime/library").Decimal | null;
        };
    }>;
    remove(id: number): Promise<{
        code: number;
        message: string;
    }>;
    getPackageStatistics(id: number): Promise<{
        code: number;
        message: string;
        data: {
            package_info: {
                id: number;
                name: string;
                price: number;
            };
            order_statistics: {
                total_orders: number;
                completed_orders: number;
                completion_rate: number;
            };
            revenue_statistics: {
                total_revenue: number;
                average_order_value: number;
            };
            popularity_metrics: {
                popularity_score: number;
                market_share: number;
            };
        };
    }>;
    private buildOrderBy;
    private calculatePopularityScore;
    private calculateMarketShare;
    private clearPackageListCache;
    getRecommendations(packageId: number, limit?: number): Promise<{
        code: number;
        message: string;
        data: any[];
    }>;
    calculatePrice(packageId: number, date: Date): Promise<{
        basePrice: number;
        finalPrice: number;
        appliedRule: {
            type: string;
            label: string;
            id: number;
        };
    } | {
        basePrice: number;
        finalPrice: number;
        appliedRule: {
            type: string;
            label: string;
            id?: undefined;
        };
    }>;
    bulkUpdateStatus(dto: BulkUpdateStatusDto): Promise<{
        code: number;
        message: string;
        data: {
            count: number;
            status: "ACTIVE" | "INACTIVE";
        };
    }>;
    private getExportData;
    exportToExcel(searchDto: PackageSearchDto, res: Response): Promise<void>;
    exportToCSV(searchDto: PackageSearchDto, res: Response): Promise<void>;
    exportToJSON(searchDto: PackageSearchDto): Promise<{
        code: number;
        message: string;
        data: {
            exportTime: string;
            totalCount: any;
            packages: any;
        };
    }>;
}
