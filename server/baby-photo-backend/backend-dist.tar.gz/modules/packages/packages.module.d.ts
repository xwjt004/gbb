export declare class PackagesModule {
}
