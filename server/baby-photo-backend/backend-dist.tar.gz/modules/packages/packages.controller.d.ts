import { Response } from 'express';
import { PackagesService } from './packages.service';
import { BulkUpdateStatusDto } from './dto/bulk-update-status.dto';
import { CreatePackageDto } from './dto/create-package.dto';
import { UpdatePackageDto } from './dto/update-package.dto';
import { PackageSearchDto } from './dto/package-search.dto';
export declare class PackagesController {
    private readonly packagesService;
    private readonly logger;
    constructor(packagesService: PackagesService);
    create(createPackageDto: CreatePackageDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            name: string;
            status: import("@prisma/client").$Enums.PackageStatus;
            description: string | null;
            price: import("@prisma/client/runtime/library").Decimal;
            deposit: import("@prisma/client/runtime/library").Decimal;
            durationMinutes: number;
            includes: string[];
            isPopular: boolean;
            images: string[];
            category: string | null;
            tags: string[];
            categoryId: number | null;
            packageType: string;
            style: string | null;
            theme: string | null;
            detailImages: string[];
            isOnSale: boolean;
            salesVolume: number;
            baseSales: number;
            sortOrder: number;
            videoUrl: string | null;
            virtualSales: number;
            promotionPrice: import("@prisma/client/runtime/library").Decimal | null;
            promotionStart: Date | null;
            promotionEnd: Date | null;
            groupMinCount: number | null;
            groupPrice: import("@prisma/client/runtime/library").Decimal | null;
        };
    }>;
    findAll(searchDto: PackageSearchDto): Promise<{
        code: number;
        message: string;
        data: {
            packages: any;
            pagination: {
                total: number;
                page: number;
                limit: number;
                totalPages: number;
            };
        };
    }>;
    findByPriceRange(minPrice?: number, maxPrice?: number, sort?: string): Promise<{
        code: number;
        message: string;
        data: {
            packages: {
                id: any;
                name: any;
                description: any;
                price: number;
                deposit: number;
                duration_minutes: any;
                includes: any;
                category: any;
                tags: any;
                is_popular: any;
                status: any;
                order_count: any;
                created_at: any;
            }[];
            search_criteria: {
                min_price: number | undefined;
                max_price: number | undefined;
                sort: string;
            };
        };
    }>;
    findByName(name: string, fuzzy?: string): Promise<{
        code: number;
        message: string;
        data: {
            id: any;
            name: any;
            description: any;
            price: number;
            deposit: number;
            duration_minutes: any;
            includes: any;
            category: any;
            tags: any;
            is_popular: any;
            status: any;
            order_count: any;
            created_at: any;
        }[];
    }>;
    getPopularPackages(limit?: string): Promise<{
        code: number;
        message: string;
        data: {
            id: any;
            name: any;
            description: any;
            price: number;
            deposit: number;
            duration_minutes: any;
            includes: any;
            category: any;
            tags: any;
            is_popular: any;
            order_count: any;
            popularity_score: number;
            status: any;
            created_at: any;
        }[];
    }>;
    exportToExcel(searchDto: PackageSearchDto, res: Response): Promise<void>;
    exportToCSV(searchDto: PackageSearchDto, res: Response): Promise<void>;
    exportToJSON(searchDto: PackageSearchDto): Promise<{
        code: number;
        message: string;
        data: {
            exportTime: string;
            totalCount: any;
            packages: any;
        };
    }>;
    findOne(id: string): Promise<{
        code: number;
        message: string;
        data: {
            id: any;
            name: any;
            description: any;
            price: number;
            deposit: number;
            duration_minutes: any;
            includes: any;
            images: any;
            category: any;
            categoryId: any;
            packageCategory: any;
            tags: any;
            is_popular: any;
            status: any;
            order_count: any;
            recent_orders: any;
            created_at: any;
        };
    }>;
    update(id: string, updatePackageDto: UpdatePackageDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            name: string;
            status: import("@prisma/client").$Enums.PackageStatus;
            description: string | null;
            price: import("@prisma/client/runtime/library").Decimal;
            deposit: import("@prisma/client/runtime/library").Decimal;
            durationMinutes: number;
            includes: string[];
            isPopular: boolean;
            images: string[];
            category: string | null;
            tags: string[];
            categoryId: number | null;
            packageType: string;
            style: string | null;
            theme: string | null;
            detailImages: string[];
            isOnSale: boolean;
            salesVolume: number;
            baseSales: number;
            sortOrder: number;
            videoUrl: string | null;
            virtualSales: number;
            promotionPrice: import("@prisma/client/runtime/library").Decimal | null;
            promotionStart: Date | null;
            promotionEnd: Date | null;
            groupMinCount: number | null;
            groupPrice: import("@prisma/client/runtime/library").Decimal | null;
        };
    }>;
    bulkUpdateStatus(dto: BulkUpdateStatusDto): Promise<{
        code: number;
        message: string;
        data: {
            count: number;
            status: "ACTIVE" | "INACTIVE";
        };
    }>;
    remove(id: string): Promise<{
        code: number;
        message: string;
    }>;
    getRecommendations(id: string, limit?: string): Promise<{
        code: number;
        message: string;
        data: any[];
    }>;
    getPackageStatistics(id: string): Promise<{
        code: number;
        message: string;
        data: {
            package_info: {
                id: number;
                name: string;
                price: number;
            };
            order_statistics: {
                total_orders: number;
                completed_orders: number;
                completion_rate: number;
            };
            revenue_statistics: {
                total_revenue: number;
                average_order_value: number;
            };
            popularity_metrics: {
                popularity_score: number;
                market_share: number;
            };
        };
    }>;
}
