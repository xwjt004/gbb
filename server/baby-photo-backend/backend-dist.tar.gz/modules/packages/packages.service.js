"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PackagesService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PackagesService = void 0;
const common_1 = require("@nestjs/common");
const xlsx_1 = require("xlsx");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const cache_service_1 = require("../../shared/cache/cache.service");
let PackagesService = PackagesService_1 = class PackagesService {
    prisma;
    cacheService;
    logger = new common_1.Logger(PackagesService_1.name);
    constructor(prisma, cacheService) {
        this.prisma = prisma;
        this.cacheService = cacheService;
    }
    async create(createPackageDto) {
        try {
            const existingPackage = await this.prisma.package.findFirst({
                where: { name: createPackageDto.name },
            });
            if (existingPackage) {
                throw new common_1.ConflictException('套餐名称已存在');
            }
            const normalizedStatus = createPackageDto.status?.toUpperCase() === 'INACTIVE'
                ? 'INACTIVE'
                : 'ACTIVE';
            const packageData = {
                ...createPackageDto,
                status: normalizedStatus,
                deposit: createPackageDto.deposit ?? 0,
                includes: createPackageDto.includes ?? [],
                isPopular: createPackageDto.isPopular ?? false,
                tags: createPackageDto.tags ?? [],
            };
            const pkg = await this.prisma.package.create({
                data: packageData,
            });
            await this.clearPackageListCache();
            this.logger.log(`套餐创建成功: ${pkg.id}`);
            return {
                code: 200,
                message: '套餐创建成功',
                data: pkg,
            };
        }
        catch (error) {
            if (error instanceof common_1.ConflictException) {
                throw error;
            }
            this.logger.error(`创建套餐失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('创建套餐失败');
        }
    }
    async findAll(searchDto) {
        const { page = 1, limit = 20, name, minPrice, maxPrice, sort = 'created_at_desc', status, isPopular, categoryId, } = searchDto;
        try {
            const where = {};
            if (name) {
                where.name = {
                    contains: name,
                    mode: 'insensitive',
                };
            }
            if (minPrice !== undefined || maxPrice !== undefined) {
                where.price = {};
                if (minPrice !== undefined)
                    where.price.gte = minPrice;
                if (maxPrice !== undefined)
                    where.price.lte = maxPrice;
            }
            const orderBy = this.buildOrderBy(sort);
            if (status) {
                where.status = status;
            }
            if (searchDto.category) {
                where.category = searchDto.category;
            }
            if (categoryId) {
                where.categoryId = categoryId;
            }
            if (isPopular === 'true') {
                where.isPopular = true;
            }
            else if (isPopular === 'false') {
                where.isPopular = false;
            }
            if (searchDto.tags) {
                const tagList = searchDto.tags.split(',').map(tag => tag.trim()).filter(tag => tag);
                if (tagList.length > 0) {
                    where.tags = {
                        hasSome: tagList,
                    };
                }
            }
            const [packages, total] = await Promise.all([
                this.prisma.package.findMany({
                    where,
                    orderBy,
                    skip: (page - 1) * limit,
                    take: limit,
                    include: {
                        _count: { select: { orders: true } },
                        packageCategory: {
                            select: {
                                id: true,
                                name: true,
                                color: true,
                                icon: true,
                            },
                        },
                    },
                }),
                this.prisma.package.count({ where }),
            ]);
            const formattedPackages = packages.map((pkg) => ({
                id: pkg.id,
                name: pkg.name,
                description: pkg.description,
                price: Number(pkg.price),
                deposit: Number(pkg.deposit),
                duration_minutes: pkg.durationMinutes,
                includes: pkg.includes,
                images: pkg.images || [],
                category: pkg.category || '',
                categoryId: pkg.categoryId,
                packageCategory: pkg.packageCategory,
                tags: pkg.tags || [],
                status: pkg.status,
                is_popular: pkg.isPopular,
                order_count: pkg._count?.orders,
                created_at: pkg.createdAt,
            }));
            return {
                code: 200,
                message: '查询成功',
                data: {
                    packages: formattedPackages,
                    pagination: {
                        total,
                        page,
                        limit,
                        totalPages: Math.ceil(total / limit),
                    },
                },
            };
        }
        catch (error) {
            this.logger.error(`查询套餐列表失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async findByPriceRange(minPrice, maxPrice, sort = 'price_asc') {
        try {
            const cacheKey = this.cacheService.generateKey('package-price-range', (minPrice || 0).toString(), (maxPrice || 'max').toString(), sort);
            return this.cacheService.getOrSet(cacheKey, async () => {
                const where = {};
                if (minPrice !== undefined || maxPrice !== undefined) {
                    where.price = {};
                    if (minPrice !== undefined)
                        where.price.gte = minPrice;
                    if (maxPrice !== undefined)
                        where.price.lte = maxPrice;
                }
                const orderBy = this.buildOrderBy(sort);
                const packages = await this.prisma.package.findMany({
                    where,
                    orderBy,
                    include: { _count: { select: { orders: true } } },
                });
                if (packages.length === 0) {
                    throw new common_1.NotFoundException('未找到符合条件的套餐');
                }
                const formattedPackages = packages.map((pkg) => ({
                    id: pkg.id,
                    name: pkg.name,
                    description: pkg.description,
                    price: Number(pkg.price),
                    deposit: Number(pkg.deposit),
                    duration_minutes: pkg.durationMinutes,
                    includes: pkg.includes,
                    category: pkg.category || '',
                    tags: pkg.tags || [],
                    is_popular: pkg.isPopular,
                    status: pkg.status,
                    order_count: pkg._count?.orders,
                    created_at: pkg.createdAt,
                }));
                return {
                    code: 200,
                    message: '查找成功',
                    data: {
                        packages: formattedPackages,
                        search_criteria: {
                            min_price: minPrice,
                            max_price: maxPrice,
                            sort: sort,
                        },
                    },
                };
            }, 600);
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`通过价格区间查找套餐失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查找失败');
        }
    }
    async findByName(name, fuzzy = false) {
        try {
            const cacheKey = this.cacheService.generateKey('package-name', name, fuzzy.toString());
            return this.cacheService.getOrSet(cacheKey, async () => {
                const where = fuzzy
                    ? {
                        name: {
                            contains: name,
                            mode: 'insensitive',
                        },
                    }
                    : { name };
                const packages = await this.prisma.package.findMany({
                    where,
                    include: { _count: { select: { orders: true } } },
                    orderBy: { createdAt: 'desc' },
                });
                if (packages.length === 0) {
                    throw new common_1.NotFoundException('未找到匹配的套餐');
                }
                const formattedPackages = packages.map((pkg) => ({
                    id: pkg.id,
                    name: pkg.name,
                    description: pkg.description,
                    price: Number(pkg.price),
                    deposit: Number(pkg.deposit),
                    duration_minutes: pkg.durationMinutes,
                    includes: pkg.includes,
                    category: pkg.category || '',
                    tags: pkg.tags || [],
                    is_popular: pkg.isPopular,
                    status: pkg.status,
                    order_count: pkg._count?.orders,
                    created_at: pkg.createdAt,
                }));
                return {
                    code: 200,
                    message: '查找成功',
                    data: formattedPackages,
                };
            }, 600);
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`通过名称查找套餐失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查找失败');
        }
    }
    async getPopularPackages(limit = 10) {
        try {
            const cacheKey = this.cacheService.generateKey('popular-packages', limit.toString());
            return this.cacheService.getOrSet(cacheKey, async () => {
                const packages = await this.prisma.package.findMany({
                    include: { _count: { select: { orders: true } } },
                    orderBy: { orders: { _count: 'desc' } },
                    take: limit,
                });
                const formattedPackages = packages.map((pkg) => ({
                    id: pkg.id,
                    name: pkg.name,
                    description: pkg.description,
                    price: Number(pkg.price),
                    deposit: Number(pkg.deposit),
                    duration_minutes: pkg.durationMinutes,
                    includes: pkg.includes,
                    category: pkg.category || '',
                    tags: pkg.tags || [],
                    is_popular: pkg.isPopular,
                    order_count: pkg._count?.orders,
                    popularity_score: this.calculatePopularityScore(pkg._count?.orders),
                    status: pkg.status,
                    created_at: pkg.createdAt,
                }));
                return {
                    code: 200,
                    message: '获取成功',
                    data: formattedPackages,
                };
            }, 1800);
        }
        catch (error) {
            this.logger.error(`获取热门套餐失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('获取失败');
        }
    }
    async findOne(id) {
        try {
            const cacheKey = this.cacheService.getPackageCacheKey(id);
            return this.cacheService.getOrSet(cacheKey, async () => {
                const pkg = await this.prisma.package.findUnique({
                    where: { id },
                    include: {
                        orders: {
                            take: 5,
                            orderBy: { createdAt: 'desc' },
                            select: {
                                orderNo: true,
                                totalAmount: true,
                                orderStatus: true,
                                createdAt: true,
                                user: { select: { nickname: true } },
                            },
                        },
                        _count: { select: { orders: true } },
                        packageCategory: {
                            select: {
                                id: true,
                                name: true,
                                color: true,
                                icon: true,
                            },
                        },
                    },
                });
                if (!pkg) {
                    throw new common_1.NotFoundException('套餐不存在');
                }
                const formattedPackage = {
                    id: pkg.id,
                    name: pkg.name,
                    description: pkg.description,
                    price: Number(pkg.price),
                    deposit: Number(pkg.deposit),
                    duration_minutes: pkg.durationMinutes,
                    includes: pkg.includes,
                    images: pkg.images || [],
                    category: pkg.category || '',
                    categoryId: pkg.categoryId,
                    packageCategory: pkg.packageCategory,
                    tags: pkg.tags || [],
                    is_popular: pkg.isPopular,
                    status: pkg.status,
                    order_count: pkg._count?.orders,
                    recent_orders: pkg.orders.map((order) => ({
                        order_no: order.orderNo,
                        total_amount: Number(order.totalAmount),
                        order_status: order.orderStatus,
                        customer_name: order.user.nickname,
                        created_at: order.createdAt,
                    })),
                    created_at: pkg.createdAt,
                };
                return {
                    code: 200,
                    message: '查询成功',
                    data: formattedPackage,
                };
            }, 1800);
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`获取套餐详情失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    async update(id, updatePackageDto) {
        try {
            const existingPackage = await this.prisma.package.findUnique({
                where: { id },
            });
            if (!existingPackage) {
                throw new common_1.NotFoundException('套餐不存在');
            }
            if (updatePackageDto.name &&
                updatePackageDto.name !== existingPackage.name) {
                const nameExists = await this.prisma.package.findFirst({
                    where: {
                        name: updatePackageDto.name,
                        id: { not: id },
                    },
                });
                if (nameExists) {
                    throw new common_1.ConflictException('套餐名称已被使用');
                }
            }
            const updateData = { ...updatePackageDto };
            if (updatePackageDto.status) {
                updateData.status =
                    updatePackageDto.status.toUpperCase() === 'INACTIVE'
                        ? 'INACTIVE'
                        : 'ACTIVE';
            }
            const pkg = await this.prisma.package.update({
                where: { id },
                data: updateData,
            });
            const cacheKey = this.cacheService.getPackageCacheKey(id);
            await this.cacheService.del(cacheKey);
            await this.clearPackageListCache();
            this.logger.log(`套餐更新成功: ${id}`);
            return {
                code: 200,
                message: '更新成功',
                data: pkg,
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException ||
                error instanceof common_1.ConflictException) {
                throw error;
            }
            this.logger.error(`更新套餐失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('更新失败');
        }
    }
    async remove(id) {
        try {
            const pkg = await this.prisma.package.findUnique({
                where: { id },
                include: {
                    _count: {
                        select: {
                            orders: true,
                        },
                    },
                },
            });
            if (!pkg) {
                throw new common_1.NotFoundException('套餐不存在');
            }
            if (pkg._count?.orders > 0) {
                throw new common_1.BadRequestException('套餐有相关订单，无法删除');
            }
            await this.prisma.package.delete({
                where: { id },
            });
            const cacheKey = this.cacheService.getPackageCacheKey(id);
            await this.cacheService.del(cacheKey);
            await this.clearPackageListCache();
            this.logger.log(`套餐删除成功: ${id}`);
            return {
                code: 200,
                message: '删除成功',
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException ||
                error instanceof common_1.BadRequestException) {
                throw error;
            }
            this.logger.error(`删除套餐失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('删除失败');
        }
    }
    async getPackageStatistics(id) {
        try {
            const cacheKey = this.cacheService.generateKey('package-stats', id.toString());
            return this.cacheService.getOrSet(cacheKey, async () => {
                const pkg = await this.prisma.package.findUnique({
                    where: { id },
                    include: {
                        orders: {
                            include: {
                                payments: {
                                    where: { status: 'FULLY_PAID' },
                                },
                            },
                        },
                    },
                });
                if (!pkg) {
                    throw new common_1.NotFoundException('套餐不存在');
                }
                const totalOrders = pkg.orders.length;
                const completedOrders = pkg.orders.filter((order) => order.orderStatus === 'COMPLETED').length;
                const totalRevenue = pkg.orders.reduce((sum, order) => {
                    const paidAmount = order.payments.reduce((paySum, payment) => paySum + Number(payment.amount), 0);
                    return sum + paidAmount;
                }, 0);
                const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
                const statistics = {
                    package_info: {
                        id: pkg.id,
                        name: pkg.name,
                        price: Number(pkg.price),
                    },
                    order_statistics: {
                        total_orders: totalOrders,
                        completed_orders: completedOrders,
                        completion_rate: totalOrders > 0 ? (completedOrders / totalOrders) * 100 : 0,
                    },
                    revenue_statistics: {
                        total_revenue: totalRevenue,
                        average_order_value: averageOrderValue,
                    },
                    popularity_metrics: {
                        popularity_score: this.calculatePopularityScore(totalOrders),
                        market_share: await this.calculateMarketShare(id, totalOrders),
                    },
                };
                return {
                    code: 200,
                    message: '查询成功',
                    data: statistics,
                };
            }, 1800);
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`获取套餐统计信息失败: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('查询失败');
        }
    }
    buildOrderBy(sort) {
        switch (sort) {
            case 'price_asc':
                return { price: 'asc' };
            case 'price_desc':
                return { price: 'desc' };
            case 'name_asc':
                return { name: 'asc' };
            case 'name_desc':
                return { name: 'desc' };
            case 'created_at_asc':
                return { createdAt: 'asc' };
            case 'created_at_desc':
                return { createdAt: 'desc' };
            case 'popularity':
                return { orders: { _count: 'desc' } };
            default:
                return { createdAt: 'desc' };
        }
    }
    calculatePopularityScore(orderCount) {
        return Math.min(100, orderCount * 10);
    }
    async calculateMarketShare(packageId, orderCount) {
        const totalOrders = await this.prisma.order.count();
        return totalOrders > 0 ? (orderCount / totalOrders) * 100 : 0;
    }
    async clearPackageListCache() {
        const cacheKeys = ['popular-packages', 'package-price-range'];
        for (const keyPrefix of cacheKeys) {
            await this.cacheService.deleteByPattern(`${keyPrefix}:*`);
        }
    }
    async getRecommendations(packageId, limit = 4) {
        const pkg = await this.prisma.package.findUnique({ where: { id: packageId } });
        if (!pkg)
            throw new common_1.NotFoundException('套餐不存在');
        const manual = await this.prisma.crossSellPackage.findMany({
            where: { sourcePkgId: packageId },
            include: {
                recommended: true,
            },
            orderBy: { sortOrder: 'asc' },
            take: limit,
        });
        const manualIds = new Set(manual.map((m) => m.recommendedPkgId));
        const results = manual.map((m) => ({
            id: m.recommended.id,
            name: m.recommended.name,
            price: Number(m.recommended.price),
            image: m.recommended.images?.[0] || null,
            type: 'manual',
            sortOrder: m.sortOrder,
        }));
        if (results.length < limit) {
            const orderIds = await this.prisma.order.findMany({
                where: { packageId },
                select: { id: true },
                take: 50,
            });
            if (orderIds.length > 0) {
                const affinityPackages = await this.prisma.orderItem.groupBy({
                    by: ['packageId'],
                    where: {
                        orderId: { in: orderIds.map((o) => o.id) },
                        packageId: { not: null, notIn: [packageId, ...manualIds] },
                    },
                    _count: { packageId: true },
                    orderBy: { _count: { packageId: 'desc' } },
                    take: limit - results.length,
                });
                const affinityPkgIds = affinityPackages
                    .map((a) => a.packageId)
                    .filter((id) => id !== null);
                if (affinityPkgIds.length > 0) {
                    const pkgs = await this.prisma.package.findMany({
                        where: { id: { in: affinityPkgIds } },
                    });
                    const pkgMap = new Map(pkgs.map((p) => [p.id, p]));
                    for (const ap of affinityPackages) {
                        if (!ap.packageId)
                            continue;
                        const p = pkgMap.get(ap.packageId);
                        if (p) {
                            results.push({
                                id: p.id,
                                name: p.name,
                                price: Number(p.price),
                                image: p.images?.[0] || null,
                                type: 'affinity',
                                orderCount: ap._count.packageId,
                            });
                        }
                    }
                }
            }
        }
        return { code: 200, message: '查询成功', data: results.slice(0, limit) };
    }
    async calculatePrice(packageId, date) {
        const pkg = await this.prisma.package.findUnique({
            where: { id: packageId },
        });
        if (!pkg)
            throw new common_1.NotFoundException('套餐不存在');
        const basePrice = Number(pkg.price);
        const dateStr = date.toISOString().slice(0, 10);
        const seasonal = await this.prisma.seasonalPrice.findFirst({
            where: {
                packageId,
                startDate: { lte: date },
                endDate: { gte: date },
            },
            orderBy: { startDate: 'desc' },
        });
        if (seasonal) {
            return {
                basePrice,
                finalPrice: Number(seasonal.price),
                appliedRule: { type: 'seasonal', label: seasonal.label || '季节性价格', id: seasonal.id },
            };
        }
        if (pkg.promotionPrice && pkg.promotionStart && pkg.promotionEnd) {
            if (date >= pkg.promotionStart && date <= pkg.promotionEnd) {
                return {
                    basePrice,
                    finalPrice: Number(pkg.promotionPrice),
                    appliedRule: { type: 'promotion', label: '限时促销' },
                };
            }
        }
        return {
            basePrice,
            finalPrice: basePrice,
            appliedRule: { type: 'base', label: '标准价格' },
        };
    }
    async bulkUpdateStatus(dto) {
        const { ids, status } = dto;
        try {
            const normalized = status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE';
            const result = await this.prisma.package.updateMany({
                where: { id: { in: ids } },
                data: { status: normalized },
            });
            await this.clearPackageListCache();
            for (const id of ids) {
                const cacheKey = this.cacheService.getPackageCacheKey(id);
                await this.cacheService.del(cacheKey);
            }
            return {
                code: 200,
                message: '批量更新成功',
                data: { count: result.count, status: normalized },
            };
        }
        catch (e) {
            this.logger.error(`批量更新状态失败: ${e.message}`, e.stack);
            throw new common_1.BadRequestException('批量更新失败');
        }
    }
    async getExportData(searchDto) {
        const result = await this.findAll({ ...searchDto, page: 1, limit: 10000 });
        const packages = result.data.packages;
        return packages.map((pkg) => ({
            ID: pkg.id,
            '套餐名称': pkg.name,
            '套餐描述': pkg.description,
            '价格(元)': pkg.price,
            '押金(元)': pkg.deposit || 0,
            '服务时长(分钟)': pkg.duration_minutes,
            '分类': pkg.category || '',
            '标签': Array.isArray(pkg.tags) ? pkg.tags.join(', ') : '',
            '是否热门': pkg.is_popular ? '是' : '否',
            '状态': pkg.status === 'ACTIVE' ? '已上架' : '已下架',
            '预订次数': pkg.order_count || 0,
            '服务包含': Array.isArray(pkg.includes) ? pkg.includes.join(', ') : '',
            '创建时间': new Date(pkg.created_at).toLocaleString('zh-CN'),
        }));
    }
    async exportToExcel(searchDto, res) {
        try {
            this.logger.log('开始导出套餐数据到Excel');
            const data = await this.getExportData(searchDto);
            const workbook = xlsx_1.utils.book_new();
            const worksheet = data.length === 0
                ? xlsx_1.utils.json_to_sheet([])
                : xlsx_1.utils.json_to_sheet(data);
            const wscols = [
                { wch: 8 },
                { wch: 20 },
                { wch: 30 },
                { wch: 12 },
                { wch: 12 },
                { wch: 15 },
                { wch: 12 },
                { wch: 20 },
                { wch: 10 },
                { wch: 10 },
                { wch: 12 },
                { wch: 30 },
                { wch: 20 },
            ];
            worksheet['!cols'] = wscols;
            xlsx_1.utils.book_append_sheet(workbook, worksheet, '套餐数据');
            const now = new Date();
            const filename = `套餐数据_${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}_${now.getHours().toString().padStart(2, '0')}${now.getMinutes().toString().padStart(2, '0')}.xlsx`;
            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename)}"`);
            const buffer = (0, xlsx_1.write)(workbook, { type: 'buffer', bookType: 'xlsx' });
            res.send(buffer);
            this.logger.log(`Excel导出成功，文件名: ${filename}`);
        }
        catch (error) {
            this.logger.error('Excel导出失败', error);
            throw new common_1.BadRequestException('导出失败');
        }
    }
    async exportToCSV(searchDto, res) {
        try {
            this.logger.log('开始导出套餐数据到CSV');
            const data = await this.getExportData(searchDto);
            const headers = ['ID', '套餐名称', '套餐描述', '价格(元)', '押金(元)', '服务时长(分钟)', '分类', '标签', '是否热门', '状态', '预订次数', '服务包含', '创建时间'];
            const csvContent = [
                headers.join(','),
                ...data.map((row) => headers.map(header => {
                    const value = row[header] || '';
                    if (typeof value === 'string' && (value.includes(',') || value.includes('\n') || value.includes('"'))) {
                        return `"${value.replace(/"/g, '""')}"`;
                    }
                    return value;
                }).join(','))
            ].join('\n');
            const now = new Date();
            const filename = `套餐数据_${now.getFullYear()}${(now.getMonth() + 1).toString().padStart(2, '0')}${now.getDate().toString().padStart(2, '0')}_${now.getHours().toString().padStart(2, '0')}${now.getMinutes().toString().padStart(2, '0')}.csv`;
            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename)}"`);
            res.send('\uFEFF' + csvContent);
            this.logger.log(`CSV导出成功，文件名: ${filename}`);
        }
        catch (error) {
            this.logger.error('CSV导出失败', error);
            throw new common_1.BadRequestException('导出失败');
        }
    }
    async exportToJSON(searchDto) {
        try {
            this.logger.log('开始导出套餐数据到JSON');
            const data = await this.getExportData(searchDto);
            return {
                code: 200,
                message: '导出成功',
                data: {
                    exportTime: new Date().toISOString(),
                    totalCount: data.length,
                    packages: data,
                },
            };
        }
        catch (error) {
            this.logger.error('JSON导出失败', error);
            throw new common_1.BadRequestException('导出失败');
        }
    }
};
exports.PackagesService = PackagesService;
exports.PackagesService = PackagesService = PackagesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        cache_service_1.CacheService])
], PackagesService);
//# sourceMappingURL=packages.service.js.map