"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var PackagesController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PackagesController = void 0;
const common_1 = require("@nestjs/common");
const packages_service_1 = require("./packages.service");
const bulk_update_status_dto_1 = require("./dto/bulk-update-status.dto");
const create_package_dto_1 = require("./dto/create-package.dto");
const update_package_dto_1 = require("./dto/update-package.dto");
const package_search_dto_1 = require("./dto/package-search.dto");
const null_to_undefined_pipe_1 = require("../../shared/pipes/null-to-undefined.pipe");
const swagger_1 = require("@nestjs/swagger");
let PackagesController = PackagesController_1 = class PackagesController {
    packagesService;
    logger = new common_1.Logger(PackagesController_1.name);
    constructor(packagesService) {
        this.packagesService = packagesService;
    }
    async create(createPackageDto) {
        this.logger.log(`创建套餐: ${JSON.stringify(createPackageDto)}`);
        return this.packagesService.create(createPackageDto);
    }
    async findAll(searchDto) {
        this.logger.log(`查询套餐列表: ${JSON.stringify(searchDto)}`);
        return this.packagesService.findAll(searchDto);
    }
    async findByPriceRange(minPrice, maxPrice, sort) {
        this.logger.log(`通过价格区间查找套餐: ${minPrice}-${maxPrice}, 排序: ${sort}`);
        return this.packagesService.findByPriceRange(minPrice, maxPrice, sort);
    }
    async findByName(name, fuzzy) {
        this.logger.log(`通过名称查找套餐: ${name}, 模糊搜索: ${fuzzy}`);
        const isFuzzy = fuzzy === 'true';
        return this.packagesService.findByName(name, isFuzzy);
    }
    async getPopularPackages(limit) {
        const numLimit = limit ? parseInt(limit, 10) : 10;
        this.logger.log(`获取热门套餐, 限制: ${numLimit}`);
        return this.packagesService.getPopularPackages(numLimit);
    }
    async exportToExcel(searchDto, res) {
        this.logger.log(`导出套餐数据到Excel: ${JSON.stringify(searchDto)}`);
        return this.packagesService.exportToExcel(searchDto, res);
    }
    async exportToCSV(searchDto, res) {
        this.logger.log(`导出套餐数据到CSV: ${JSON.stringify(searchDto)}`);
        return this.packagesService.exportToCSV(searchDto, res);
    }
    async exportToJSON(searchDto) {
        this.logger.log(`导出套餐数据到JSON: ${JSON.stringify(searchDto)}`);
        return this.packagesService.exportToJSON(searchDto);
    }
    async findOne(id) {
        this.logger.log(`获取套餐详情: ${id}`);
        return this.packagesService.findOne(+id);
    }
    async update(id, updatePackageDto) {
        this.logger.log(`更新套餐: ${id}, 数据: ${JSON.stringify(updatePackageDto)}`);
        return this.packagesService.update(+id, updatePackageDto);
    }
    async bulkUpdateStatus(dto) {
        this.logger.log(`批量更新套餐状态: ${dto.ids.join(',')} -> ${dto.status}`);
        return this.packagesService.bulkUpdateStatus(dto);
    }
    async remove(id) {
        this.logger.log(`删除套餐: ${id}`);
        return this.packagesService.remove(+id);
    }
    async getRecommendations(id, limit) {
        const numLimit = limit ? parseInt(limit, 10) : 4;
        this.logger.log(`获取套餐推荐: ${id}, limit: ${numLimit}`);
        return this.packagesService.getRecommendations(+id, numLimit);
    }
    async getPackageStatistics(id) {
        this.logger.log(`获取套餐统计信息: ${id}`);
        return this.packagesService.getPackageStatistics(+id);
    }
};
exports.PackagesController = PackagesController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建套餐' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '套餐创建成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_package_dto_1.CreatePackageDto]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取套餐列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [package_search_dto_1.PackageSearchDto]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('by-price-range'),
    (0, swagger_1.ApiOperation)({ summary: '通过价格区间查找套餐' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查找成功' }),
    __param(0, (0, common_1.Query)('min_price')),
    __param(1, (0, common_1.Query)('max_price')),
    __param(2, (0, common_1.Query)('sort')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, String]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "findByPriceRange", null);
__decorate([
    (0, common_1.Get)('by-name'),
    (0, swagger_1.ApiOperation)({ summary: '通过名称查找套餐' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查找成功' }),
    __param(0, (0, common_1.Query)('name')),
    __param(1, (0, common_1.Query)('fuzzy')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "findByName", null);
__decorate([
    (0, common_1.Get)('popular'),
    (0, swagger_1.ApiOperation)({ summary: '获取热门套餐' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "getPopularPackages", null);
__decorate([
    (0, common_1.Get)('export/excel'),
    (0, swagger_1.ApiOperation)({ summary: '导出套餐数据到Excel' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '导出成功' }),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [package_search_dto_1.PackageSearchDto, Object]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "exportToExcel", null);
__decorate([
    (0, common_1.Get)('export/csv'),
    (0, swagger_1.ApiOperation)({ summary: '导出套餐数据到CSV' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '导出成功' }),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [package_search_dto_1.PackageSearchDto, Object]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "exportToCSV", null);
__decorate([
    (0, common_1.Get)('export/json'),
    (0, swagger_1.ApiOperation)({ summary: '导出套餐数据到JSON' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '导出成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [package_search_dto_1.PackageSearchDto]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "exportToJSON", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '获取套餐详情' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新套餐' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)(null_to_undefined_pipe_1.NullToUndefinedPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_package_dto_1.UpdatePackageDto]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)('bulk/status'),
    (0, swagger_1.ApiOperation)({ summary: '批量更新套餐状态' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '批量更新成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [bulk_update_status_dto_1.BulkUpdateStatusDto]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "bulkUpdateStatus", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除套餐' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '删除成功' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)(':id/recommendations'),
    (0, swagger_1.ApiOperation)({ summary: '获取套餐关联推荐（交叉销售）' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "getRecommendations", null);
__decorate([
    (0, common_1.Get)(':id/statistics'),
    (0, swagger_1.ApiOperation)({ summary: '获取套餐统计信息' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PackagesController.prototype, "getPackageStatistics", null);
exports.PackagesController = PackagesController = PackagesController_1 = __decorate([
    (0, swagger_1.ApiTags)('packages'),
    (0, common_1.Controller)('packages'),
    __metadata("design:paramtypes", [packages_service_1.PackagesService])
], PackagesController);
//# sourceMappingURL=packages.controller.js.map