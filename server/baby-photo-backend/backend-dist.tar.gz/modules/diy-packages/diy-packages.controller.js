"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var DiyPackagesController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiyPackagesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const diy_packages_service_1 = require("./diy-packages.service");
const create_diy_package_dto_1 = require("./dto/create-diy-package.dto");
const update_diy_package_dto_1 = require("./dto/update-diy-package.dto");
const query_diy_package_dto_1 = require("./dto/query-diy-package.dto");
let DiyPackagesController = DiyPackagesController_1 = class DiyPackagesController {
    diyPackagesService;
    logger = new common_1.Logger(DiyPackagesController_1.name);
    constructor(diyPackagesService) {
        this.diyPackagesService = diyPackagesService;
    }
    create(createDto) {
        this.logger.log(`创建DIY套系: ${createDto.packageName}`);
        return this.diyPackagesService.create(createDto);
    }
    previewPricing(body) {
        return this.diyPackagesService.previewPricing(body.selectedItems, body.originalAmount);
    }
    findAll(query) {
        return this.diyPackagesService.findAll(query);
    }
    findOne(id) {
        return this.diyPackagesService.findOne(id);
    }
    update(id, updateDto) {
        this.logger.log(`更新DIY套系: ID=${id}`);
        return this.diyPackagesService.update(id, updateDto);
    }
    remove(id) {
        this.logger.log(`删除DIY套系: ID=${id}`);
        return this.diyPackagesService.remove(id);
    }
    createOrder(id, createOrderData) {
        this.logger.log(`从DIY套系创建订单: packageId=${id}`);
        return this.diyPackagesService.createOrderFromDiyPackage(id, {
            ...createOrderData,
            appointmentDate: createOrderData.appointmentDate
                ? new Date(createOrderData.appointmentDate)
                : undefined,
        });
    }
};
exports.DiyPackagesController = DiyPackagesController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建DIY套系' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '创建成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_diy_package_dto_1.CreateDiyPackageDto]),
    __metadata("design:returntype", void 0)
], DiyPackagesController.prototype, "create", null);
__decorate([
    (0, common_1.Post)('preview-pricing'),
    (0, swagger_1.ApiOperation)({ summary: '预览价格计算' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '计算成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], DiyPackagesController.prototype, "previewPricing", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取DIY套系列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_diy_package_dto_1.QueryDiyPackageDto]),
    __metadata("design:returntype", void 0)
], DiyPackagesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '获取DIY套系详情' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '套系ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], DiyPackagesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新DIY套系' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '套系ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, update_diy_package_dto_1.UpdateDiyPackageDto]),
    __metadata("design:returntype", void 0)
], DiyPackagesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除DIY套系' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '套系ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '删除成功' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], DiyPackagesController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)(':id/create-order'),
    (0, swagger_1.ApiOperation)({ summary: '从DIY套系创建订单' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '套系ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '订单创建成功' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", void 0)
], DiyPackagesController.prototype, "createOrder", null);
exports.DiyPackagesController = DiyPackagesController = DiyPackagesController_1 = __decorate([
    (0, swagger_1.ApiTags)('DIY套系管理'),
    (0, common_1.Controller)('diy-packages'),
    __metadata("design:paramtypes", [diy_packages_service_1.DiyPackagesService])
], DiyPackagesController);
//# sourceMappingURL=diy-packages.controller.js.map