export declare class DiyPackagesModule {
}
