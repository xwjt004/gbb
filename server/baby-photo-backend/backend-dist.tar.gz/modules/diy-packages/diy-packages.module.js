"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiyPackagesModule = void 0;
const common_1 = require("@nestjs/common");
const prisma_module_1 = require("../../shared/prisma/prisma.module");
const discount_rules_module_1 = require("../discount-rules/discount-rules.module");
const orders_module_1 = require("../orders/orders.module");
const diy_packages_service_1 = require("./diy-packages.service");
const diy_packages_controller_1 = require("./diy-packages.controller");
let DiyPackagesModule = class DiyPackagesModule {
};
exports.DiyPackagesModule = DiyPackagesModule;
exports.DiyPackagesModule = DiyPackagesModule = __decorate([
    (0, common_1.Module)({
        imports: [
            prisma_module_1.PrismaModule,
            discount_rules_module_1.DiscountRulesModule,
            (0, common_1.forwardRef)(() => orders_module_1.OrdersModule),
        ],
        controllers: [diy_packages_controller_1.DiyPackagesController],
        providers: [diy_packages_service_1.DiyPackagesService],
        exports: [diy_packages_service_1.DiyPackagesService],
    })
], DiyPackagesModule);
//# sourceMappingURL=diy-packages.module.js.map