export declare class QueryDiyPackageDto {
    keyword?: string;
    customerId?: number;
    status?: 'DRAFT' | 'CONFIRMED' | 'ORDERED';
    startDate?: string;
    endDate?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    page?: number;
    pageSize?: number;
}
