import { CreateDiyPackageDto } from './create-diy-package.dto';
declare const UpdateDiyPackageDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateDiyPackageDto>>;
export declare class UpdateDiyPackageDto extends UpdateDiyPackageDto_base {
    status?: 'DRAFT' | 'CONFIRMED' | 'ORDERED';
}
export {};
