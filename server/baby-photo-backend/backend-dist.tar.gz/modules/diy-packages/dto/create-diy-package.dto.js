"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateDiyPackageDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class SelectedItemDto {
    id;
    type;
    name;
    price;
    quantity;
    subtotal;
}
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品/服务ID' }),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], SelectedItemDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品/服务类型', enum: ['product', 'service'] }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SelectedItemDto.prototype, "type", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品/服务名称' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SelectedItemDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '单价' }),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], SelectedItemDto.prototype, "price", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '数量', default: 1 }),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], SelectedItemDto.prototype, "quantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '小计' }),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], SelectedItemDto.prototype, "subtotal", void 0);
class CustomerInfoDto {
    name;
    phone;
    notes;
}
__decorate([
    (0, swagger_1.ApiProperty)({ description: '客户姓名' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CustomerInfoDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '联系电话' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CustomerInfoDto.prototype, "phone", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '备注', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CustomerInfoDto.prototype, "notes", void 0);
class CreateDiyPackageDto {
    packageName;
    customerId;
    customerInfo;
    selectedItems;
    originalAmount;
    expiresAt;
}
exports.CreateDiyPackageDto = CreateDiyPackageDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套系名称' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateDiyPackageDto.prototype, "packageName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '客户ID', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CreateDiyPackageDto.prototype, "customerId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '客户信息', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateNested)(),
    (0, class_transformer_1.Type)(() => CustomerInfoDto),
    __metadata("design:type", CustomerInfoDto)
], CreateDiyPackageDto.prototype, "customerInfo", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '选中的商品和服务列表', type: [SelectedItemDto] }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => SelectedItemDto),
    __metadata("design:type", Array)
], CreateDiyPackageDto.prototype, "selectedItems", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '原始总价' }),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CreateDiyPackageDto.prototype, "originalAmount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套系过期时间', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateDiyPackageDto.prototype, "expiresAt", void 0);
//# sourceMappingURL=create-diy-package.dto.js.map