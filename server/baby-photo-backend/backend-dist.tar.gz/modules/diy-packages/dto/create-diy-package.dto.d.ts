declare class SelectedItemDto {
    id: number;
    type: 'product' | 'service';
    name: string;
    price: number;
    quantity: number;
    subtotal: number;
}
declare class CustomerInfoDto {
    name: string;
    phone: string;
    notes?: string;
}
export declare class CreateDiyPackageDto {
    packageName: string;
    customerId?: number;
    customerInfo?: CustomerInfoDto;
    selectedItems: SelectedItemDto[];
    originalAmount: number;
    expiresAt?: string;
}
export {};
