import { PrismaService } from '../../shared/prisma/prisma.service';
import { DiscountRulesService } from '../discount-rules/discount-rules.service';
import { OrdersService } from '../orders/orders.service';
import { CreateDiyPackageDto } from './dto/create-diy-package.dto';
import { UpdateDiyPackageDto } from './dto/update-diy-package.dto';
import { QueryDiyPackageDto } from './dto/query-diy-package.dto';
export declare class DiyPackagesService {
    private readonly prisma;
    private readonly discountRulesService;
    private readonly ordersService;
    private readonly logger;
    constructor(prisma: PrismaService, discountRulesService: DiscountRulesService, ordersService: OrdersService);
    create(createDto: CreateDiyPackageDto): Promise<{
        code: number;
        message: string;
        data: {
            discountRule: {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                description: string | null;
                discountRate: import("@prisma/client/runtime/library").Decimal;
                minAmount: import("@prisma/client/runtime/library").Decimal;
                maxAmount: import("@prisma/client/runtime/library").Decimal;
                isActive: boolean;
            } | null;
        } & {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            discountAmount: import("@prisma/client/runtime/library").Decimal;
            wxUserId: string | null;
            status: string;
            packageName: string;
            customerId: number | null;
            customerInfo: import("@prisma/client/runtime/library").JsonValue | null;
            selectedItems: import("@prisma/client/runtime/library").JsonValue;
            originalAmount: import("@prisma/client/runtime/library").Decimal;
            discountRate: import("@prisma/client/runtime/library").Decimal;
            savedAmount: import("@prisma/client/runtime/library").Decimal;
            discountRuleId: number | null;
            expiresAt: Date | null;
        };
    }>;
    findAll(query: QueryDiyPackageDto): Promise<{
        code: number;
        message: string;
        data: {
            list: {
                orderCount: number;
                totalSalesAmount: number;
                discountRule: {
                    id: number;
                    createdAt: Date;
                    updatedAt: Date;
                    name: string;
                    description: string | null;
                    discountRate: import("@prisma/client/runtime/library").Decimal;
                    minAmount: import("@prisma/client/runtime/library").Decimal;
                    maxAmount: import("@prisma/client/runtime/library").Decimal;
                    isActive: boolean;
                } | null;
                id: number;
                createdAt: Date;
                updatedAt: Date;
                discountAmount: import("@prisma/client/runtime/library").Decimal;
                wxUserId: string | null;
                status: string;
                packageName: string;
                customerId: number | null;
                customerInfo: import("@prisma/client/runtime/library").JsonValue | null;
                selectedItems: import("@prisma/client/runtime/library").JsonValue;
                originalAmount: import("@prisma/client/runtime/library").Decimal;
                discountRate: import("@prisma/client/runtime/library").Decimal;
                savedAmount: import("@prisma/client/runtime/library").Decimal;
                discountRuleId: number | null;
                expiresAt: Date | null;
            }[];
            pagination: {
                page: number;
                pageSize: number;
                total: number;
                totalPages: number;
            };
        };
    }>;
    findOne(id: number): Promise<{
        code: number;
        message: string;
        data: {
            orderCount: number;
            totalSalesAmount: number;
            discountRule: {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                description: string | null;
                discountRate: import("@prisma/client/runtime/library").Decimal;
                minAmount: import("@prisma/client/runtime/library").Decimal;
                maxAmount: import("@prisma/client/runtime/library").Decimal;
                isActive: boolean;
            } | null;
            id: number;
            createdAt: Date;
            updatedAt: Date;
            discountAmount: import("@prisma/client/runtime/library").Decimal;
            wxUserId: string | null;
            status: string;
            packageName: string;
            customerId: number | null;
            customerInfo: import("@prisma/client/runtime/library").JsonValue | null;
            selectedItems: import("@prisma/client/runtime/library").JsonValue;
            originalAmount: import("@prisma/client/runtime/library").Decimal;
            discountRate: import("@prisma/client/runtime/library").Decimal;
            savedAmount: import("@prisma/client/runtime/library").Decimal;
            discountRuleId: number | null;
            expiresAt: Date | null;
        };
    }>;
    update(id: number, updateDto: UpdateDiyPackageDto): Promise<{
        code: number;
        message: string;
        data: {
            discountRule: {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                description: string | null;
                discountRate: import("@prisma/client/runtime/library").Decimal;
                minAmount: import("@prisma/client/runtime/library").Decimal;
                maxAmount: import("@prisma/client/runtime/library").Decimal;
                isActive: boolean;
            } | null;
        } & {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            discountAmount: import("@prisma/client/runtime/library").Decimal;
            wxUserId: string | null;
            status: string;
            packageName: string;
            customerId: number | null;
            customerInfo: import("@prisma/client/runtime/library").JsonValue | null;
            selectedItems: import("@prisma/client/runtime/library").JsonValue;
            originalAmount: import("@prisma/client/runtime/library").Decimal;
            discountRate: import("@prisma/client/runtime/library").Decimal;
            savedAmount: import("@prisma/client/runtime/library").Decimal;
            discountRuleId: number | null;
            expiresAt: Date | null;
        };
    }>;
    remove(id: number): Promise<{
        code: number;
        message: string;
    }>;
    previewPricing(selectedItems: any[], originalAmount: number): Promise<{
        code: number;
        message: string;
        data: {
            selectedItems: any[];
            originalAmount: number;
            discountAmount: number;
            discountRate: number;
            savedAmount: number;
            appliedRule: {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                description: string | null;
                discountRate: import("@prisma/client/runtime/library").Decimal;
                minAmount: import("@prisma/client/runtime/library").Decimal;
                maxAmount: import("@prisma/client/runtime/library").Decimal;
                isActive: boolean;
            } | null;
        };
    }>;
    createOrderFromDiyPackage(diyPackageId: number, data: {
        userOpenid: string;
        timeSlotId?: number;
        appointmentDate?: Date;
        childrenCount?: number;
        customerName?: string;
        notes?: string;
    }): Promise<{
        code: number;
        message: string;
        data: {
            order: {
                id: string;
                orderNo: string;
                appointmentDate: Date | null;
                totalAmount: import("@prisma/client/runtime/library").Decimal;
                depositAmount: import("@prisma/client/runtime/library").Decimal;
                paidAmount: import("@prisma/client/runtime/library").Decimal;
                notes: string | null;
                childrenCount: number;
                createdAt: Date;
                updatedAt: Date;
                customerName: string | null;
                customerPhone: string | null;
                couponId: string | null;
                discountAmount: import("@prisma/client/runtime/library").Decimal;
                shippingAddressId: string | null;
                shippingInfo: import("@prisma/client/runtime/library").JsonValue | null;
                source: import("@prisma/client").$Enums.OrderSource;
                deletedAt: Date | null;
                depositTimeout: Date | null;
                finalTimeout: Date | null;
                paymentMode: import("@prisma/client").$Enums.PaymentMode;
                paymentSummary: import("@prisma/client/runtime/library").JsonValue | null;
                refundedAmount: import("@prisma/client/runtime/library").Decimal;
                remainingAmount: import("@prisma/client/runtime/library").Decimal;
                paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
                orderStatus: import("@prisma/client").$Enums.OrderStatus;
                agreementAccepted: boolean | null;
                agreementVersion: string | null;
                agreementAcceptedAt: Date | null;
                checkinStatus: string;
                checkinTime: Date | null;
                reminderSentAt: Date | null;
                completedAt: Date | null;
                photoPickReminderSentAt: Date | null;
                userId: number;
                packageId: number | null;
                timeSlotId: number | null;
                diyPackageId: number | null;
                wxUserId: string | null;
                photographerId: number | null;
            };
            diyPackage: {
                discountRule: {
                    id: number;
                    createdAt: Date;
                    updatedAt: Date;
                    name: string;
                    description: string | null;
                    discountRate: import("@prisma/client/runtime/library").Decimal;
                    minAmount: import("@prisma/client/runtime/library").Decimal;
                    maxAmount: import("@prisma/client/runtime/library").Decimal;
                    isActive: boolean;
                } | null;
            } & {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                discountAmount: import("@prisma/client/runtime/library").Decimal;
                wxUserId: string | null;
                status: string;
                packageName: string;
                customerId: number | null;
                customerInfo: import("@prisma/client/runtime/library").JsonValue | null;
                selectedItems: import("@prisma/client/runtime/library").JsonValue;
                originalAmount: import("@prisma/client/runtime/library").Decimal;
                discountRate: import("@prisma/client/runtime/library").Decimal;
                savedAmount: import("@prisma/client/runtime/library").Decimal;
                discountRuleId: number | null;
                expiresAt: Date | null;
            };
        };
    }>;
}
