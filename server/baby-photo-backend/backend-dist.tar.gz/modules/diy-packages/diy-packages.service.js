"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var DiyPackagesService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiyPackagesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const discount_rules_service_1 = require("../discount-rules/discount-rules.service");
const orders_service_1 = require("../orders/orders.service");
let DiyPackagesService = DiyPackagesService_1 = class DiyPackagesService {
    prisma;
    discountRulesService;
    ordersService;
    logger = new common_1.Logger(DiyPackagesService_1.name);
    constructor(prisma, discountRulesService, ordersService) {
        this.prisma = prisma;
        this.discountRulesService = discountRulesService;
        this.ordersService = ordersService;
    }
    async create(createDto) {
        this.logger.log(`创建DIY套系: ${createDto.packageName}`);
        try {
            const discountResult = await this.discountRulesService.calculateDiscount(createDto.originalAmount);
            const diyPackage = await this.prisma.diyPackage.create({
                data: {
                    packageName: createDto.packageName,
                    customerId: createDto.customerId,
                    customerInfo: createDto.customerInfo,
                    selectedItems: createDto.selectedItems,
                    originalAmount: createDto.originalAmount,
                    discountAmount: discountResult.data.discountAmount,
                    discountRate: discountResult.data.discountRate,
                    savedAmount: discountResult.data.savedAmount,
                    discountRuleId: discountResult.data.rule?.id,
                    expiresAt: createDto.expiresAt ? new Date(createDto.expiresAt) : null,
                },
                include: {
                    discountRule: true,
                },
            });
            this.logger.log(`DIY套系创建成功: ID=${diyPackage.id}`);
            return {
                code: 200,
                message: '创建成功',
                data: diyPackage,
            };
        }
        catch (error) {
            this.logger.error(`创建DIY套系失败: ${error.message}`);
            throw error;
        }
    }
    async findAll(query) {
        const { keyword, customerId, status, startDate, endDate, sortBy, sortOrder = 'desc', page = 1, pageSize = 20 } = query;
        const where = {};
        if (keyword) {
            where.packageName = { contains: keyword };
        }
        if (customerId)
            where.customerId = customerId;
        if (status)
            where.status = status;
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate) {
                where.createdAt.gte = new Date(startDate);
            }
            if (endDate) {
                const endDateTime = new Date(endDate);
                endDateTime.setHours(23, 59, 59, 999);
                where.createdAt.lte = endDateTime;
            }
        }
        try {
            const total = await this.prisma.diyPackage.count({ where });
            const allList = await this.prisma.diyPackage.findMany({
                where,
                include: {
                    discountRule: true,
                    orders: {
                        select: {
                            id: true,
                            totalAmount: true,
                            orderStatus: true,
                            paymentStatus: true,
                        },
                    },
                },
                orderBy: [
                    { createdAt: 'desc' },
                ],
            });
            let listWithStats = allList.map((pkg) => {
                const orderCount = pkg.orders?.length || 0;
                const totalSalesAmount = pkg.orders?.reduce((sum, order) => {
                    return sum + (Number(order.totalAmount) || 0);
                }, 0) || 0;
                const { orders, ...pkgWithoutOrders } = pkg;
                return {
                    ...pkgWithoutOrders,
                    orderCount,
                    totalSalesAmount,
                };
            });
            if (sortBy === 'orderCount' || sortBy === 'totalSalesAmount') {
                listWithStats.sort((a, b) => {
                    const aValue = a[sortBy] || 0;
                    const bValue = b[sortBy] || 0;
                    return sortOrder === 'asc' ? aValue - bValue : bValue - aValue;
                });
            }
            else if (sortBy === 'createdAt') {
                listWithStats.sort((a, b) => {
                    const aTime = new Date(a.createdAt).getTime();
                    const bTime = new Date(b.createdAt).getTime();
                    return sortOrder === 'asc' ? aTime - bTime : bTime - aTime;
                });
            }
            const startIndex = (page - 1) * pageSize;
            const endIndex = startIndex + pageSize;
            const paginatedList = listWithStats.slice(startIndex, endIndex);
            return {
                code: 200,
                message: '查询成功',
                data: {
                    list: paginatedList,
                    pagination: {
                        page,
                        pageSize,
                        total,
                        totalPages: Math.ceil(total / pageSize),
                    },
                },
            };
        }
        catch (error) {
            this.logger.error(`查询DIY套系列表失败: ${error.message}`);
            throw error;
        }
    }
    async findOne(id) {
        try {
            const diyPackage = await this.prisma.diyPackage.findUnique({
                where: { id },
                include: {
                    discountRule: true,
                    orders: {
                        select: {
                            id: true,
                            totalAmount: true,
                            orderStatus: true,
                            paymentStatus: true,
                        },
                    },
                },
            });
            if (!diyPackage) {
                throw new common_1.NotFoundException(`DIY套系 ID=${id} 不存在`);
            }
            const orderCount = diyPackage.orders?.length || 0;
            const totalSalesAmount = diyPackage.orders?.reduce((sum, order) => {
                return sum + (Number(order.totalAmount) || 0);
            }, 0) || 0;
            const { orders, ...pkgWithoutOrders } = diyPackage;
            return {
                code: 200,
                message: '查询成功',
                data: {
                    ...pkgWithoutOrders,
                    orderCount,
                    totalSalesAmount,
                },
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`查询DIY套系失败: ${error.message}`);
            throw error;
        }
    }
    async update(id, updateDto) {
        this.logger.log(`更新DIY套系: ID=${id}`);
        const existing = await this.prisma.diyPackage.findUnique({
            where: { id },
        });
        if (!existing) {
            throw new common_1.NotFoundException(`DIY套系 ID=${id} 不存在`);
        }
        try {
            let discountData = {};
            if (updateDto.originalAmount && updateDto.originalAmount !== Number(existing.originalAmount)) {
                const discountResult = await this.discountRulesService.calculateDiscount(updateDto.originalAmount);
                discountData = {
                    discountAmount: discountResult.data.discountAmount,
                    discountRate: discountResult.data.discountRate,
                    savedAmount: discountResult.data.savedAmount,
                    discountRuleId: discountResult.data.rule?.id,
                };
            }
            const diyPackage = await this.prisma.diyPackage.update({
                where: { id },
                data: {
                    ...updateDto,
                    customerInfo: updateDto.customerInfo,
                    selectedItems: updateDto.selectedItems,
                    ...discountData,
                    expiresAt: updateDto.expiresAt ? new Date(updateDto.expiresAt) : undefined,
                },
                include: {
                    discountRule: true,
                },
            });
            this.logger.log(`DIY套系更新成功: ID=${id}`);
            return {
                code: 200,
                message: '更新成功',
                data: diyPackage,
            };
        }
        catch (error) {
            this.logger.error(`更新DIY套系失败: ${error.message}`);
            throw error;
        }
    }
    async remove(id) {
        this.logger.log(`删除DIY套系: ID=${id}`);
        const existing = await this.prisma.diyPackage.findUnique({
            where: { id },
            include: { orders: true },
        });
        if (!existing) {
            throw new common_1.NotFoundException(`DIY套系 ID=${id} 不存在`);
        }
        if (existing.orders.length > 0) {
            throw new common_1.ConflictException('该DIY套系已有订单，无法删除');
        }
        try {
            await this.prisma.diyPackage.delete({
                where: { id },
            });
            this.logger.log(`DIY套系删除成功: ID=${id}`);
            return {
                code: 200,
                message: '删除成功',
            };
        }
        catch (error) {
            this.logger.error(`删除DIY套系失败: ${error.message}`);
            throw error;
        }
    }
    async previewPricing(selectedItems, originalAmount) {
        try {
            const discountResult = await this.discountRulesService.calculateDiscount(originalAmount);
            return {
                code: 200,
                message: '计算成功',
                data: {
                    selectedItems,
                    originalAmount,
                    discountAmount: discountResult.data.discountAmount,
                    discountRate: discountResult.data.discountRate,
                    savedAmount: discountResult.data.savedAmount,
                    appliedRule: discountResult.data.rule,
                },
            };
        }
        catch (error) {
            this.logger.error(`预览价格计算失败: ${error.message}`);
            throw error;
        }
    }
    async createOrderFromDiyPackage(diyPackageId, data) {
        this.logger.log(`从DIY套系创建订单: packageId=${diyPackageId}`);
        try {
            const diyPackage = await this.prisma.diyPackage.findUnique({
                where: { id: diyPackageId },
                include: { discountRule: true },
            });
            if (!diyPackage) {
                throw new common_1.NotFoundException(`DIY套系 ID=${diyPackageId} 不存在`);
            }
            const finalAmount = Number(diyPackage.originalAmount) - Number(diyPackage.discountAmount);
            const customerInfo = diyPackage.customerInfo;
            const orderData = {
                userOpenid: data.userOpenid,
                diyPackageId: diyPackageId,
                packageId: null,
                timeSlotId: data.timeSlotId,
                appointmentDate: data.appointmentDate,
                totalAmount: finalAmount,
                depositAmount: 0,
                childrenCount: data.childrenCount || 1,
                customerName: data.customerName || customerInfo?.name || '',
                notes: data.notes || `DIY套系订单: ${diyPackage.packageName}`,
            };
            const orderResult = await this.ordersService.create(orderData);
            this.logger.log(`从DIY套系创建订单成功: orderId=${orderResult.id}`);
            return {
                code: 200,
                message: '订单创建成功',
                data: {
                    order: orderResult,
                    diyPackage,
                },
            };
        }
        catch (error) {
            this.logger.error(`从DIY套系创建订单失败: ${error.message}`);
            throw error;
        }
    }
};
exports.DiyPackagesService = DiyPackagesService;
exports.DiyPackagesService = DiyPackagesService = DiyPackagesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(2, (0, common_1.Inject)((0, common_1.forwardRef)(() => orders_service_1.OrdersService))),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        discount_rules_service_1.DiscountRulesService,
        orders_service_1.OrdersService])
], DiyPackagesService);
//# sourceMappingURL=diy-packages.service.js.map