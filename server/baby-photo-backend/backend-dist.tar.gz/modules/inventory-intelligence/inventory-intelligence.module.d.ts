export declare class InventoryIntelligenceModule {
}
