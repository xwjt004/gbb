"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateSafetyStockDto = exports.BatchCalculateDto = exports.SafetyStockQueryDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class SafetyStockQueryDto {
    productId;
    page;
    pageSize;
}
exports.SafetyStockQueryDto = SafetyStockQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Filter by product ID' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    __metadata("design:type", Number)
], SafetyStockQueryDto.prototype, "productId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Page number', default: 1 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], SafetyStockQueryDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Page size', default: 20 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], SafetyStockQueryDto.prototype, "pageSize", void 0);
class BatchCalculateDto {
    serviceLevel;
    demandPeriodDays;
}
exports.BatchCalculateDto = BatchCalculateDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Service level (0-1)', default: 0.95 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0.5),
    (0, class_validator_1.Max)(0.999),
    __metadata("design:type", Number)
], BatchCalculateDto.prototype, "serviceLevel", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Demand lookback period in days', default: 90 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(30),
    __metadata("design:type", Number)
], BatchCalculateDto.prototype, "demandPeriodDays", void 0);
class UpdateSafetyStockDto {
    serviceLevel;
    demandPeriodDays;
}
exports.UpdateSafetyStockDto = UpdateSafetyStockDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Service level (0-1)', default: 0.95 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0.5),
    (0, class_validator_1.Max)(0.999),
    __metadata("design:type", Number)
], UpdateSafetyStockDto.prototype, "serviceLevel", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Demand lookback period in days', default: 90 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(30),
    __metadata("design:type", Number)
], UpdateSafetyStockDto.prototype, "demandPeriodDays", void 0);
//# sourceMappingURL=safety-stock.dto.js.map