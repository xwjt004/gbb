export declare class SafetyStockQueryDto {
    productId?: number;
    page?: number;
    pageSize?: number;
}
export declare class BatchCalculateDto {
    serviceLevel?: number;
    demandPeriodDays?: number;
}
export declare class UpdateSafetyStockDto {
    serviceLevel?: number;
    demandPeriodDays?: number;
}
