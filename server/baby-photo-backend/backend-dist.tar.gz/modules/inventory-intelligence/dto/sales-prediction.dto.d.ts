export declare class PredictionQueryDto {
    method?: string;
    periods?: number;
    alpha?: number;
    productIds?: number[];
    page?: number;
    pageSize?: number;
}
export declare class ProductPredictionQueryDto {
    method?: string;
    periods?: number;
    alpha?: number;
}
