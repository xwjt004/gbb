export declare class RestockSuggestionQueryDto {
    urgency?: string;
    page?: number;
    pageSize?: number;
}
export declare class ConvertSuggestionDto {
    supplierId?: string;
}
