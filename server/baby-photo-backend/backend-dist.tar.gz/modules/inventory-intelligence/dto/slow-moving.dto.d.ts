export declare class SlowMovingQueryDto {
    thresholdDays?: number;
    categoryId?: number;
    status?: string;
    page?: number;
    pageSize?: number;
}
