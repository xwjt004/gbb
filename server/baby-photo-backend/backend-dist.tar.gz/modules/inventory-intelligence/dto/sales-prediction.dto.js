"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductPredictionQueryDto = exports.PredictionQueryDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class PredictionQueryDto {
    method;
    periods;
    alpha;
    productIds;
    page;
    pageSize;
}
exports.PredictionQueryDto = PredictionQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Forecast method: MA or ES', default: 'MA' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PredictionQueryDto.prototype, "method", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Lookback/forecast periods in days', default: 30 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(7),
    __metadata("design:type", Number)
], PredictionQueryDto.prototype, "periods", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Exponential smoothing alpha (0.1-0.5)', default: 0.3 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0.1),
    (0, class_validator_1.Max)(0.5),
    __metadata("design:type", Number)
], PredictionQueryDto.prototype, "alpha", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Filter by product IDs' }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Array)
], PredictionQueryDto.prototype, "productIds", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Page number', default: 1 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], PredictionQueryDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Page size', default: 20 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], PredictionQueryDto.prototype, "pageSize", void 0);
class ProductPredictionQueryDto {
    method;
    periods;
    alpha;
}
exports.ProductPredictionQueryDto = ProductPredictionQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Forecast method: MA or ES', default: 'MA' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ProductPredictionQueryDto.prototype, "method", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Lookback/forecast periods in days', default: 30 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(7),
    __metadata("design:type", Number)
], ProductPredictionQueryDto.prototype, "periods", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Exponential smoothing alpha (0.1-0.5)', default: 0.3 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0.1),
    (0, class_validator_1.Max)(0.5),
    __metadata("design:type", Number)
], ProductPredictionQueryDto.prototype, "alpha", void 0);
//# sourceMappingURL=sales-prediction.dto.js.map