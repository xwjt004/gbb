export declare class TurnoverQueryDto {
    categoryId?: number;
    startDate?: string;
    endDate?: string;
    productId?: number;
}
