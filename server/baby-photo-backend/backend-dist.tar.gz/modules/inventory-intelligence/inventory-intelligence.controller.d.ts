import { SalesPredictionService } from './services/sales-prediction.service';
import { SafetyStockService } from './services/safety-stock.service';
import { RestockSuggestionService } from './services/restock-suggestion.service';
import { SlowMovingService } from './services/slow-moving.service';
import { TurnoverAnalysisService } from './services/turnover-analysis.service';
import { PredictionQueryDto, ProductPredictionQueryDto } from './dto/sales-prediction.dto';
import { SafetyStockQueryDto, BatchCalculateDto, UpdateSafetyStockDto } from './dto/safety-stock.dto';
import { RestockSuggestionQueryDto, ConvertSuggestionDto } from './dto/restock-suggestion.dto';
import { SlowMovingQueryDto } from './dto/slow-moving.dto';
import { TurnoverQueryDto } from './dto/turnover-analysis.dto';
export declare class InventoryIntelligenceController {
    private readonly salesPredictionService;
    private readonly safetyStockService;
    private readonly restockSuggestionService;
    private readonly slowMovingService;
    private readonly turnoverAnalysisService;
    constructor(salesPredictionService: SalesPredictionService, safetyStockService: SafetyStockService, restockSuggestionService: RestockSuggestionService, slowMovingService: SlowMovingService, turnoverAnalysisService: TurnoverAnalysisService);
    getSalesPrediction(query: PredictionQueryDto): Promise<{
        code: number;
        message: string;
        data: {
            items: {
                productId: any;
                productName: any;
                productNo: any;
                currentStock: any;
                method: string;
                forecastDaily: number;
                forecastMonthly: number;
                confidence: number;
                last30dSales: number;
            }[];
            pagination: {
                current: number;
                pageSize: number;
                total: number;
            };
        };
    }>;
    getProductSalesPrediction(productId: string, query: ProductPredictionQueryDto): Promise<{
        code: number;
        message: string;
        data: {
            productId: number;
            forecastDaily: number;
            forecastMonthly: number;
            historicalData: never[];
            smoothedValues: never[];
            productName?: undefined;
            productNo?: undefined;
            currentStock?: undefined;
            method?: undefined;
        } | {
            productId: number;
            productName: string;
            productNo: string;
            currentStock: number;
            method: string;
            forecastDaily: number;
            forecastMonthly: number;
            historicalData: {
                date: string;
                qty: number;
            }[];
            smoothedValues: {
                date: string;
                actual: number;
                smoothed: number;
            }[] | undefined;
        };
    }>;
    getSafetyStock(query: SafetyStockQueryDto): Promise<{
        code: number;
        message: string;
        data: {
            items: {
                id: number;
                name: string;
                productNo: string;
                costPrice: import("@prisma/client/runtime/library").Decimal;
                stockQuantity: number;
                reorderPoint: number | null;
                safetyStock: number;
                dailyConsumption: number;
            }[];
            pagination: {
                current: number;
                pageSize: number;
                total: number;
            };
        };
    }>;
    batchCalculateSafetyStock(dto: BatchCalculateDto): Promise<{
        code: number;
        message: string;
        data: {
            total: number;
            updated: number;
            errors: {
                productId: number;
                error: string;
            }[];
        };
    }>;
    updateSafetyStockConfig(productId: string, dto: UpdateSafetyStockDto): Promise<{
        code: number;
        message: string;
        data: any;
    }>;
    getRestockSuggestions(query: RestockSuggestionQueryDto): Promise<{
        code: number;
        message: string;
        data: {
            items: {
                id: any;
                productId: any;
                productName: any;
                currentStock: any;
                minStock: any;
                suggestedQty: any;
                status: any;
                daysUntilStockout: number;
                urgency: string;
                createdAt: any;
            }[];
            pagination: {
                current: number;
                pageSize: number;
                total: number;
            };
        };
    }>;
    generateRestockSuggestions(): Promise<{
        code: number;
        message: string;
        data: {
            generated: number;
            suggestions: any[];
        };
    }>;
    convertSuggestion(id: string, dto: ConvertSuggestionDto): Promise<{
        code: number;
        message: string;
        data: {
            error: string;
            purchaseOrderId?: undefined;
            purchaseNo?: undefined;
        } | {
            purchaseOrderId: string;
            purchaseNo: string;
            error?: undefined;
        };
    }>;
    getSlowMovingProducts(query: SlowMovingQueryDto): Promise<{
        code: number;
        message: string;
        data: {
            items: {
                productId: any;
                productName: any;
                productNo: any;
                categoryName: any;
                stockQuantity: any;
                costPrice: number;
                stockValue: number;
                lastSaleDate: Date | null;
                daysSinceLastSale: number;
                thresholdDays: number;
                status: string;
            }[];
            summary: {
                totalSlowMoving: number;
                totalDeadStock: number;
                totalStockValue: any;
            };
            pagination: {
                current: number;
                pageSize: number;
                total: number;
            };
        };
    }>;
    checkSlowMoving(): Promise<{
        code: number;
        message: string;
        data: {
            checkedProducts: number;
            slowMovingCount: number;
            alertsCreated: number;
        };
    }>;
    getTurnoverAnalysis(query: TurnoverQueryDto): Promise<{
        code: number;
        message: string;
        data: {
            overall: {
                turnoverRatio: number;
                daysInventoryOutstanding: number | null;
                averageInventory: number;
                cogs: number;
                currentStockValue: number;
            };
            byCategory: {
                categoryId: any;
                categoryName: any;
                turnoverRatio: number;
                dio: number | null;
                stockValue: number;
                suggestion: string;
            }[];
            topSlowest: {
                productId: any;
                productName: any;
                turnoverRatio: number;
                dio: number | null;
                stockQuantity: any;
                stockValue: number;
                suggestion: string;
            }[];
        };
    }>;
    getTurnoverReport(query: TurnoverQueryDto): Promise<{
        code: number;
        message: string;
        data: {
            overview: {
                turnoverRatio: number;
                daysInventoryOutstanding: number | null;
                averageInventory: number;
                cogs: number;
                currentStockValue: number;
            };
            details: {
                productId: any;
                productName: any;
                stockQuantity: any;
                costPrice: number;
                stockValue: number;
                dailyConsumption: any;
                daysOfStock: number;
                evaluation: string;
                suggestion: string;
            }[];
            optimizationSuggestions: {
                overstocked: {
                    productName: any;
                    stockValue: any;
                    suggestion: string;
                }[];
                understocked: {
                    productName: any;
                    suggestion: string;
                }[];
                fastMoving: {
                    productName: any;
                    suggestion: string;
                }[];
            };
        };
    }>;
    refreshTurnoverData(): Promise<{
        code: number;
        message: string;
        data: {
            overall: {
                turnoverRatio: number;
                daysInventoryOutstanding: number | null;
                averageInventory: number;
                cogs: number;
                currentStockValue: number;
            };
            byCategory: {
                categoryId: any;
                categoryName: any;
                turnoverRatio: number;
                dio: number | null;
                stockValue: number;
                suggestion: string;
            }[];
            topSlowest: {
                productId: any;
                productName: any;
                turnoverRatio: number;
                dio: number | null;
                stockQuantity: any;
                stockValue: number;
                suggestion: string;
            }[];
        };
    }>;
}
