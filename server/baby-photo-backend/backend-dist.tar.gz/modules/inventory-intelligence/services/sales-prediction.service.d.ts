import { PrismaService } from '../../../shared/prisma/prisma.service';
import { PredictionQueryDto, ProductPredictionQueryDto } from '../dto/sales-prediction.dto';
export declare class SalesPredictionService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getBatchForecasts(query: PredictionQueryDto): Promise<{
        items: {
            productId: any;
            productName: any;
            productNo: any;
            currentStock: any;
            method: string;
            forecastDaily: number;
            forecastMonthly: number;
            confidence: number;
            last30dSales: number;
        }[];
        pagination: {
            current: number;
            pageSize: number;
            total: number;
        };
    }>;
    getProductForecast(productId: number, query: ProductPredictionQueryDto): Promise<{
        productId: number;
        forecastDaily: number;
        forecastMonthly: number;
        historicalData: never[];
        smoothedValues: never[];
        productName?: undefined;
        productNo?: undefined;
        currentStock?: undefined;
        method?: undefined;
    } | {
        productId: number;
        productName: string;
        productNo: string;
        currentStock: number;
        method: string;
        forecastDaily: number;
        forecastMonthly: number;
        historicalData: {
            date: string;
            qty: number;
        }[];
        smoothedValues: {
            date: string;
            actual: number;
            smoothed: number;
        }[] | undefined;
    }>;
    private getDailyOutboundQty;
    private calcMovingAverage;
    private calcExponentialSmoothing;
    private getSmoothingSeries;
    private calcConfidence;
}
