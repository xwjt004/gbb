"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var SalesPredictionService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesPredictionService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
let SalesPredictionService = SalesPredictionService_1 = class SalesPredictionService {
    prisma;
    logger = new common_1.Logger(SalesPredictionService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getBatchForecasts(query) {
        const method = query.method || 'MA';
        const periods = query.periods || 30;
        const alpha = query.alpha || 0.3;
        const page = query.page || 1;
        const pageSize = query.pageSize || 20;
        const where = { isActive: true, isTrackStock: true };
        if (query.productIds?.length) {
            where.id = { in: query.productIds };
        }
        const [products, total] = await Promise.all([
            this.prisma.product.findMany({
                where,
                select: { id: true, name: true, productNo: true, stockQuantity: true, salesVolume: true, costPrice: true },
                skip: (page - 1) * pageSize,
                take: pageSize,
                orderBy: { id: 'asc' },
            }),
            this.prisma.product.count({ where }),
        ]);
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - periods * 2);
        const items = await Promise.all(products.map(async (product) => {
            const dailyMap = await this.getDailyOutboundQty(product.id, startDate, endDate);
            const dailyValues = Object.values(dailyMap);
            const last30dSales = dailyValues.slice(-30).reduce((s, v) => s + v, 0);
            let forecastDaily = 0;
            let confidence = 0;
            if (dailyValues.length >= 7) {
                if (method === 'ES') {
                    forecastDaily = this.calcExponentialSmoothing(dailyValues, alpha);
                    confidence = this.calcConfidence(dailyValues, forecastDaily);
                }
                else {
                    forecastDaily = this.calcMovingAverage(dailyValues, Math.min(periods, dailyValues.length));
                    confidence = this.calcConfidence(dailyValues, forecastDaily);
                }
            }
            if (forecastDaily > 0) {
                await this.prisma.product.update({
                    where: { id: product.id },
                    data: { dailyConsumption: Math.round(forecastDaily) },
                }).catch(() => { });
            }
            return {
                productId: product.id,
                productName: product.name,
                productNo: product.productNo,
                currentStock: product.stockQuantity,
                method,
                forecastDaily: Math.round(forecastDaily * 10) / 10,
                forecastMonthly: Math.round(forecastDaily * 30),
                confidence: Math.round(confidence * 100) / 100,
                last30dSales,
            };
        }));
        return { items, pagination: { current: page, pageSize, total } };
    }
    async getProductForecast(productId, query) {
        const method = query.method || 'MA';
        const periods = query.periods || 30;
        const alpha = query.alpha || 0.3;
        const product = await this.prisma.product.findUnique({
            where: { id: productId },
            select: { id: true, name: true, productNo: true, stockQuantity: true, costPrice: true },
        });
        if (!product) {
            return { productId, forecastDaily: 0, forecastMonthly: 0, historicalData: [], smoothedValues: [] };
        }
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - periods * 2);
        const dailyMap = await this.getDailyOutboundQty(productId, startDate, endDate);
        const historicalData = Object.entries(dailyMap)
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([date, qty]) => ({ date, qty }));
        const dailyValues = historicalData.map((d) => d.qty);
        let forecastDaily = 0;
        let smoothedValues = [];
        if (dailyValues.length >= 7) {
            if (method === 'ES') {
                forecastDaily = this.calcExponentialSmoothing(dailyValues, alpha);
                smoothedValues = this.getSmoothingSeries(historicalData, dailyValues, alpha);
            }
            else {
                forecastDaily = this.calcMovingAverage(dailyValues, Math.min(periods, dailyValues.length));
            }
        }
        return {
            productId: product.id,
            productName: product.name,
            productNo: product.productNo,
            currentStock: product.stockQuantity,
            method,
            forecastDaily: Math.round(forecastDaily * 10) / 10,
            forecastMonthly: Math.round(forecastDaily * 30),
            historicalData: historicalData.slice(-periods),
            smoothedValues: method === 'ES' ? smoothedValues.slice(-periods) : undefined,
        };
    }
    async getDailyOutboundQty(productId, startDate, endDate) {
        const transactions = await this.prisma.stockTransaction.findMany({
            where: {
                productId,
                transactionType: 'OUTBOUND',
                createdAt: { gte: startDate, lte: endDate },
            },
            select: { createdAt: true, quantity: true },
            orderBy: { createdAt: 'asc' },
        });
        const dailyMap = {};
        for (const txn of transactions) {
            const dateKey = txn.createdAt.toISOString().slice(0, 10);
            dailyMap[dateKey] = (dailyMap[dateKey] || 0) + txn.quantity;
        }
        return dailyMap;
    }
    calcMovingAverage(dailyValues, window) {
        if (dailyValues.length < window)
            return 0;
        const recent = dailyValues.slice(-window);
        return recent.reduce((s, v) => s + v, 0) / window;
    }
    calcExponentialSmoothing(dailyValues, alpha) {
        if (dailyValues.length === 0)
            return 0;
        let smoothed = dailyValues[0];
        for (let i = 1; i < dailyValues.length; i++) {
            smoothed = alpha * dailyValues[i] + (1 - alpha) * smoothed;
        }
        return smoothed;
    }
    getSmoothingSeries(historicalData, dailyValues, alpha) {
        if (dailyValues.length === 0)
            return [];
        let smoothed = dailyValues[0];
        const result = [{ date: historicalData[0].date, actual: dailyValues[0], smoothed }];
        for (let i = 1; i < dailyValues.length; i++) {
            smoothed = alpha * dailyValues[i] + (1 - alpha) * smoothed;
            result.push({ date: historicalData[i].date, actual: dailyValues[i], smoothed: Math.round(smoothed * 10) / 10 });
        }
        return result;
    }
    calcConfidence(dailyValues, forecast) {
        if (forecast <= 0 || dailyValues.length < 7)
            return 0;
        const mean = dailyValues.reduce((s, v) => s + v, 0) / dailyValues.length;
        if (mean <= 0)
            return 0.5;
        const variance = dailyValues.reduce((s, v) => s + (v - mean) ** 2, 0) / dailyValues.length;
        const stdDev = Math.sqrt(variance);
        const cv = stdDev / mean;
        return Math.max(0.1, Math.min(0.95, 1 - cv));
    }
};
exports.SalesPredictionService = SalesPredictionService;
exports.SalesPredictionService = SalesPredictionService = SalesPredictionService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], SalesPredictionService);
//# sourceMappingURL=sales-prediction.service.js.map