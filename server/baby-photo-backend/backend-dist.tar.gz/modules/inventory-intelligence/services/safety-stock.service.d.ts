import { PrismaService } from '../../../shared/prisma/prisma.service';
import { SafetyStockQueryDto, BatchCalculateDto, UpdateSafetyStockDto } from '../dto/safety-stock.dto';
export declare class SafetyStockService {
    private readonly prisma;
    private readonly logger;
    private readonly Z_TABLE;
    constructor(prisma: PrismaService);
    getList(query: SafetyStockQueryDto): Promise<{
        items: {
            id: number;
            name: string;
            productNo: string;
            costPrice: import("@prisma/client/runtime/library").Decimal;
            stockQuantity: number;
            reorderPoint: number | null;
            safetyStock: number;
            dailyConsumption: number;
        }[];
        pagination: {
            current: number;
            pageSize: number;
            total: number;
        };
    }>;
    private getZScore;
    private getLeadTimeDays;
    calculateAndUpdate(productId: number, dto: UpdateSafetyStockDto): Promise<any>;
    calculate(productId: number, serviceLevel: number, demandPeriodDays: number): Promise<{
        productId: number;
        error: string;
        productName?: undefined;
        currentStock?: undefined;
        demandMean?: undefined;
        demandStdDev?: undefined;
        leadTimeDays?: undefined;
        serviceLevel?: undefined;
        zScore?: undefined;
        safetyStock?: undefined;
        reorderPoint?: undefined;
        suggestedMaxStock?: undefined;
    } | {
        productId: number;
        productName: string;
        currentStock: number;
        demandMean: number;
        demandStdDev: number;
        leadTimeDays: number;
        serviceLevel: number;
        zScore: number;
        safetyStock: number;
        reorderPoint: number;
        suggestedMaxStock: number;
        error?: undefined;
    }>;
    batchCalculate(dto: BatchCalculateDto): Promise<{
        total: number;
        updated: number;
        errors: {
            productId: number;
            error: string;
        }[];
    }>;
    weeklyBatchCalculation(): Promise<void>;
}
