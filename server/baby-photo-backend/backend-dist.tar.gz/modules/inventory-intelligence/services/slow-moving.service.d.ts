import { PrismaService } from '../../../shared/prisma/prisma.service';
import { SlowMovingQueryDto } from '../dto/slow-moving.dto';
export declare class SlowMovingService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getList(query: SlowMovingQueryDto): Promise<{
        items: {
            productId: any;
            productName: any;
            productNo: any;
            categoryName: any;
            stockQuantity: any;
            costPrice: number;
            stockValue: number;
            lastSaleDate: Date | null;
            daysSinceLastSale: number;
            thresholdDays: number;
            status: string;
        }[];
        summary: {
            totalSlowMoving: number;
            totalDeadStock: number;
            totalStockValue: any;
        };
        pagination: {
            current: number;
            pageSize: number;
            total: number;
        };
    }>;
    checkSlowMoving(thresholdDays?: number): Promise<{
        checkedProducts: number;
        slowMovingCount: number;
        alertsCreated: number;
    }>;
    dailyCheck(): Promise<void>;
}
