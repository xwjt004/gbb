"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var SlowMovingService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SlowMovingService = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
let SlowMovingService = SlowMovingService_1 = class SlowMovingService {
    prisma;
    logger = new common_1.Logger(SlowMovingService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getList(query) {
        const thresholdDays = query.thresholdDays || 90;
        const page = query.page || 1;
        const pageSize = query.pageSize || 20;
        const where = { isActive: true, isTrackStock: true };
        if (query.categoryId) {
            where.categoryId = query.categoryId;
        }
        const products = await this.prisma.product.findMany({
            where,
            select: {
                id: true, name: true, productNo: true, stockQuantity: true,
                costPrice: true, categoryId: true,
                category: { select: { name: true } },
            },
            orderBy: { id: 'asc' },
        });
        const enriched = await Promise.all(products.map(async (product) => {
            const lastTxn = await this.prisma.stockTransaction.findFirst({
                where: { productId: product.id, transactionType: 'OUTBOUND' },
                orderBy: { createdAt: 'desc' },
                select: { createdAt: true },
            });
            const lastSaleDate = lastTxn?.createdAt ?? null;
            const daysSinceLastSale = lastSaleDate
                ? Math.floor((Date.now() - lastSaleDate.getTime()) / (1000 * 60 * 60 * 24))
                : 999;
            const stockValue = Number(product.costPrice) * product.stockQuantity;
            let status = 'NORMAL';
            if (daysSinceLastSale >= thresholdDays * 2)
                status = 'DEAD_STOCK';
            else if (daysSinceLastSale >= thresholdDays)
                status = 'SLOW_MOVING';
            return {
                productId: product.id,
                productName: product.name,
                productNo: product.productNo,
                categoryName: product.category?.name || '-',
                stockQuantity: product.stockQuantity,
                costPrice: Number(product.costPrice),
                stockValue,
                lastSaleDate,
                daysSinceLastSale,
                thresholdDays,
                status,
            };
        }));
        const filtered = query.status
            ? enriched.filter((e) => e.status === query.status)
            : enriched;
        filtered.sort((a, b) => b.daysSinceLastSale - a.daysSinceLastSale);
        const total = filtered.length;
        const paginated = filtered.slice((page - 1) * pageSize, page * pageSize);
        const slowMovingItems = filtered.filter((e) => e.status === 'SLOW_MOVING' || e.status === 'DEAD_STOCK');
        const summary = {
            totalSlowMoving: slowMovingItems.length,
            totalDeadStock: slowMovingItems.filter((e) => e.status === 'DEAD_STOCK').length,
            totalStockValue: slowMovingItems.reduce((s, e) => s + e.stockValue, 0),
        };
        return { items: paginated, summary, pagination: { current: page, pageSize, total } };
    }
    async checkSlowMoving(thresholdDays) {
        const products = await this.prisma.product.findMany({
            where: { isActive: true, isTrackStock: true },
            select: { id: true, name: true, slowMovingDays: true, stockQuantity: true },
        });
        let slowMovingCount = 0;
        let alertsCreated = 0;
        for (const product of products) {
            const threshold = thresholdDays || product.slowMovingDays || 90;
            const lastTxn = await this.prisma.stockTransaction.findFirst({
                where: { productId: product.id, transactionType: 'OUTBOUND' },
                orderBy: { createdAt: 'desc' },
                select: { createdAt: true },
            });
            const daysSinceLastSale = lastTxn?.createdAt
                ? Math.floor((Date.now() - lastTxn.createdAt.getTime()) / (1000 * 60 * 60 * 24))
                : 999;
            if (daysSinceLastSale >= threshold) {
                slowMovingCount++;
                const existingAlert = await this.prisma.stockAlert.findFirst({
                    where: {
                        productId: product.id,
                        alertType: 'SLOW_MOVING',
                        status: { in: ['PENDING', 'PROCESSING'] },
                    },
                });
                if (!existingAlert) {
                    const priority = daysSinceLastSale >= threshold * 2 ? 'HIGH' : 'MEDIUM';
                    await this.prisma.stockAlert.create({
                        data: {
                            alertNo: `SLW-${Date.now()}-${product.id}`,
                            productId: product.id,
                            alertType: 'SLOW_MOVING',
                            currentStock: product.stockQuantity,
                            threshold,
                            status: 'PENDING',
                            priority,
                            alertedAt: new Date(),
                        },
                    });
                    alertsCreated++;
                }
            }
        }
        this.logger.log(`Slow-moving check: ${slowMovingCount} found, ${alertsCreated} new alerts`);
        return { checkedProducts: products.length, slowMovingCount, alertsCreated };
    }
    async dailyCheck() {
        this.logger.log('Starting daily slow-moving check...');
        await this.checkSlowMoving();
        this.logger.log('Daily slow-moving check completed');
    }
};
exports.SlowMovingService = SlowMovingService;
__decorate([
    (0, schedule_1.Cron)('0 2 * * *', { name: 'daily-slow-moving-check', timeZone: 'Asia/Shanghai' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SlowMovingService.prototype, "dailyCheck", null);
exports.SlowMovingService = SlowMovingService = SlowMovingService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], SlowMovingService);
//# sourceMappingURL=slow-moving.service.js.map