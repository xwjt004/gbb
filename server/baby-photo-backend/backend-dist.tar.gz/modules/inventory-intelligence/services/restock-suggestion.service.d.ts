import { PrismaService } from '../../../shared/prisma/prisma.service';
import { RestockSuggestionQueryDto } from '../dto/restock-suggestion.dto';
export declare class RestockSuggestionService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getSuggestions(query: RestockSuggestionQueryDto): Promise<{
        items: {
            id: any;
            productId: any;
            productName: any;
            currentStock: any;
            minStock: any;
            suggestedQty: any;
            status: any;
            daysUntilStockout: number;
            urgency: string;
            createdAt: any;
        }[];
        pagination: {
            current: number;
            pageSize: number;
            total: number;
        };
    }>;
    generateBatch(): Promise<{
        generated: number;
        suggestions: any[];
    }>;
    convertToPurchaseOrder(suggestionId: string, supplierId?: string): Promise<{
        error: string;
        purchaseOrderId?: undefined;
        purchaseNo?: undefined;
    } | {
        purchaseOrderId: string;
        purchaseNo: string;
        error?: undefined;
    }>;
}
