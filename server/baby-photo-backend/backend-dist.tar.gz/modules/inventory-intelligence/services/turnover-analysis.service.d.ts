import { PrismaService } from '../../../shared/prisma/prisma.service';
import { TurnoverQueryDto } from '../dto/turnover-analysis.dto';
export declare class TurnoverAnalysisService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getAnalysis(query: TurnoverQueryDto): Promise<{
        overall: {
            turnoverRatio: number;
            daysInventoryOutstanding: number | null;
            averageInventory: number;
            cogs: number;
            currentStockValue: number;
        };
        byCategory: {
            categoryId: any;
            categoryName: any;
            turnoverRatio: number;
            dio: number | null;
            stockValue: number;
            suggestion: string;
        }[];
        topSlowest: {
            productId: any;
            productName: any;
            turnoverRatio: number;
            dio: number | null;
            stockQuantity: any;
            stockValue: number;
            suggestion: string;
        }[];
    }>;
    getReport(query: TurnoverQueryDto): Promise<{
        overview: {
            turnoverRatio: number;
            daysInventoryOutstanding: number | null;
            averageInventory: number;
            cogs: number;
            currentStockValue: number;
        };
        details: {
            productId: any;
            productName: any;
            stockQuantity: any;
            costPrice: number;
            stockValue: number;
            dailyConsumption: any;
            daysOfStock: number;
            evaluation: string;
            suggestion: string;
        }[];
        optimizationSuggestions: {
            overstocked: {
                productName: any;
                stockValue: any;
                suggestion: string;
            }[];
            understocked: {
                productName: any;
                suggestion: string;
            }[];
            fastMoving: {
                productName: any;
                suggestion: string;
            }[];
        };
    }>;
    refresh(): Promise<{
        overall: {
            turnoverRatio: number;
            daysInventoryOutstanding: number | null;
            averageInventory: number;
            cogs: number;
            currentStockValue: number;
        };
        byCategory: {
            categoryId: any;
            categoryName: any;
            turnoverRatio: number;
            dio: number | null;
            stockValue: number;
            suggestion: string;
        }[];
        topSlowest: {
            productId: any;
            productName: any;
            turnoverRatio: number;
            dio: number | null;
            stockQuantity: any;
            stockValue: number;
            suggestion: string;
        }[];
    }>;
    private getCategorySuggestion;
    private getProductSuggestion;
}
