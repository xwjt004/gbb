"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RestockSuggestionService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RestockSuggestionService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../shared/prisma/prisma.service");
let RestockSuggestionService = RestockSuggestionService_1 = class RestockSuggestionService {
    prisma;
    logger = new common_1.Logger(RestockSuggestionService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getSuggestions(query) {
        const page = query.page || 1;
        const pageSize = query.pageSize || 20;
        const where = {};
        if (query.urgency) {
        }
        const [items, total] = await Promise.all([
            this.prisma.autoPurchaseSuggestion.findMany({
                where,
                include: { product: { select: { id: true, name: true, unit: true, stockQuantity: true } } },
                skip: (page - 1) * pageSize,
                take: pageSize,
                orderBy: { createdAt: 'desc' },
            }),
            this.prisma.autoPurchaseSuggestion.count({ where }),
        ]);
        const enriched = items.map((item) => {
            const avgConsumption = item.product?.stockQuantity
                ? Math.max(1, Math.round(item.product.stockQuantity / 30))
                : 1;
            const daysUntilStockout = avgConsumption > 0
                ? Math.round(item.currentStock / avgConsumption)
                : 999;
            const urgency = daysUntilStockout <= 3 ? 'HIGH' : daysUntilStockout <= 7 ? 'MEDIUM' : 'LOW';
            return {
                id: item.id,
                productId: item.productId,
                productName: item.productName,
                currentStock: item.currentStock,
                minStock: item.minStock,
                suggestedQty: item.suggestedQty,
                status: item.status,
                daysUntilStockout,
                urgency,
                createdAt: item.createdAt,
            };
        });
        const filtered = query.urgency
            ? enriched.filter((e) => e.urgency === query.urgency)
            : enriched;
        return { items: filtered, pagination: { current: page, pageSize, total } };
    }
    async generateBatch() {
        const products = await this.prisma.product.findMany({
            where: { isActive: true, isTrackStock: true },
            select: {
                id: true, name: true, stockQuantity: true, minStock: true,
                safetyStock: true, dailyConsumption: true, reorderPoint: true,
            },
        });
        let generated = 0;
        const suggestions = [];
        for (const product of products) {
            const reorderPoint = product.reorderPoint ?? product.minStock ?? 10;
            const safetyStock = product.safetyStock || 0;
            const dailyConsumption = product.dailyConsumption || 1;
            if (product.stockQuantity <= reorderPoint) {
                const suggestedQty = Math.max(safetyStock * 2, dailyConsumption * 7 + safetyStock - product.stockQuantity);
                try {
                    await this.prisma.autoPurchaseSuggestion.create({
                        data: {
                            productId: product.id,
                            productName: product.name,
                            currentStock: product.stockQuantity,
                            minStock: reorderPoint,
                            suggestedQty: Math.max(1, Math.round(suggestedQty)),
                            status: 'PENDING',
                        },
                    });
                    generated++;
                    suggestions.push({
                        productId: product.id,
                        productName: product.name,
                        suggestedQty: Math.max(1, Math.round(suggestedQty)),
                    });
                }
                catch (err) {
                    this.logger.debug(`Skipping duplicate suggestion for product ${product.id}`);
                }
            }
        }
        this.logger.log(`Generated ${generated} restock suggestions`);
        return { generated, suggestions };
    }
    async convertToPurchaseOrder(suggestionId, supplierId) {
        const suggestion = await this.prisma.autoPurchaseSuggestion.findUnique({
            where: { id: suggestionId },
        });
        if (!suggestion) {
            return { error: 'Suggestion not found' };
        }
        if (suggestion.status !== 'PENDING') {
            return { error: `Suggestion already ${suggestion.status}` };
        }
        const product = await this.prisma.product.findUnique({
            where: { id: suggestion.productId },
            select: { productNo: true, salePrice: true },
        });
        let supplier = null;
        if (supplierId) {
            supplier = await this.prisma.supplier.findUnique({ where: { id: supplierId } });
        }
        if (!supplier) {
            supplier = await this.prisma.supplier.findFirst({
                where: { status: 'ACTIVE' },
                orderBy: { totalOrders: 'desc' },
            });
        }
        if (!supplier) {
            return { error: 'No active supplier found' };
        }
        const purchaseOrder = await this.prisma.purchaseOrder.create({
            data: {
                purchaseNo: `PO-${Date.now()}`,
                purchaseDate: new Date(),
                expectedDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
                supplier: { connect: { id: supplier.id } },
                totalQuantity: suggestion.suggestedQty,
                totalAmount: 0,
                status: 'DRAFT',
                items: {
                    create: {
                        productId: suggestion.productId,
                        productName: suggestion.productName,
                        productNo: product?.productNo || '',
                        quantity: suggestion.suggestedQty,
                        unitPrice: 0,
                        totalPrice: 0,
                        unit: '件',
                    },
                },
            },
        });
        await this.prisma.autoPurchaseSuggestion.update({
            where: { id: suggestionId },
            data: { status: 'CONVERTED' },
        });
        return { purchaseOrderId: purchaseOrder.id, purchaseNo: purchaseOrder.purchaseNo };
    }
};
exports.RestockSuggestionService = RestockSuggestionService;
exports.RestockSuggestionService = RestockSuggestionService = RestockSuggestionService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], RestockSuggestionService);
//# sourceMappingURL=restock-suggestion.service.js.map