"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryIntelligenceController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const sales_prediction_service_1 = require("./services/sales-prediction.service");
const safety_stock_service_1 = require("./services/safety-stock.service");
const restock_suggestion_service_1 = require("./services/restock-suggestion.service");
const slow_moving_service_1 = require("./services/slow-moving.service");
const turnover_analysis_service_1 = require("./services/turnover-analysis.service");
const sales_prediction_dto_1 = require("./dto/sales-prediction.dto");
const safety_stock_dto_1 = require("./dto/safety-stock.dto");
const restock_suggestion_dto_1 = require("./dto/restock-suggestion.dto");
const slow_moving_dto_1 = require("./dto/slow-moving.dto");
const turnover_analysis_dto_1 = require("./dto/turnover-analysis.dto");
let InventoryIntelligenceController = class InventoryIntelligenceController {
    salesPredictionService;
    safetyStockService;
    restockSuggestionService;
    slowMovingService;
    turnoverAnalysisService;
    constructor(salesPredictionService, safetyStockService, restockSuggestionService, slowMovingService, turnoverAnalysisService) {
        this.salesPredictionService = salesPredictionService;
        this.safetyStockService = safetyStockService;
        this.restockSuggestionService = restockSuggestionService;
        this.slowMovingService = slowMovingService;
        this.turnoverAnalysisService = turnoverAnalysisService;
    }
    async getSalesPrediction(query) {
        const data = await this.salesPredictionService.getBatchForecasts(query);
        return { code: 200, message: 'success', data };
    }
    async getProductSalesPrediction(productId, query) {
        const data = await this.salesPredictionService.getProductForecast(+productId, query);
        return { code: 200, message: 'success', data };
    }
    async getSafetyStock(query) {
        const data = await this.safetyStockService.getList(query);
        return { code: 200, message: 'success', data };
    }
    async batchCalculateSafetyStock(dto) {
        const data = await this.safetyStockService.batchCalculate(dto);
        return { code: 200, message: 'success', data };
    }
    async updateSafetyStockConfig(productId, dto) {
        const data = await this.safetyStockService.calculateAndUpdate(+productId, dto);
        return { code: 200, message: 'success', data };
    }
    async getRestockSuggestions(query) {
        const data = await this.restockSuggestionService.getSuggestions(query);
        return { code: 200, message: 'success', data };
    }
    async generateRestockSuggestions() {
        const data = await this.restockSuggestionService.generateBatch();
        return { code: 200, message: 'success', data };
    }
    async convertSuggestion(id, dto) {
        const data = await this.restockSuggestionService.convertToPurchaseOrder(id, dto.supplierId);
        return { code: 200, message: 'success', data };
    }
    async getSlowMovingProducts(query) {
        const data = await this.slowMovingService.getList(query);
        return { code: 200, message: 'success', data };
    }
    async checkSlowMoving() {
        const data = await this.slowMovingService.checkSlowMoving();
        return { code: 200, message: 'success', data };
    }
    async getTurnoverAnalysis(query) {
        const data = await this.turnoverAnalysisService.getAnalysis(query);
        return { code: 200, message: 'success', data };
    }
    async getTurnoverReport(query) {
        const data = await this.turnoverAnalysisService.getReport(query);
        return { code: 200, message: 'success', data };
    }
    async refreshTurnoverData() {
        const data = await this.turnoverAnalysisService.refresh();
        return { code: 200, message: 'success', data };
    }
};
exports.InventoryIntelligenceController = InventoryIntelligenceController;
__decorate([
    (0, common_1.Get)('sales-prediction'),
    (0, swagger_1.ApiOperation)({ summary: 'Batch sales forecasts' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [sales_prediction_dto_1.PredictionQueryDto]),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "getSalesPrediction", null);
__decorate([
    (0, common_1.Get)('sales-prediction/product/:productId'),
    (0, swagger_1.ApiOperation)({ summary: 'Single product sales forecast' }),
    __param(0, (0, common_1.Param)('productId')),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, sales_prediction_dto_1.ProductPredictionQueryDto]),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "getProductSalesPrediction", null);
__decorate([
    (0, common_1.Get)('safety-stock'),
    (0, swagger_1.ApiOperation)({ summary: 'List safety stock configs' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [safety_stock_dto_1.SafetyStockQueryDto]),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "getSafetyStock", null);
__decorate([
    (0, common_1.Post)('safety-stock/batch-calculate'),
    (0, swagger_1.ApiOperation)({ summary: 'Batch calculate safety stock for all tracked products' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [safety_stock_dto_1.BatchCalculateDto]),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "batchCalculateSafetyStock", null);
__decorate([
    (0, common_1.Put)('safety-stock/product/:productId'),
    (0, swagger_1.ApiOperation)({ summary: 'Update safety stock config for a product' }),
    __param(0, (0, common_1.Param)('productId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, safety_stock_dto_1.UpdateSafetyStockDto]),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "updateSafetyStockConfig", null);
__decorate([
    (0, common_1.Get)('restock-suggestions'),
    (0, swagger_1.ApiOperation)({ summary: 'List restock suggestions' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [restock_suggestion_dto_1.RestockSuggestionQueryDto]),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "getRestockSuggestions", null);
__decorate([
    (0, common_1.Post)('restock-suggestions/generate'),
    (0, swagger_1.ApiOperation)({ summary: 'Generate restock suggestions for all tracked products' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "generateRestockSuggestions", null);
__decorate([
    (0, common_1.Post)('restock-suggestions/:id/convert'),
    (0, swagger_1.ApiOperation)({ summary: 'Convert suggestion to purchase order' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, restock_suggestion_dto_1.ConvertSuggestionDto]),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "convertSuggestion", null);
__decorate([
    (0, common_1.Get)('slow-moving'),
    (0, swagger_1.ApiOperation)({ summary: 'List slow-moving products' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [slow_moving_dto_1.SlowMovingQueryDto]),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "getSlowMovingProducts", null);
__decorate([
    (0, common_1.Post)('slow-moving/check'),
    (0, swagger_1.ApiOperation)({ summary: 'Run slow-moving detection' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "checkSlowMoving", null);
__decorate([
    (0, common_1.Get)('turnover-analysis'),
    (0, swagger_1.ApiOperation)({ summary: 'Get turnover analysis' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [turnover_analysis_dto_1.TurnoverQueryDto]),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "getTurnoverAnalysis", null);
__decorate([
    (0, common_1.Get)('turnover-analysis/report'),
    (0, swagger_1.ApiOperation)({ summary: 'Get detailed turnover report with suggestions' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [turnover_analysis_dto_1.TurnoverQueryDto]),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "getTurnoverReport", null);
__decorate([
    (0, common_1.Post)('turnover-analysis/refresh'),
    (0, swagger_1.ApiOperation)({ summary: 'Refresh turnover analysis data' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], InventoryIntelligenceController.prototype, "refreshTurnoverData", null);
exports.InventoryIntelligenceController = InventoryIntelligenceController = __decorate([
    (0, swagger_1.ApiTags)('库存智能预测'),
    (0, common_1.Controller)('inventory-intelligence'),
    __metadata("design:paramtypes", [sales_prediction_service_1.SalesPredictionService,
        safety_stock_service_1.SafetyStockService,
        restock_suggestion_service_1.RestockSuggestionService,
        slow_moving_service_1.SlowMovingService,
        turnover_analysis_service_1.TurnoverAnalysisService])
], InventoryIntelligenceController);
//# sourceMappingURL=inventory-intelligence.controller.js.map