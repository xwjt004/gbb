"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryIntelligenceModule = void 0;
const common_1 = require("@nestjs/common");
const prisma_module_1 = require("../../shared/prisma/prisma.module");
const inventory_intelligence_controller_1 = require("./inventory-intelligence.controller");
const sales_prediction_service_1 = require("./services/sales-prediction.service");
const safety_stock_service_1 = require("./services/safety-stock.service");
const restock_suggestion_service_1 = require("./services/restock-suggestion.service");
const slow_moving_service_1 = require("./services/slow-moving.service");
const turnover_analysis_service_1 = require("./services/turnover-analysis.service");
const stock_alert_module_1 = require("../stock-alert/stock-alert.module");
let InventoryIntelligenceModule = class InventoryIntelligenceModule {
};
exports.InventoryIntelligenceModule = InventoryIntelligenceModule;
exports.InventoryIntelligenceModule = InventoryIntelligenceModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule, (0, common_1.forwardRef)(() => stock_alert_module_1.StockAlertModule)],
        controllers: [inventory_intelligence_controller_1.InventoryIntelligenceController],
        providers: [
            sales_prediction_service_1.SalesPredictionService,
            safety_stock_service_1.SafetyStockService,
            restock_suggestion_service_1.RestockSuggestionService,
            slow_moving_service_1.SlowMovingService,
            turnover_analysis_service_1.TurnoverAnalysisService,
        ],
        exports: [
            sales_prediction_service_1.SalesPredictionService,
            safety_stock_service_1.SafetyStockService,
            restock_suggestion_service_1.RestockSuggestionService,
            slow_moving_service_1.SlowMovingService,
            turnover_analysis_service_1.TurnoverAnalysisService,
        ],
    })
], InventoryIntelligenceModule);
//# sourceMappingURL=inventory-intelligence.module.js.map