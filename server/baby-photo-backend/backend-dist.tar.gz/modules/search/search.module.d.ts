export declare class SearchModule {
}
