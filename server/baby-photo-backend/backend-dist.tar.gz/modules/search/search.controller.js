"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const search_service_1 = require("./search.service");
let SearchController = class SearchController {
    searchService;
    constructor(searchService) {
        this.searchService = searchService;
    }
    async global(keyword, limit, page, type) {
        return this.searchService.global({
            keyword,
            limit: limit ? parseInt(limit) : 5,
            page: page ? parseInt(page) : 1,
            type: type || undefined,
        });
    }
};
exports.SearchController = SearchController;
__decorate([
    (0, common_1.Get)('global'),
    (0, swagger_1.ApiOperation)({ summary: '全局搜索(用户/订单/套餐)' }),
    (0, swagger_1.ApiQuery)({ name: 'keyword', required: true, description: '关键字(昵称/手机号/订单号/套餐名称)' }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, description: '每类返回条数(默认5)' }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, description: '页码(默认1)' }),
    (0, swagger_1.ApiQuery)({ name: 'type', required: false, description: '限定类型: user|order|package|payment (为空表示全部)' }),
    __param(0, (0, common_1.Query)('keyword')),
    __param(1, (0, common_1.Query)('limit')),
    __param(2, (0, common_1.Query)('page')),
    __param(3, (0, common_1.Query)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], SearchController.prototype, "global", null);
exports.SearchController = SearchController = __decorate([
    (0, swagger_1.ApiTags)('搜索'),
    (0, common_1.Controller)('search'),
    __metadata("design:paramtypes", [search_service_1.SearchService])
], SearchController);
//# sourceMappingURL=search.controller.js.map