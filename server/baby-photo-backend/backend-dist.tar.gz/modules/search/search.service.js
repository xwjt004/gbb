"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var SearchService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let SearchService = SearchService_1 = class SearchService {
    prisma;
    logger = new common_1.Logger(SearchService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async global(params) {
        const { keyword, limit = 5, type, page = 1 } = params;
        if (!keyword)
            throw new common_1.BadRequestException('keyword 不能为空');
        const take = limit;
        const skip = (page - 1) * take;
        const userWhere = {
            OR: [
                { nickname: { contains: keyword, mode: 'insensitive' } },
                { phone: { contains: keyword } },
            ],
        };
        const orderWhere = {
            OR: [
                { orderNo: { contains: keyword, mode: 'insensitive' } },
                { user: { nickname: { contains: keyword, mode: 'insensitive' } } },
                { user: { phone: { contains: keyword } } },
            ],
        };
        const packageWhere = {
            name: { contains: keyword, mode: 'insensitive' },
        };
        const paymentWhere = {
            OR: [
                { id: { contains: keyword, mode: 'insensitive' } },
                { transactionId: { contains: keyword, mode: 'insensitive' } },
                { order: { orderNo: { contains: keyword, mode: 'insensitive' } } },
                { order: { user: { phone: { contains: keyword } } } },
                { order: { user: { nickname: { contains: keyword, mode: 'insensitive' } } } },
            ],
        };
        try {
            const doUsers = async () => {
                const [items, total] = await Promise.all([
                    this.prisma.user.findMany({
                        where: userWhere,
                        take,
                        skip,
                        select: {
                            openid: true,
                            nickname: true,
                            phone: true,
                            avatar: true,
                            status: true,
                            createdAt: true,
                            _count: { select: { orders: true } },
                        },
                        orderBy: { createdAt: 'desc' },
                    }),
                    this.prisma.user.count({ where: userWhere }),
                ]);
                return { items, total };
            };
            const doOrders = async () => {
                const [items, total] = await Promise.all([
                    this.prisma.order.findMany({
                        where: orderWhere,
                        take,
                        skip,
                        include: {
                            user: { select: { nickname: true, phone: true, avatar: true, openid: true } },
                            package: { select: { name: true, price: true, id: true } },
                        },
                        orderBy: { createdAt: 'desc' },
                    }),
                    this.prisma.order.count({ where: orderWhere }),
                ]);
                return { items, total };
            };
            const doPackages = async () => {
                const [items, total] = await Promise.all([
                    this.prisma.package.findMany({
                        where: packageWhere,
                        take,
                        skip,
                        select: {
                            id: true,
                            name: true,
                            price: true,
                            deposit: true,
                            durationMinutes: true,
                            includes: true,
                            createdAt: true,
                        },
                        orderBy: { createdAt: 'desc' },
                    }),
                    this.prisma.package.count({ where: packageWhere }),
                ]);
                return { items, total };
            };
            const doPayments = async () => {
                const [items, total] = await Promise.all([
                    this.prisma.payment.findMany({
                        where: paymentWhere,
                        take,
                        skip,
                        include: {
                            order: {
                                select: {
                                    orderNo: true,
                                    user: { select: { nickname: true, phone: true, openid: true } },
                                },
                            },
                        },
                        orderBy: { createdAt: 'desc' },
                    }),
                    this.prisma.payment.count({ where: paymentWhere }),
                ]);
                return { items, total };
            };
            const needAll = !type;
            const [users, orders, packages, payments] = await Promise.all([
                needAll || type === 'user' ? doUsers() : Promise.resolve(undefined),
                needAll || type === 'order' ? doOrders() : Promise.resolve(undefined),
                needAll || type === 'package' ? doPackages() : Promise.resolve(undefined),
                needAll || type === 'payment' ? doPayments() : Promise.resolve(undefined),
            ]);
            return {
                code: 200,
                message: '搜索成功',
                data: {
                    users: users?.items?.map(u => {
                        const orderCount = u._count?.orders || 0;
                        const isVip = orderCount >= 10;
                        const vipLevel = orderCount >= 30 ? 3 : orderCount >= 20 ? 2 : orderCount >= 10 ? 1 : undefined;
                        return { ...u, isVip, vipLevel };
                    }) || [],
                    orders: orders?.items || [],
                    packages: packages?.items || [],
                    payments: payments?.items || [],
                    meta: {
                        users: users ? { total: users.total, page, limit: take, totalPages: Math.ceil(users.total / take) } : undefined,
                        orders: orders ? { total: orders.total, page, limit: take, totalPages: Math.ceil(orders.total / take) } : undefined,
                        packages: packages ? { total: packages.total, page, limit: take, totalPages: Math.ceil(packages.total / take) } : undefined,
                        payments: payments ? { total: payments.total, page, limit: take, totalPages: Math.ceil(payments.total / take) } : undefined,
                    },
                },
            };
        }
        catch (e) {
            this.logger.error(`全局搜索失败: ${e.message}`, e.stack);
            throw new common_1.BadRequestException('搜索失败');
        }
    }
};
exports.SearchService = SearchService;
exports.SearchService = SearchService = SearchService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], SearchService);
//# sourceMappingURL=search.service.js.map