import { PrismaService } from '../../shared/prisma/prisma.service';
export declare class SearchService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    global(params: {
        keyword: string;
        limit?: number;
        type?: string;
        page?: number;
    }): Promise<{
        code: number;
        message: string;
        data: {
            users: {
                isVip: boolean;
                vipLevel: number | undefined;
                createdAt: Date;
                _count: {
                    orders: number;
                };
                openid: string;
                nickname: string | null;
                avatar: string | null;
                phone: string | null;
                status: import("@prisma/client").$Enums.UserStatus;
            }[];
            orders: ({
                user: {
                    openid: string;
                    nickname: string | null;
                    avatar: string | null;
                    phone: string | null;
                };
                package: {
                    id: number;
                    name: string;
                    price: import("@prisma/client/runtime/library").Decimal;
                } | null;
            } & {
                id: string;
                orderNo: string;
                appointmentDate: Date | null;
                totalAmount: import("@prisma/client/runtime/library").Decimal;
                depositAmount: import("@prisma/client/runtime/library").Decimal;
                paidAmount: import("@prisma/client/runtime/library").Decimal;
                notes: string | null;
                childrenCount: number;
                createdAt: Date;
                updatedAt: Date;
                customerName: string | null;
                customerPhone: string | null;
                couponId: string | null;
                discountAmount: import("@prisma/client/runtime/library").Decimal;
                shippingAddressId: string | null;
                shippingInfo: import("@prisma/client/runtime/library").JsonValue | null;
                source: import("@prisma/client").$Enums.OrderSource;
                deletedAt: Date | null;
                depositTimeout: Date | null;
                finalTimeout: Date | null;
                paymentMode: import("@prisma/client").$Enums.PaymentMode;
                paymentSummary: import("@prisma/client/runtime/library").JsonValue | null;
                refundedAmount: import("@prisma/client/runtime/library").Decimal;
                remainingAmount: import("@prisma/client/runtime/library").Decimal;
                paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
                orderStatus: import("@prisma/client").$Enums.OrderStatus;
                agreementAccepted: boolean | null;
                agreementVersion: string | null;
                agreementAcceptedAt: Date | null;
                checkinStatus: string;
                checkinTime: Date | null;
                reminderSentAt: Date | null;
                completedAt: Date | null;
                photoPickReminderSentAt: Date | null;
                userId: number;
                packageId: number | null;
                timeSlotId: number | null;
                diyPackageId: number | null;
                wxUserId: string | null;
                photographerId: number | null;
            })[];
            packages: {
                id: number;
                createdAt: Date;
                name: string;
                price: import("@prisma/client/runtime/library").Decimal;
                deposit: import("@prisma/client/runtime/library").Decimal;
                durationMinutes: number;
                includes: string[];
            }[];
            payments: ({
                order: {
                    user: {
                        openid: string;
                        nickname: string | null;
                        phone: string | null;
                    };
                    orderNo: string;
                };
            } & {
                id: string;
                notes: string | null;
                createdAt: Date;
                updatedAt: Date;
                status: import("@prisma/client").$Enums.PaymentStatus;
                orderId: string;
                amount: import("@prisma/client/runtime/library").Decimal;
                transactionId: string | null;
                paidAt: Date | null;
                refundReason: string | null;
                refundedAt: Date | null;
                expiredAt: Date | null;
                idempotencyKey: string | null;
                operatorId: string | null;
                operatorName: string | null;
                paymentMethod: import("@prisma/client").$Enums.PaymentMethod;
                receiptImage: string | null;
                receiptImages: string[];
                receiptNo: string | null;
                paymentType: import("@prisma/client").$Enums.PaymentType;
            })[];
            meta: {
                users: {
                    total: number;
                    page: number;
                    limit: number;
                    totalPages: number;
                } | undefined;
                orders: {
                    total: number;
                    page: number;
                    limit: number;
                    totalPages: number;
                } | undefined;
                packages: {
                    total: number;
                    page: number;
                    limit: number;
                    totalPages: number;
                } | undefined;
                payments: {
                    total: number;
                    page: number;
                    limit: number;
                    totalPages: number;
                } | undefined;
            };
        };
    }>;
}
