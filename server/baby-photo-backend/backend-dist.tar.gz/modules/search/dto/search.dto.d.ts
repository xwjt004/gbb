export declare class SearchUserByPhoneDto {
    phone: string;
}
export declare class SearchUserByNicknameDto {
    nickname: string;
    fuzzy?: boolean;
}
export declare class DateRangeSearchDto {
    start_date?: string;
    end_date?: string;
}
export declare enum PriceSortOrder {
    ASC = "price_asc",
    DESC = "price_desc"
}
export declare class PriceRangeSearchDto {
    min_price?: number;
    max_price?: number;
    sort?: PriceSortOrder;
}
export declare class SearchPackageByNameDto {
    package_name: string;
    fuzzy?: boolean;
}
export declare enum PaymentStatus {
    PENDING = "PENDING",
    PROCESSING = "PROCESSING",
    PAID = "PAID",
    FAILED = "FAILED",
    CANCELLED = "CANCELLED",
    REFUNDING = "REFUNDING",
    REFUNDED = "REFUNDED"
}
export declare class SearchByPaymentStatusDto {
    status: PaymentStatus;
}
export declare class UserSearchResultDto {
    openid: string;
    nickname: string;
    phone: string;
    avatar: string;
    createdAt: Date;
    _count: {
        orders: number;
    };
}
export declare class OrderSearchResultDto {
    order_no: string;
    user: {
        nickname: string;
        phone: string;
        avatar?: string;
    };
    package: {
        name: string;
        price: number;
    };
    appointment_date: Date;
    order_status: string;
    payment_status: string;
    total_amount: number;
}
export declare class PackageSearchResultDto {
    id: number;
    name: string;
    description: string;
    price: number;
    deposit: number;
    durationMinutes: number;
    includes: string[];
    createdAt: Date;
}
export declare class SearchResponseDto<T> {
    code: number;
    message?: string;
    data: T[];
    meta: {
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    };
}
