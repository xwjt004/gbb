"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchResponseDto = exports.PackageSearchResultDto = exports.OrderSearchResultDto = exports.UserSearchResultDto = exports.SearchByPaymentStatusDto = exports.PaymentStatus = exports.SearchPackageByNameDto = exports.PriceRangeSearchDto = exports.PriceSortOrder = exports.DateRangeSearchDto = exports.SearchUserByNicknameDto = exports.SearchUserByPhoneDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class SearchUserByPhoneDto {
    phone;
}
exports.SearchUserByPhoneDto = SearchUserByPhoneDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '用户手机号码',
        example: '13800138000',
        required: true,
    }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SearchUserByPhoneDto.prototype, "phone", void 0);
class SearchUserByNicknameDto {
    nickname;
    fuzzy;
}
exports.SearchUserByNicknameDto = SearchUserByNicknameDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '用户昵称',
        example: '张三',
    }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SearchUserByNicknameDto.prototype, "nickname", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '是否启用模糊查找',
        example: true,
        default: true,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], SearchUserByNicknameDto.prototype, "fuzzy", void 0);
class DateRangeSearchDto {
    start_date;
    end_date;
}
exports.DateRangeSearchDto = DateRangeSearchDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '开始日期',
        example: '2024-01-01',
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], DateRangeSearchDto.prototype, "start_date", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '结束日期',
        example: '2024-01-31',
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], DateRangeSearchDto.prototype, "end_date", void 0);
var PriceSortOrder;
(function (PriceSortOrder) {
    PriceSortOrder["ASC"] = "price_asc";
    PriceSortOrder["DESC"] = "price_desc";
})(PriceSortOrder || (exports.PriceSortOrder = PriceSortOrder = {}));
class PriceRangeSearchDto {
    min_price;
    max_price;
    sort;
}
exports.PriceRangeSearchDto = PriceRangeSearchDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '最低价格',
        example: 500,
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PriceRangeSearchDto.prototype, "min_price", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '最高价格',
        example: 1500,
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], PriceRangeSearchDto.prototype, "max_price", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '价格排序方式',
        enum: PriceSortOrder,
        example: PriceSortOrder.ASC,
        default: PriceSortOrder.ASC,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(PriceSortOrder),
    __metadata("design:type", String)
], PriceRangeSearchDto.prototype, "sort", void 0);
class SearchPackageByNameDto {
    package_name;
    fuzzy;
}
exports.SearchPackageByNameDto = SearchPackageByNameDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '套系名称',
        example: '儿童写真套系A',
    }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SearchPackageByNameDto.prototype, "package_name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '是否启用模糊查找',
        example: true,
        default: true,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], SearchPackageByNameDto.prototype, "fuzzy", void 0);
var PaymentStatus;
(function (PaymentStatus) {
    PaymentStatus["PENDING"] = "PENDING";
    PaymentStatus["PROCESSING"] = "PROCESSING";
    PaymentStatus["PAID"] = "PAID";
    PaymentStatus["FAILED"] = "FAILED";
    PaymentStatus["CANCELLED"] = "CANCELLED";
    PaymentStatus["REFUNDING"] = "REFUNDING";
    PaymentStatus["REFUNDED"] = "REFUNDED";
})(PaymentStatus || (exports.PaymentStatus = PaymentStatus = {}));
class SearchByPaymentStatusDto {
    status;
}
exports.SearchByPaymentStatusDto = SearchByPaymentStatusDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付状态',
        enum: PaymentStatus,
        example: PaymentStatus.PAID,
    }),
    (0, class_validator_1.IsEnum)(PaymentStatus),
    __metadata("design:type", String)
], SearchByPaymentStatusDto.prototype, "status", void 0);
class UserSearchResultDto {
    openid;
    nickname;
    phone;
    avatar;
    createdAt;
    _count;
}
exports.UserSearchResultDto = UserSearchResultDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '用户 OpenID' }),
    __metadata("design:type", String)
], UserSearchResultDto.prototype, "openid", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '用户昵称' }),
    __metadata("design:type", String)
], UserSearchResultDto.prototype, "nickname", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '手机号码' }),
    __metadata("design:type", String)
], UserSearchResultDto.prototype, "phone", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '头像 URL' }),
    __metadata("design:type", String)
], UserSearchResultDto.prototype, "avatar", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '注册时间' }),
    __metadata("design:type", Date)
], UserSearchResultDto.prototype, "createdAt", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '订单统计' }),
    __metadata("design:type", Object)
], UserSearchResultDto.prototype, "_count", void 0);
class OrderSearchResultDto {
    order_no;
    user;
    package;
    appointment_date;
    order_status;
    payment_status;
    total_amount;
}
exports.OrderSearchResultDto = OrderSearchResultDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '订单号' }),
    __metadata("design:type", String)
], OrderSearchResultDto.prototype, "order_no", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '用户信息' }),
    __metadata("design:type", Object)
], OrderSearchResultDto.prototype, "user", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套系信息' }),
    __metadata("design:type", Object)
], OrderSearchResultDto.prototype, "package", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '预约日期' }),
    __metadata("design:type", Date)
], OrderSearchResultDto.prototype, "appointment_date", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '订单状态' }),
    __metadata("design:type", String)
], OrderSearchResultDto.prototype, "order_status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '支付状态' }),
    __metadata("design:type", String)
], OrderSearchResultDto.prototype, "payment_status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '总金额' }),
    __metadata("design:type", Number)
], OrderSearchResultDto.prototype, "total_amount", void 0);
class PackageSearchResultDto {
    id;
    name;
    description;
    price;
    deposit;
    durationMinutes;
    includes;
    createdAt;
}
exports.PackageSearchResultDto = PackageSearchResultDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套系 ID' }),
    __metadata("design:type", Number)
], PackageSearchResultDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套系名称' }),
    __metadata("design:type", String)
], PackageSearchResultDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套系描述' }),
    __metadata("design:type", String)
], PackageSearchResultDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套系价格' }),
    __metadata("design:type", Number)
], PackageSearchResultDto.prototype, "price", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '定金金额' }),
    __metadata("design:type", Number)
], PackageSearchResultDto.prototype, "deposit", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '拍摄时长（分钟）' }),
    __metadata("design:type", Number)
], PackageSearchResultDto.prototype, "durationMinutes", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '套系包含项目' }),
    __metadata("design:type", Array)
], PackageSearchResultDto.prototype, "includes", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '创建时间' }),
    __metadata("design:type", Date)
], PackageSearchResultDto.prototype, "createdAt", void 0);
class SearchResponseDto {
    code;
    message;
    data;
    meta;
}
exports.SearchResponseDto = SearchResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '响应状态码', example: 200 }),
    __metadata("design:type", Number)
], SearchResponseDto.prototype, "code", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '响应消息', example: '查找成功' }),
    __metadata("design:type", String)
], SearchResponseDto.prototype, "message", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '查找结果数据' }),
    __metadata("design:type", Array)
], SearchResponseDto.prototype, "data", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '分页信息' }),
    __metadata("design:type", Object)
], SearchResponseDto.prototype, "meta", void 0);
//# sourceMappingURL=search.dto.js.map