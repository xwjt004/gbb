"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const enums_1 = require("../users/enums");
let AuthService = class AuthService {
    jwtService;
    constructor(jwtService) {
        this.jwtService = jwtService;
    }
    async wechatLogin(wxLoginDto) {
        const { code } = wxLoginDto;
        const user = await this.getWechatUser(code);
        const payload = {
            sub: user.id,
            userType: enums_1.UserType.WECHAT,
        };
        return {
            access_token: this.jwtService.sign(payload),
            user: user,
            userType: enums_1.UserType.WECHAT,
        };
    }
    async adminLogin(adminLoginDto) {
        const { username, password } = adminLoginDto;
        const admin = await this.validateAdmin(username, password);
        if (!admin) {
            throw new common_1.UnauthorizedException('用户名或密码错误');
        }
        const payload = {
            sub: admin.id,
            userType: enums_1.UserType.ADMIN,
            username: admin.username,
        };
        return {
            access_token: this.jwtService.sign(payload),
            user: admin,
            userType: enums_1.UserType.ADMIN,
        };
    }
    async phoneLogin(phoneLoginDto) {
        const { phone, code } = phoneLoginDto;
        const isValidCode = await this.validatePhoneCode(phone, code);
        if (!isValidCode) {
            throw new common_1.UnauthorizedException('验证码错误或已过期');
        }
        let user = await this.findUserByPhone(phone);
        if (!user) {
            user = await this.createPhoneUser(phone);
        }
        const payload = {
            sub: user.id,
            userType: enums_1.UserType.PHONE,
            phone: user.phone,
        };
        return {
            access_token: this.jwtService.sign(payload),
            user: user,
            userType: enums_1.UserType.PHONE,
        };
    }
    async getWechatUser(code) {
        return {
            id: 'wx_' + Date.now(),
            openid: 'test_openid',
        };
    }
    async validateAdmin(username, password) {
        if (username === 'admin' && password === 'admin123') {
            return {
                id: 'admin_1',
                username: 'admin',
            };
        }
        return null;
    }
    async validatePhoneCode(phone, code) {
        return phone && code ? true : false;
    }
    async findUserByPhone(phone) {
        return null;
    }
    async createPhoneUser(phone) {
        return {
            id: 'phone_' + Date.now(),
            phone: phone,
        };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [jwt_1.JwtService])
], AuthService);
//# sourceMappingURL=auth.service.js.map