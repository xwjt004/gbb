import { AuthService } from './auth.service';
import { UsersWxLoginDto, AdminLoginDto, PhoneLoginDto } from '../users/dto';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    wechatLogin(wxLoginDto: UsersWxLoginDto): Promise<{
        access_token: string;
        user: {
            id: string;
            openid: string;
        };
        userType: import("../users/enums").UserType;
    }>;
    adminLogin(adminLoginDto: AdminLoginDto): Promise<{
        access_token: string;
        user: {
            id: string;
            username: string;
        };
        userType: import("../users/enums").UserType;
    }>;
    phoneLogin(phoneLoginDto: PhoneLoginDto): Promise<{
        access_token: string;
        user: {
            id: string;
            phone: string;
        };
        userType: import("../users/enums").UserType;
    }>;
}
