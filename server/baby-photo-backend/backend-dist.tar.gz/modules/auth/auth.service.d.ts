import { JwtService } from '@nestjs/jwt';
import { UsersWxLoginDto, AdminLoginDto, PhoneLoginDto } from '../users/dto';
import { UserType } from '../users/enums';
export declare class AuthService {
    private readonly jwtService;
    constructor(jwtService: JwtService);
    wechatLogin(wxLoginDto: UsersWxLoginDto): Promise<{
        access_token: string;
        user: {
            id: string;
            openid: string;
        };
        userType: UserType;
    }>;
    adminLogin(adminLoginDto: AdminLoginDto): Promise<{
        access_token: string;
        user: {
            id: string;
            username: string;
        };
        userType: UserType;
    }>;
    phoneLogin(phoneLoginDto: PhoneLoginDto): Promise<{
        access_token: string;
        user: {
            id: string;
            phone: string;
        };
        userType: UserType;
    }>;
    private getWechatUser;
    private validateAdmin;
    private validatePhoneCode;
    private findUserByPhone;
    private createPhoneUser;
}
