import { PrismaService } from '../../shared/prisma/prisma.service';
import { Response } from 'express';
export interface OrderExportQuery {
    startDate?: string;
    endDate?: string;
    orderStatus?: string;
    paymentStatus?: string;
    userId?: string;
    packageId?: string;
}
export declare class ExportService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    exportOrders(query: OrderExportQuery, res: Response): Promise<void>;
    exportUsers(res: Response): Promise<void>;
    exportFinancial(startDate: string, endDate: string, res: Response): Promise<void>;
    exportAll(res: Response): Promise<void>;
    private getOrderStatusText;
    private getPaymentStatusText;
}
