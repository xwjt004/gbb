"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ExportController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExportController = void 0;
const common_1 = require("@nestjs/common");
const export_service_1 = require("./export.service");
let ExportController = ExportController_1 = class ExportController {
    exportService;
    logger = new common_1.Logger(ExportController_1.name);
    constructor(exportService) {
        this.exportService = exportService;
    }
    async exportOrders(res, startDate, endDate, orderStatus, paymentStatus, userId, packageId) {
        this.logger.log('导出订单请求');
        const query = {
            startDate,
            endDate,
            orderStatus,
            paymentStatus,
            userId,
            packageId,
        };
        return this.exportService.exportOrders(query, res);
    }
    async exportUsers(res) {
        this.logger.log('导出用户请求');
        return this.exportService.exportUsers(res);
    }
    async exportFinancial(startDate, endDate, res) {
        this.logger.log('导出财务请求');
        if (!startDate || !endDate) {
            res.status(400).json({
                statusCode: 400,
                message: '请提供开始日期和结束日期',
            });
            return;
        }
        return this.exportService.exportFinancial(startDate, endDate, res);
    }
    async exportAll(res) {
        this.logger.log('导出全部数据请求');
        return this.exportService.exportAll(res);
    }
};
exports.ExportController = ExportController;
__decorate([
    (0, common_1.Get)('orders'),
    __param(0, (0, common_1.Res)()),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __param(3, (0, common_1.Query)('orderStatus')),
    __param(4, (0, common_1.Query)('paymentStatus')),
    __param(5, (0, common_1.Query)('userId')),
    __param(6, (0, common_1.Query)('packageId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], ExportController.prototype, "exportOrders", null);
__decorate([
    (0, common_1.Get)('users'),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ExportController.prototype, "exportUsers", null);
__decorate([
    (0, common_1.Get)('financial'),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], ExportController.prototype, "exportFinancial", null);
__decorate([
    (0, common_1.Get)('all'),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ExportController.prototype, "exportAll", null);
exports.ExportController = ExportController = ExportController_1 = __decorate([
    (0, common_1.Controller)('export'),
    __metadata("design:paramtypes", [export_service_1.ExportService])
], ExportController);
//# sourceMappingURL=export.controller.js.map