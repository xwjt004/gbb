import { Response } from 'express';
import { ExportService } from './export.service';
export declare class ExportController {
    private readonly exportService;
    private readonly logger;
    constructor(exportService: ExportService);
    exportOrders(res: Response, startDate?: string, endDate?: string, orderStatus?: string, paymentStatus?: string, userId?: string, packageId?: string): Promise<void>;
    exportUsers(res: Response): Promise<void>;
    exportFinancial(startDate: string, endDate: string, res: Response): Promise<void>;
    exportAll(res: Response): Promise<void>;
}
