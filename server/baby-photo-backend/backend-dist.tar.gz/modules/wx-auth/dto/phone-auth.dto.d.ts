export declare class PhoneAuthDto {
    code: string;
}
