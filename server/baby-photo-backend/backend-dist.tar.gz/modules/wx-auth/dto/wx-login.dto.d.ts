export declare class WxLoginDto {
    code: string;
    encryptedData?: string;
    iv?: string;
}
