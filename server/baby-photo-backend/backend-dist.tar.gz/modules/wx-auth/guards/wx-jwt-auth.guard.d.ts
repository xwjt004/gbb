declare const WxJwtAuthGuard_base: import("@nestjs/passport").Type<import("@nestjs/passport").IAuthGuard>;
export declare class WxJwtAuthGuard extends WxJwtAuthGuard_base {
}
export {};
