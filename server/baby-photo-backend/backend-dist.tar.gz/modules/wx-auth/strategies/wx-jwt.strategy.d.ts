import { Strategy } from 'passport-jwt';
import { PrismaService } from '../../../shared/prisma/prisma.service';
declare const WxJwtStrategy_base: new (...args: [opt: import("passport-jwt").StrategyOptionsWithRequest] | [opt: import("passport-jwt").StrategyOptionsWithoutRequest]) => Strategy & {
    validate(...args: any[]): unknown;
};
export declare class WxJwtStrategy extends WxJwtStrategy_base {
    private prisma;
    constructor(prisma: PrismaService);
    validate(payload: any): Promise<{
        memberLevel: string;
        id: string;
        totalAmount: import("@prisma/client/runtime/library").Decimal;
        createdAt: Date;
        updatedAt: Date;
        openid: string;
        nickname: string | null;
        avatar: string | null;
        phone: string | null;
        status: import("@prisma/client").$Enums.WxUserStatus;
        unionid: string | null;
        sessionKey: string | null;
        gender: number | null;
        phoneEncrypted: string | null;
        realName: string | null;
        birthday: Date | null;
        height: number | null;
        weight: number | null;
        zodiac: string | null;
        constellation: string | null;
        hundredDaysDate: Date | null;
        firstBirthdayDate: Date | null;
        graspGift: string | null;
        handFootPrint: string | null;
        walletPhoto: string | null;
        address: string | null;
        schoolName: string | null;
        talent: string | null;
        linkedUserId: number | null;
        totalOrders: number;
        growthPoints: number;
        lastOrderAt: Date | null;
        churnStatus: string;
        lastLoginAt: Date | null;
    }>;
}
export {};
