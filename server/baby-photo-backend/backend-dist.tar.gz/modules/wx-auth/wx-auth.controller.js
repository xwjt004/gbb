"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WxAuthController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const wx_auth_service_1 = require("./wx-auth.service");
const wx_login_dto_1 = require("./dto/wx-login.dto");
const phone_auth_dto_1 = require("./dto/phone-auth.dto");
const wx_jwt_auth_guard_1 = require("./guards/wx-jwt-auth.guard");
let WxAuthController = class WxAuthController {
    wxAuthService;
    constructor(wxAuthService) {
        this.wxAuthService = wxAuthService;
    }
    async login(loginDto) {
        return this.wxAuthService.login(loginDto);
    }
    async getPhone(req, phoneDto) {
        return this.wxAuthService.getPhoneNumber(req.user.id, phoneDto);
    }
    async refresh(refreshToken) {
        return this.wxAuthService.refreshToken(refreshToken);
    }
};
exports.WxAuthController = WxAuthController;
__decorate([
    (0, common_1.Post)('login'),
    (0, swagger_1.ApiOperation)({ summary: '微信登录' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '登录成功' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: '登录失败' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wx_login_dto_1.WxLoginDto]),
    __metadata("design:returntype", Promise)
], WxAuthController.prototype, "login", null);
__decorate([
    (0, common_1.Post)('phone'),
    (0, common_1.UseGuards)(wx_jwt_auth_guard_1.WxJwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({ summary: '获取手机号' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: '未授权' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, phone_auth_dto_1.PhoneAuthDto]),
    __metadata("design:returntype", Promise)
], WxAuthController.prototype, "getPhone", null);
__decorate([
    (0, common_1.Post)('refresh'),
    (0, swagger_1.ApiOperation)({ summary: '刷新Token' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '刷新成功' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Token无效' }),
    __param(0, (0, common_1.Body)('refreshToken')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], WxAuthController.prototype, "refresh", null);
exports.WxAuthController = WxAuthController = __decorate([
    (0, swagger_1.ApiTags)('微信授权'),
    (0, common_1.Controller)('wx-auth'),
    __metadata("design:paramtypes", [wx_auth_service_1.WxAuthService])
], WxAuthController);
//# sourceMappingURL=wx-auth.controller.js.map