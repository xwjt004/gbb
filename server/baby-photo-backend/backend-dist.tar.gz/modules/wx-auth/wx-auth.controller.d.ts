import { WxAuthService } from './wx-auth.service';
import { WxLoginDto } from './dto/wx-login.dto';
import { PhoneAuthDto } from './dto/phone-auth.dto';
export declare class WxAuthController {
    private readonly wxAuthService;
    constructor(wxAuthService: WxAuthService);
    login(loginDto: WxLoginDto): Promise<{
        user: {
            id: string;
            openid: string;
            nickname: string | null;
            avatar: string | null;
            phone: string | null;
            memberLevel: string;
        };
        accessToken: string;
        refreshToken: string;
        expiresIn: number;
    }>;
    getPhone(req: any, phoneDto: PhoneAuthDto): Promise<{
        phone: any;
        purePhone: any;
        countryCode: any;
    }>;
    refresh(refreshToken: string): Promise<{
        accessToken: string;
        refreshToken: string;
        expiresIn: number;
    }>;
}
