"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrmModule = void 0;
const common_1 = require("@nestjs/common");
const crm_controller_1 = require("./crm.controller");
const crm_service_1 = require("./crm.service");
const prisma_module_1 = require("../../shared/prisma/prisma.module");
let CrmModule = class CrmModule {
    crmService;
    constructor(crmService) {
        this.crmService = crmService;
    }
    async onModuleInit() {
        await this.crmService.seedDefaultLevels();
    }
};
exports.CrmModule = CrmModule;
exports.CrmModule = CrmModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule],
        controllers: [crm_controller_1.CrmController],
        providers: [crm_service_1.CrmService],
        exports: [crm_service_1.CrmService],
    }),
    __metadata("design:paramtypes", [crm_service_1.CrmService])
], CrmModule);
//# sourceMappingURL=crm.module.js.map