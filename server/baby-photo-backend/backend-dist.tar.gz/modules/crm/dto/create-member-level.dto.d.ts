export declare class CreateMemberLevelDto {
    level: number;
    name: string;
    minGrowth: number;
    maxGrowth: number;
    benefits?: string[];
    icon?: string;
}
