"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateComplaintDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class UpdateComplaintDto {
    title;
    description;
    status;
    priority;
    handlerId;
    resolution;
}
exports.UpdateComplaintDto = UpdateComplaintDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '投诉标题', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateComplaintDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '投诉描述', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateComplaintDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '状态', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateComplaintDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '优先级', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateComplaintDto.prototype, "priority", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '处理人 ID', required: false }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], UpdateComplaintDto.prototype, "handlerId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '处理结果说明', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateComplaintDto.prototype, "resolution", void 0);
//# sourceMappingURL=update-complaint.dto.js.map