export declare class QueryComplaintDto {
    page?: number;
    pageSize?: number;
    status?: string;
    priority?: string;
    search?: string;
}
