export declare class UpdateComplaintDto {
    title?: string;
    description?: string;
    status?: string;
    priority?: string;
    handlerId?: number;
    resolution?: string;
}
