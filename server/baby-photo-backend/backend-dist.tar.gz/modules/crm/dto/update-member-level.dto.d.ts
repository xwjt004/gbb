export declare class UpdateMemberLevelDto {
    name?: string;
    minGrowth?: number;
    maxGrowth?: number;
    benefits?: string[];
    icon?: string;
}
