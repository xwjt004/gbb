export declare class CreateComplaintDto {
    wxUserId: string;
    orderId?: string;
    title: string;
    description: string;
    priority?: string;
}
