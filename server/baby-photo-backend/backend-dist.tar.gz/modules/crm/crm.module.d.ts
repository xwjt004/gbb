import { OnModuleInit } from '@nestjs/common';
import { CrmService } from './crm.service';
export declare class CrmModule implements OnModuleInit {
    private readonly crmService;
    constructor(crmService: CrmService);
    onModuleInit(): Promise<void>;
}
