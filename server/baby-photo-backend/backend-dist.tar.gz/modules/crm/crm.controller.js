"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrmController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const crm_service_1 = require("./crm.service");
const create_member_level_dto_1 = require("./dto/create-member-level.dto");
const update_member_level_dto_1 = require("./dto/update-member-level.dto");
const create_complaint_dto_1 = require("./dto/create-complaint.dto");
const update_complaint_dto_1 = require("./dto/update-complaint.dto");
const query_complaint_dto_1 = require("./dto/query-complaint.dto");
let CrmController = class CrmController {
    crmService;
    constructor(crmService) {
        this.crmService = crmService;
    }
    getMemberLevels() {
        return this.crmService.getMemberLevels();
    }
    createMemberLevel(dto) {
        return this.crmService.createMemberLevel(dto);
    }
    updateMemberLevel(id, dto) {
        return this.crmService.updateMemberLevel(id, dto);
    }
    deleteMemberLevel(id) {
        return this.crmService.deleteMemberLevel(id);
    }
    getGrowthRules() {
        return this.crmService.getGrowthRules();
    }
    getCustomerProfile(wxUserId) {
        return this.crmService.getCustomerProfile(wxUserId);
    }
    createComplaint(dto) {
        return this.crmService.createComplaint(dto);
    }
    findComplaints(query) {
        return this.crmService.findComplaints(query);
    }
    findOneComplaint(id) {
        return this.crmService.findOneComplaint(id);
    }
    updateComplaint(id, dto) {
        return this.crmService.updateComplaint(id, dto);
    }
    deleteComplaint(id) {
        return this.crmService.deleteComplaint(id);
    }
    upgradeAll() {
        return this.crmService.autoUpgradeAll();
    }
    detectChurn() {
        return this.crmService.detectChurnUsers();
    }
    birthdayReminders() {
        return this.crmService.sendBirthdayReminders();
    }
};
exports.CrmController = CrmController;
__decorate([
    (0, common_1.Get)('member-levels'),
    (0, swagger_1.ApiOperation)({ summary: '会员等级列表' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "getMemberLevels", null);
__decorate([
    (0, common_1.Post)('member-levels'),
    (0, swagger_1.ApiOperation)({ summary: '创建会员等级' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_member_level_dto_1.CreateMemberLevelDto]),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "createMemberLevel", null);
__decorate([
    (0, common_1.Patch)('member-levels/:id'),
    (0, swagger_1.ApiOperation)({ summary: '更新会员等级' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, update_member_level_dto_1.UpdateMemberLevelDto]),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "updateMemberLevel", null);
__decorate([
    (0, common_1.Delete)('member-levels/:id'),
    (0, swagger_1.ApiOperation)({ summary: '删除会员等级' }),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "deleteMemberLevel", null);
__decorate([
    (0, common_1.Get)('growth-rules'),
    (0, swagger_1.ApiOperation)({ summary: '成长值规则' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "getGrowthRules", null);
__decorate([
    (0, common_1.Get)('customers/:wxUserId/profile'),
    (0, swagger_1.ApiOperation)({ summary: '客户画像' }),
    __param(0, (0, common_1.Param)('wxUserId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "getCustomerProfile", null);
__decorate([
    (0, common_1.Post)('complaints'),
    (0, swagger_1.ApiOperation)({ summary: '创建投诉' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_complaint_dto_1.CreateComplaintDto]),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "createComplaint", null);
__decorate([
    (0, common_1.Get)('complaints'),
    (0, swagger_1.ApiOperation)({ summary: '投诉列表' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_complaint_dto_1.QueryComplaintDto]),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "findComplaints", null);
__decorate([
    (0, common_1.Get)('complaints/:id'),
    (0, swagger_1.ApiOperation)({ summary: '投诉详情' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "findOneComplaint", null);
__decorate([
    (0, common_1.Patch)('complaints/:id'),
    (0, swagger_1.ApiOperation)({ summary: '更新投诉' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_complaint_dto_1.UpdateComplaintDto]),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "updateComplaint", null);
__decorate([
    (0, common_1.Delete)('complaints/:id'),
    (0, swagger_1.ApiOperation)({ summary: '删除投诉' }),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "deleteComplaint", null);
__decorate([
    (0, common_1.Post)('upgrade-all'),
    (0, swagger_1.ApiOperation)({ summary: '手动触发全部会员等级升级' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "upgradeAll", null);
__decorate([
    (0, common_1.Post)('detect-churn'),
    (0, swagger_1.ApiOperation)({ summary: '手动触发流失检测' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "detectChurn", null);
__decorate([
    (0, common_1.Post)('birthday-reminders'),
    (0, swagger_1.ApiOperation)({ summary: '手动触发生日提醒' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], CrmController.prototype, "birthdayReminders", null);
exports.CrmController = CrmController = __decorate([
    (0, swagger_1.ApiTags)('CRM'),
    (0, common_1.Controller)('crm'),
    __metadata("design:paramtypes", [crm_service_1.CrmService])
], CrmController);
//# sourceMappingURL=crm.controller.js.map