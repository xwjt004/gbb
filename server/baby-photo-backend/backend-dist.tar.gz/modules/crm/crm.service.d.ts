import { PrismaService } from '../../shared/prisma/prisma.service';
import { CreateMemberLevelDto } from './dto/create-member-level.dto';
import { UpdateMemberLevelDto } from './dto/update-member-level.dto';
import { CreateComplaintDto } from './dto/create-complaint.dto';
import { UpdateComplaintDto } from './dto/update-complaint.dto';
import { QueryComplaintDto } from './dto/query-complaint.dto';
export declare class CrmService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    seedDefaultLevels(): Promise<void>;
    getMemberLevels(): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            icon: string | null;
            level: number;
            minGrowth: number;
            maxGrowth: number;
            benefits: import("@prisma/client/runtime/library").JsonValue | null;
        }[];
    }>;
    createMemberLevel(dto: CreateMemberLevelDto): Promise<{
        code: number;
        message: string;
        data: null;
    } | {
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            icon: string | null;
            level: number;
            minGrowth: number;
            maxGrowth: number;
            benefits: import("@prisma/client/runtime/library").JsonValue | null;
        };
    }>;
    updateMemberLevel(id: number, dto: UpdateMemberLevelDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            icon: string | null;
            level: number;
            minGrowth: number;
            maxGrowth: number;
            benefits: import("@prisma/client/runtime/library").JsonValue | null;
        };
    }>;
    deleteMemberLevel(id: number): Promise<{
        code: number;
        message: string;
        data: null;
    }>;
    getGrowthRules(): Promise<{
        code: number;
        message: string;
        data: {
            orderAmountRate: number;
            orderCompleteBonus: number;
            dailyCheckinBonus: number;
            maxDailyGrowth: number;
        };
    }>;
    private calculateLevel;
    autoUpgradeAll(): Promise<{
        code: number;
        message: string;
        data: {
            total: number;
            upgraded: number;
        };
    }>;
    private getLevelName;
    getCustomerProfile(wxUserId: string): Promise<{
        code: number;
        message: string;
        data: {
            basic: {
                id: string;
                openid: string;
                nickname: string | null;
                avatar: string | null;
                phone: string | null;
                realName: string | null;
                birthday: Date | null;
                status: import("@prisma/client").$Enums.WxUserStatus;
                linkedUserId: number | null;
                linkedUserName: string | null | undefined;
            };
            member: {
                level: string;
                levelInfo: {
                    id: number;
                    createdAt: Date;
                    updatedAt: Date;
                    name: string;
                    icon: string | null;
                    level: number;
                    minGrowth: number;
                    maxGrowth: number;
                    benefits: import("@prisma/client/runtime/library").JsonValue | null;
                } | null;
                growthPoints: number;
                nextLevel: {
                    name: string;
                    minGrowth: number;
                } | null;
                growthProgress: {
                    current: number;
                    min: number;
                    max: number;
                    remaining: number;
                };
            };
            stats: {
                totalOrders: number;
                totalAmount: import("@prisma/client/runtime/library").Decimal;
                lastOrderAt: Date | null;
                lastLoginAt: Date | null;
                churnStatus: string;
                createdAt: Date;
            };
            orders: {
                id: string;
                orderNo: string;
                packageName: string;
                totalAmount: import("@prisma/client/runtime/library").Decimal;
                status: import("@prisma/client").$Enums.OrderStatus;
                createdAt: Date;
            }[];
            coupons: {
                id: string;
                name: string;
                code: string;
                status: import("@prisma/client").$Enums.UserCouponStatus;
                expiredAt: Date;
            }[];
        };
    }>;
    createComplaint(dto: CreateComplaintDto): Promise<{
        code: number;
        message: string;
        data: {
            wxUser: {
                nickname: string | null;
                phone: string | null;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            wxUserId: string;
            status: string;
            description: string;
            orderId: string | null;
            title: string;
            priority: string;
            handledAt: Date | null;
            handlerId: number | null;
            resolution: string | null;
            complaintNo: string;
        };
    }>;
    findComplaints(query: QueryComplaintDto): Promise<{
        code: number;
        message: string;
        data: {
            items: ({
                wxUser: {
                    nickname: string | null;
                    avatar: string | null;
                    phone: string | null;
                };
                handler: {
                    nickname: string | null;
                } | null;
            } & {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                wxUserId: string;
                status: string;
                description: string;
                orderId: string | null;
                title: string;
                priority: string;
                handledAt: Date | null;
                handlerId: number | null;
                resolution: string | null;
                complaintNo: string;
            })[];
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
        };
    }>;
    findOneComplaint(id: string): Promise<{
        code: number;
        message: string;
        data: {
            wxUser: {
                nickname: string | null;
                avatar: string | null;
                phone: string | null;
            };
            handler: {
                nickname: string | null;
            } | null;
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            wxUserId: string;
            status: string;
            description: string;
            orderId: string | null;
            title: string;
            priority: string;
            handledAt: Date | null;
            handlerId: number | null;
            resolution: string | null;
            complaintNo: string;
        };
    }>;
    updateComplaint(id: string, dto: UpdateComplaintDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            wxUserId: string;
            status: string;
            description: string;
            orderId: string | null;
            title: string;
            priority: string;
            handledAt: Date | null;
            handlerId: number | null;
            resolution: string | null;
            complaintNo: string;
        };
    }>;
    deleteComplaint(id: string): Promise<{
        code: number;
        message: string;
        data: null;
    }>;
    detectChurnUsers(): Promise<{
        code: number;
        message: string;
        data: {
            atRisk: number;
        };
    }>;
    sendBirthdayReminders(): Promise<{
        code: number;
        message: string;
        data: {
            total: number;
        };
    }>;
}
