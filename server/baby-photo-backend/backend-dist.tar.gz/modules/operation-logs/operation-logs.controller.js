"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationLogsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const operation_logs_service_1 = require("./operation-logs.service");
const query_operation_log_dto_1 = require("./dto/query-operation-log.dto");
let OperationLogsController = class OperationLogsController {
    service;
    constructor(service) {
        this.service = service;
    }
    async findAll(query) {
        return this.service.findAll({
            ...query,
            page: query.page || 1,
            pageSize: query.pageSize || 20,
        });
    }
    async getModules() {
        return this.service.getModules();
    }
};
exports.OperationLogsController = OperationLogsController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '查询操作日志列表' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_operation_log_dto_1.QueryOperationLogDto]),
    __metadata("design:returntype", Promise)
], OperationLogsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('modules'),
    (0, swagger_1.ApiOperation)({ summary: '获取所有模块列表' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OperationLogsController.prototype, "getModules", null);
exports.OperationLogsController = OperationLogsController = __decorate([
    (0, swagger_1.ApiTags)('操作日志'),
    (0, common_1.Controller)('operation-logs'),
    __metadata("design:paramtypes", [operation_logs_service_1.OperationLogsService])
], OperationLogsController);
//# sourceMappingURL=operation-logs.controller.js.map