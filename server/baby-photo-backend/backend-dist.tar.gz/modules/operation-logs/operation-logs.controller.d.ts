import { OperationLogsService } from './operation-logs.service';
import { QueryOperationLogDto } from './dto/query-operation-log.dto';
export declare class OperationLogsController {
    private readonly service;
    constructor(service: OperationLogsService);
    findAll(query: QueryOperationLogDto): Promise<{
        items: {
            id: string;
            createdAt: Date;
            operatorId: string | null;
            operatorName: string | null;
            action: string;
            duration: number;
            params: import("@prisma/client/runtime/library").JsonValue | null;
            ip: string | null;
            method: string;
            path: string;
            module: string;
            targetId: string | null;
            targetDesc: string | null;
            statusCode: number;
        }[];
        total: number;
        page: number;
        pageSize: number;
    }>;
    getModules(): Promise<string[]>;
}
