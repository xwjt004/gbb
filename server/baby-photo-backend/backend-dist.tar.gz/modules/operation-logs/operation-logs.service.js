"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationLogsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let OperationLogsService = class OperationLogsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(data) {
        return this.prisma.operationLog.create({ data });
    }
    async findAll(query) {
        const where = {};
        if (query.module) {
            where.module = query.module;
        }
        if (query.operatorName) {
            where.operatorName = { contains: query.operatorName };
        }
        if (query.startDate || query.endDate) {
            where.createdAt = {};
            if (query.startDate)
                where.createdAt.gte = new Date(query.startDate);
            if (query.endDate)
                where.createdAt.lte = new Date(query.endDate);
        }
        const [items, total] = await Promise.all([
            this.prisma.operationLog.findMany({
                where,
                orderBy: { createdAt: 'desc' },
                skip: (query.page - 1) * query.pageSize,
                take: query.pageSize,
            }),
            this.prisma.operationLog.count({ where }),
        ]);
        return { items, total, page: query.page, pageSize: query.pageSize };
    }
    async getModules() {
        const result = await this.prisma.operationLog.findMany({
            select: { module: true },
            distinct: ['module'],
            orderBy: { module: 'asc' },
        });
        return result.map((r) => r.module);
    }
};
exports.OperationLogsService = OperationLogsService;
exports.OperationLogsService = OperationLogsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], OperationLogsService);
//# sourceMappingURL=operation-logs.service.js.map