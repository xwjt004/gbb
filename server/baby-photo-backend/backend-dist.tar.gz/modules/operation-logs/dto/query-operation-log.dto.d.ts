export declare class QueryOperationLogDto {
    module?: string;
    operatorName?: string;
    startDate?: string;
    endDate?: string;
    page?: number;
    pageSize?: number;
}
