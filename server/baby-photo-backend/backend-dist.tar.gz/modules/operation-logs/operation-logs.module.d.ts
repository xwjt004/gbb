export declare class OperationLogsModule {
}
