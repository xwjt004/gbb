import { PrismaService } from '../../shared/prisma/prisma.service';
import { Prisma } from '@prisma/client';
export declare class OperationLogsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(data: Prisma.OperationLogCreateInput): Promise<{
        id: string;
        createdAt: Date;
        operatorId: string | null;
        operatorName: string | null;
        action: string;
        duration: number;
        params: Prisma.JsonValue | null;
        ip: string | null;
        method: string;
        path: string;
        module: string;
        targetId: string | null;
        targetDesc: string | null;
        statusCode: number;
    }>;
    findAll(query: {
        module?: string;
        operatorName?: string;
        startDate?: string;
        endDate?: string;
        page: number;
        pageSize: number;
    }): Promise<{
        items: {
            id: string;
            createdAt: Date;
            operatorId: string | null;
            operatorName: string | null;
            action: string;
            duration: number;
            params: Prisma.JsonValue | null;
            ip: string | null;
            method: string;
            path: string;
            module: string;
            targetId: string | null;
            targetDesc: string | null;
            statusCode: number;
        }[];
        total: number;
        page: number;
        pageSize: number;
    }>;
    getModules(): Promise<string[]>;
}
