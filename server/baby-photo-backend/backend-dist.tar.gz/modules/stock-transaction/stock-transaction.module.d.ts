export declare class StockTransactionModule {
}
