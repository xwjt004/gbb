"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var StockTransactionService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockTransactionService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let StockTransactionService = StockTransactionService_1 = class StockTransactionService {
    prisma;
    logger = new common_1.Logger(StockTransactionService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async generateTransactionNo() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const dateStr = `${year}${month}${day}`;
        const startOfDay = new Date(year, now.getMonth(), now.getDate(), 0, 0, 0, 0);
        const endOfDay = new Date(year, now.getMonth(), now.getDate(), 23, 59, 59, 999);
        const count = await this.prisma.stockTransaction.count({
            where: {
                createdAt: {
                    gte: startOfDay,
                    lte: endOfDay
                }
            }
        });
        const sequence = String(count + 1).padStart(6, '0');
        return `TXN-${dateStr}-${sequence}`;
    }
    async findAll(queryDto) {
        const { productId, transactionType, refType, refId, startDate, endDate, operatorId, page = 1, limit = 20 } = queryDto;
        const where = {};
        if (productId) {
            where.productId = productId;
        }
        if (transactionType) {
            where.transactionType = transactionType;
        }
        if (refType) {
            where.refType = refType;
        }
        if (refId) {
            where.refId = refId;
        }
        if (operatorId) {
            where.operatorId = operatorId;
        }
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate) {
                where.createdAt.gte = new Date(startDate);
            }
            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                where.createdAt.lte = end;
            }
        }
        const total = await this.prisma.stockTransaction.count({ where });
        const items = await this.prisma.stockTransaction.findMany({
            where,
            include: {
                product: {
                    select: {
                        id: true,
                        productNo: true,
                        name: true,
                        unit: true
                    }
                },
                operator: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            },
            orderBy: {
                createdAt: 'desc'
            },
            skip: (page - 1) * limit,
            take: limit
        });
        return {
            items,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit)
        };
    }
    async findOne(id) {
        const transaction = await this.prisma.stockTransaction.findUnique({
            where: { id },
            include: {
                product: {
                    select: {
                        id: true,
                        productNo: true,
                        name: true,
                        unit: true,
                        category: true
                    }
                },
                operator: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        if (!transaction) {
            throw new common_1.NotFoundException('库存流水记录不存在');
        }
        return transaction;
    }
    async findByProduct(productId, startDate, endDate) {
        const product = await this.prisma.product.findUnique({
            where: { id: productId },
            select: {
                id: true,
                productNo: true,
                name: true,
                stockQuantity: true
            }
        });
        if (!product) {
            throw new common_1.NotFoundException('商品不存在');
        }
        const where = { productId };
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate) {
                where.createdAt.gte = new Date(startDate);
            }
            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                where.createdAt.lte = end;
            }
        }
        const transactions = await this.prisma.stockTransaction.findMany({
            where,
            include: {
                operator: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            },
            orderBy: {
                createdAt: 'desc'
            }
        });
        return {
            product,
            transactions,
            total: transactions.length
        };
    }
    async statistics(productId, startDate, endDate) {
        const where = {};
        if (productId) {
            where.productId = productId;
        }
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate) {
                where.createdAt.gte = new Date(startDate);
            }
            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                where.createdAt.lte = end;
            }
        }
        const transactions = await this.prisma.stockTransaction.findMany({
            where,
            select: {
                transactionType: true,
                quantity: true
            }
        });
        let totalInbound = 0;
        let totalOutbound = 0;
        const byType = {};
        transactions.forEach(txn => {
            if (!byType[txn.transactionType]) {
                byType[txn.transactionType] = 0;
            }
            byType[txn.transactionType] += txn.quantity;
            if (txn.quantity > 0) {
                totalInbound += txn.quantity;
            }
            else {
                totalOutbound += Math.abs(txn.quantity);
            }
        });
        const netChange = totalInbound - totalOutbound;
        const typeStats = Object.keys(byType).map(type => ({
            type,
            quantity: byType[type]
        }));
        return {
            totalInbound,
            totalOutbound,
            netChange,
            totalRecords: transactions.length,
            byType: typeStats
        };
    }
    async manualAdjust(adjustDto) {
        this.logger.log(`[manualAdjust] 开始手工调整库存: ${JSON.stringify(adjustDto)}`);
        const { productId, quantity, remark, operatorId } = adjustDto;
        this.logger.log(`[manualAdjust] 查询商品 ID=${productId}`);
        const product = await this.prisma.product.findUnique({
            where: { id: productId }
        });
        if (!product) {
            this.logger.error(`[manualAdjust] 商品不存在: ID=${productId}`);
            throw new common_1.NotFoundException('商品不存在');
        }
        this.logger.log(`[manualAdjust] 商品找到: ${product.name}, 当前库存=${product.stockQuantity}`);
        this.logger.log(`[manualAdjust] 商品找到: ${product.name}, 当前库存=${product.stockQuantity}`);
        const beforeStock = product.stockQuantity;
        const afterStock = beforeStock + quantity;
        this.logger.log(`[manualAdjust] 库存计算: 调整前=${beforeStock}, 调整数量=${quantity}, 调整后=${afterStock}`);
        if (afterStock < 0) {
            this.logger.error(`[manualAdjust] 库存不足: 当前=${beforeStock}, 调整=${quantity}, 结果=${afterStock}`);
            throw new common_1.BadRequestException(`调整后库存不能为负数。当前库存: ${beforeStock}，调整数量: ${quantity}`);
        }
        this.logger.log(`[manualAdjust] 开始生成流水号...`);
        const transactionNo = await this.generateTransactionNo();
        this.logger.log(`[manualAdjust] 流水号生成成功: ${transactionNo}`);
        this.logger.log(`[manualAdjust] 流水号生成成功: ${transactionNo}`);
        this.logger.log(`[manualAdjust] 开始执行数据库事务...`);
        try {
            const result = await this.prisma.$transaction(async (tx) => {
                this.logger.log(`[manualAdjust] 事务内: 创建库存流水记录...`);
                const transaction = await tx.stockTransaction.create({
                    data: {
                        transactionNo,
                        productId,
                        transactionType: 'MANUAL_ADJUST',
                        quantity,
                        beforeStock,
                        afterStock,
                        operatorId,
                        remark: remark || '手工调整库存'
                    },
                    include: {
                        product: {
                            select: {
                                id: true,
                                productNo: true,
                                name: true
                            }
                        },
                        operator: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        }
                    }
                });
                this.logger.log(`[manualAdjust] 事务内: 流水记录创建成功 ID=${transaction.id}`);
                this.logger.log(`[manualAdjust] 事务内: 更新商品库存 productId=${productId}, newStock=${afterStock}`);
                await tx.product.update({
                    where: { id: productId },
                    data: {
                        stockQuantity: afterStock
                    }
                });
                this.logger.log(`[manualAdjust] 事务内: 商品库存更新成功`);
                return transaction;
            });
            this.logger.log(`[manualAdjust] 手工调整库存成功: 商品ID=${productId}, 调整数量=${quantity}, ` +
                `变动前=${beforeStock}, 变动后=${afterStock}, 流水号=${transactionNo}`);
            return result;
        }
        catch (error) {
            this.logger.error(`[manualAdjust] 事务执行失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async exportTransactions(queryDto) {
        const { productId, transactionType, refType, refId, startDate, endDate, operatorId } = queryDto;
        const where = {};
        if (productId)
            where.productId = productId;
        if (transactionType)
            where.transactionType = transactionType;
        if (refType)
            where.refType = refType;
        if (refId)
            where.refId = refId;
        if (operatorId)
            where.operatorId = operatorId;
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate) {
                where.createdAt.gte = new Date(startDate);
            }
            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                where.createdAt.lte = end;
            }
        }
        const transactions = await this.prisma.stockTransaction.findMany({
            where,
            include: {
                product: {
                    select: {
                        productNo: true,
                        name: true,
                        unit: true
                    }
                },
                operator: {
                    select: {
                        nickname: true
                    }
                }
            },
            orderBy: {
                createdAt: 'desc'
            }
        });
        const exportData = transactions.map(txn => ({
            流水号: txn.transactionNo,
            商品编号: txn.product.productNo,
            商品名称: txn.product.name,
            单位: txn.product.unit,
            变动类型: this.getTransactionTypeLabel(txn.transactionType),
            变动数量: txn.quantity,
            变动前库存: txn.beforeStock,
            变动后库存: txn.afterStock,
            关联类型: txn.refType || '-',
            关联单号: txn.refId || '-',
            操作人: txn.operator.nickname,
            备注: txn.remark || '-',
            操作时间: txn.createdAt.toISOString()
        }));
        return {
            data: exportData,
            total: exportData.length,
            exportTime: new Date().toISOString()
        };
    }
    getTransactionTypeLabel(type) {
        const labels = {
            'INBOUND': '入库',
            'OUTBOUND': '出库',
            'CHECK_IN': '盘盈',
            'CHECK_OUT': '盘亏',
            'TRANSFER_IN': '调拨入库',
            'TRANSFER_OUT': '调拨出库',
            'MANUAL_ADJUST': '手工调整'
        };
        return labels[type] || type;
    }
};
exports.StockTransactionService = StockTransactionService;
exports.StockTransactionService = StockTransactionService = StockTransactionService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], StockTransactionService);
//# sourceMappingURL=stock-transaction.service.js.map