import { PrismaService } from '../../shared/prisma/prisma.service';
import { QueryTransactionDto, ManualAdjustDto } from './dto';
export declare class StockTransactionService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    private generateTransactionNo;
    findAll(queryDto: QueryTransactionDto): Promise<{
        items: ({
            product: {
                id: number;
                name: string;
                productNo: string;
                unit: string;
            };
            operator: {
                id: number;
                nickname: string | null;
            };
        } & {
            id: string;
            createdAt: Date;
            operatorId: number;
            productId: number;
            quantity: number;
            remark: string | null;
            transactionNo: string;
            transactionType: string;
            beforeStock: number;
            afterStock: number;
            refType: string | null;
            refId: string | null;
            outboundId: string | null;
            checkId: string | null;
        })[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    findOne(id: string): Promise<{
        product: {
            id: number;
            name: string;
            category: {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                description: string | null;
                sortOrder: number;
                code: string;
                isActive: boolean;
            };
            productNo: string;
            unit: string;
        };
        operator: {
            id: number;
            nickname: string | null;
        };
    } & {
        id: string;
        createdAt: Date;
        operatorId: number;
        productId: number;
        quantity: number;
        remark: string | null;
        transactionNo: string;
        transactionType: string;
        beforeStock: number;
        afterStock: number;
        refType: string | null;
        refId: string | null;
        outboundId: string | null;
        checkId: string | null;
    }>;
    findByProduct(productId: number, startDate?: string, endDate?: string): Promise<{
        product: {
            id: number;
            name: string;
            productNo: string;
            stockQuantity: number;
        };
        transactions: ({
            operator: {
                id: number;
                nickname: string | null;
            };
        } & {
            id: string;
            createdAt: Date;
            operatorId: number;
            productId: number;
            quantity: number;
            remark: string | null;
            transactionNo: string;
            transactionType: string;
            beforeStock: number;
            afterStock: number;
            refType: string | null;
            refId: string | null;
            outboundId: string | null;
            checkId: string | null;
        })[];
        total: number;
    }>;
    statistics(productId?: number, startDate?: string, endDate?: string): Promise<{
        totalInbound: number;
        totalOutbound: number;
        netChange: number;
        totalRecords: number;
        byType: {
            type: string;
            quantity: number;
        }[];
    }>;
    manualAdjust(adjustDto: ManualAdjustDto): Promise<{
        product: {
            id: number;
            name: string;
            productNo: string;
        };
        operator: {
            id: number;
            nickname: string | null;
        };
    } & {
        id: string;
        createdAt: Date;
        operatorId: number;
        productId: number;
        quantity: number;
        remark: string | null;
        transactionNo: string;
        transactionType: string;
        beforeStock: number;
        afterStock: number;
        refType: string | null;
        refId: string | null;
        outboundId: string | null;
        checkId: string | null;
    }>;
    exportTransactions(queryDto: QueryTransactionDto): Promise<{
        data: {
            流水号: string;
            商品编号: string;
            商品名称: string;
            单位: string;
            变动类型: string;
            变动数量: number;
            变动前库存: number;
            变动后库存: number;
            关联类型: string;
            关联单号: string;
            操作人: string | null;
            备注: string;
            操作时间: string;
        }[];
        total: number;
        exportTime: string;
    }>;
    private getTransactionTypeLabel;
}
