export declare class QueryTransactionDto {
    productId?: number;
    transactionType?: string;
    refType?: string;
    refId?: string;
    startDate?: string;
    endDate?: string;
    operatorId?: number;
    page?: number;
    limit?: number;
}
