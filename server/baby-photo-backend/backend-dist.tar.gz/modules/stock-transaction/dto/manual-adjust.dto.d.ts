export declare class ManualAdjustDto {
    productId: number;
    quantity: number;
    remark?: string;
    operatorId: number;
}
