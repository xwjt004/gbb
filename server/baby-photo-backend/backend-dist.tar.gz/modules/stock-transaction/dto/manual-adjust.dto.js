"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ManualAdjustDto = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const swagger_1 = require("@nestjs/swagger");
class ManualAdjustDto {
    productId;
    quantity;
    remark;
    operatorId;
}
exports.ManualAdjustDto = ManualAdjustDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品ID', example: 1 }),
    (0, class_validator_1.IsNotEmpty)({ message: '商品ID不能为空' }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)({ message: '商品ID必须是整数' }),
    __metadata("design:type", Number)
], ManualAdjustDto.prototype, "productId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '调整数量（正数=增加，负数=减少）',
        example: 10
    }),
    (0, class_validator_1.IsNotEmpty)({ message: '调整数量不能为空' }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)({ message: '调整数量必须是整数' }),
    __metadata("design:type", Number)
], ManualAdjustDto.prototype, "quantity", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '调整原因', example: '盘点后手工调整' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ManualAdjustDto.prototype, "remark", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '操作人ID', example: 1 }),
    (0, class_validator_1.IsNotEmpty)({ message: '操作人ID不能为空' }),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)({ message: '操作人ID必须是整数' }),
    __metadata("design:type", Number)
], ManualAdjustDto.prototype, "operatorId", void 0);
//# sourceMappingURL=manual-adjust.dto.js.map