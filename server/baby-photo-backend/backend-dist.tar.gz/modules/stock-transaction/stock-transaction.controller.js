"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var StockTransactionController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockTransactionController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const stock_transaction_service_1 = require("./stock-transaction.service");
const dto_1 = require("./dto");
let StockTransactionController = StockTransactionController_1 = class StockTransactionController {
    stockTransactionService;
    logger = new common_1.Logger(StockTransactionController_1.name);
    constructor(stockTransactionService) {
        this.stockTransactionService = stockTransactionService;
    }
    async findAll(queryDto) {
        const result = await this.stockTransactionService.findAll(queryDto);
        return {
            success: true,
            data: result,
            message: '查询成功'
        };
    }
    async findOne(id) {
        const transaction = await this.stockTransactionService.findOne(id);
        return {
            success: true,
            data: transaction,
            message: '查询成功'
        };
    }
    async findByProduct(productId, startDate, endDate) {
        const result = await this.stockTransactionService.findByProduct(parseInt(productId), startDate, endDate);
        return {
            success: true,
            data: result,
            message: '查询成功'
        };
    }
    async statistics(productId, startDate, endDate) {
        const stats = await this.stockTransactionService.statistics(productId ? parseInt(productId) : undefined, startDate, endDate);
        return {
            success: true,
            data: stats,
            message: '统计成功'
        };
    }
    async manualAdjust(adjustDto) {
        this.logger.log(`[Controller] 收到手工调整请求: ${JSON.stringify(adjustDto)}`);
        try {
            const result = await this.stockTransactionService.manualAdjust(adjustDto);
            this.logger.log(`[Controller] 手工调整成功: 流水号=${result.transactionNo}`);
            return {
                success: true,
                data: result,
                message: '库存调整成功'
            };
        }
        catch (error) {
            this.logger.error(`[Controller] 手工调整失败: ${error.message}`, error.stack);
            throw error;
        }
    }
    async export(queryDto) {
        const result = await this.stockTransactionService.exportTransactions(queryDto);
        return {
            success: true,
            data: result,
            message: '导出成功'
        };
    }
};
exports.StockTransactionController = StockTransactionController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '查询库存流水列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [dto_1.QueryTransactionDto]),
    __metadata("design:returntype", Promise)
], StockTransactionController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '查询流水详情' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '流水记录ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '流水记录不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], StockTransactionController.prototype, "findOne", null);
__decorate([
    (0, common_1.Get)('product/:productId'),
    (0, swagger_1.ApiOperation)({ summary: '查询商品流水记录' }),
    (0, swagger_1.ApiParam)({ name: 'productId', description: '商品ID', type: 'number' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, description: '开始日期' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, description: '结束日期' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '商品不存在' }),
    __param(0, (0, common_1.Param)('productId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], StockTransactionController.prototype, "findByProduct", null);
__decorate([
    (0, common_1.Get)('statistics/summary'),
    (0, swagger_1.ApiOperation)({ summary: '库存流水统计' }),
    (0, swagger_1.ApiQuery)({ name: 'productId', required: false, description: '商品ID' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, description: '开始日期' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, description: '结束日期' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '统计成功' }),
    __param(0, (0, common_1.Query)('productId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], StockTransactionController.prototype, "statistics", null);
__decorate([
    (0, common_1.Post)('manual-adjust'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: '手工调整库存' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '调整成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '参数错误或库存不足' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '商品不存在' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [dto_1.ManualAdjustDto]),
    __metadata("design:returntype", Promise)
], StockTransactionController.prototype, "manualAdjust", null);
__decorate([
    (0, common_1.Post)('export'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: '导出库存流水' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '导出成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [dto_1.QueryTransactionDto]),
    __metadata("design:returntype", Promise)
], StockTransactionController.prototype, "export", null);
exports.StockTransactionController = StockTransactionController = StockTransactionController_1 = __decorate([
    (0, swagger_1.ApiTags)('库存管理 - 库存流水'),
    (0, common_1.Controller)('stock-transaction'),
    __metadata("design:paramtypes", [stock_transaction_service_1.StockTransactionService])
], StockTransactionController);
//# sourceMappingURL=stock-transaction.controller.js.map