import { StockTransactionService } from './stock-transaction.service';
import { QueryTransactionDto, ManualAdjustDto } from './dto';
export declare class StockTransactionController {
    private readonly stockTransactionService;
    private readonly logger;
    constructor(stockTransactionService: StockTransactionService);
    findAll(queryDto: QueryTransactionDto): Promise<{
        success: boolean;
        data: {
            items: ({
                product: {
                    id: number;
                    name: string;
                    productNo: string;
                    unit: string;
                };
                operator: {
                    id: number;
                    nickname: string | null;
                };
            } & {
                id: string;
                createdAt: Date;
                operatorId: number;
                productId: number;
                quantity: number;
                remark: string | null;
                transactionNo: string;
                transactionType: string;
                beforeStock: number;
                afterStock: number;
                refType: string | null;
                refId: string | null;
                outboundId: string | null;
                checkId: string | null;
            })[];
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
        message: string;
    }>;
    findOne(id: string): Promise<{
        success: boolean;
        data: {
            product: {
                id: number;
                name: string;
                category: {
                    id: number;
                    createdAt: Date;
                    updatedAt: Date;
                    name: string;
                    description: string | null;
                    sortOrder: number;
                    code: string;
                    isActive: boolean;
                };
                productNo: string;
                unit: string;
            };
            operator: {
                id: number;
                nickname: string | null;
            };
        } & {
            id: string;
            createdAt: Date;
            operatorId: number;
            productId: number;
            quantity: number;
            remark: string | null;
            transactionNo: string;
            transactionType: string;
            beforeStock: number;
            afterStock: number;
            refType: string | null;
            refId: string | null;
            outboundId: string | null;
            checkId: string | null;
        };
        message: string;
    }>;
    findByProduct(productId: string, startDate?: string, endDate?: string): Promise<{
        success: boolean;
        data: {
            product: {
                id: number;
                name: string;
                productNo: string;
                stockQuantity: number;
            };
            transactions: ({
                operator: {
                    id: number;
                    nickname: string | null;
                };
            } & {
                id: string;
                createdAt: Date;
                operatorId: number;
                productId: number;
                quantity: number;
                remark: string | null;
                transactionNo: string;
                transactionType: string;
                beforeStock: number;
                afterStock: number;
                refType: string | null;
                refId: string | null;
                outboundId: string | null;
                checkId: string | null;
            })[];
            total: number;
        };
        message: string;
    }>;
    statistics(productId?: string, startDate?: string, endDate?: string): Promise<{
        success: boolean;
        data: {
            totalInbound: number;
            totalOutbound: number;
            netChange: number;
            totalRecords: number;
            byType: {
                type: string;
                quantity: number;
            }[];
        };
        message: string;
    }>;
    manualAdjust(adjustDto: ManualAdjustDto): Promise<{
        success: boolean;
        data: {
            product: {
                id: number;
                name: string;
                productNo: string;
            };
            operator: {
                id: number;
                nickname: string | null;
            };
        } & {
            id: string;
            createdAt: Date;
            operatorId: number;
            productId: number;
            quantity: number;
            remark: string | null;
            transactionNo: string;
            transactionType: string;
            beforeStock: number;
            afterStock: number;
            refType: string | null;
            refId: string | null;
            outboundId: string | null;
            checkId: string | null;
        };
        message: string;
    }>;
    export(queryDto: QueryTransactionDto): Promise<{
        success: boolean;
        data: {
            data: {
                流水号: string;
                商品编号: string;
                商品名称: string;
                单位: string;
                变动类型: string;
                变动数量: number;
                变动前库存: number;
                变动后库存: number;
                关联类型: string;
                关联单号: string;
                操作人: string | null;
                备注: string;
                操作时间: string;
            }[];
            total: number;
            exportTime: string;
        };
        message: string;
    }>;
}
