"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemBackupModule = void 0;
const common_1 = require("@nestjs/common");
const system_backup_controller_1 = require("./system-backup.controller");
const system_backup_service_1 = require("./system-backup.service");
const prisma_module_1 = require("../../shared/prisma/prisma.module");
let SystemBackupModule = class SystemBackupModule {
};
exports.SystemBackupModule = SystemBackupModule;
exports.SystemBackupModule = SystemBackupModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule],
        controllers: [system_backup_controller_1.SystemBackupController],
        providers: [system_backup_service_1.SystemBackupService],
        exports: [system_backup_service_1.SystemBackupService],
    })
], SystemBackupModule);
//# sourceMappingURL=system-backup.module.js.map