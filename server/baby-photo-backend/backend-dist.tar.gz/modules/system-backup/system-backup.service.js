"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SystemBackupService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemBackupService = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const child_process_1 = require("child_process");
const util_1 = require("util");
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const backup_entity_1 = require("./entities/backup.entity");
const execAsync = (0, util_1.promisify)(child_process_1.exec);
let SystemBackupService = SystemBackupService_1 = class SystemBackupService {
    prisma;
    schedulerRegistry;
    logger = new common_1.Logger(SystemBackupService_1.name);
    backupDir = path.join(process.cwd(), 'backups');
    currentConfig;
    pgBinPath;
    constructor(prisma, schedulerRegistry) {
        this.prisma = prisma;
        this.schedulerRegistry = schedulerRegistry;
        this.pgBinPath = this.getPostgreSQLBinPath();
        this.ensureBackupDirectory();
        this.initializeScheduledBackup().catch((error) => {
            this.logger.error('Failed to initialize scheduled backup', error);
        });
    }
    getPostgreSQLBinPath() {
        const isWindows = process.platform === 'win32';
        if (isWindows) {
            const possiblePaths = [
                'C:\\Program Files\\PostgreSQL\\17\\bin',
                'C:\\Program Files\\PostgreSQL\\16\\bin',
                'C:\\Program Files\\PostgreSQL\\15\\bin',
                'C:\\Program Files\\PostgreSQL\\14\\bin',
                'C:\\Program Files (x86)\\PostgreSQL\\17\\bin',
                'C:\\Program Files (x86)\\PostgreSQL\\16\\bin',
            ];
            const envPath = process.env.POSTGRESQL_BIN_PATH;
            if (envPath) {
                return envPath;
            }
            return possiblePaths[0];
        }
        return '';
    }
    async ensureBackupDirectory() {
        try {
            await fs.access(this.backupDir);
        }
        catch {
            await fs.mkdir(this.backupDir, { recursive: true });
            this.logger.log(`Created backup directory: ${this.backupDir}`);
        }
    }
    async initializeScheduledBackup() {
        try {
            const config = await this.getConfig();
            this.currentConfig = config;
            if (config.autoBackup) {
                this.scheduleBackup(config);
            }
        }
        catch (error) {
            this.logger.error('Failed to initialize scheduled backup', error);
        }
    }
    scheduleBackup(config) {
        if (!this.schedulerRegistry) {
            this.logger.warn('SchedulerRegistry not available, scheduled backup disabled');
            return;
        }
        try {
            const existingJob = this.schedulerRegistry.getCronJob('auto-backup');
            if (existingJob) {
                existingJob.stop();
                this.schedulerRegistry.deleteCronJob('auto-backup');
            }
        }
        catch (error) {
        }
        if (!config.autoBackup) {
            this.logger.log('Auto backup is disabled');
            return;
        }
        const [hour, minute] = config.backupTime.split(':').map(Number);
        let cronExpression;
        switch (config.backupFrequency) {
            case 'daily':
                cronExpression = `${minute} ${hour} * * *`;
                break;
            case 'weekly':
                cronExpression = `${minute} ${hour} * * 1`;
                break;
            case 'monthly':
                cronExpression = `${minute} ${hour} 1 * *`;
                break;
            default:
                cronExpression = `${minute} ${hour} * * *`;
        }
        this.logger.log(`Scheduling auto backup: ${cronExpression} (${config.backupFrequency})`);
        const callback = async () => {
            this.logger.log('Running scheduled backup...');
            try {
                await this.createBackup({
                    description: `自动备份 - ${config.backupFrequency}`,
                    includeUploads: config.includeUploads
                }, backup_entity_1.BackupType.SCHEDULED);
                if (config.retentionDays > 0) {
                    await this.cleanupOldBackups(config.retentionDays);
                }
            }
            catch (error) {
                this.logger.error('Scheduled backup failed', error);
            }
        };
        const CronJob = require('cron').CronJob;
        const job = new CronJob(cronExpression, callback);
        this.schedulerRegistry.addCronJob('auto-backup', job);
        job.start();
        this.logger.log(`Auto backup scheduled successfully: ${config.backupFrequency} at ${config.backupTime}`);
    }
    async handleDailyCleanup() {
        try {
            const config = await this.getConfig();
            if (config.retentionDays > 0) {
                await this.cleanupOldBackups(config.retentionDays);
            }
        }
        catch (error) {
            this.logger.error('Daily cleanup failed', error);
        }
    }
    async createBackup(dto, backupType = backup_entity_1.BackupType.MANUAL) {
        const startTime = Date.now();
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T').join('_').substring(0, 19);
        const fileName = `backup_${timestamp}.sql`;
        const filePath = path.join(this.backupDir, fileName);
        const backupRecord = {
            id: `backup_${Date.now()}`,
            fileName,
            filePath,
            fileSize: 0,
            backupType,
            status: backup_entity_1.BackupStatus.IN_PROGRESS,
            createdAt: new Date(),
            description: dto.description,
        };
        try {
            this.logger.log(`Starting database backup: ${fileName}`);
            const dbHost = process.env.DATABASE_HOST || 'localhost';
            const dbPort = process.env.DATABASE_PORT || '5432';
            const dbName = process.env.DATABASE_NAME || 'baby_photo_db';
            const dbUser = process.env.DATABASE_USER || 'postgres';
            const dbPassword = process.env.DATABASE_PASSWORD || '';
            const isWindows = process.platform === 'win32';
            let command;
            if (isWindows) {
                const pgDumpPath = path.join(this.pgBinPath, 'pg_dump.exe');
                command = `set PGPASSWORD=${dbPassword}&& "${pgDumpPath}" -h ${dbHost} -p ${dbPort} -U ${dbUser} -d ${dbName} -F p -f "${filePath}"`;
            }
            else {
                command = `PGPASSWORD="${dbPassword}" pg_dump -h ${dbHost} -p ${dbPort} -U ${dbUser} -d ${dbName} -F p -f "${filePath}"`;
            }
            await execAsync(command);
            const stats = await fs.stat(filePath);
            backupRecord.fileSize = stats.size;
            const duration = Math.round((Date.now() - startTime) / 1000);
            backupRecord.duration = duration;
            backupRecord.status = backup_entity_1.BackupStatus.SUCCESS;
            const tableCount = await this.getTableCount();
            const recordCount = await this.getRecordCount();
            backupRecord.tablesCount = tableCount;
            backupRecord.recordsCount = recordCount;
            this.logger.log(`Backup completed successfully: ${fileName} (${this.formatFileSize(stats.size)}, ${duration}s)`);
            await this.saveBackupRecord(backupRecord);
            return backupRecord;
        }
        catch (error) {
            backupRecord.status = backup_entity_1.BackupStatus.FAILED;
            backupRecord.error = error.message;
            this.logger.error(`Backup failed: ${error.message}`, error.stack);
            await this.saveBackupRecord(backupRecord);
            throw error;
        }
    }
    async getBackups() {
        try {
            const files = await fs.readdir(this.backupDir);
            const backupFiles = files.filter(file => file.endsWith('.sql') || file.endsWith('.zip'));
            const backupRecords = [];
            for (const fileName of backupFiles) {
                const filePath = path.join(this.backupDir, fileName);
                const stats = await fs.stat(filePath);
                backupRecords.push({
                    id: fileName.replace(/\.(sql|zip)$/, ''),
                    fileName,
                    filePath,
                    fileSize: stats.size,
                    backupType: fileName.includes('auto') ? backup_entity_1.BackupType.AUTO : backup_entity_1.BackupType.MANUAL,
                    status: backup_entity_1.BackupStatus.SUCCESS,
                    createdAt: stats.birthtime,
                });
            }
            return backupRecords.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
        }
        catch (error) {
            this.logger.error(`Failed to get backups: ${error.message}`, error.stack);
            return [];
        }
    }
    async getBackup(id) {
        const backups = await this.getBackups();
        const backup = backups.find(b => b.id === id);
        if (!backup) {
            throw new common_1.NotFoundException(`Backup not found: ${id}`);
        }
        return backup;
    }
    async downloadBackup(id) {
        const backup = await this.getBackup(id);
        return {
            filePath: backup.filePath,
            fileName: backup.fileName,
        };
    }
    async deleteBackup(id) {
        const backup = await this.getBackup(id);
        try {
            await fs.unlink(backup.filePath);
            this.logger.log(`Backup deleted: ${backup.fileName}`);
        }
        catch (error) {
            this.logger.error(`Failed to delete backup: ${error.message}`, error.stack);
            throw error;
        }
    }
    async restoreBackup(backupId) {
        const backup = await this.getBackup(backupId);
        try {
            this.logger.log(`Starting database restore from: ${backup.fileName}`);
            const dbHost = process.env.DATABASE_HOST || 'localhost';
            const dbPort = process.env.DATABASE_PORT || '5432';
            const dbName = process.env.DATABASE_NAME || 'baby_photo_db';
            const dbUser = process.env.DATABASE_USER || 'postgres';
            const dbPassword = process.env.DATABASE_PASSWORD || '';
            const isWindows = process.platform === 'win32';
            let command;
            if (isWindows) {
                const psqlPath = path.join(this.pgBinPath, 'psql.exe');
                command = `set PGPASSWORD=${dbPassword}&& "${psqlPath}" -h ${dbHost} -p ${dbPort} -U ${dbUser} -d ${dbName} -f "${backup.filePath}"`;
            }
            else {
                command = `PGPASSWORD="${dbPassword}" psql -h ${dbHost} -p ${dbPort} -U ${dbUser} -d ${dbName} -f "${backup.filePath}"`;
            }
            await execAsync(command);
            this.logger.log(`Database restored successfully from: ${backup.fileName}`);
        }
        catch (error) {
            this.logger.error(`Failed to restore database: ${error.message}`, error.stack);
            throw error;
        }
    }
    async uploadAndRestore(filePath) {
        try {
            this.logger.log(`Starting database restore from uploaded file: ${filePath}`);
            const dbHost = process.env.DATABASE_HOST || 'localhost';
            const dbPort = process.env.DATABASE_PORT || '5432';
            const dbName = process.env.DATABASE_NAME || 'baby_photo_db';
            const dbUser = process.env.DATABASE_USER || 'postgres';
            const dbPassword = process.env.DATABASE_PASSWORD || '';
            const isWindows = process.platform === 'win32';
            let command;
            if (isWindows) {
                const psqlPath = path.join(this.pgBinPath, 'psql.exe');
                command = `set PGPASSWORD=${dbPassword}&& "${psqlPath}" -h ${dbHost} -p ${dbPort} -U ${dbUser} -d ${dbName} -f "${filePath}"`;
            }
            else {
                command = `PGPASSWORD="${dbPassword}" psql -h ${dbHost} -p ${dbPort} -U ${dbUser} -d ${dbName} -f "${filePath}"`;
            }
            await execAsync(command);
            this.logger.log(`Database restored successfully from uploaded file`);
            await fs.unlink(filePath);
        }
        catch (error) {
            this.logger.error(`Failed to restore from upload: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getConfig() {
        if (this.currentConfig) {
            this.logger.log(`Returning saved config: ${JSON.stringify(this.currentConfig)}`);
            return this.currentConfig;
        }
        const defaultConfig = {
            id: 1,
            autoBackup: true,
            backupFrequency: 'daily',
            backupTime: '02:00',
            retentionDays: 30,
            includeUploads: false,
            updatedAt: new Date(),
        };
        this.currentConfig = defaultConfig;
        this.logger.log(`Returning default config: ${JSON.stringify(defaultConfig)}`);
        return defaultConfig;
    }
    async updateConfig(config) {
        this.logger.log(`Backup config updated: ${JSON.stringify(config)}`);
        const updatedConfig = {
            id: 1,
            autoBackup: config.autoBackup,
            backupFrequency: config.backupFrequency || 'daily',
            backupTime: config.backupTime || '02:00',
            retentionDays: config.retentionDays,
            includeUploads: config.includeUploads,
            updatedAt: new Date(),
        };
        this.currentConfig = updatedConfig;
        this.scheduleBackup(updatedConfig);
        return updatedConfig;
    }
    async cleanupOldBackups(retentionDays) {
        const backups = await this.getBackups();
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - retentionDays);
        let deletedCount = 0;
        for (const backup of backups) {
            if (backup.createdAt < cutoffDate) {
                try {
                    await this.deleteBackup(backup.id);
                    deletedCount++;
                }
                catch (error) {
                    this.logger.error(`Failed to delete old backup: ${backup.fileName}`, error.stack);
                }
            }
        }
        if (deletedCount > 0) {
            this.logger.log(`Cleaned up ${deletedCount} old backups`);
        }
        return deletedCount;
    }
    getScheduleStatus() {
        if (!this.schedulerRegistry) {
            return {
                isScheduled: false,
                isRunning: false,
                nextRun: null,
                lastRun: null,
                config: this.currentConfig,
            };
        }
        try {
            const job = this.schedulerRegistry.getCronJob('auto-backup');
            return {
                isScheduled: !!job,
                isRunning: job ? true : false,
                nextRun: job ? job.nextDate()?.toJSDate() : null,
                lastRun: null,
                config: this.currentConfig,
            };
        }
        catch (error) {
            return {
                isScheduled: false,
                isRunning: false,
                nextRun: null,
                lastRun: null,
                config: this.currentConfig,
            };
        }
    }
    async getTableCount() {
        try {
            const result = await this.prisma.$queryRaw `
        SELECT COUNT(*) as count
        FROM information_schema.tables
        WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
      `;
            return parseInt(result[0].count);
        }
        catch {
            return 0;
        }
    }
    async getRecordCount() {
        try {
            const result = await this.prisma.$queryRaw `
        SELECT SUM(n_live_tup) as count
        FROM pg_stat_user_tables
      `;
            return parseInt(result[0].count) || 0;
        }
        catch {
            return 0;
        }
    }
    async saveBackupRecord(record) {
        this.logger.log(`Backup record saved: ${JSON.stringify(record)}`);
    }
    formatFileSize(bytes) {
        if (bytes === 0)
            return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
};
exports.SystemBackupService = SystemBackupService;
__decorate([
    (0, schedule_1.Cron)('0 2 * * *', {
        name: 'daily-cleanup',
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SystemBackupService.prototype, "handleDailyCleanup", null);
exports.SystemBackupService = SystemBackupService = SystemBackupService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Optional)()),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        schedule_1.SchedulerRegistry])
], SystemBackupService);
//# sourceMappingURL=system-backup.service.js.map