export declare class SystemBackupModule {
}
