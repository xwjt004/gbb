import { SchedulerRegistry } from '@nestjs/schedule';
import { PrismaService } from '../../shared/prisma/prisma.service';
import { CreateBackupDto, BackupConfigDto } from './dto/backup.dto';
import { BackupRecord, BackupType, BackupConfig } from './entities/backup.entity';
export declare class SystemBackupService {
    private readonly prisma;
    private readonly schedulerRegistry?;
    private readonly logger;
    private readonly backupDir;
    private currentConfig;
    private readonly pgBinPath;
    constructor(prisma: PrismaService, schedulerRegistry?: SchedulerRegistry | undefined);
    private getPostgreSQLBinPath;
    private ensureBackupDirectory;
    private initializeScheduledBackup;
    private scheduleBackup;
    handleDailyCleanup(): Promise<void>;
    createBackup(dto: CreateBackupDto, backupType?: BackupType): Promise<BackupRecord>;
    getBackups(): Promise<BackupRecord[]>;
    getBackup(id: string): Promise<BackupRecord>;
    downloadBackup(id: string): Promise<{
        filePath: string;
        fileName: string;
    }>;
    deleteBackup(id: string): Promise<void>;
    restoreBackup(backupId: string): Promise<void>;
    uploadAndRestore(filePath: string): Promise<void>;
    getConfig(): Promise<BackupConfig>;
    updateConfig(config: BackupConfigDto): Promise<BackupConfig>;
    cleanupOldBackups(retentionDays: number): Promise<number>;
    getScheduleStatus(): {
        isScheduled: boolean;
        isRunning: boolean;
        nextRun: Date | null;
        lastRun: null;
        config: BackupConfig;
    };
    private getTableCount;
    private getRecordCount;
    private saveBackupRecord;
    private formatFileSize;
}
