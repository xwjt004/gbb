import { Response } from 'express';
import { SystemBackupService } from './system-backup.service';
import { CreateBackupDto, BackupConfigDto, RestoreBackupDto } from './dto/backup.dto';
export declare class SystemBackupController {
    private readonly backupService;
    constructor(backupService: SystemBackupService);
    createBackup(dto: CreateBackupDto): Promise<{
        code: number;
        message: string;
        data: import("./entities/backup.entity").BackupRecord;
    }>;
    getBackups(): Promise<{
        code: number;
        message: string;
        data: import("./entities/backup.entity").BackupRecord[];
    }>;
    downloadBackup(id: string, res: Response): Promise<void>;
    deleteBackup(id: string): Promise<{
        code: number;
        message: string;
    }>;
    restoreBackup(dto: RestoreBackupDto): Promise<{
        code: number;
        message: string;
    }>;
    uploadAndRestore(file: Express.Multer.File): Promise<{
        code: number;
        message: string;
    }>;
    getConfig(): Promise<{
        code: number;
        message: string;
        data: import("./entities/backup.entity").BackupConfig;
    }>;
    updateConfig(dto: BackupConfigDto): Promise<{
        code: number;
        message: string;
        data: import("./entities/backup.entity").BackupConfig;
    }>;
    cleanupOldBackups(body: {
        retentionDays: number;
    }): Promise<{
        code: number;
        message: string;
        data: {
            deletedCount: number;
        };
    }>;
    getScheduleStatus(): Promise<{
        code: number;
        message: string;
        data: {
            isScheduled: boolean;
            isRunning: boolean;
            nextRun: Date | null;
            lastRun: null;
            config: import("./entities/backup.entity").BackupConfig;
        };
    }>;
}
