"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackupStatus = exports.BackupType = void 0;
var BackupType;
(function (BackupType) {
    BackupType["MANUAL"] = "manual";
    BackupType["AUTO"] = "auto";
    BackupType["SCHEDULED"] = "scheduled";
})(BackupType || (exports.BackupType = BackupType = {}));
var BackupStatus;
(function (BackupStatus) {
    BackupStatus["SUCCESS"] = "success";
    BackupStatus["FAILED"] = "failed";
    BackupStatus["IN_PROGRESS"] = "inProgress";
})(BackupStatus || (exports.BackupStatus = BackupStatus = {}));
//# sourceMappingURL=backup.entity.js.map