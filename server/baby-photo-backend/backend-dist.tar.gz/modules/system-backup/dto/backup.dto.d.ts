export declare enum BackupFrequency {
    DAILY = "daily",
    WEEKLY = "weekly",
    MONTHLY = "monthly"
}
export declare class CreateBackupDto {
    description?: string;
    includeUploads?: boolean;
}
export declare class BackupConfigDto {
    autoBackup: boolean;
    backupFrequency?: BackupFrequency;
    backupTime?: string;
    retentionDays: number;
    includeUploads: boolean;
}
export declare class RestoreBackupDto {
    backupId: string;
}
