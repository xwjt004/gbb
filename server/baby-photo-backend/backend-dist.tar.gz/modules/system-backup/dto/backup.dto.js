"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RestoreBackupDto = exports.BackupConfigDto = exports.CreateBackupDto = exports.BackupFrequency = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
var BackupFrequency;
(function (BackupFrequency) {
    BackupFrequency["DAILY"] = "daily";
    BackupFrequency["WEEKLY"] = "weekly";
    BackupFrequency["MONTHLY"] = "monthly";
})(BackupFrequency || (exports.BackupFrequency = BackupFrequency = {}));
class CreateBackupDto {
    description;
    includeUploads;
}
exports.CreateBackupDto = CreateBackupDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '备份说明' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBackupDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '是否包含上传文件', default: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateBackupDto.prototype, "includeUploads", void 0);
class BackupConfigDto {
    autoBackup;
    backupFrequency;
    backupTime;
    retentionDays;
    includeUploads;
}
exports.BackupConfigDto = BackupConfigDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否启用自动备份' }),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], BackupConfigDto.prototype, "autoBackup", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '备份频率', enum: BackupFrequency }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(BackupFrequency),
    __metadata("design:type", String)
], BackupConfigDto.prototype, "backupFrequency", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: '备份时间，格式：HH:mm' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], BackupConfigDto.prototype, "backupTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '保留天数' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(365),
    __metadata("design:type", Number)
], BackupConfigDto.prototype, "retentionDays", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否包含上传文件' }),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], BackupConfigDto.prototype, "includeUploads", void 0);
class RestoreBackupDto {
    backupId;
}
exports.RestoreBackupDto = RestoreBackupDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '备份文件ID' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RestoreBackupDto.prototype, "backupId", void 0);
//# sourceMappingURL=backup.dto.js.map