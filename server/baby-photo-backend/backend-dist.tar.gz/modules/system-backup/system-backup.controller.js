"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemBackupController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const system_backup_service_1 = require("./system-backup.service");
const backup_dto_1 = require("./dto/backup.dto");
const multer_1 = require("multer");
const path_1 = require("path");
let SystemBackupController = class SystemBackupController {
    backupService;
    constructor(backupService) {
        this.backupService = backupService;
    }
    async createBackup(dto) {
        const backup = await this.backupService.createBackup(dto);
        return {
            code: 0,
            message: '备份创建成功',
            data: backup,
        };
    }
    async getBackups() {
        const backups = await this.backupService.getBackups();
        return {
            code: 0,
            message: '获取成功',
            data: backups,
        };
    }
    async downloadBackup(id, res) {
        const { filePath, fileName } = await this.backupService.downloadBackup(id);
        res.setHeader('Content-Type', 'application/octet-stream');
        res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
        return res.sendFile(filePath);
    }
    async deleteBackup(id) {
        await this.backupService.deleteBackup(id);
        return {
            code: 0,
            message: '备份删除成功',
        };
    }
    async restoreBackup(dto) {
        await this.backupService.restoreBackup(dto.backupId);
        return {
            code: 0,
            message: '数据库恢复成功',
        };
    }
    async uploadAndRestore(file) {
        if (!file) {
            return {
                code: 1,
                message: '请上传备份文件',
            };
        }
        await this.backupService.uploadAndRestore(file.path);
        return {
            code: 0,
            message: '数据库恢复成功',
        };
    }
    async getConfig() {
        const config = await this.backupService.getConfig();
        return {
            code: 0,
            message: '获取成功',
            data: config,
        };
    }
    async updateConfig(dto) {
        const config = await this.backupService.updateConfig(dto);
        return {
            code: 0,
            message: '配置更新成功',
            data: config,
        };
    }
    async cleanupOldBackups(body) {
        const deletedCount = await this.backupService.cleanupOldBackups(body.retentionDays || 30);
        return {
            code: 0,
            message: '清理完成',
            data: { deletedCount },
        };
    }
    async getScheduleStatus() {
        const status = this.backupService.getScheduleStatus();
        return {
            code: 0,
            message: '获取成功',
            data: status,
        };
    }
};
exports.SystemBackupController = SystemBackupController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建数据库备份' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '备份创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 500, description: '备份失败' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [backup_dto_1.CreateBackupDto]),
    __metadata("design:returntype", Promise)
], SystemBackupController.prototype, "createBackup", null);
__decorate([
    (0, common_1.Get)('list'),
    (0, swagger_1.ApiOperation)({ summary: '获取备份列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SystemBackupController.prototype, "getBackups", null);
__decorate([
    (0, common_1.Get)(':id/download'),
    (0, swagger_1.ApiOperation)({ summary: '下载备份文件' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '下载成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '备份不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], SystemBackupController.prototype, "downloadBackup", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: '删除备份' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '删除成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '备份不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SystemBackupController.prototype, "deleteBackup", null);
__decorate([
    (0, common_1.Post)('restore'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: '恢复数据库' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '恢复成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '备份不存在' }),
    (0, swagger_1.ApiResponse)({ status: 500, description: '恢复失败' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [backup_dto_1.RestoreBackupDto]),
    __metadata("design:returntype", Promise)
], SystemBackupController.prototype, "restoreBackup", null);
__decorate([
    (0, common_1.Post)('restore/upload'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: (0, multer_1.diskStorage)({
            destination: './temp',
            filename: (req, file, cb) => {
                const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
                cb(null, `backup-${uniqueSuffix}${(0, path_1.extname)(file.originalname)}`);
            },
        }),
        fileFilter: (req, file, cb) => {
            if (file.originalname.match(/\.(sql|zip)$/)) {
                cb(null, true);
            }
            else {
                cb(new Error('只支持 .sql 和 .zip 文件'), false);
            }
        },
        limits: {
            fileSize: 500 * 1024 * 1024,
        },
    })),
    (0, swagger_1.ApiOperation)({ summary: '上传备份文件并恢复' }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({
        schema: {
            type: 'object',
            properties: {
                file: {
                    type: 'string',
                    format: 'binary',
                },
            },
        },
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '上传并恢复成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '文件格式不支持' }),
    (0, swagger_1.ApiResponse)({ status: 500, description: '恢复失败' }),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SystemBackupController.prototype, "uploadAndRestore", null);
__decorate([
    (0, common_1.Get)('config'),
    (0, swagger_1.ApiOperation)({ summary: '获取备份配置' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SystemBackupController.prototype, "getConfig", null);
__decorate([
    (0, common_1.Put)('config'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: '更新备份配置' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [backup_dto_1.BackupConfigDto]),
    __metadata("design:returntype", Promise)
], SystemBackupController.prototype, "updateConfig", null);
__decorate([
    (0, common_1.Post)('cleanup'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: '清理过期备份' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '清理成功' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SystemBackupController.prototype, "cleanupOldBackups", null);
__decorate([
    (0, common_1.Get)('schedule/status'),
    (0, swagger_1.ApiOperation)({ summary: '获取定时任务状态' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SystemBackupController.prototype, "getScheduleStatus", null);
exports.SystemBackupController = SystemBackupController = __decorate([
    (0, swagger_1.ApiTags)('系统备份'),
    (0, common_1.Controller)('system/backup'),
    __metadata("design:paramtypes", [system_backup_service_1.SystemBackupService])
], SystemBackupController);
//# sourceMappingURL=system-backup.controller.js.map