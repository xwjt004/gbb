"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SmartMarketingController = void 0;
const common_1 = require("@nestjs/common");
const smart_marketing_service_1 = require("./smart-marketing.service");
const create_segment_dto_1 = require("./dto/create-segment.dto");
const query_segment_dto_1 = require("./dto/query-segment.dto");
const create_campaign_dto_1 = require("./dto/create-campaign.dto");
const query_campaign_dto_1 = require("./dto/query-campaign.dto");
const track_event_dto_1 = require("./dto/track-event.dto");
let SmartMarketingController = class SmartMarketingController {
    service;
    constructor(service) {
        this.service = service;
    }
    findSegments(query) {
        return this.service.findSegments(query);
    }
    createSegment(dto) {
        return this.service.createSegment(dto);
    }
    getPresetSegments() {
        return this.service.getPresetSegments();
    }
    findSegment(id) {
        return this.service.findSegment(id);
    }
    updateSegment(id, dto) {
        return this.service.updateSegment(id, dto);
    }
    removeSegment(id) {
        return this.service.removeSegment(id);
    }
    getSegmentMembers(id, page, pageSize) {
        return this.service.getSegmentMembers(id, Number(page) || 1, Number(pageSize) || 20);
    }
    refreshSegment(id) {
        return this.service.refreshSegmentMemberCount(id);
    }
    findCampaigns(query) {
        return this.service.findCampaigns(query);
    }
    createCampaign(dto) {
        return this.service.createCampaign(dto);
    }
    findCampaign(id) {
        return this.service.findCampaign(id);
    }
    updateCampaign(id, dto) {
        return this.service.updateCampaign(id, dto);
    }
    removeCampaign(id) {
        return this.service.removeCampaign(id);
    }
    sendCampaign(id) {
        return this.service.sendCampaign(id);
    }
    getCampaignFunnel(id) {
        return this.service.getCampaignFunnel(id);
    }
    trackEvent(dto) {
        return this.service.trackEvent(dto);
    }
};
exports.SmartMarketingController = SmartMarketingController;
__decorate([
    (0, common_1.Get)('segments'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_segment_dto_1.QuerySegmentDto]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "findSegments", null);
__decorate([
    (0, common_1.Post)('segments'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_segment_dto_1.CreateSegmentDto]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "createSegment", null);
__decorate([
    (0, common_1.Get)('segments/presets'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "getPresetSegments", null);
__decorate([
    (0, common_1.Get)('segments/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "findSegment", null);
__decorate([
    (0, common_1.Patch)('segments/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_segment_dto_1.UpdateSegmentDto]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "updateSegment", null);
__decorate([
    (0, common_1.Delete)('segments/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "removeSegment", null);
__decorate([
    (0, common_1.Get)('segments/:id/members'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('pageSize')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "getSegmentMembers", null);
__decorate([
    (0, common_1.Post)('segments/:id/refresh'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "refreshSegment", null);
__decorate([
    (0, common_1.Get)('campaigns'),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_campaign_dto_1.QueryCampaignDto]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "findCampaigns", null);
__decorate([
    (0, common_1.Post)('campaigns'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_campaign_dto_1.CreateCampaignDto]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "createCampaign", null);
__decorate([
    (0, common_1.Get)('campaigns/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "findCampaign", null);
__decorate([
    (0, common_1.Patch)('campaigns/:id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_campaign_dto_1.UpdateCampaignDto]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "updateCampaign", null);
__decorate([
    (0, common_1.Delete)('campaigns/:id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "removeCampaign", null);
__decorate([
    (0, common_1.Post)('campaigns/:id/send'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "sendCampaign", null);
__decorate([
    (0, common_1.Get)('campaigns/:id/funnel'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "getCampaignFunnel", null);
__decorate([
    (0, common_1.Post)('tracks'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [track_event_dto_1.TrackEventDto]),
    __metadata("design:returntype", void 0)
], SmartMarketingController.prototype, "trackEvent", null);
exports.SmartMarketingController = SmartMarketingController = __decorate([
    (0, common_1.Controller)('smart-marketing'),
    __metadata("design:paramtypes", [smart_marketing_service_1.SmartMarketingService])
], SmartMarketingController);
//# sourceMappingURL=smart-marketing.controller.js.map