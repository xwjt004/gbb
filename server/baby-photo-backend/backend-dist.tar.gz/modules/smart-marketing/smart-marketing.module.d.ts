export declare class SmartMarketingModule {
}
