"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var SmartMarketingService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SmartMarketingService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let SmartMarketingService = class SmartMarketingService {
    static { SmartMarketingService_1 = this; }
    prisma;
    logger = new common_1.Logger(SmartMarketingService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    static PRESET_SEGMENTS = [
        {
            name: 'VIP客户',
            description: '消费10次以上且总金额5000元以上',
            rules: [
                { field: 'totalOrders', operator: '>=', value: 10 },
                { field: 'totalAmount', operator: '>=', value: 5000 },
            ],
        },
        {
            name: '黄金客户',
            description: '消费5次以上且总金额2000元以上',
            rules: [
                { field: 'totalOrders', operator: '>=', value: 5 },
                { field: 'totalAmount', operator: '>=', value: 2000 },
            ],
        },
        {
            name: '白银客户',
            description: '消费2次以上且总金额500元以上',
            rules: [
                { field: 'totalOrders', operator: '>=', value: 2 },
                { field: 'totalAmount', operator: '>=', value: 500 },
            ],
        },
        {
            name: '新客户',
            description: '未下过单的注册用户',
            rules: [
                { field: 'totalOrders', operator: '==', value: 0 },
            ],
        },
        {
            name: '即将流失',
            description: '超过60天未下单的活跃用户',
            rules: [
                { field: 'daysSinceLastOrder', operator: '>=', value: 60 },
                { field: 'churnStatus', operator: '==', value: 'ACTIVE' },
            ],
        },
        {
            name: '本月生日',
            description: '本月过生日的用户',
            rules: [
                { field: 'birthdayMonth', operator: '==', value: new Date().getMonth() + 1 },
            ],
        },
    ];
    async createSegment(dto) {
        const segment = await this.prisma.customerSegment.create({
            data: {
                name: dto.name,
                description: dto.description,
                rules: dto.rules,
            },
        });
        this.refreshSegmentMemberCount(segment.id).catch((err) => this.logger.error(`刷新分群成员数失败: ${segment.id}`, err));
        return { code: 200, message: '分群创建成功', data: segment };
    }
    async findSegments(query) {
        const { page = 1, pageSize = 20, name, status } = query;
        const where = {};
        if (name)
            where.name = { contains: name };
        if (status)
            where.status = status;
        const [items, total] = await Promise.all([
            this.prisma.customerSegment.findMany({
                where,
                skip: (page - 1) * pageSize,
                take: pageSize,
                orderBy: { createdAt: 'desc' },
            }),
            this.prisma.customerSegment.count({ where }),
        ]);
        return {
            code: 200,
            data: {
                items,
                pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
            },
        };
    }
    async findSegment(id) {
        const segment = await this.prisma.customerSegment.findUnique({ where: { id } });
        if (!segment)
            throw new common_1.NotFoundException('分群不存在');
        return { code: 200, data: segment };
    }
    async updateSegment(id, dto) {
        const segment = await this.prisma.customerSegment.findUnique({ where: { id } });
        if (!segment)
            throw new common_1.NotFoundException('分群不存在');
        const updated = await this.prisma.customerSegment.update({
            where: { id },
            data: {
                ...(dto.name !== undefined && { name: dto.name }),
                ...(dto.description !== undefined && { description: dto.description }),
                ...(dto.rules !== undefined && { rules: dto.rules }),
                ...(dto.status !== undefined && { status: dto.status }),
            },
        });
        if (dto.rules) {
            this.refreshSegmentMemberCount(id).catch((err) => this.logger.error(`刷新分群成员数失败: ${id}`, err));
        }
        return { code: 200, message: '更新成功', data: updated };
    }
    async removeSegment(id) {
        const segment = await this.prisma.customerSegment.findUnique({ where: { id } });
        if (!segment)
            throw new common_1.NotFoundException('分群不存在');
        await this.prisma.customerSegment.delete({ where: { id } });
        return { code: 200, message: '删除成功' };
    }
    async getSegmentMembers(id, page = 1, pageSize = 20) {
        const segment = await this.prisma.customerSegment.findUnique({ where: { id } });
        if (!segment)
            throw new common_1.NotFoundException('分群不存在');
        const where = this.buildSegmentQuery(segment.rules);
        const [items, total] = await Promise.all([
            this.prisma.wxUser.findMany({
                where,
                skip: (page - 1) * pageSize,
                take: pageSize,
                orderBy: { createdAt: 'desc' },
                select: {
                    id: true,
                    nickname: true,
                    avatar: true,
                    gender: true,
                    phone: true,
                    memberLevel: true,
                    totalOrders: true,
                    totalAmount: true,
                    growthPoints: true,
                    lastOrderAt: true,
                    createdAt: true,
                },
            }),
            this.prisma.wxUser.count({ where }),
        ]);
        return {
            code: 200,
            data: {
                items,
                pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
            },
        };
    }
    async refreshSegmentMemberCount(id) {
        const segment = await this.prisma.customerSegment.findUnique({ where: { id } });
        if (!segment)
            throw new common_1.NotFoundException('分群不存在');
        const where = this.buildSegmentQuery(segment.rules);
        const count = await this.prisma.wxUser.count({ where });
        await this.prisma.customerSegment.update({
            where: { id },
            data: { memberCount: count },
        });
        return { code: 200, data: { memberCount: count } };
    }
    buildSegmentQuery(rules) {
        if (!rules || rules.length === 0)
            return {};
        const conditions = [];
        for (const rule of rules) {
            const { field, operator, value } = rule;
            if (!field || !operator)
                continue;
            switch (field) {
                case 'totalOrders':
                case 'totalAmount':
                case 'growthPoints': {
                    const numVal = Number(value);
                    const opMap = {
                        '>': 'gt', '>=': 'gte', '<': 'lt', '<=': 'lte', '==': 'equals',
                    };
                    const prismaOp = opMap[operator];
                    if (prismaOp)
                        conditions.push({ [field]: { [prismaOp]: numVal } });
                    break;
                }
                case 'memberLevel':
                case 'churnStatus':
                    if (operator === '==')
                        conditions.push({ [field]: String(value) });
                    else if (operator === '!=')
                        conditions.push({ [field]: { not: String(value) } });
                    break;
                case 'gender': {
                    const genVal = Number(value);
                    if (operator === '==')
                        conditions.push({ gender: genVal });
                    break;
                }
                case 'daysSinceLastOrder': {
                    const days = Number(value);
                    const date = new Date();
                    date.setDate(date.getDate() - days);
                    if (operator === '>=')
                        conditions.push({ lastOrderAt: { lte: date } });
                    else if (operator === '<=')
                        conditions.push({ lastOrderAt: { gte: date } });
                    else if (operator === '==') {
                        const nextDay = new Date(date);
                        nextDay.setDate(nextDay.getDate() + 1);
                        conditions.push({
                            lastOrderAt: { gte: date, lte: nextDay },
                        });
                    }
                    break;
                }
                case 'birthdayMonth': {
                    const month = Number(value);
                    conditions.push({
                        birthday: { not: null },
                    });
                    conditions.push({
                        id: {
                            in: this.getBirthdayMonthUserIds(month),
                        },
                    });
                    break;
                }
            }
        }
        return conditions.length > 0 ? { AND: conditions } : {};
    }
    getBirthdayMonthUserIds(month) {
        return [];
    }
    async getBirthdayUsers(month) {
        const result = await this.prisma.$queryRawUnsafe(`SELECT id FROM "wx_users" WHERE EXTRACT(MONTH FROM birthday) = $1 AND birthday IS NOT NULL`, month);
        return result.map((r) => r.id);
    }
    async createCampaign(dto) {
        const data = {
            name: dto.name,
            description: dto.description,
            segmentId: dto.segmentId,
            campaignType: dto.campaignType,
            couponId: dto.couponId,
            title: dto.title,
            content: dto.content,
        };
        if (dto.scheduledAt)
            data.scheduledAt = new Date(dto.scheduledAt);
        const campaign = await this.prisma.marketingCampaign.create({ data });
        return { code: 200, message: '活动创建成功', data: campaign };
    }
    async findCampaigns(query) {
        const { page = 1, pageSize = 20, name, status, campaignType } = query;
        const where = {};
        if (name)
            where.name = { contains: name };
        if (status)
            where.status = status;
        if (campaignType)
            where.campaignType = campaignType;
        const [items, total] = await Promise.all([
            this.prisma.marketingCampaign.findMany({
                where,
                skip: (page - 1) * pageSize,
                take: pageSize,
                orderBy: { createdAt: 'desc' },
                include: {
                    segment: { select: { id: true, name: true, memberCount: true } },
                },
            }),
            this.prisma.marketingCampaign.count({ where }),
        ]);
        return {
            code: 200,
            data: {
                items,
                pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
            },
        };
    }
    async findCampaign(id) {
        const campaign = await this.prisma.marketingCampaign.findUnique({
            where: { id },
            include: {
                segment: { select: { id: true, name: true, memberCount: true, rules: true } },
            },
        });
        if (!campaign)
            throw new common_1.NotFoundException('活动不存在');
        return { code: 200, data: campaign };
    }
    async updateCampaign(id, dto) {
        const campaign = await this.prisma.marketingCampaign.findUnique({ where: { id } });
        if (!campaign)
            throw new common_1.NotFoundException('活动不存在');
        if (campaign.status !== 'DRAFT') {
            throw new common_1.BadRequestException('只能编辑草稿状态的活动');
        }
        const data = {};
        if (dto.name !== undefined)
            data.name = dto.name;
        if (dto.description !== undefined)
            data.description = dto.description;
        if (dto.segmentId !== undefined)
            data.segmentId = dto.segmentId;
        if (dto.campaignType !== undefined)
            data.campaignType = dto.campaignType;
        if (dto.couponId !== undefined)
            data.couponId = dto.couponId;
        if (dto.title !== undefined)
            data.title = dto.title;
        if (dto.content !== undefined)
            data.content = dto.content;
        if (dto.status !== undefined)
            data.status = dto.status;
        if (dto.scheduledAt !== undefined)
            data.scheduledAt = new Date(dto.scheduledAt);
        const updated = await this.prisma.marketingCampaign.update({ where: { id }, data });
        return { code: 200, message: '更新成功', data: updated };
    }
    async removeCampaign(id) {
        const campaign = await this.prisma.marketingCampaign.findUnique({ where: { id } });
        if (!campaign)
            throw new common_1.NotFoundException('活动不存在');
        await this.prisma.marketingCampaign.delete({ where: { id } });
        return { code: 200, message: '删除成功' };
    }
    async sendCampaign(id) {
        const campaign = await this.prisma.marketingCampaign.findUnique({
            where: { id },
            include: { segment: true },
        });
        if (!campaign)
            throw new common_1.NotFoundException('活动不存在');
        if (campaign.status !== 'DRAFT') {
            throw new common_1.BadRequestException('只能发送草稿状态的活动');
        }
        await this.prisma.marketingCampaign.update({
            where: { id },
            data: { status: 'SENDING' },
        });
        try {
            let wxUserIds = [];
            if (campaign.segment && campaign.segment.rules) {
                const rules = campaign.segment.rules;
                const birthdayRule = rules.find((r) => r.field === 'birthdayMonth');
                let baseWhere = {};
                if (birthdayRule) {
                    const month = Number(birthdayRule.value);
                    const birthdayIds = await this.getBirthdayUsers(month);
                    const otherRules = rules.filter((r) => r.field !== 'birthdayMonth');
                    const otherWhere = this.buildSegmentQuery(otherRules);
                    if (otherRules.length > 0) {
                        baseWhere = { AND: [{ id: { in: birthdayIds } }, otherWhere] };
                    }
                    else {
                        baseWhere = { id: { in: birthdayIds } };
                    }
                }
                else {
                    baseWhere = this.buildSegmentQuery(rules);
                }
                const users = await this.prisma.wxUser.findMany({
                    where: baseWhere,
                    select: { id: true },
                });
                wxUserIds = users.map((u) => u.id);
            }
            if (wxUserIds.length === 0) {
                await this.prisma.marketingCampaign.update({
                    where: { id },
                    data: { status: 'COMPLETED', sentCount: 0 },
                });
                return { code: 200, message: '没有匹配的用户', data: { sentCount: 0 } };
            }
            let sentCount = 0;
            if (campaign.campaignType === 'COUPON_PUSH' && campaign.couponId) {
                sentCount = await this.batchIssueCoupons(wxUserIds, campaign.couponId, id);
            }
            else if (campaign.campaignType === 'NOTIFICATION_PUSH') {
                sentCount = await this.batchSendNotifications(wxUserIds, campaign.title, campaign.content, id);
            }
            await this.prisma.marketingCampaign.update({
                where: { id },
                data: { status: 'SENT', sentCount },
            });
            return { code: 200, message: '发送成功', data: { sentCount } };
        }
        catch (err) {
            this.logger.error(`活动发送失败: ${id}`, err);
            await this.prisma.marketingCampaign.update({
                where: { id },
                data: { status: 'DRAFT' },
            });
            throw err;
        }
    }
    async batchIssueCoupons(wxUserIds, couponId, campaignId) {
        const coupon = await this.prisma.coupon.findUnique({ where: { id: couponId } });
        if (!coupon || coupon.status !== 'ACTIVE') {
            throw new common_1.BadRequestException('优惠券不存在或未激活');
        }
        let sentCount = 0;
        const perUserLimit = coupon.perUserLimit || 1;
        for (const wxUserId of wxUserIds) {
            try {
                const existingCount = await this.prisma.userCoupon.count({
                    where: { wxUserId, couponId },
                });
                if (existingCount >= perUserLimit)
                    continue;
                await this.prisma.userCoupon.create({
                    data: {
                        wxUserId,
                        couponId,
                        status: 'UNUSED',
                        expiredAt: coupon.endTime,
                    },
                });
                await this.prisma.campaignTrack.create({
                    data: {
                        campaignId,
                        wxUserId,
                        event: 'DELIVERED',
                    },
                });
                sentCount++;
            }
            catch (err) {
                this.logger.warn(`发放优惠券失败: userId=${wxUserId}, couponId=${couponId}`, err);
            }
        }
        return sentCount;
    }
    async batchSendNotifications(wxUserIds, title, content, campaignId) {
        let sentCount = 0;
        for (const wxUserId of wxUserIds) {
            try {
                await this.prisma.appNotification.create({
                    data: {
                        type: 'SYSTEM',
                        title: title || '营销通知',
                        content: content || '',
                        recipient: wxUserId,
                        status: 'SENT',
                        sentAt: new Date(),
                    },
                });
                await this.prisma.campaignTrack.create({
                    data: {
                        campaignId,
                        wxUserId,
                        event: 'DELIVERED',
                    },
                });
                sentCount++;
            }
            catch (err) {
                this.logger.warn(`发送通知失败: userId=${wxUserId}`, err);
            }
        }
        return sentCount;
    }
    async getCampaignFunnel(id) {
        const campaign = await this.prisma.marketingCampaign.findUnique({ where: { id } });
        if (!campaign)
            throw new common_1.NotFoundException('活动不存在');
        const events = await this.prisma.campaignTrack.groupBy({
            by: ['event'],
            where: { campaignId: id },
            _count: { id: true },
        });
        const eventMap = {
            DELIVERED: 0,
            OPENED: 0,
            CLICKED: 0,
            CONVERTED: 0,
        };
        for (const e of events) {
            eventMap[e.event] = e._count.id;
        }
        const total = eventMap.DELIVERED || 1;
        const funnel = [
            { stage: '已送达', count: eventMap.DELIVERED, rate: '100%' },
            { stage: '已查看', count: eventMap.OPENED, rate: `${((eventMap.OPENED / total) * 100).toFixed(1)}%` },
            { stage: '已点击', count: eventMap.CLICKED, rate: `${((eventMap.CLICKED / total) * 100).toFixed(1)}%` },
            { stage: '已转化', count: eventMap.CONVERTED, rate: `${((eventMap.CONVERTED / total) * 100).toFixed(1)}%` },
        ];
        return {
            code: 200,
            data: {
                campaign: {
                    id: campaign.id,
                    name: campaign.name,
                    sentCount: campaign.sentCount,
                    openedCount: campaign.openedCount,
                    clickedCount: campaign.clickedCount,
                    convertedCount: campaign.convertedCount,
                },
                funnel,
            },
        };
    }
    async trackEvent(dto) {
        const campaign = await this.prisma.marketingCampaign.findUnique({
            where: { id: dto.campaignId },
        });
        if (!campaign)
            throw new common_1.NotFoundException('活动不存在');
        await this.prisma.campaignTrack.create({
            data: {
                campaignId: dto.campaignId,
                wxUserId: dto.wxUserId,
                event: dto.event,
                orderId: dto.orderId,
                metadata: dto.metadata || undefined,
            },
        });
        const countField = dto.event === 'OPENED'
            ? 'openedCount'
            : dto.event === 'CLICKED'
                ? 'clickedCount'
                : dto.event === 'CONVERTED'
                    ? 'convertedCount'
                    : null;
        if (countField) {
            await this.prisma.marketingCampaign.update({
                where: { id: dto.campaignId },
                data: { [countField]: { increment: 1 } },
            });
        }
        return { code: 200, message: '事件记录成功' };
    }
    async getPresetSegments() {
        return { code: 200, data: SmartMarketingService_1.PRESET_SEGMENTS };
    }
};
exports.SmartMarketingService = SmartMarketingService;
exports.SmartMarketingService = SmartMarketingService = SmartMarketingService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], SmartMarketingService);
//# sourceMappingURL=smart-marketing.service.js.map