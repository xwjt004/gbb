import { SmartMarketingService } from './smart-marketing.service';
import { CreateSegmentDto, UpdateSegmentDto } from './dto/create-segment.dto';
import { QuerySegmentDto } from './dto/query-segment.dto';
import { CreateCampaignDto, UpdateCampaignDto } from './dto/create-campaign.dto';
import { QueryCampaignDto } from './dto/query-campaign.dto';
import { TrackEventDto } from './dto/track-event.dto';
export declare class SmartMarketingController {
    private readonly service;
    constructor(service: SmartMarketingService);
    findSegments(query: QuerySegmentDto): Promise<{
        code: number;
        data: {
            items: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                status: string;
                description: string | null;
                rules: import("@prisma/client/runtime/library").JsonValue;
                memberCount: number;
            }[];
            pagination: {
                page: number;
                pageSize: number;
                total: number;
                totalPages: number;
            };
        };
    }>;
    createSegment(dto: CreateSegmentDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            status: string;
            description: string | null;
            rules: import("@prisma/client/runtime/library").JsonValue;
            memberCount: number;
        };
    }>;
    getPresetSegments(): Promise<{
        code: number;
        data: {
            name: string;
            description: string;
            rules: ({
                field: string;
                operator: string;
                value: number;
            } | {
                field: string;
                operator: string;
                value: string;
            })[];
        }[];
    }>;
    findSegment(id: string): Promise<{
        code: number;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            status: string;
            description: string | null;
            rules: import("@prisma/client/runtime/library").JsonValue;
            memberCount: number;
        };
    }>;
    updateSegment(id: string, dto: UpdateSegmentDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            status: string;
            description: string | null;
            rules: import("@prisma/client/runtime/library").JsonValue;
            memberCount: number;
        };
    }>;
    removeSegment(id: string): Promise<{
        code: number;
        message: string;
    }>;
    getSegmentMembers(id: string, page?: string, pageSize?: string): Promise<{
        code: number;
        data: {
            items: {
                memberLevel: string;
                id: string;
                totalAmount: import("@prisma/client/runtime/library").Decimal;
                createdAt: Date;
                nickname: string | null;
                avatar: string | null;
                phone: string | null;
                gender: number | null;
                totalOrders: number;
                growthPoints: number;
                lastOrderAt: Date | null;
            }[];
            pagination: {
                page: number;
                pageSize: number;
                total: number;
                totalPages: number;
            };
        };
    }>;
    refreshSegment(id: string): Promise<{
        code: number;
        data: {
            memberCount: number;
        };
    }>;
    findCampaigns(query: QueryCampaignDto): Promise<{
        code: number;
        data: {
            items: ({
                segment: {
                    id: string;
                    name: string;
                    memberCount: number;
                } | null;
            } & {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                couponId: string | null;
                name: string;
                status: string;
                description: string | null;
                content: string | null;
                title: string | null;
                segmentId: string | null;
                campaignType: string;
                scheduledAt: Date | null;
                sentCount: number;
                openedCount: number;
                clickedCount: number;
                convertedCount: number;
            })[];
            pagination: {
                page: number;
                pageSize: number;
                total: number;
                totalPages: number;
            };
        };
    }>;
    createCampaign(dto: CreateCampaignDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            couponId: string | null;
            name: string;
            status: string;
            description: string | null;
            content: string | null;
            title: string | null;
            segmentId: string | null;
            campaignType: string;
            scheduledAt: Date | null;
            sentCount: number;
            openedCount: number;
            clickedCount: number;
            convertedCount: number;
        };
    }>;
    findCampaign(id: string): Promise<{
        code: number;
        data: {
            segment: {
                id: string;
                name: string;
                rules: import("@prisma/client/runtime/library").JsonValue;
                memberCount: number;
            } | null;
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            couponId: string | null;
            name: string;
            status: string;
            description: string | null;
            content: string | null;
            title: string | null;
            segmentId: string | null;
            campaignType: string;
            scheduledAt: Date | null;
            sentCount: number;
            openedCount: number;
            clickedCount: number;
            convertedCount: number;
        };
    }>;
    updateCampaign(id: string, dto: UpdateCampaignDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            couponId: string | null;
            name: string;
            status: string;
            description: string | null;
            content: string | null;
            title: string | null;
            segmentId: string | null;
            campaignType: string;
            scheduledAt: Date | null;
            sentCount: number;
            openedCount: number;
            clickedCount: number;
            convertedCount: number;
        };
    }>;
    removeCampaign(id: string): Promise<{
        code: number;
        message: string;
    }>;
    sendCampaign(id: string): Promise<{
        code: number;
        message: string;
        data: {
            sentCount: number;
        };
    }>;
    getCampaignFunnel(id: string): Promise<{
        code: number;
        data: {
            campaign: {
                id: string;
                name: string;
                sentCount: number;
                openedCount: number;
                clickedCount: number;
                convertedCount: number;
            };
            funnel: {
                stage: string;
                count: number;
                rate: string;
            }[];
        };
    }>;
    trackEvent(dto: TrackEventDto): Promise<{
        code: number;
        message: string;
    }>;
}
