export declare class TrackEventDto {
    campaignId: string;
    wxUserId: string;
    event: string;
    orderId?: string;
    metadata?: Record<string, any>;
}
