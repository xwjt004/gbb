export declare class CreateCampaignDto {
    name: string;
    description?: string;
    segmentId?: string;
    campaignType: string;
    couponId?: string;
    title?: string;
    content?: string;
    scheduledAt?: string;
}
export declare class UpdateCampaignDto {
    name?: string;
    description?: string;
    segmentId?: string;
    campaignType?: string;
    couponId?: string;
    title?: string;
    content?: string;
    scheduledAt?: string;
    status?: string;
}
