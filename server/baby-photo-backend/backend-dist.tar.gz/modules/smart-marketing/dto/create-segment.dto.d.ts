export declare class CreateSegmentDto {
    name: string;
    description?: string;
    rules: Record<string, any>[];
}
export declare class UpdateSegmentDto {
    name?: string;
    description?: string;
    rules?: Record<string, any>[];
    status?: string;
}
