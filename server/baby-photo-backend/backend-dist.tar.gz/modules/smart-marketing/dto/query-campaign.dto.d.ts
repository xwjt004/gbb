export declare class QueryCampaignDto {
    page?: number;
    pageSize?: number;
    name?: string;
    status?: string;
    campaignType?: string;
}
