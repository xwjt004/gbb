export declare class QuerySegmentDto {
    page?: number;
    pageSize?: number;
    name?: string;
    status?: string;
}
