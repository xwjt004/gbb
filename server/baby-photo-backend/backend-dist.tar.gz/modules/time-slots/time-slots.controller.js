"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimeSlotsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const time_slots_service_1 = require("./time-slots.service");
const create_time_slot_dto_1 = require("./dto/create-time-slot.dto");
const update_time_slot_dto_1 = require("./dto/update-time-slot.dto");
const query_time_slots_dto_1 = require("./dto/query-time-slots.dto");
const create_batch_time_slots_dto_1 = require("./dto/create-batch-time-slots.dto");
const batch_operation_dto_1 = require("./dto/batch-operation.dto");
let TimeSlotsController = class TimeSlotsController {
    timeSlotsService;
    constructor(timeSlotsService) {
        this.timeSlotsService = timeSlotsService;
    }
    create(createTimeSlotDto) {
        return this.timeSlotsService.create(createTimeSlotDto);
    }
    createBatch(createBatchDto) {
        return this.timeSlotsService.createBatch(createBatchDto);
    }
    findAll(query) {
        return this.timeSlotsService.findAll(query);
    }
    findAvailable(date, startDate, endDate, limit) {
        const limitNum = limit ? parseInt(limit, 10) : undefined;
        return this.timeSlotsService.getAvailableSlots(date, limitNum, startDate, endDate);
    }
    getStatistics(startDate, endDate) {
        return this.timeSlotsService.getStatistics(startDate, endDate);
    }
    getDailyStatistics(startDate, endDate) {
        return this.timeSlotsService.getDailyStatistics(startDate, endDate);
    }
    getConflicts(date) {
        return this.timeSlotsService.getConflictAnalysis(date);
    }
    getRecommendations(startDate, endDate, limit) {
        return this.timeSlotsService.getRecommendations(startDate, endDate, limit ? parseInt(limit, 10) : 5);
    }
    findOne(id) {
        return this.timeSlotsService.findOne(id);
    }
    update(id, updateTimeSlotDto) {
        return this.timeSlotsService.update(id, updateTimeSlotDto);
    }
    async batchUpdateStatus(batchUpdateDto) {
        const count = await this.timeSlotsService.batchUpdateStatus(batchUpdateDto.ids, batchUpdateDto.status);
        return { count };
    }
    async batchDelete(batchDeleteDto) {
        const count = await this.timeSlotsService.batchDelete(batchDeleteDto.ids);
        return { count };
    }
    remove(id) {
        return this.timeSlotsService.remove(id);
    }
};
exports.TimeSlotsController = TimeSlotsController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建单个时间槽' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '时间槽创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    (0, swagger_1.ApiResponse)({ status: 409, description: '时间槽已存在' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_time_slot_dto_1.CreateTimeSlotDto]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "create", null);
__decorate([
    (0, common_1.Post)('batch'),
    (0, swagger_1.ApiOperation)({ summary: '批量创建时间槽' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '批量时间槽创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_batch_time_slots_dto_1.CreateBatchTimeSlotsDto]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "createBatch", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取时间槽列表' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, description: '开始日期' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, description: '结束日期' }),
    (0, swagger_1.ApiQuery)({ name: 'isBooked', required: false, description: '是否已预订' }),
    (0, swagger_1.ApiQuery)({ name: 'status', required: false, description: '时间槽状态', enum: ['AVAILABLE', 'BOOKED', 'UNAVAILABLE'] }),
    (0, swagger_1.ApiQuery)({ name: 'isHoliday', required: false, description: '是否为节假日' }),
    (0, swagger_1.ApiQuery)({ name: 'hasCapacity', required: false, description: '是否只显示有余量的时间槽' }),
    (0, swagger_1.ApiQuery)({ name: 'notes', required: false, description: '备注搜索关键词' }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, description: '页码', type: Number }),
    (0, swagger_1.ApiQuery)({ name: 'pageSize', required: false, description: '每页数量', type: Number }),
    (0, swagger_1.ApiQuery)({
        name: 'sortBy',
        required: false,
        description: '排序方式',
        enum: ['date_asc', 'date_desc', 'time_asc', 'time_desc'],
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取时间槽列表' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_time_slots_dto_1.QueryTimeSlotsDto]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('available'),
    (0, swagger_1.ApiOperation)({ summary: '获取可用时间槽' }),
    (0, swagger_1.ApiQuery)({ name: 'date', required: false, description: '指定日期（可选）' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, description: '开始日期（与 endDate 搭配使用）' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, description: '结束日期（与 startDate 搭配使用）' }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, description: '限制数量（可选）' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取可用时间槽' }),
    __param(0, (0, common_1.Query)('date')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __param(3, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "findAvailable", null);
__decorate([
    (0, common_1.Get)('statistics/overview'),
    (0, swagger_1.ApiOperation)({ summary: '获取时间槽统计概览' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, description: '开始日期' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, description: '结束日期' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取统计数据' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "getStatistics", null);
__decorate([
    (0, common_1.Get)('statistics/daily'),
    (0, swagger_1.ApiOperation)({ summary: '获取每日统计数据' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: true, description: '开始日期' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: true, description: '结束日期' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取每日统计数据' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "getDailyStatistics", null);
__decorate([
    (0, common_1.Get)('conflicts'),
    (0, swagger_1.ApiOperation)({ summary: '检测指定日期时间槽冲突与容量预警' }),
    (0, swagger_1.ApiQuery)({ name: 'date', required: true, description: '日期 YYYY-MM-DD' }),
    __param(0, (0, common_1.Query)('date')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "getConflicts", null);
__decorate([
    (0, common_1.Get)('recommendations'),
    (0, swagger_1.ApiOperation)({ summary: '智能推荐可用时间槽' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, description: '开始日期' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, description: '结束日期' }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, description: '返回数量' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "getRecommendations", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '根据ID获取时间槽详情' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '时间槽ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '成功获取时间槽详情' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '时间槽不存在' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新时间槽' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '时间槽ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '时间槽更新成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '时间槽不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, update_time_slot_dto_1.UpdateTimeSlotDto]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)('batch/status'),
    (0, swagger_1.ApiOperation)({ summary: '批量更新时间槽状态' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '批量更新成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '请求参数错误' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [batch_operation_dto_1.BatchUpdateStatusDto]),
    __metadata("design:returntype", Promise)
], TimeSlotsController.prototype, "batchUpdateStatus", null);
__decorate([
    (0, common_1.Delete)('batch'),
    (0, swagger_1.ApiOperation)({ summary: '批量删除时间槽' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '批量删除成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '无法删除有订单的时间槽' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [batch_operation_dto_1.BatchDeleteDto]),
    __metadata("design:returntype", Promise)
], TimeSlotsController.prototype, "batchDelete", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除时间槽' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '时间槽ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '时间槽删除成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '时间槽不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '无法删除有订单的时间槽' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], TimeSlotsController.prototype, "remove", null);
exports.TimeSlotsController = TimeSlotsController = __decorate([
    (0, swagger_1.ApiTags)('时间槽管理'),
    (0, common_1.Controller)('time-slots'),
    __metadata("design:paramtypes", [time_slots_service_1.TimeSlotsService])
], TimeSlotsController);
//# sourceMappingURL=time-slots.controller.js.map