export declare class TimeSlotsModule {
}
