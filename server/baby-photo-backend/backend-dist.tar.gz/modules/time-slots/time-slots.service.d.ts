import { PrismaService } from '../../shared/prisma/prisma.service';
import { CreateTimeSlotDto, TimeSlotStatus } from './dto/create-time-slot.dto';
import { UpdateTimeSlotDto } from './dto/update-time-slot.dto';
import { QueryTimeSlotsDto } from './dto/query-time-slots.dto';
import { CreateBatchTimeSlotsDto } from './dto/create-batch-time-slots.dto';
import type { TimeSlot } from '@prisma/client';
export interface TimeSlotStatistics {
    totalSlots: number;
    availableSlots: number;
    bookedSlots: number;
    expiredBookedSlots: number;
    totalCapacity: number;
    totalBooked: number;
    utilizationRate: number;
    averageBookingRate: number;
}
export interface DailyStatistics {
    date: string;
    totalSlots: number;
    availableSlots: number;
    bookedSlots: number;
    totalCapacity: number;
    totalBooked: number;
    utilizationRate: number;
}
export declare class TimeSlotsService {
    private prisma;
    constructor(prisma: PrismaService);
    private mapStatusToPrisma;
    private createTimeDate;
    create(createTimeSlotDto: CreateTimeSlotDto): Promise<TimeSlot>;
    createBatch(createBatchDto: CreateBatchTimeSlotsDto): Promise<TimeSlot[]>;
    findAll(query: QueryTimeSlotsDto): Promise<TimeSlot[]>;
    findOne(id: number): Promise<TimeSlot>;
    findAvailable(date?: string): Promise<TimeSlot[]>;
    update(id: number, updateTimeSlotDto: UpdateTimeSlotDto): Promise<TimeSlot>;
    remove(id: number): Promise<TimeSlot>;
    private validateTimeSlot;
    private checkTimeSlotConflict;
    private findExistingTimeSlot;
    getStatistics(startDate?: string, endDate?: string): Promise<TimeSlotStatistics>;
    private updateExpiredSlots;
    private calculateStatistics;
    getDailyStatistics(startDate: string, endDate: string): Promise<DailyStatistics[]>;
    getAvailableSlots(date?: string, limit?: number, startDate?: string, endDate?: string): Promise<TimeSlot[]>;
    batchUpdateStatus(ids: number[], status: TimeSlotStatus): Promise<number>;
    batchDelete(ids: number[]): Promise<number>;
    getConflictAnalysis(date: string): Promise<{
        date: string;
        totalSlots: number;
        conflicts: {
            slotId: number;
            startTime: string;
            endTime: string;
            severity: "INFO" | "WARNING" | "ERROR";
            message: string;
            bookedCount: number;
            capacity: number;
            utilizationRate: number;
        }[];
        nearCapacitySlots: number;
        fullyBookedSlots: number;
        availableSlots: number;
    }>;
    getRecommendations(startDate?: string, endDate?: string, limit?: number): Promise<{
        date: string;
        startTime: string;
        endTime: string;
        recommendationScore: number;
        reason: string;
        historicalUtilizationRate: number;
        remainingCapacity: number;
    }[]>;
}
