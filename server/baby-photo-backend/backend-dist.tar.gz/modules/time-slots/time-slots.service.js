"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimeSlotsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const create_time_slot_dto_1 = require("./dto/create-time-slot.dto");
const client_1 = require("@prisma/client");
let TimeSlotsService = class TimeSlotsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    mapStatusToPrisma(status) {
        switch (status) {
            case 'AVAILABLE':
                return client_1.TimeSlotStatus.AVAILABLE;
            case 'BOOKED':
                return client_1.TimeSlotStatus.BOOKED;
            case 'UNAVAILABLE':
                return client_1.TimeSlotStatus.UNAVAILABLE;
            default:
                return client_1.TimeSlotStatus.AVAILABLE;
        }
    }
    createTimeDate(timeStr) {
        const [hours, minutes] = timeStr.split(':').map(num => parseInt(num, 10));
        if (isNaN(hours) || isNaN(minutes)) {
            throw new common_1.BadRequestException(`Invalid time format: ${timeStr}. Expected format: HH:mm`);
        }
        if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
            throw new common_1.BadRequestException(`Invalid time range: ${timeStr}. Hours must be 0-23, minutes must be 0-59`);
        }
        const utcHours = hours - 8;
        return new Date(Date.UTC(1970, 0, 1, utcHours, minutes, 0, 0));
    }
    async create(createTimeSlotDto) {
        try {
            this.validateTimeSlot(createTimeSlotDto);
            await this.checkTimeSlotConflict(createTimeSlotDto);
            const timeSlot = await this.prisma.timeSlot.create({
                data: {
                    date: new Date(createTimeSlotDto.date),
                    startTime: this.createTimeDate(createTimeSlotDto.startTime),
                    endTime: this.createTimeDate(createTimeSlotDto.endTime),
                    capacity: createTimeSlotDto.capacity || 10,
                    bookedCount: 0,
                    availableCount: createTimeSlotDto.capacity || 10,
                    status: this.mapStatusToPrisma(createTimeSlotDto.status || create_time_slot_dto_1.TimeSlotStatus.AVAILABLE),
                    isHoliday: createTimeSlotDto.isHoliday || false,
                    priceMultiplier: createTimeSlotDto.priceMultiplier || 1.0,
                    notes: createTimeSlotDto.notes || null,
                },
            });
            return timeSlot;
        }
        catch (error) {
            if (error instanceof common_1.ConflictException ||
                error instanceof common_1.BadRequestException) {
                throw error;
            }
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to create time slot: ${errorMessage}`);
        }
    }
    async createBatch(createBatchDto) {
        try {
            const timeSlots = [];
            for (const date of createBatchDto.dates) {
                for (const timeRange of createBatchDto.timeRanges) {
                    const timeSlotDto = {
                        date,
                        startTime: timeRange.startTime,
                        endTime: timeRange.endTime,
                    };
                    this.validateTimeSlot(timeSlotDto);
                    const existing = await this.findExistingTimeSlot(timeSlotDto);
                    if (existing) {
                        continue;
                    }
                    const capacity = timeRange.capacity !== undefined ? Number(timeRange.capacity) : 10;
                    const timeSlot = await this.prisma.timeSlot.create({
                        data: {
                            date: new Date(date),
                            startTime: this.createTimeDate(timeRange.startTime),
                            endTime: this.createTimeDate(timeRange.endTime),
                            capacity: capacity,
                            bookedCount: 0,
                            availableCount: capacity,
                            status: client_1.TimeSlotStatus.AVAILABLE,
                        },
                    });
                    timeSlots.push(timeSlot);
                }
            }
            return timeSlots;
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to create batch time slots: ${errorMessage}`);
        }
    }
    async findAll(query) {
        try {
            await this.updateExpiredSlots();
            const where = {};
            if (query.startDate || query.endDate) {
                where.date = {};
                if (query.startDate) {
                    where.date.gte = new Date(query.startDate);
                }
                if (query.endDate) {
                    where.date.lte = new Date(query.endDate);
                }
            }
            if (query.isBooked !== undefined) {
                where.isBooked = query.isBooked;
            }
            if (query.status !== undefined) {
                where.status = query.status;
            }
            if (query.isHoliday !== undefined) {
                where.isHoliday = query.isHoliday;
            }
            const hasCapacityFilter = query.hasCapacity;
            const queryWithoutCapacity = { ...query };
            delete queryWithoutCapacity.hasCapacity;
            if (query.hasCapacity !== undefined) {
            }
            if (query.notes !== undefined && query.notes.trim() !== '') {
                where.notes = {
                    contains: query.notes,
                    mode: 'insensitive',
                };
            }
            let orderBy = [{ date: 'asc' }, { startTime: 'asc' }];
            if (query.sortBy) {
                switch (query.sortBy) {
                    case 'date_desc':
                        orderBy = [{ date: 'desc' }, { startTime: 'asc' }];
                        break;
                    case 'time_asc':
                        orderBy = [{ startTime: 'asc' }, { date: 'asc' }];
                        break;
                    case 'time_desc':
                        orderBy = [{ startTime: 'desc' }, { date: 'asc' }];
                        break;
                    default:
                        orderBy = [{ date: 'asc' }, { startTime: 'asc' }];
                }
            }
            const page = query.page || 1;
            const pageSize = query.pageSize || 20;
            const allTimeSlots = await this.prisma.timeSlot.findMany({
                where,
                orderBy,
                include: {
                    orders: {
                        select: {
                            id: true,
                            orderNo: true,
                            user: {
                                select: {
                                    id: true,
                                    nickname: true,
                                },
                            },
                        },
                    },
                },
            });
            let processedTimeSlots = allTimeSlots.map(slot => ({
                ...slot,
                availableCount: Math.max(0, slot.capacity - slot.bookedCount),
            }));
            if (hasCapacityFilter !== undefined) {
                if (hasCapacityFilter) {
                    processedTimeSlots = processedTimeSlots.filter(slot => slot.availableCount > 0);
                }
                else {
                    processedTimeSlots = processedTimeSlots.filter(slot => slot.availableCount <= 0);
                }
            }
            const total = processedTimeSlots.length;
            const skip = (page - 1) * pageSize;
            const paginatedTimeSlots = processedTimeSlots.slice(skip, skip + pageSize);
            return {
                list: paginatedTimeSlots,
                pagination: {
                    current: page,
                    pageSize,
                    total,
                    totalPages: Math.ceil(total / pageSize),
                },
            };
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to fetch time slots: ${errorMessage}`);
        }
    }
    async findOne(id) {
        try {
            const timeSlot = await this.prisma.timeSlot.findUnique({
                where: { id },
                include: {
                    orders: {
                        include: {
                            user: {
                                select: {
                                    id: true,
                                    nickname: true,
                                    phone: true,
                                },
                            },
                            package: {
                                select: {
                                    id: true,
                                    name: true,
                                },
                            },
                        },
                    },
                },
            });
            if (!timeSlot) {
                throw new common_1.NotFoundException(`Time slot with id ${id} not found`);
            }
            return timeSlot;
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to find time slot: ${errorMessage}`);
        }
    }
    async findAvailable(date) {
        try {
            const where = { isBooked: false };
            if (date) {
                where.date = new Date(date);
            }
            else {
                where.date = {
                    gte: new Date(),
                };
            }
            const timeSlots = await this.prisma.timeSlot.findMany({
                where,
                orderBy: [{ date: 'asc' }, { startTime: 'asc' }],
            });
            return timeSlots;
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to find available time slots: ${errorMessage}`);
        }
    }
    async update(id, updateTimeSlotDto) {
        try {
            await this.findOne(id);
            if (updateTimeSlotDto.date ||
                updateTimeSlotDto.startTime ||
                updateTimeSlotDto.endTime) {
                const currentTimeSlot = await this.prisma.timeSlot.findUnique({
                    where: { id },
                });
                if (!currentTimeSlot) {
                    throw new common_1.NotFoundException(`Time slot with id ${id} not found`);
                }
                const updatedData = {
                    date: updateTimeSlotDto.date ||
                        currentTimeSlot.date.toISOString().split('T')[0],
                    startTime: updateTimeSlotDto.startTime ||
                        currentTimeSlot.startTime.toTimeString().split(' ')[0],
                    endTime: updateTimeSlotDto.endTime ||
                        currentTimeSlot.endTime.toTimeString().split(' ')[0],
                };
                this.validateTimeSlot(updatedData);
            }
            const data = {};
            if (updateTimeSlotDto.date) {
                data.date = new Date(updateTimeSlotDto.date);
            }
            if (updateTimeSlotDto.startTime) {
                data.startTime = this.createTimeDate(updateTimeSlotDto.startTime);
            }
            if (updateTimeSlotDto.endTime) {
                data.endTime = this.createTimeDate(updateTimeSlotDto.endTime);
            }
            if (updateTimeSlotDto.capacity !== undefined) {
                data.capacity = updateTimeSlotDto.capacity;
                const currentTimeSlot = await this.prisma.timeSlot.findUnique({
                    where: { id },
                    select: { bookedCount: true },
                });
                if (currentTimeSlot) {
                    data.availableCount = Math.max(0, updateTimeSlotDto.capacity - currentTimeSlot.bookedCount);
                }
            }
            if (updateTimeSlotDto.status !== undefined) {
                data.status = updateTimeSlotDto.status;
            }
            if (updateTimeSlotDto.isHoliday !== undefined) {
                data.isHoliday = updateTimeSlotDto.isHoliday;
            }
            if (updateTimeSlotDto.priceMultiplier !== undefined) {
                data.priceMultiplier = updateTimeSlotDto.priceMultiplier;
            }
            if (updateTimeSlotDto.notes !== undefined) {
                data.notes = updateTimeSlotDto.notes;
            }
            if (updateTimeSlotDto.isBooked !== undefined) {
                data.isBooked = updateTimeSlotDto.isBooked;
            }
            const updatedTimeSlot = await this.prisma.timeSlot.update({
                where: { id },
                data,
                include: {
                    orders: true,
                },
            });
            return updatedTimeSlot;
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException ||
                error instanceof common_1.BadRequestException) {
                throw error;
            }
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to update time slot: ${errorMessage}`);
        }
    }
    async remove(id) {
        try {
            const timeSlot = await this.prisma.timeSlot.findUnique({
                where: { id },
                include: { orders: true },
            });
            if (!timeSlot) {
                throw new common_1.NotFoundException(`Time slot with id ${id} not found`);
            }
            if (timeSlot.orders && timeSlot.orders.length > 0) {
                throw new common_1.BadRequestException('Cannot delete time slot with existing orders');
            }
            const deletedTimeSlot = await this.prisma.timeSlot.delete({
                where: { id },
            });
            return deletedTimeSlot;
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException ||
                error instanceof common_1.BadRequestException) {
                throw error;
            }
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to delete time slot: ${errorMessage}`);
        }
    }
    validateTimeSlot(data) {
        const date = new Date(data.date);
        const startTime = new Date(`1970-01-01T${data.startTime}Z`);
        const endTime = new Date(`1970-01-01T${data.endTime}Z`);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (date < today) {
            throw new common_1.BadRequestException('Date cannot be in the past');
        }
        if (endTime <= startTime) {
            throw new common_1.BadRequestException('End time must be after start time');
        }
        const durationMinutes = (endTime.getTime() - startTime.getTime()) / (1000 * 60);
        if (durationMinutes < 30) {
            throw new common_1.BadRequestException('Time slot duration must be at least 30 minutes');
        }
    }
    async checkTimeSlotConflict(data) {
        const existing = await this.findExistingTimeSlot(data);
        if (existing) {
            throw new common_1.ConflictException('Time slot already exists for this date and time');
        }
    }
    async findExistingTimeSlot(data) {
        return await this.prisma.timeSlot.findFirst({
            where: {
                date: new Date(data.date),
                startTime: this.createTimeDate(data.startTime),
                endTime: this.createTimeDate(data.endTime),
            },
        });
    }
    async getStatistics(startDate, endDate) {
        try {
            const now = new Date();
            now.setHours(0, 0, 0, 0);
            const tomorrow = new Date(now);
            tomorrow.setDate(tomorrow.getDate() + 1);
            const futureWhere = {
                date: {
                    gte: startDate ? new Date(startDate) : tomorrow,
                }
            };
            if (endDate) {
                const endDateObj = new Date(endDate);
                endDateObj.setDate(endDateObj.getDate() + 1);
                futureWhere.date.lt = endDateObj;
            }
            const expiredWhere = {
                date: {
                    lte: now,
                },
                status: client_1.TimeSlotStatus.BOOKED,
            };
            console.log('📊 统计查询条件:', {
                当前日期: now.toISOString().split('T')[0],
                明天: tomorrow.toISOString().split('T')[0],
                startDate,
                endDate,
                futureWhere,
                expiredWhere
            });
            await this.updateExpiredSlots();
            const futureSlots = await this.prisma.timeSlot.findMany({ where: futureWhere });
            const expiredBookedSlots = await this.prisma.timeSlot.findMany({ where: expiredWhere });
            console.log('📈 查询结果:', {
                未来时间槽数量: futureSlots.length,
                过期已预定数量: expiredBookedSlots.length,
            });
            return this.calculateStatistics(futureSlots, expiredBookedSlots.length);
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to get statistics: ${errorMessage}`);
        }
    }
    async updateExpiredSlots() {
        const now = new Date();
        const availableSlots = await this.prisma.timeSlot.findMany({
            where: {
                status: client_1.TimeSlotStatus.AVAILABLE
            }
        });
        const expiredSlots = availableSlots.filter(slot => {
            const slotDateTime = new Date(slot.date);
            const startTime = new Date(slot.startTime);
            slotDateTime.setHours(startTime.getUTCHours() + 8);
            slotDateTime.setMinutes(startTime.getUTCMinutes());
            return slotDateTime < now;
        });
        if (expiredSlots.length > 0) {
            await this.prisma.timeSlot.updateMany({
                where: {
                    id: { in: expiredSlots.map(s => s.id) }
                },
                data: {
                    status: client_1.TimeSlotStatus.UNAVAILABLE
                }
            });
            console.log(`已将 ${expiredSlots.length} 个过期时间槽设为不可用`);
        }
    }
    calculateStatistics(futureSlots, expiredBookedCount) {
        const totalSlots = futureSlots.length;
        const bookedSlots = futureSlots.filter(slot => slot.status === client_1.TimeSlotStatus.BOOKED).length;
        const availableSlots = futureSlots.filter(slot => slot.status === client_1.TimeSlotStatus.AVAILABLE).length;
        const expiredBookedSlots = expiredBookedCount;
        const totalCapacity = futureSlots.reduce((sum, slot) => sum + slot.capacity, 0);
        const totalBooked = futureSlots.reduce((sum, slot) => sum + slot.bookedCount, 0);
        const utilizationRate = totalCapacity > 0 ? (totalBooked / totalCapacity) * 100 : 0;
        const averageBookingRate = totalSlots > 0 ? (bookedSlots / totalSlots) * 100 : 0;
        const stats = {
            totalSlots,
            availableSlots,
            bookedSlots,
            expiredBookedSlots,
            totalCapacity,
            totalBooked,
            utilizationRate: Math.round(utilizationRate * 100) / 100,
            averageBookingRate: Math.round(averageBookingRate * 100) / 100,
        };
        console.log('✅ 时间槽统计结果（新逻辑）:', stats);
        console.log('📊 统计详情:', {
            '总时间槽（当前日期到未来）': totalSlots,
            '可用时间槽': availableSlots,
            '已预定时间槽': bookedSlots,
            '过期已预定': expiredBookedSlots,
            '总容量': totalCapacity,
            '已预订人数': totalBooked,
        });
        return stats;
    }
    async getDailyStatistics(startDate, endDate) {
        try {
            const timeSlots = await this.prisma.timeSlot.findMany({
                where: {
                    date: {
                        gte: new Date(startDate),
                        lte: new Date(endDate),
                    },
                },
                orderBy: { date: 'asc' },
            });
            const dailyStats = new Map();
            timeSlots.forEach(slot => {
                const dateKey = slot.date.toISOString().split('T')[0];
                if (!dailyStats.has(dateKey)) {
                    dailyStats.set(dateKey, {
                        date: dateKey,
                        totalSlots: 0,
                        availableSlots: 0,
                        bookedSlots: 0,
                        totalCapacity: 0,
                        totalBooked: 0,
                        utilizationRate: 0,
                    });
                }
                const stats = dailyStats.get(dateKey);
                stats.totalSlots++;
                stats.totalCapacity += slot.capacity;
                stats.totalBooked += slot.bookedCount;
                if (slot.status === client_1.TimeSlotStatus.AVAILABLE) {
                    stats.availableSlots++;
                }
                else if (slot.status === client_1.TimeSlotStatus.BOOKED) {
                    stats.bookedSlots++;
                }
            });
            const result = Array.from(dailyStats.values()).map(stats => ({
                ...stats,
                utilizationRate: stats.totalCapacity > 0
                    ? Math.round((stats.totalBooked / stats.totalCapacity) * 10000) / 100
                    : 0,
            }));
            return result;
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to get daily statistics: ${errorMessage}`);
        }
    }
    async getAvailableSlots(date, limit, startDate, endDate) {
        try {
            const where = {
                status: client_1.TimeSlotStatus.AVAILABLE,
            };
            if (date) {
                where.date = new Date(date);
            }
            else if (startDate && endDate) {
                where.date = {
                    gte: new Date(startDate),
                    lte: new Date(endDate),
                };
            }
            else {
                where.date = { gte: new Date() };
            }
            const allSlots = await this.prisma.timeSlot.findMany({
                where,
                include: {
                    _count: {
                        select: { orders: true }
                    }
                },
                orderBy: [{ date: 'asc' }, { startTime: 'asc' }],
            });
            const availableSlots = allSlots.filter(slot => {
                const currentBookedCount = slot._count?.orders;
                return currentBookedCount < slot.capacity;
            });
            if (limit) {
                return availableSlots.slice(0, limit);
            }
            return availableSlots;
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to get available slots: ${errorMessage}`);
        }
    }
    async batchUpdateStatus(ids, status) {
        try {
            const result = await this.prisma.timeSlot.updateMany({
                where: { id: { in: ids } },
                data: { status: this.mapStatusToPrisma(status) },
            });
            return result.count;
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to batch update status: ${errorMessage}`);
        }
    }
    async batchDelete(ids) {
        try {
            const bookedSlots = await this.prisma.timeSlot.findMany({
                where: {
                    id: { in: ids },
                    bookedCount: { gt: 0 },
                },
            });
            if (bookedSlots.length > 0) {
                throw new common_1.BadRequestException(`Cannot delete time slots with bookings. Found ${bookedSlots.length} booked slots.`);
            }
            const result = await this.prisma.timeSlot.deleteMany({
                where: { id: { in: ids } },
            });
            return result.count;
        }
        catch (error) {
            if (error instanceof common_1.BadRequestException) {
                throw error;
            }
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            throw new common_1.BadRequestException(`Failed to batch delete: ${errorMessage}`);
        }
    }
    async getConflictAnalysis(date) {
        const queryDate = new Date(date + 'T00:00:00.000Z');
        const slots = await this.prisma.timeSlot.findMany({
            where: { date: queryDate },
            orderBy: { startTime: 'asc' },
        });
        const toCstTime = (d) => {
            const cst = new Date(d.getTime() + 8 * 60 * 60 * 1000);
            return cst.toISOString().slice(11, 16);
        };
        const conflicts = [];
        for (const slot of slots) {
            const utilization = slot.capacity > 0 ? (slot.bookedCount / slot.capacity) * 100 : 0;
            if (utilization >= 100) {
                conflicts.push({
                    slotId: slot.id,
                    startTime: toCstTime(slot.startTime),
                    endTime: toCstTime(slot.endTime),
                    severity: 'ERROR',
                    message: `时间段已满 (${slot.bookedCount}/${slot.capacity})`,
                    bookedCount: slot.bookedCount,
                    capacity: slot.capacity,
                    utilizationRate: utilization,
                });
            }
            else if (utilization >= 80) {
                conflicts.push({
                    slotId: slot.id,
                    startTime: toCstTime(slot.startTime),
                    endTime: toCstTime(slot.endTime),
                    severity: 'WARNING',
                    message: `时间段即将饱和 (${slot.bookedCount}/${slot.capacity})`,
                    bookedCount: slot.bookedCount,
                    capacity: slot.capacity,
                    utilizationRate: utilization,
                });
            }
        }
        for (let i = 0; i < slots.length; i++) {
            for (let j = i + 1; j < slots.length; j++) {
                const a = slots[i];
                const b = slots[j];
                const aStart = a.startTime.getTime();
                const aEnd = a.endTime.getTime();
                const bStart = b.startTime.getTime();
                const bEnd = b.endTime.getTime();
                if (aStart < bEnd && bStart < aEnd) {
                    conflicts.push({
                        slotId: a.id,
                        startTime: toCstTime(a.startTime),
                        endTime: toCstTime(a.endTime),
                        severity: 'WARNING',
                        message: `与时间段 ${toCstTime(b.startTime)}-${toCstTime(b.endTime)} 重叠`,
                        bookedCount: a.bookedCount,
                        capacity: a.capacity,
                        utilizationRate: 0,
                    });
                }
            }
        }
        const totalSlots = slots.length;
        const nearCapacity = conflicts.filter(c => c.severity === 'WARNING').length;
        const fullyBooked = conflicts.filter(c => c.severity === 'ERROR').length;
        const available = slots.filter(s => (s.availableCount ?? 0) > 0).length;
        return {
            date,
            totalSlots,
            conflicts,
            nearCapacitySlots: nearCapacity,
            fullyBookedSlots: fullyBooked,
            availableSlots: available,
        };
    }
    async getRecommendations(startDate, endDate, limit = 5) {
        const today = new Date();
        const todayUtc = new Date(today.toISOString().slice(0, 10) + 'T00:00:00.000Z');
        const start = startDate ? new Date(startDate + 'T00:00:00.000Z') : todayUtc;
        if (!startDate) {
            start.setUTCDate(start.getUTCDate() + 1);
        }
        const end = endDate ? new Date(endDate + 'T00:00:00.000Z') : new Date(start);
        if (!endDate) {
            end.setUTCDate(end.getUTCDate() + 14);
        }
        const toCstTime = (d) => {
            const cst = new Date(d.getTime() + 8 * 60 * 60 * 1000);
            return cst.toISOString().slice(11, 16);
        };
        const slots = await this.prisma.timeSlot.findMany({
            where: {
                date: { gte: start, lte: end },
                status: 'AVAILABLE',
            },
            orderBy: [{ date: 'asc' }, { startTime: 'asc' }],
        });
        const scored = slots
            .filter(s => (s.availableCount ?? 0) > 0)
            .map(s => {
            const utilization = s.capacity > 0 ? s.bookedCount / s.capacity : 0;
            const score = Math.round((1 - utilization) * 100);
            return {
                date: s.date.toISOString().slice(0, 10),
                startTime: toCstTime(s.startTime),
                endTime: toCstTime(s.endTime),
                recommendationScore: score,
                reason: utilization < 0.3
                    ? '该时间段非常宽松，建议安排预约'
                    : utilization < 0.6
                        ? '该时间段仍有较多余量'
                        : '该时间段即将饱和，建议尽早安排',
                historicalUtilizationRate: Math.round(utilization * 100),
                remainingCapacity: s.availableCount ?? 0,
            };
        })
            .sort((a, b) => b.recommendationScore - a.recommendationScore)
            .slice(0, limit);
        return scored;
    }
};
exports.TimeSlotsService = TimeSlotsService;
exports.TimeSlotsService = TimeSlotsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], TimeSlotsService);
//# sourceMappingURL=time-slots.service.js.map