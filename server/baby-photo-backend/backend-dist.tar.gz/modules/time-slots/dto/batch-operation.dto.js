"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchDeleteDto = exports.BatchUpdateStatusDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const create_time_slot_dto_1 = require("./create-time-slot.dto");
class BatchUpdateStatusDto {
    ids;
    status;
}
exports.BatchUpdateStatusDto = BatchUpdateStatusDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '时间槽ID数组',
        example: [1, 2, 3],
    }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", Array)
], BatchUpdateStatusDto.prototype, "ids", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '新状态',
        enum: create_time_slot_dto_1.TimeSlotStatus,
        example: create_time_slot_dto_1.TimeSlotStatus.UNAVAILABLE,
    }),
    (0, class_validator_1.IsEnum)(create_time_slot_dto_1.TimeSlotStatus),
    __metadata("design:type", String)
], BatchUpdateStatusDto.prototype, "status", void 0);
class BatchDeleteDto {
    ids;
}
exports.BatchDeleteDto = BatchDeleteDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '要删除的时间槽ID数组',
        example: [1, 2, 3],
    }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", Array)
], BatchDeleteDto.prototype, "ids", void 0);
//# sourceMappingURL=batch-operation.dto.js.map