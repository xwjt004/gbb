export declare enum TimeSlotStatus {
    AVAILABLE = "AVAILABLE",
    BOOKED = "BOOKED",
    UNAVAILABLE = "UNAVAILABLE"
}
export declare class CreateTimeSlotDto {
    date: string;
    startTime: string;
    endTime: string;
    capacity?: number;
    status?: TimeSlotStatus;
    priceMultiplier?: number;
    isHoliday?: boolean;
    notes?: string;
}
