"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateTimeSlotDto = exports.TimeSlotStatus = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
var TimeSlotStatus;
(function (TimeSlotStatus) {
    TimeSlotStatus["AVAILABLE"] = "AVAILABLE";
    TimeSlotStatus["BOOKED"] = "BOOKED";
    TimeSlotStatus["UNAVAILABLE"] = "UNAVAILABLE";
})(TimeSlotStatus || (exports.TimeSlotStatus = TimeSlotStatus = {}));
class CreateTimeSlotDto {
    date;
    startTime;
    endTime;
    capacity;
    status;
    priceMultiplier;
    isHoliday;
    notes;
}
exports.CreateTimeSlotDto = CreateTimeSlotDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '预约日期',
        example: '2024-08-15',
        format: 'date',
    }),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateTimeSlotDto.prototype, "date", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '开始时间',
        example: '09:00:00',
        pattern: '^([0-1]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/, {
        message: '开始时间格式必须为 HH:MM:SS',
    }),
    __metadata("design:type", String)
], CreateTimeSlotDto.prototype, "startTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '结束时间',
        example: '11:00:00',
        pattern: '^([0-1]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Matches)(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/, {
        message: '结束时间格式必须为 HH:MM:SS',
    }),
    __metadata("design:type", String)
], CreateTimeSlotDto.prototype, "endTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '容量',
        example: 3,
        minimum: 1,
        maximum: 100,
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1, { message: '容量至少为1' }),
    (0, class_validator_1.Max)(100, { message: '容量不能超过100' }),
    __metadata("design:type", Number)
], CreateTimeSlotDto.prototype, "capacity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '状态',
        enum: TimeSlotStatus,
        example: TimeSlotStatus.AVAILABLE,
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(TimeSlotStatus, { message: '状态必须是有效的枚举值' }),
    __metadata("design:type", String)
], CreateTimeSlotDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '价格倍数',
        example: 1.0,
        minimum: 0.1,
        maximum: 10,
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0.1, { message: '价格倍数不能低于0.1' }),
    (0, class_validator_1.Max)(10, { message: '价格倍数不能超过10' }),
    __metadata("design:type", Number)
], CreateTimeSlotDto.prototype, "priceMultiplier", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '是否为节假日',
        example: false,
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateTimeSlotDto.prototype, "isHoliday", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '备注',
        example: '上午时段',
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateTimeSlotDto.prototype, "notes", void 0);
//# sourceMappingURL=create-time-slot.dto.js.map