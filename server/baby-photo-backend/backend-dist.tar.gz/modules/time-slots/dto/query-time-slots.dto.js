"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryTimeSlotsDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const create_time_slot_dto_1 = require("./create-time-slot.dto");
class QueryTimeSlotsDto {
    startDate;
    endDate;
    isBooked;
    status;
    isHoliday;
    hasCapacity;
    notes;
    sortBy;
    page;
    pageSize;
}
exports.QueryTimeSlotsDto = QueryTimeSlotsDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '开始日期',
        required: false,
        example: '2024-08-15',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], QueryTimeSlotsDto.prototype, "startDate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '结束日期',
        required: false,
        example: '2024-08-30',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], QueryTimeSlotsDto.prototype, "endDate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '是否已被预订',
        required: false,
        example: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (value === 'true')
            return true;
        if (value === 'false')
            return false;
        return value;
    }),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], QueryTimeSlotsDto.prototype, "isBooked", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '时间槽状态',
        enum: create_time_slot_dto_1.TimeSlotStatus,
        required: false,
        example: create_time_slot_dto_1.TimeSlotStatus.AVAILABLE,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(create_time_slot_dto_1.TimeSlotStatus),
    __metadata("design:type", String)
], QueryTimeSlotsDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '是否为节假日',
        required: false,
        example: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (value === 'true')
            return true;
        if (value === 'false')
            return false;
        return value;
    }),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], QueryTimeSlotsDto.prototype, "isHoliday", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '是否只显示有余量的时间槽',
        required: false,
        example: false,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (value === 'true')
            return true;
        if (value === 'false')
            return false;
        return value;
    }),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], QueryTimeSlotsDto.prototype, "hasCapacity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '备注搜索关键词',
        required: false,
        example: '上午',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], QueryTimeSlotsDto.prototype, "notes", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '排序方式',
        enum: ['date_asc', 'date_desc', 'time_asc', 'time_desc'],
        required: false,
        default: 'date_asc',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['date_asc', 'date_desc', 'time_asc', 'time_desc']),
    __metadata("design:type", String)
], QueryTimeSlotsDto.prototype, "sortBy", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '页码',
        required: false,
        default: 1,
        minimum: 1,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], QueryTimeSlotsDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '每页数量',
        required: false,
        default: 20,
        minimum: 1,
        maximum: 100,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], QueryTimeSlotsDto.prototype, "pageSize", void 0);
//# sourceMappingURL=query-time-slots.dto.js.map