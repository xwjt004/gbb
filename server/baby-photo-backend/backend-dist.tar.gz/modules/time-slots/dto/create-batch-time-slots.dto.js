"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateBatchTimeSlotsDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
class TimeRange {
    startTime;
    endTime;
    capacity;
}
__decorate([
    (0, swagger_1.ApiProperty)({ description: '开始时间', example: '09:00:00' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TimeRange.prototype, "startTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '结束时间', example: '11:00:00' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TimeRange.prototype, "endTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '容量', example: 10, required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], TimeRange.prototype, "capacity", void 0);
class CreateBatchTimeSlotsDto {
    dates;
    timeRanges;
}
exports.CreateBatchTimeSlotsDto = CreateBatchTimeSlotsDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '日期列表',
        example: ['2024-08-15', '2024-08-16', '2024-08-17'],
        type: [String],
    }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsDateString)({}, { each: true }),
    __metadata("design:type", Array)
], CreateBatchTimeSlotsDto.prototype, "dates", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '时间段列表',
        type: [TimeRange],
    }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => TimeRange),
    __metadata("design:type", Array)
], CreateBatchTimeSlotsDto.prototype, "timeRanges", void 0);
//# sourceMappingURL=create-batch-time-slots.dto.js.map