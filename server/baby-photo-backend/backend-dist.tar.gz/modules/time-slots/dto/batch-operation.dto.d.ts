import { TimeSlotStatus } from './create-time-slot.dto';
export declare class BatchUpdateStatusDto {
    ids: number[];
    status: TimeSlotStatus;
}
export declare class BatchDeleteDto {
    ids: number[];
}
