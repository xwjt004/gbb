declare class TimeRange {
    startTime: string;
    endTime: string;
    capacity?: number;
}
export declare class CreateBatchTimeSlotsDto {
    dates: string[];
    timeRanges: TimeRange[];
}
export {};
