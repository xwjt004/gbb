import { TimeSlotStatus } from './create-time-slot.dto';
export declare class QueryTimeSlotsDto {
    startDate?: string;
    endDate?: string;
    isBooked?: boolean;
    status?: TimeSlotStatus;
    isHoliday?: boolean;
    hasCapacity?: boolean;
    notes?: string;
    sortBy?: string;
    page?: number;
    pageSize?: number;
}
