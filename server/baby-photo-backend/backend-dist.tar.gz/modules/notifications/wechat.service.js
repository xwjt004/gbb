"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var WechatNotificationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatNotificationService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const axios_1 = __importDefault(require("axios"));
let WechatNotificationService = WechatNotificationService_1 = class WechatNotificationService {
    configService;
    logger = new common_1.Logger(WechatNotificationService_1.name);
    tokenCache = null;
    API_BASE = 'https://api.weixin.qq.com';
    constructor(configService) {
        this.configService = configService;
    }
    async getAccessToken() {
        if (this.tokenCache && Date.now() < this.tokenCache.expiresAt) {
            return this.tokenCache.token;
        }
        const appId = this.configService.get('WX_APP_ID');
        const appSecret = this.configService.get('WX_APP_SECRET');
        if (!appId || !appSecret || appId === 'your-wechat-app-id') {
            throw new Error('微信配置缺失：请设置 WX_APP_ID 和 WX_APP_SECRET');
        }
        const res = await axios_1.default.get(`${this.API_BASE}/cgi-bin/token`, {
            params: { grant_type: 'client_credential', appid: appId, secret: appSecret },
        });
        if (res.data.errcode) {
            throw new Error(`获取 access_token 失败: ${res.data.errmsg} (${res.data.errcode})`);
        }
        this.tokenCache = {
            token: res.data.access_token,
            expiresAt: Date.now() + (res.data.expires_in - 300) * 1000,
        };
        return res.data.access_token;
    }
    async sendTemplateMessage(openid, templateId, data, page) {
        const token = await this.getAccessToken();
        const url = `${this.API_BASE}/cgi-bin/message/subscribe/send?access_token=${token}`;
        const wechatData = {};
        for (const [key, value] of Object.entries(data)) {
            wechatData[key] = { value: String(value ?? '') };
        }
        const body = {
            touser: openid,
            template_id: templateId,
            data: wechatData,
        };
        if (page)
            body.page = page;
        const res = await axios_1.default.post(url, body);
        if (res.data.errcode === 0) {
            this.logger.log(`微信订阅消息发送成功: ${openid} 模板 ${templateId}`);
            return true;
        }
        if (res.data.errcode === 43101) {
            this.logger.warn(`用户未订阅模板消息: ${openid} (${res.data.errmsg})`);
            return false;
        }
        this.logger.error(`微信消息发送失败: ${res.data.errmsg} (${res.data.errcode})`);
        return false;
    }
    clearTokenCache() {
        this.tokenCache = null;
    }
};
exports.WechatNotificationService = WechatNotificationService;
exports.WechatNotificationService = WechatNotificationService = WechatNotificationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], WechatNotificationService);
//# sourceMappingURL=wechat.service.js.map