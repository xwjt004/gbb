import { ConfigService } from '@nestjs/config';
export declare class EmailService {
    private configService;
    private readonly logger;
    private transporter;
    constructor(configService: ConfigService);
    private initTransporter;
    sendMail(to: string, subject: string, html: string): Promise<boolean>;
    isConfigured(): Promise<boolean>;
}
