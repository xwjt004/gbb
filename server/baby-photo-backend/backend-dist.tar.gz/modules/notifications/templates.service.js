"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TemplatesService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TemplatesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let TemplatesService = TemplatesService_1 = class TemplatesService {
    prisma;
    logger = new common_1.Logger(TemplatesService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(dto) {
        const template = await this.prisma.notificationTemplate.create({
            data: {
                name: dto.name,
                type: dto.type,
                title: dto.title,
                content: dto.content,
                variables: dto.variables ? JSON.stringify(dto.variables) : null,
            },
        });
        return { code: 200, message: '模板创建成功', data: template };
    }
    async findAll(query) {
        const { page = 1, pageSize = 20, type } = query;
        const skip = (page - 1) * pageSize;
        const where = {};
        if (type)
            where.type = type;
        const [total, items] = await Promise.all([
            this.prisma.notificationTemplate.count({ where }),
            this.prisma.notificationTemplate.findMany({
                where,
                skip,
                take: pageSize,
                orderBy: { createdAt: 'desc' },
            }),
        ]);
        const parsed = items.map((t) => ({
            ...t,
            variables: t.variables ? JSON.parse(t.variables) : [],
        }));
        return {
            code: 200,
            message: '查询模板列表成功',
            data: { items: parsed, total, page, pageSize, totalPages: Math.ceil(total / pageSize) },
        };
    }
    async findOne(id) {
        const template = await this.prisma.notificationTemplate.findUnique({
            where: { id },
        });
        if (!template) {
            throw new common_1.NotFoundException('通知模板不存在');
        }
        return {
            code: 200,
            message: '查询模板详情成功',
            data: { ...template, variables: template.variables ? JSON.parse(template.variables) : [] },
        };
    }
    async update(id, dto) {
        const existing = await this.prisma.notificationTemplate.findUnique({ where: { id } });
        if (!existing) {
            throw new common_1.NotFoundException('通知模板不存在');
        }
        const data = {};
        if (dto.name !== undefined)
            data.name = dto.name;
        if (dto.type !== undefined)
            data.type = dto.type;
        if (dto.title !== undefined)
            data.title = dto.title;
        if (dto.content !== undefined)
            data.content = dto.content;
        if (dto.variables !== undefined)
            data.variables = JSON.stringify(dto.variables);
        const template = await this.prisma.notificationTemplate.update({ where: { id }, data });
        return { code: 200, message: '模板更新成功', data: template };
    }
    async remove(id) {
        const existing = await this.prisma.notificationTemplate.findUnique({ where: { id } });
        if (!existing) {
            throw new common_1.NotFoundException('通知模板不存在');
        }
        await this.prisma.notificationTemplate.delete({ where: { id } });
        return { code: 200, message: '模板删除成功', data: null };
    }
};
exports.TemplatesService = TemplatesService;
exports.TemplatesService = TemplatesService = TemplatesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], TemplatesService);
//# sourceMappingURL=templates.service.js.map