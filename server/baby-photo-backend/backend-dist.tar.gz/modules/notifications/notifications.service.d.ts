import { PrismaService } from '../../shared/prisma/prisma.service';
import { CreateNotificationDto } from './dto/create-notification.dto';
import { QueryNotificationDto } from './dto/query-notification.dto';
import { EmailService } from './email.service';
import { WechatNotificationService } from './wechat.service';
export declare class NotificationsService {
    private readonly prisma;
    private readonly emailService;
    private readonly wechatService;
    private readonly logger;
    constructor(prisma: PrismaService, emailService: EmailService, wechatService: WechatNotificationService);
    create(dto: CreateNotificationDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            status: import("@prisma/client").$Enums.NotificationStatus;
            errorMessage: string | null;
            content: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            recipient: string | null;
            sentAt: Date | null;
        };
    }>;
    findAll(query: QueryNotificationDto): Promise<{
        code: number;
        message: string;
        data: {
            items: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                status: import("@prisma/client").$Enums.NotificationStatus;
                errorMessage: string | null;
                content: string;
                type: import("@prisma/client").$Enums.NotificationType;
                title: string;
                recipient: string | null;
                sentAt: Date | null;
            }[];
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
        };
    }>;
    findOne(id: string): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            status: import("@prisma/client").$Enums.NotificationStatus;
            errorMessage: string | null;
            content: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            recipient: string | null;
            sentAt: Date | null;
        };
    }>;
    remove(id: string): Promise<{
        code: number;
        message: string;
        data: null;
    }>;
    retry(id: string): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            status: "FAILED" | "SENT";
            sentAt: Date | null;
            errorMessage: string | null;
        };
    }>;
    retryAllFailed(): Promise<{
        code: number;
        message: string;
        data: {
            total: number;
            success: number;
        };
    }>;
}
