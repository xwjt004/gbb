export declare class NotificationsModule {
}
