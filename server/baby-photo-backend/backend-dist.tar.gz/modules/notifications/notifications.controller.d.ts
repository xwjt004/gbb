import { NotificationsService } from './notifications.service';
import { TemplatesService } from './templates.service';
import { CreateNotificationDto } from './dto/create-notification.dto';
import { QueryNotificationDto } from './dto/query-notification.dto';
import { CreateTemplateDto } from './dto/create-template.dto';
import { UpdateTemplateDto } from './dto/update-template.dto';
import { QueryTemplateDto } from './dto/query-template.dto';
export declare class NotificationsController {
    private readonly notificationsService;
    private readonly templatesService;
    constructor(notificationsService: NotificationsService, templatesService: TemplatesService);
    create(dto: CreateNotificationDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            status: import("@prisma/client").$Enums.NotificationStatus;
            errorMessage: string | null;
            content: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            recipient: string | null;
            sentAt: Date | null;
        };
    }>;
    findAll(query: QueryNotificationDto): Promise<{
        code: number;
        message: string;
        data: {
            items: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                status: import("@prisma/client").$Enums.NotificationStatus;
                errorMessage: string | null;
                content: string;
                type: import("@prisma/client").$Enums.NotificationType;
                title: string;
                recipient: string | null;
                sentAt: Date | null;
            }[];
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
        };
    }>;
    createTemplate(dto: CreateTemplateDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            content: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            variables: string | null;
        };
    }>;
    findAllTemplates(query: QueryTemplateDto): Promise<{
        code: number;
        message: string;
        data: {
            items: {
                variables: any;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                content: string;
                type: import("@prisma/client").$Enums.NotificationType;
                title: string;
            }[];
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
        };
    }>;
    findOneTemplate(id: string): Promise<{
        code: number;
        message: string;
        data: {
            variables: any;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            content: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
        };
    }>;
    updateTemplate(id: string, dto: UpdateTemplateDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            content: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            variables: string | null;
        };
    }>;
    removeTemplate(id: string): Promise<{
        code: number;
        message: string;
        data: null;
    }>;
    findOne(id: string): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            status: import("@prisma/client").$Enums.NotificationStatus;
            errorMessage: string | null;
            content: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            recipient: string | null;
            sentAt: Date | null;
        };
    }>;
    remove(id: string): Promise<{
        code: number;
        message: string;
        data: null;
    }>;
    retry(id: string): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            status: "FAILED" | "SENT";
            sentAt: Date | null;
            errorMessage: string | null;
        };
    }>;
    retryAllFailed(): Promise<{
        code: number;
        message: string;
        data: {
            total: number;
            success: number;
        };
    }>;
}
