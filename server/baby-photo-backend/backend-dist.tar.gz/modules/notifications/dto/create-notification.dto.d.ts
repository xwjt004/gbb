export declare class CreateNotificationDto {
    type: 'PUSH' | 'EMAIL' | 'SYSTEM' | 'WECHAT';
    title: string;
    content: string;
    recipient?: string;
}
