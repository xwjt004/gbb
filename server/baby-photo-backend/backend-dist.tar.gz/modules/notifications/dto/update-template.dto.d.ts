export declare class UpdateTemplateDto {
    name?: string;
    type?: 'PUSH' | 'EMAIL' | 'SYSTEM' | 'WECHAT';
    title?: string;
    content?: string;
    variables?: string[];
}
