export declare class CreateTemplateDto {
    name: string;
    type: 'PUSH' | 'EMAIL' | 'SYSTEM' | 'WECHAT';
    title: string;
    content: string;
    variables?: string[];
}
