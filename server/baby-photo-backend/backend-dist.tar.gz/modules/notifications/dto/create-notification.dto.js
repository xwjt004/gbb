"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateNotificationDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class CreateNotificationDto {
    type;
    title;
    content;
    recipient;
}
exports.CreateNotificationDto = CreateNotificationDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '通知类型', enum: ['PUSH', 'EMAIL', 'SYSTEM', 'WECHAT'] }),
    (0, class_validator_1.IsNotEmpty)({ message: '通知类型不能为空' }),
    (0, class_validator_1.IsEnum)(['PUSH', 'EMAIL', 'SYSTEM', 'WECHAT'], { message: '通知类型必须是 PUSH, EMAIL, SYSTEM 或 WECHAT' }),
    __metadata("design:type", String)
], CreateNotificationDto.prototype, "type", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '通知标题' }),
    (0, class_validator_1.IsNotEmpty)({ message: '通知标题不能为空' }),
    (0, class_validator_1.IsString)({ message: '通知标题必须是字符串' }),
    __metadata("design:type", String)
], CreateNotificationDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '通知内容' }),
    (0, class_validator_1.IsNotEmpty)({ message: '通知内容不能为空' }),
    (0, class_validator_1.IsString)({ message: '通知内容必须是字符串' }),
    __metadata("design:type", String)
], CreateNotificationDto.prototype, "content", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '接收者（邮箱或用户ID）', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '接收者必须是字符串' }),
    __metadata("design:type", String)
], CreateNotificationDto.prototype, "recipient", void 0);
//# sourceMappingURL=create-notification.dto.js.map