export declare class QueryTemplateDto {
    page?: number;
    pageSize?: number;
    type?: string;
}
