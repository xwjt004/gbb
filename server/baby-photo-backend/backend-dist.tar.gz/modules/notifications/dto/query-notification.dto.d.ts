export declare class QueryNotificationDto {
    page?: number;
    pageSize?: number;
    type?: string;
    status?: string;
}
