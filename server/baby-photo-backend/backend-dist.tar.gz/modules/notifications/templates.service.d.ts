import { PrismaService } from '../../shared/prisma/prisma.service';
import { CreateTemplateDto } from './dto/create-template.dto';
import { UpdateTemplateDto } from './dto/update-template.dto';
import { QueryTemplateDto } from './dto/query-template.dto';
export declare class TemplatesService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    create(dto: CreateTemplateDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            content: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            variables: string | null;
        };
    }>;
    findAll(query: QueryTemplateDto): Promise<{
        code: number;
        message: string;
        data: {
            items: {
                variables: any;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                content: string;
                type: import("@prisma/client").$Enums.NotificationType;
                title: string;
            }[];
            total: number;
            page: number;
            pageSize: number;
            totalPages: number;
        };
    }>;
    findOne(id: string): Promise<{
        code: number;
        message: string;
        data: {
            variables: any;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            content: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
        };
    }>;
    update(id: string, dto: UpdateTemplateDto): Promise<{
        code: number;
        message: string;
        data: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            content: string;
            type: import("@prisma/client").$Enums.NotificationType;
            title: string;
            variables: string | null;
        };
    }>;
    remove(id: string): Promise<{
        code: number;
        message: string;
        data: null;
    }>;
}
