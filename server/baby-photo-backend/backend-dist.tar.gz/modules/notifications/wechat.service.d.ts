import { ConfigService } from '@nestjs/config';
export declare class WechatNotificationService {
    private configService;
    private readonly logger;
    private tokenCache;
    private readonly API_BASE;
    constructor(configService: ConfigService);
    private getAccessToken;
    sendTemplateMessage(openid: string, templateId: string, data: Record<string, any>, page?: string): Promise<boolean>;
    clearTokenCache(): void;
}
