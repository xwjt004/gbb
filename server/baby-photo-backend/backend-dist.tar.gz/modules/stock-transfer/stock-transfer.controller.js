"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockTransferController = void 0;
const common_1 = require("@nestjs/common");
const stock_transfer_service_1 = require("./stock-transfer.service");
const create_transfer_dto_1 = require("./dto/create-transfer.dto");
const query_transfer_dto_1 = require("./dto/query-transfer.dto");
let StockTransferController = class StockTransferController {
    stockTransferService;
    constructor(stockTransferService) {
        this.stockTransferService = stockTransferService;
    }
    async create(createTransferDto) {
        const submitterId = 172;
        const transfer = await this.stockTransferService.create(createTransferDto, submitterId);
        return {
            success: true,
            data: transfer,
            message: '调拨单创建成功'
        };
    }
    async findAll(queryDto) {
        const result = await this.stockTransferService.findAll(queryDto);
        return {
            success: true,
            data: result
        };
    }
    async statistics(startDate, endDate) {
        const stats = await this.stockTransferService.statistics(startDate, endDate);
        return {
            success: true,
            data: stats
        };
    }
    async findOne(id) {
        const transfer = await this.stockTransferService.findOne(id);
        return {
            success: true,
            data: transfer
        };
    }
    async approve(id, approvalNote) {
        const approverId = 173;
        const transfer = await this.stockTransferService.approve(id, approverId, approvalNote);
        return {
            success: true,
            data: transfer,
            message: '调拨单审批通过'
        };
    }
    async reject(id, approvalNote) {
        const approverId = 173;
        const transfer = await this.stockTransferService.reject(id, approverId, approvalNote);
        return {
            success: true,
            data: transfer,
            message: '调拨单已拒绝'
        };
    }
    async ship(id, shippingNote) {
        const transfer = await this.stockTransferService.ship(id, shippingNote);
        return {
            success: true,
            data: transfer,
            message: '调拨单已发货'
        };
    }
    async receive(id, receivingNote) {
        const transfer = await this.stockTransferService.receive(id, receivingNote);
        return {
            success: true,
            data: transfer,
            message: '调拨单已收货'
        };
    }
    async cancel(id) {
        const transfer = await this.stockTransferService.cancel(id);
        return {
            success: true,
            data: transfer,
            message: '调拨单已取消'
        };
    }
    async remove(id) {
        const result = await this.stockTransferService.remove(id);
        return {
            success: true,
            ...result
        };
    }
};
exports.StockTransferController = StockTransferController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_transfer_dto_1.CreateTransferDto]),
    __metadata("design:returntype", Promise)
], StockTransferController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_transfer_dto_1.QueryTransferDto]),
    __metadata("design:returntype", Promise)
], StockTransferController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('statistics'),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StockTransferController.prototype, "statistics", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], StockTransferController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(':id/approve'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('approvalNote')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StockTransferController.prototype, "approve", null);
__decorate([
    (0, common_1.Post)(':id/reject'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('approvalNote')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StockTransferController.prototype, "reject", null);
__decorate([
    (0, common_1.Post)(':id/ship'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('shippingNote')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StockTransferController.prototype, "ship", null);
__decorate([
    (0, common_1.Post)(':id/receive'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('receivingNote')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], StockTransferController.prototype, "receive", null);
__decorate([
    (0, common_1.Post)(':id/cancel'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], StockTransferController.prototype, "cancel", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], StockTransferController.prototype, "remove", null);
exports.StockTransferController = StockTransferController = __decorate([
    (0, common_1.Controller)('stock-transfer'),
    __metadata("design:paramtypes", [stock_transfer_service_1.StockTransferService])
], StockTransferController);
//# sourceMappingURL=stock-transfer.controller.js.map