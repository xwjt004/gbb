export declare class StockTransferModule {
}
