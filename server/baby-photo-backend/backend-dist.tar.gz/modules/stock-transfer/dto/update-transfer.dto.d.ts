import { CreateTransferDto } from './create-transfer.dto';
declare const UpdateTransferDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateTransferDto>>;
export declare class UpdateTransferDto extends UpdateTransferDto_base {
    status?: string;
    approvalNote?: string;
    shippingNote?: string;
    receivingNote?: string;
}
export {};
