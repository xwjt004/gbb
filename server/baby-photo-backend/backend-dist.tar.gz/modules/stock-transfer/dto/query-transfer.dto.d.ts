export declare class QueryTransferDto {
    page?: number;
    pageSize?: number;
    status?: string;
    fromWarehouse?: string;
    toWarehouse?: string;
    startDate?: string;
    endDate?: string;
    productId?: number;
    submitterId?: number;
}
