export declare class CreateTransferDto {
    productId: number;
    quantity: number;
    fromWarehouse?: string;
    toWarehouse?: string;
    reason?: string;
}
