"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var StockTransferService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockTransferService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let StockTransferService = StockTransferService_1 = class StockTransferService {
    prisma;
    logger = new common_1.Logger(StockTransferService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async generateTransferNo() {
        const today = new Date();
        const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
        const count = await this.prisma.stockTransfer.count({
            where: {
                createdAt: {
                    gte: new Date(today.setHours(0, 0, 0, 0)),
                    lt: new Date(today.setHours(23, 59, 59, 999))
                }
            }
        });
        const sequence = String(count + 1).padStart(4, '0');
        return `TRF-${dateStr}-${sequence}`;
    }
    async create(createTransferDto, submitterId) {
        const { productId, quantity, fromWarehouse, toWarehouse, reason } = createTransferDto;
        const product = await this.prisma.product.findUnique({
            where: { id: productId }
        });
        if (!product) {
            throw new common_1.NotFoundException(`��ƷID ${productId} ������`);
        }
        if (fromWarehouse === toWarehouse) {
            throw new common_1.BadRequestException('Դ�ֿ��Ŀ��ֿⲻ����ͬ');
        }
        if (product.isTrackStock && product.stockQuantity < quantity) {
            throw new common_1.BadRequestException(`��Ʒ ${product.name} ��治�㣬��ǰ��棺${product.stockQuantity}������������${quantity}`);
        }
        const transferNo = await this.generateTransferNo();
        const transfer = await this.prisma.stockTransfer.create({
            data: {
                transferNo,
                productId,
                quantity,
                fromWarehouse: fromWarehouse || 'MAIN',
                toWarehouse: toWarehouse || 'BRANCH',
                reason,
                status: 'PENDING',
                submitterId,
                submittedAt: new Date()
            },
            include: {
                product: true,
                submitter: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        this.logger.log(`������������?? ${transferNo}, ��Ʒ: ${product.name}, ����: ${quantity}`);
        return transfer;
    }
    async findAll(queryTransferDto) {
        const { page = 1, pageSize = 10, status, fromWarehouse, toWarehouse, productId, submitterId, startDate, endDate } = queryTransferDto;
        const where = {};
        if (status) {
            where.status = status;
        }
        if (fromWarehouse) {
            where.fromWarehouse = fromWarehouse;
        }
        if (toWarehouse) {
            where.toWarehouse = toWarehouse;
        }
        if (productId) {
            where.productId = productId;
        }
        if (submitterId) {
            where.submitterId = submitterId;
        }
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate) {
                where.createdAt.gte = new Date(startDate);
            }
            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                where.createdAt.lte = end;
            }
        }
        const total = await this.prisma.stockTransfer.count({ where });
        const transfers = await this.prisma.stockTransfer.findMany({
            where,
            include: {
                product: {
                    select: {
                        id: true,
                        name: true,
                        productNo: true
                    }
                },
                submitter: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                approver: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            },
            orderBy: {
                createdAt: 'desc'
            },
            skip: (page - 1) * pageSize,
            take: pageSize
        });
        return {
            items: transfers,
            total,
            page,
            pageSize,
            totalPages: Math.ceil(total / pageSize)
        };
    }
    async findOne(id) {
        const transfer = await this.prisma.stockTransfer.findUnique({
            where: { id },
            include: {
                product: {
                    select: {
                        id: true,
                        name: true,
                        productNo: true,
                        stockQuantity: true
                    }
                },
                submitter: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                approver: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        if (!transfer) {
            throw new common_1.NotFoundException(`������ID ${id} ������`);
        }
        return transfer;
    }
    async approve(id, approverId, approvalNote) {
        const transfer = await this.findOne(id);
        if (transfer.status !== 'PENDING') {
            throw new common_1.BadRequestException(`������״̬Ϊ ${transfer.status}����������`);
        }
        const product = await this.prisma.product.findUnique({
            where: { id: transfer.productId }
        });
        if (!product) {
            throw new common_1.NotFoundException('��Ʒ������');
        }
        if (product.isTrackStock && product.stockQuantity < transfer.quantity) {
            throw new common_1.BadRequestException(`��Ʒ ${product.name} ��治�㣬��ǰ��棺${product.stockQuantity}������������${transfer.quantity}`);
        }
        const updatedTransfer = await this.prisma.stockTransfer.update({
            where: { id },
            data: {
                status: 'APPROVED',
                approverId,
                approvedAt: new Date(),
                approvalNote
            },
            include: {
                product: true,
                submitter: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                approver: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        this.logger.log(`����??${transfer.transferNo} ������ͨ��`);
        return updatedTransfer;
    }
    async reject(id, approverId, approvalNote) {
        const transfer = await this.findOne(id);
        if (transfer.status !== 'PENDING') {
            throw new common_1.BadRequestException(`������״̬Ϊ ${transfer.status}�����ܾܾ�`);
        }
        const updatedTransfer = await this.prisma.stockTransfer.update({
            where: { id },
            data: {
                status: 'REJECTED',
                approverId,
                approvedAt: new Date(),
                approvalNote
            },
            include: {
                product: true,
                submitter: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                approver: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        this.logger.log(`����??${transfer.transferNo} �Ѿܾ�`);
        return updatedTransfer;
    }
    async ship(id, shippingNote) {
        const transfer = await this.findOne(id);
        if (transfer.status !== 'APPROVED') {
            throw new common_1.BadRequestException(`������״̬Ϊ ${transfer.status}�����ܷ���`);
        }
        const product = await this.prisma.product.findUnique({
            where: { id: transfer.productId },
        });
        if (!product) {
            throw new common_1.NotFoundException('��Ʒ������');
        }
        if (product.isTrackStock) {
            if (product.stockQuantity < transfer.quantity) {
                throw new common_1.BadRequestException(`��Ʒ ${product.name} ��治�㣬��ǰ��棺${product.stockQuantity}������������${transfer.quantity}`);
            }
            await this.prisma.product.update({
                where: { id: transfer.productId },
                data: {
                    stockQuantity: {
                        decrement: transfer.quantity
                    }
                }
            });
            await this.createStockTransaction({
                productId: transfer.productId,
                transactionType: 'TRANSFER_OUT',
                quantity: -transfer.quantity,
                beforeStock: product.stockQuantity,
                afterStock: product.stockQuantity - transfer.quantity,
                operatorId: transfer.submitterId,
                remark: `����??${transfer.transferNo} ����`
            });
        }
        const updatedTransfer = await this.prisma.stockTransfer.update({
            where: { id },
            data: {
                status: 'IN_TRANSIT',
                shippedAt: new Date(),
                shippingNote
            },
            include: {
                product: true,
                submitter: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                approver: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        this.logger.log(`����??${transfer.transferNo} �ѷ������ۼ����?${transfer.quantity}`);
        return updatedTransfer;
    }
    async receive(id, receivingNote) {
        const transfer = await this.findOne(id);
        if (transfer.status !== 'IN_TRANSIT') {
            throw new common_1.BadRequestException(`������״̬Ϊ ${transfer.status}�������ջ�`);
        }
        const product = await this.prisma.product.findUnique({
            where: { id: transfer.productId },
        });
        if (!product) {
            throw new common_1.NotFoundException('��Ʒ������');
        }
        if (product.isTrackStock) {
            await this.prisma.product.update({
                where: { id: transfer.productId },
                data: {
                    stockQuantity: {
                        increment: transfer.quantity
                    }
                }
            });
            await this.createStockTransaction({
                productId: transfer.productId,
                transactionType: 'TRANSFER_IN',
                quantity: transfer.quantity,
                beforeStock: product.stockQuantity,
                afterStock: product.stockQuantity + transfer.quantity,
                operatorId: transfer.submitterId,
                remark: `����??${transfer.transferNo} �ջ�`
            });
        }
        const updatedTransfer = await this.prisma.stockTransfer.update({
            where: { id },
            data: {
                status: 'COMPLETED',
                receivedAt: new Date(),
                completedAt: new Date(),
                receivingNote
            },
            include: {
                product: true,
                submitter: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                approver: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        this.logger.log(`����??${transfer.transferNo} ���ջ������ӿ��?${transfer.quantity}`);
        return updatedTransfer;
    }
    async cancel(id) {
        const transfer = await this.findOne(id);
        if (!['PENDING', 'APPROVED'].includes(transfer.status)) {
            throw new common_1.BadRequestException(`������״̬Ϊ ${transfer.status}������ȡ��`);
        }
        const updatedTransfer = await this.prisma.stockTransfer.update({
            where: { id },
            data: {
                status: 'CANCELLED',
                completedAt: new Date()
            },
            include: {
                product: true,
                submitter: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                approver: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        this.logger.log(`����??${transfer.transferNo} ��ȡ��`);
        return updatedTransfer;
    }
    async remove(id) {
        const transfer = await this.findOne(id);
        if (!['COMPLETED', 'CANCELLED', 'REJECTED'].includes(transfer.status)) {
            throw new common_1.BadRequestException(`������״̬Ϊ ${transfer.status}������ɾ��`);
        }
        await this.prisma.stockTransfer.delete({
            where: { id }
        });
        this.logger.log(`����??${transfer.transferNo} ��ɾ��`);
        return { message: 'ɾ���ɹ�' };
    }
    async statistics(startDate, endDate) {
        const where = {};
        if (startDate || endDate) {
            where.createdAt = {};
            if (startDate) {
                where.createdAt.gte = new Date(startDate);
            }
            if (endDate) {
                const end = new Date(endDate);
                end.setHours(23, 59, 59, 999);
                where.createdAt.lte = end;
            }
        }
        const totalCount = await this.prisma.stockTransfer.count({ where });
        const statusStats = await this.prisma.stockTransfer.groupBy({
            by: ['status'],
            where,
            _count: {
                status: true
            }
        });
        const fromWarehouseStats = await this.prisma.stockTransfer.groupBy({
            by: ['fromWarehouse'],
            where,
            _count: {
                fromWarehouse: true
            },
            _sum: {
                quantity: true
            }
        });
        const toWarehouseStats = await this.prisma.stockTransfer.groupBy({
            by: ['toWarehouse'],
            where,
            _count: {
                toWarehouse: true
            },
            _sum: {
                quantity: true
            }
        });
        const byStatus = {};
        statusStats.forEach(stat => {
            byStatus[stat.status] = stat._count?.status;
        });
        const byFromWarehouse = {};
        fromWarehouseStats.forEach(stat => {
            byFromWarehouse[stat.fromWarehouse] = {
                count: stat._count?.fromWarehouse,
                totalQuantity: stat._sum?.quantity || 0
            };
        });
        const byToWarehouse = {};
        toWarehouseStats.forEach(stat => {
            byToWarehouse[stat.toWarehouse] = {
                count: stat._count?.toWarehouse,
                totalQuantity: stat._sum?.quantity || 0
            };
        });
        return {
            totalCount,
            pendingCount: byStatus.PENDING || 0,
            approvedCount: byStatus.APPROVED || 0,
            inTransitCount: byStatus.IN_TRANSIT || 0,
            completedCount: byStatus.COMPLETED || 0,
            rejectedCount: byStatus.REJECTED || 0,
            cancelledCount: byStatus.CANCELLED || 0,
            byStatus,
            byFromWarehouse,
            byToWarehouse
        };
    }
    async createStockTransaction(data) {
        const today = new Date();
        const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
        const count = await this.prisma.stockTransaction.count({
            where: {
                createdAt: {
                    gte: new Date(today.setHours(0, 0, 0, 0)),
                    lt: new Date(today.setHours(23, 59, 59, 999))
                }
            }
        });
        const sequence = String(count + 1).padStart(6, '0');
        const transactionNo = `TXN-${dateStr}-${sequence}`;
        return await this.prisma.stockTransaction.create({
            data: {
                transactionNo,
                productId: data.productId,
                transactionType: data.transactionType,
                quantity: data.quantity,
                beforeStock: data.beforeStock,
                afterStock: data.afterStock,
                operatorId: data.operatorId,
                remark: data.remark
            }
        });
    }
};
exports.StockTransferService = StockTransferService;
exports.StockTransferService = StockTransferService = StockTransferService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], StockTransferService);
//# sourceMappingURL=stock-transfer.service.js.map