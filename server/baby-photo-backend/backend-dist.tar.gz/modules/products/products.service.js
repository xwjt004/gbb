"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ProductsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let ProductsService = ProductsService_1 = class ProductsService {
    prisma;
    logger = new common_1.Logger(ProductsService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createDto) {
        this.logger.log(`创建商品: ${createDto.name}`);
        const existing = await this.prisma.product.findUnique({
            where: { productNo: createDto.productNo },
        });
        if (existing) {
            throw new common_1.ConflictException(`商品编号 "${createDto.productNo}" 已存在`);
        }
        const category = await this.prisma.productCategory.findUnique({
            where: { id: createDto.categoryId },
        });
        if (!category) {
            throw new common_1.NotFoundException(`分类 ID=${createDto.categoryId} 不存在`);
        }
        try {
            const product = await this.prisma.product.create({
                data: {
                    productNo: createDto.productNo,
                    name: createDto.name,
                    categoryId: createDto.categoryId,
                    brand: createDto.brand,
                    model: createDto.model,
                    specification: createDto.specification,
                    unit: createDto.unit || '件',
                    costPrice: createDto.costPrice || 0,
                    salePrice: createDto.salePrice,
                    marketPrice: createDto.marketPrice,
                    stockQuantity: createDto.stockQuantity || 0,
                    lowStock: createDto.lowStock || 10,
                    minStock: createDto.minStock,
                    maxStock: createDto.maxStock,
                    reorderPoint: createDto.reorderPoint,
                    isTrackStock: createDto.isTrackStock ?? true,
                    description: createDto.description,
                    images: createDto.images,
                    attributes: createDto.attributes,
                    status: createDto.status || 'ACTIVE',
                    isActive: createDto.isActive ?? true,
                    isFeatured: createDto.isFeatured ?? false,
                },
                include: {
                    category: true,
                },
            });
            this.logger.log(`商品创建成功: ID=${product.id}`);
            return { code: 200, message: '创建成功', data: product };
        }
        catch (error) {
            this.logger.error(`创建商品失败: ${error.message}`);
            throw error;
        }
    }
    async findAll(query) {
        const { categoryId, status, isActive, isFeatured, keyword, stockStatus, page = 1, pageSize = 20 } = query;
        const where = {};
        if (categoryId)
            where.categoryId = categoryId;
        if (status)
            where.status = status;
        if (isActive !== undefined)
            where.isActive = isActive;
        if (isFeatured !== undefined)
            where.isFeatured = isFeatured;
        if (keyword) {
            where.OR = [
                { name: { contains: keyword } },
                { productNo: { contains: keyword } },
            ];
        }
        if (stockStatus) {
            if (stockStatus === 'OUT') {
                where.stockQuantity = 0;
            }
            else if (stockStatus === 'LOW') {
                where.AND = [
                    { stockQuantity: { gt: 0 } },
                    { stockQuantity: { lte: this.prisma.product.fields.lowStock } },
                ];
            }
            else if (stockStatus === 'NORMAL') {
                where.stockQuantity = { gt: this.prisma.product.fields.lowStock };
            }
        }
        try {
            const [total, list] = await Promise.all([
                this.prisma.product.count({ where }),
                this.prisma.product.findMany({
                    where,
                    include: {
                        category: {
                            select: { id: true, name: true, code: true },
                        },
                    },
                    orderBy: { createdAt: 'desc' },
                    skip: (page - 1) * pageSize,
                    take: pageSize,
                }),
            ]);
            return {
                code: 200,
                message: '查询成功',
                data: {
                    list,
                    pagination: {
                        page,
                        pageSize,
                        total,
                        totalPages: Math.ceil(total / pageSize),
                    },
                },
            };
        }
        catch (error) {
            this.logger.error(`查询商品列表失败: ${error.message}`);
            throw error;
        }
    }
    async findOne(id) {
        try {
            const product = await this.prisma.product.findUnique({
                where: { id },
                include: {
                    category: true,
                },
            });
            if (!product) {
                throw new common_1.NotFoundException(`商品 ID=${id} 不存在`);
            }
            return { code: 200, message: '查询成功', data: product };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException)
                throw error;
            this.logger.error(`查询商品详情失败: ${error.message}`);
            throw error;
        }
    }
    async update(id, updateDto) {
        this.logger.log(`更新商品: ID=${id}`);
        this.logger.log(`更新数据: ${JSON.stringify(updateDto)}`);
        const existing = await this.prisma.product.findUnique({ where: { id } });
        if (!existing) {
            throw new common_1.NotFoundException(`商品 ID=${id} 不存在`);
        }
        if (updateDto.productNo && updateDto.productNo !== existing.productNo) {
            const duplicate = await this.prisma.product.findFirst({
                where: { productNo: updateDto.productNo, id: { not: id } },
            });
            if (duplicate) {
                throw new common_1.ConflictException(`商品编号 "${updateDto.productNo}" 已存在`);
            }
        }
        if (updateDto.categoryId && updateDto.categoryId !== existing.categoryId) {
            const category = await this.prisma.productCategory.findUnique({
                where: { id: updateDto.categoryId },
            });
            if (!category) {
                throw new common_1.NotFoundException(`分类 ID=${updateDto.categoryId} 不存在`);
            }
        }
        try {
            if (updateDto.salePrice !== undefined && Number(updateDto.salePrice) !== Number(existing.salePrice)) {
                this.logger.log(`价格变更: ID=${id}, ${existing.salePrice} → ${updateDto.salePrice}`);
            }
            if (updateDto.costPrice !== undefined && Number(updateDto.costPrice) !== Number(existing.costPrice)) {
                this.logger.log(`成本价变更: ID=${id}, ${existing.costPrice} → ${updateDto.costPrice}`);
            }
            if (updateDto.marketPrice !== undefined && Number(updateDto.marketPrice) !== Number(existing.marketPrice)) {
                this.logger.log(`市场价变更: ID=${id}, ${existing.marketPrice} → ${updateDto.marketPrice}`);
            }
            const product = await this.prisma.product.update({
                where: { id },
                data: updateDto,
                include: { category: true },
            });
            this.logger.log(`商品更新成功: ID=${id}, isActive=${product.isActive}`);
            return { code: 200, message: '更新成功', data: product };
        }
        catch (error) {
            this.logger.error(`更新商品失败: ${error.message}`);
            throw error;
        }
    }
    async remove(id) {
        this.logger.log(`删除商品: ID=${id}`);
        const existing = await this.prisma.product.findUnique({ where: { id } });
        if (!existing) {
            throw new common_1.NotFoundException(`商品 ID=${id} 不存在`);
        }
        try {
            await this.prisma.product.delete({ where: { id } });
            this.logger.log(`商品删除成功: ID=${id}`);
            return { code: 200, message: '删除成功' };
        }
        catch (error) {
            this.logger.error(`删除商品失败: ${error.message}`);
            throw error;
        }
    }
    async updateStock(id, updateDto) {
        this.logger.log(`更新库存: ID=${id}, ${updateDto.operation} ${updateDto.quantity}`);
        const product = await this.prisma.product.findUnique({ where: { id } });
        if (!product) {
            throw new common_1.NotFoundException(`商品 ID=${id} 不存在`);
        }
        let newQuantity = product.stockQuantity;
        if (updateDto.operation === 'ADD') {
            newQuantity += updateDto.quantity;
        }
        else if (updateDto.operation === 'SUBTRACT') {
            newQuantity -= updateDto.quantity;
            if (newQuantity < 0) {
                throw new common_1.BadRequestException('库存不足');
            }
        }
        else if (updateDto.operation === 'SET') {
            newQuantity = updateDto.quantity;
        }
        try {
            const updated = await this.prisma.product.update({
                where: { id },
                data: { stockQuantity: newQuantity },
            });
            this.logger.log(`库存更新成功: ID=${id}, 新库存=${newQuantity}`);
            return { code: 200, message: '库存更新成功', data: updated };
        }
        catch (error) {
            this.logger.error(`更新库存失败: ${error.message}`);
            throw error;
        }
    }
    async batchUpdateStatus(batchDto) {
        this.logger.log(`批量更新状态: ${batchDto.productIds.length} 个商品`);
        try {
            await this.prisma.product.updateMany({
                where: { id: { in: batchDto.productIds } },
                data: { status: batchDto.status },
            });
            this.logger.log('批量更新状态成功');
            return { code: 200, message: '批量更新成功' };
        }
        catch (error) {
            this.logger.error(`批量更新状态失败: ${error.message}`);
            throw error;
        }
    }
    async getStatistics() {
        try {
            const [total, active, lowStock, outOfStock] = await Promise.all([
                this.prisma.product.count(),
                this.prisma.product.count({ where: { isActive: true } }),
                this.prisma.product.count({
                    where: {
                        AND: [
                            { stockQuantity: { gt: 0 } },
                            { stockQuantity: { lte: this.prisma.product.fields.lowStock } },
                        ],
                    },
                }),
                this.prisma.product.count({ where: { stockQuantity: 0 } }),
            ]);
            return {
                code: 200,
                message: '查询成功',
                data: {
                    total,
                    active,
                    inactive: total - active,
                    lowStock,
                    outOfStock,
                },
            };
        }
        catch (error) {
            this.logger.error(`获取统计失败: ${error.message}`);
            throw error;
        }
    }
};
exports.ProductsService = ProductsService;
exports.ProductsService = ProductsService = ProductsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ProductsService);
//# sourceMappingURL=products.service.js.map