"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductBatchUpdateStatusDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class ProductBatchUpdateStatusDto {
    productIds;
    status;
}
exports.ProductBatchUpdateStatusDto = ProductBatchUpdateStatusDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品ID数组', example: [1, 2, 3] }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsNotEmpty)({ message: '商品ID数组不能为空' }),
    __metadata("design:type", Array)
], ProductBatchUpdateStatusDto.prototype, "productIds", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商品状态',
        enum: ['ACTIVE', 'INACTIVE', 'DISCONTINUED'],
        example: 'INACTIVE'
    }),
    (0, class_validator_1.IsEnum)(['ACTIVE', 'INACTIVE', 'DISCONTINUED']),
    (0, class_validator_1.IsNotEmpty)({ message: '状态不能为空' }),
    __metadata("design:type", String)
], ProductBatchUpdateStatusDto.prototype, "status", void 0);
//# sourceMappingURL=batch-update-status.dto.js.map