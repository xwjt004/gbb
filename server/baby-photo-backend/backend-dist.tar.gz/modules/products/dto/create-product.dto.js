"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateProductDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class CreateProductDto {
    productNo;
    name;
    categoryId;
    specification;
    unit;
    costPrice;
    salePrice;
    marketPrice;
    stockQuantity;
    lowStock;
    minStock;
    maxStock;
    reorderPoint;
    isTrackStock;
    description;
    detailContent;
    images;
    attributes;
    brand;
    model;
    baseSales;
    status;
    isActive;
    isFeatured;
}
exports.CreateProductDto = CreateProductDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品编号', example: 'PROD-ALBUM-8F' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: '商品编号不能为空' }),
    (0, class_validator_1.MaxLength)(50, { message: '商品编号最长50个字符' }),
    __metadata("design:type", String)
], CreateProductDto.prototype, "productNo", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品名称', example: '8寸方相册' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: '商品名称不能为空' }),
    (0, class_validator_1.MaxLength)(100, { message: '商品名称最长100个字符' }),
    __metadata("design:type", String)
], CreateProductDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '分类ID', example: 1 }),
    (0, class_validator_1.IsInt)({ message: '分类ID必须是整数' }),
    (0, class_validator_1.IsNotEmpty)({ message: '分类ID不能为空' }),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "categoryId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '规格', example: '8寸', required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], CreateProductDto.prototype, "specification", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '单位', example: '本', required: false, default: '件' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.MaxLength)(20),
    __metadata("design:type", String)
], CreateProductDto.prototype, "unit", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '成本价', example: 50.00, required: false, default: 0 }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "costPrice", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '销售价', example: 150.00 }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsNotEmpty)({ message: '销售价不能为空' }),
    (0, class_validator_1.Min)(0),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "salePrice", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '市场价', example: 200.00, required: false }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "marketPrice", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '库存数量', example: 100, required: false, default: 0 }),
    (0, class_validator_1.IsInt)({ message: '库存数量必须是整数' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "stockQuantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '低库存预警值', example: 10, required: false, default: 10 }),
    (0, class_validator_1.IsInt)({ message: '低库存预警值必须是整数' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "lowStock", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '最低库存', example: 5, required: false }),
    (0, class_validator_1.IsInt)({ message: '最低库存必须是整数' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "minStock", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '最高库存', example: 1000, required: false }),
    (0, class_validator_1.IsInt)({ message: '最高库存必须是整数' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "maxStock", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '再订货点', example: 20, required: false }),
    (0, class_validator_1.IsInt)({ message: '再订货点必须是整数' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "reorderPoint", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否追踪库存', example: true, required: false, default: true }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], CreateProductDto.prototype, "isTrackStock", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品描述', required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateProductDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商品详情富文本内容',
        required: false,
        example: {
            blocks: [
                { type: 'text', content: '<p>商品介绍</p>' },
                { type: 'image', url: 'https://...', caption: '图片说明' },
                { type: 'video', url: 'https://...', poster: 'https://...', caption: '视频说明' }
            ]
        }
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], CreateProductDto.prototype, "detailContent", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品图片数组', required: false, example: ['image1.jpg', 'image2.jpg'] }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], CreateProductDto.prototype, "images", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '扩展属性', required: false, example: { material: 'PU皮', pages: 20 } }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], CreateProductDto.prototype, "attributes", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '品牌', required: false, example: 'Canon' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.MaxLength)(50),
    __metadata("design:type", String)
], CreateProductDto.prototype, "brand", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '型号', required: false, example: 'EOS R5' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.MaxLength)(50),
    __metadata("design:type", String)
], CreateProductDto.prototype, "model", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '基础销量（营销展示用）', example: 100, required: false, default: 0 }),
    (0, class_validator_1.IsInt)({ message: '基础销量必须是整数' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateProductDto.prototype, "baseSales", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商品状态',
        example: 'ACTIVE',
        enum: ['ACTIVE', 'INACTIVE', 'DISCONTINUED'],
        required: false,
        default: 'ACTIVE'
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['ACTIVE', 'INACTIVE', 'DISCONTINUED']),
    __metadata("design:type", String)
], CreateProductDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否启用', example: true, required: false, default: true }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], CreateProductDto.prototype, "isActive", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否推荐', example: false, required: false, default: false }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], CreateProductDto.prototype, "isFeatured", void 0);
//# sourceMappingURL=create-product.dto.js.map