export declare class QueryProductDto {
    categoryId?: number;
    status?: string;
    isActive?: boolean;
    isFeatured?: boolean;
    keyword?: string;
    stockStatus?: string;
    page?: number;
    pageSize?: number;
}
