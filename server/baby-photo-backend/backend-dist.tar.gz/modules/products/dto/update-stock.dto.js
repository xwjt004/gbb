"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateStockDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class UpdateStockDto {
    quantity;
    operation;
}
exports.UpdateStockDto = UpdateStockDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '数量', example: 50 }),
    (0, class_validator_1.IsInt)({ message: '数量必须是整数' }),
    (0, class_validator_1.IsNotEmpty)({ message: '数量不能为空' }),
    (0, class_validator_1.Min)(0),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], UpdateStockDto.prototype, "quantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '操作类型',
        enum: ['ADD', 'SUBTRACT', 'SET'],
        example: 'ADD'
    }),
    (0, class_validator_1.IsEnum)(['ADD', 'SUBTRACT', 'SET']),
    (0, class_validator_1.IsNotEmpty)({ message: '操作类型不能为空' }),
    __metadata("design:type", String)
], UpdateStockDto.prototype, "operation", void 0);
//# sourceMappingURL=update-stock.dto.js.map