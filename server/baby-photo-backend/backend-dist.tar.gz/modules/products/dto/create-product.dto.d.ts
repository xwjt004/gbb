export declare class CreateProductDto {
    productNo: string;
    name: string;
    categoryId: number;
    specification?: string;
    unit?: string;
    costPrice?: number;
    salePrice: number;
    marketPrice?: number;
    stockQuantity?: number;
    lowStock?: number;
    minStock?: number;
    maxStock?: number;
    reorderPoint?: number;
    isTrackStock?: boolean;
    description?: string;
    detailContent?: any;
    images?: any;
    attributes?: any;
    brand?: string;
    model?: string;
    baseSales?: number;
    status?: string;
    isActive?: boolean;
    isFeatured?: boolean;
}
