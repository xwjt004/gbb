export declare class UpdateStockDto {
    quantity: number;
    operation: 'ADD' | 'SUBTRACT' | 'SET';
}
