export declare class ProductBatchUpdateStatusDto {
    productIds: number[];
    status: string;
}
