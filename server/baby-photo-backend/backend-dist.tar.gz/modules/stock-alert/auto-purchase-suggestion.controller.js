"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoPurchaseSuggestionController = void 0;
const common_1 = require("@nestjs/common");
const auto_purchase_suggestion_service_1 = require("./auto-purchase-suggestion.service");
let AutoPurchaseSuggestionController = class AutoPurchaseSuggestionController {
    service;
    constructor(service) {
        this.service = service;
    }
    findAll(page, pageSize, status) {
        return this.service.findAll(page, pageSize, status);
    }
    markIgnored(id) {
        return this.service.markIgnored(id);
    }
    convertToPO(id, supplierId) {
        return this.service.convertToPurchaseOrder(id, supplierId);
    }
};
exports.AutoPurchaseSuggestionController = AutoPurchaseSuggestionController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('page', new common_1.DefaultValuePipe(1), common_1.ParseIntPipe)),
    __param(1, (0, common_1.Query)('pageSize', new common_1.DefaultValuePipe(20), common_1.ParseIntPipe)),
    __param(2, (0, common_1.Query)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, String]),
    __metadata("design:returntype", void 0)
], AutoPurchaseSuggestionController.prototype, "findAll", null);
__decorate([
    (0, common_1.Post)(':id/ignore'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], AutoPurchaseSuggestionController.prototype, "markIgnored", null);
__decorate([
    (0, common_1.Post)(':id/convert'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('supplierId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], AutoPurchaseSuggestionController.prototype, "convertToPO", null);
exports.AutoPurchaseSuggestionController = AutoPurchaseSuggestionController = __decorate([
    (0, common_1.Controller)('auto-purchase-suggestions'),
    __metadata("design:paramtypes", [auto_purchase_suggestion_service_1.AutoPurchaseSuggestionService])
], AutoPurchaseSuggestionController);
//# sourceMappingURL=auto-purchase-suggestion.controller.js.map