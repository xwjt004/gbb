export declare class CreateAlertDto {
    productId: number;
    alertType: string;
    currentStock: number;
    threshold: number;
    priority?: string;
}
