"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateAlertDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class CreateAlertDto {
    productId;
    alertType;
    currentStock;
    threshold;
    priority = 'MEDIUM';
}
exports.CreateAlertDto = CreateAlertDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品ID', example: 1 }),
    (0, class_validator_1.IsNotEmpty)({ message: '商品ID不能为空' }),
    (0, class_validator_1.IsInt)({ message: '商品ID必须是整数' }),
    (0, class_validator_1.Min)(1, { message: '商品ID必须大于0' }),
    __metadata("design:type", Number)
], CreateAlertDto.prototype, "productId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '预警类型',
        enum: ['LOW_STOCK', 'HIGH_STOCK', 'OUT_OF_STOCK'],
        example: 'LOW_STOCK'
    }),
    (0, class_validator_1.IsNotEmpty)({ message: '预警类型不能为空' }),
    (0, class_validator_1.IsString)({ message: '预警类型必须是字符串' }),
    __metadata("design:type", String)
], CreateAlertDto.prototype, "alertType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '当前库存', example: 5 }),
    (0, class_validator_1.IsNotEmpty)({ message: '当前库存不能为空' }),
    (0, class_validator_1.IsInt)({ message: '当前库存必须是整数' }),
    (0, class_validator_1.Min)(0, { message: '当前库存不能为负数' }),
    __metadata("design:type", Number)
], CreateAlertDto.prototype, "currentStock", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '预警阈值', example: 10 }),
    (0, class_validator_1.IsNotEmpty)({ message: '预警阈值不能为空' }),
    (0, class_validator_1.IsInt)({ message: '预警阈值必须是整数' }),
    (0, class_validator_1.Min)(0, { message: '预警阈值不能为负数' }),
    __metadata("design:type", Number)
], CreateAlertDto.prototype, "threshold", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '优先级',
        enum: ['HIGH', 'MEDIUM', 'LOW'],
        example: 'MEDIUM',
        required: false,
        default: 'MEDIUM'
    }),
    (0, class_validator_1.IsString)({ message: '优先级必须是字符串' }),
    __metadata("design:type", String)
], CreateAlertDto.prototype, "priority", void 0);
//# sourceMappingURL=create-alert.dto.js.map