export declare class UpdateAlertDto {
    status?: string;
    priority?: string;
    handleNote?: string;
}
