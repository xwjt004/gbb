export declare class QueryAlertDto {
    page?: number;
    pageSize?: number;
    status?: string;
    alertType?: string;
    priority?: string;
    startDate?: string;
    endDate?: string;
    productId?: number;
    alertNo?: string;
}
