"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateAlertDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class UpdateAlertDto {
    status;
    priority;
    handleNote;
}
exports.UpdateAlertDto = UpdateAlertDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '预警状态',
        enum: ['PENDING', 'PROCESSING', 'RESOLVED', 'IGNORED'],
        example: 'RESOLVED',
        required: false
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['PENDING', 'PROCESSING', 'RESOLVED', 'IGNORED'], {
        message: '状态必须是 PENDING, PROCESSING, RESOLVED 或 IGNORED'
    }),
    __metadata("design:type", String)
], UpdateAlertDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '优先级',
        enum: ['HIGH', 'MEDIUM', 'LOW'],
        example: 'HIGH',
        required: false
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['HIGH', 'MEDIUM', 'LOW'], {
        message: '优先级必须是 HIGH, MEDIUM 或 LOW'
    }),
    __metadata("design:type", String)
], UpdateAlertDto.prototype, "priority", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '处理说明', example: '已补充库存', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '处理说明必须是字符串' }),
    __metadata("design:type", String)
], UpdateAlertDto.prototype, "handleNote", void 0);
//# sourceMappingURL=update-alert.dto.js.map