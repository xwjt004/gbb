"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryAlertDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
class QueryAlertDto {
    page = 1;
    pageSize = 20;
    status;
    alertType;
    priority;
    startDate;
    endDate;
    productId;
    alertNo;
}
exports.QueryAlertDto = QueryAlertDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '页码', example: 1, required: false, default: 1 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)({ message: '页码必须是整数' }),
    (0, class_validator_1.Min)(1, { message: '页码必须大于0' }),
    __metadata("design:type", Number)
], QueryAlertDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '每页数量', example: 20, required: false, default: 20 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)({ message: '每页数量必须是整数' }),
    (0, class_validator_1.Min)(1, { message: '每页数量必须大于0' }),
    __metadata("design:type", Number)
], QueryAlertDto.prototype, "pageSize", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '预警状态',
        enum: ['PENDING', 'PROCESSING', 'RESOLVED', 'IGNORED'],
        example: 'PENDING',
        required: false
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['PENDING', 'PROCESSING', 'RESOLVED', 'IGNORED'], {
        message: '状态必须是 PENDING, PROCESSING, RESOLVED 或 IGNORED'
    }),
    __metadata("design:type", String)
], QueryAlertDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '预警类型',
        enum: ['LOW_STOCK', 'HIGH_STOCK', 'OUT_OF_STOCK'],
        example: 'LOW_STOCK',
        required: false
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['LOW_STOCK', 'HIGH_STOCK', 'OUT_OF_STOCK'], {
        message: '类型必须是 LOW_STOCK, HIGH_STOCK 或 OUT_OF_STOCK'
    }),
    __metadata("design:type", String)
], QueryAlertDto.prototype, "alertType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '优先级',
        enum: ['HIGH', 'MEDIUM', 'LOW'],
        example: 'HIGH',
        required: false
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['HIGH', 'MEDIUM', 'LOW'], {
        message: '优先级必须是 HIGH, MEDIUM 或 LOW'
    }),
    __metadata("design:type", String)
], QueryAlertDto.prototype, "priority", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '开始日期', example: '2025-11-01', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)({}, { message: '开始日期格式不正确' }),
    __metadata("design:type", String)
], QueryAlertDto.prototype, "startDate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '结束日期', example: '2025-11-30', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)({}, { message: '结束日期格式不正确' }),
    __metadata("design:type", String)
], QueryAlertDto.prototype, "endDate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品ID', example: 1, required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)({ message: '商品ID必须是整数' }),
    (0, class_validator_1.Min)(1, { message: '商品ID必须大于0' }),
    __metadata("design:type", Number)
], QueryAlertDto.prototype, "productId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '预警编号（模糊查询）', example: 'ALT-20251105', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '预警编号必须是字符串' }),
    __metadata("design:type", String)
], QueryAlertDto.prototype, "alertNo", void 0);
//# sourceMappingURL=query-alert.dto.js.map