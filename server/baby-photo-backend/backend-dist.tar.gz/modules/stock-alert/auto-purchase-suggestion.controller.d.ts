import { AutoPurchaseSuggestionService } from './auto-purchase-suggestion.service';
export declare class AutoPurchaseSuggestionController {
    private readonly service;
    constructor(service: AutoPurchaseSuggestionService);
    findAll(page: number, pageSize: number, status?: string): Promise<{
        code: number;
        message: string;
        data: {
            items: ({
                product: {
                    id: number;
                    name: string;
                    unit: string;
                };
            } & {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                status: string;
                productId: number;
                minStock: number;
                currentStock: number;
                productName: string;
                suggestedQty: number;
            })[];
            pagination: {
                page: number;
                pageSize: number;
                total: number;
                totalPages: number;
            };
        };
    }>;
    markIgnored(id: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        productId: number;
        minStock: number;
        currentStock: number;
        productName: string;
        suggestedQty: number;
    }>;
    convertToPO(id: string, supplierId: string): Promise<{
        code: number;
        message: string;
        data: {
            supplier: {
                id: string;
                name: string;
                supplierNo: string;
                contactPerson: string;
                contactPhone: string;
            };
            items: ({
                product: {
                    id: number;
                    name: string;
                    description: string | null;
                    images: import("@prisma/client/runtime/library").JsonValue;
                    categoryId: number;
                    specification: string | null;
                    productNo: string;
                    unit: string;
                    costPrice: import("@prisma/client/runtime/library").Decimal;
                    salePrice: import("@prisma/client/runtime/library").Decimal;
                    brand: string | null;
                    model: string | null;
                } | null;
            } & {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                description: string | null;
                images: string[];
                productId: number | null;
                specification: string | null;
                quantity: number;
                unitPrice: import("@prisma/client/runtime/library").Decimal;
                totalPrice: import("@prisma/client/runtime/library").Decimal;
                productNo: string;
                unit: string;
                costPrice: import("@prisma/client/runtime/library").Decimal | null;
                salePrice: import("@prisma/client/runtime/library").Decimal | null;
                brand: string | null;
                model: string | null;
                remark: string | null;
                receivedQuantity: number;
                qualifiedQuantity: number;
                defectiveQuantity: number;
                barcode: string | null;
                productCategoryId: number | null;
                productName: string;
                purchaseOrderId: string;
            })[];
        } & {
            id: string;
            totalAmount: import("@prisma/client/runtime/library").Decimal;
            createdAt: Date;
            updatedAt: Date;
            discountAmount: import("@prisma/client/runtime/library").Decimal;
            status: string;
            approvedAt: Date | null;
            rejectReason: string | null;
            remark: string | null;
            supplierId: string;
            purchaseDate: Date;
            expectedDate: Date;
            purchaseNo: string;
            shippingStatus: string;
            actualDate: Date | null;
            totalQuantity: number;
            shippingFee: import("@prisma/client/runtime/library").Decimal;
            finalAmount: import("@prisma/client/runtime/library").Decimal;
            shippingCompany: string | null;
            trackingNo: string | null;
            submitterId: number | null;
            submittedAt: Date | null;
            approverId: number | null;
            receiverId: number | null;
            receivedAt: Date | null;
            receivedQuantity: number | null;
            qualityCheckStatus: string | null;
            qualityCheckRemark: string | null;
            createdBy: number | null;
        };
    }>;
}
