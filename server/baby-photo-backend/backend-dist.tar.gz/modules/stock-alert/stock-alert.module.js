"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockAlertModule = void 0;
const common_1 = require("@nestjs/common");
const stock_alert_service_1 = require("./stock-alert.service");
const stock_alert_controller_1 = require("./stock-alert.controller");
const auto_purchase_suggestion_service_1 = require("./auto-purchase-suggestion.service");
const auto_purchase_suggestion_controller_1 = require("./auto-purchase-suggestion.controller");
const prisma_module_1 = require("../../shared/prisma/prisma.module");
const supplier_module_1 = require("../../supplier/supplier.module");
let StockAlertModule = class StockAlertModule {
};
exports.StockAlertModule = StockAlertModule;
exports.StockAlertModule = StockAlertModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule, supplier_module_1.SupplierModule],
        controllers: [stock_alert_controller_1.StockAlertController, auto_purchase_suggestion_controller_1.AutoPurchaseSuggestionController],
        providers: [stock_alert_service_1.StockAlertService, auto_purchase_suggestion_service_1.AutoPurchaseSuggestionService],
        exports: [stock_alert_service_1.StockAlertService, auto_purchase_suggestion_service_1.AutoPurchaseSuggestionService],
    })
], StockAlertModule);
//# sourceMappingURL=stock-alert.module.js.map