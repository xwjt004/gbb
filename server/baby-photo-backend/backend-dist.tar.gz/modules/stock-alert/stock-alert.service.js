"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var StockAlertService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockAlertService = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const auto_purchase_suggestion_service_1 = require("./auto-purchase-suggestion.service");
let StockAlertService = StockAlertService_1 = class StockAlertService {
    prisma;
    autoPurchaseSuggestionService;
    logger = new common_1.Logger(StockAlertService_1.name);
    constructor(prisma, autoPurchaseSuggestionService) {
        this.prisma = prisma;
        this.autoPurchaseSuggestionService = autoPurchaseSuggestionService;
    }
    async generateAlertNo() {
        const today = new Date();
        const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
        const count = await this.prisma.stockAlert.count({
            where: {
                createdAt: {
                    gte: new Date(today.setHours(0, 0, 0, 0)),
                    lt: new Date(today.setHours(23, 59, 59, 999))
                }
            }
        });
        const sequence = String(count + 1).padStart(4, '0');
        return `ALT-${dateStr}-${sequence}`;
    }
    determinePriority(alertType, currentStock, threshold) {
        if (alertType === 'OUT_OF_STOCK') {
            return 'HIGH';
        }
        if (alertType === 'LOW_STOCK') {
            const ratio = currentStock / threshold;
            if (ratio <= 0.3) {
                return 'HIGH';
            }
            else if (ratio <= 0.7) {
                return 'MEDIUM';
            }
            else {
                return 'LOW';
            }
        }
        if (alertType === 'HIGH_STOCK') {
            const ratio = currentStock / threshold;
            if (ratio >= 2.0) {
                return 'HIGH';
            }
            else if (ratio >= 1.5) {
                return 'MEDIUM';
            }
            else {
                return 'LOW';
            }
        }
        return 'MEDIUM';
    }
    async autoCheckStockAlerts() {
        this.logger.log('开始自动检测库存预警...');
        try {
            const products = await this.prisma.product.findMany({
                where: {
                    isActive: true,
                    isTrackStock: true
                }
            });
            let alertCount = 0;
            for (const product of products) {
                if (product.stockQuantity === 0) {
                    const exists = await this.checkAlertExists(product.id, 'OUT_OF_STOCK');
                    if (!exists) {
                        await this.createAlert({
                            productId: product.id,
                            alertType: 'OUT_OF_STOCK',
                            currentStock: 0,
                            threshold: product.lowStock,
                            priority: 'HIGH'
                        });
                        alertCount++;
                        this.logger.warn(`商品 ${product.name} (ID: ${product.id}) 已缺货`);
                    }
                }
                else if (product.stockQuantity <= product.lowStock) {
                    const exists = await this.checkAlertExists(product.id, 'LOW_STOCK');
                    if (!exists) {
                        const priority = this.determinePriority('LOW_STOCK', product.stockQuantity, product.lowStock);
                        await this.createAlert({
                            productId: product.id,
                            alertType: 'LOW_STOCK',
                            currentStock: product.stockQuantity,
                            threshold: product.lowStock,
                            priority
                        });
                        alertCount++;
                        this.logger.warn(`商品 ${product.name} (ID: ${product.id}) 库存低于预警值`);
                        await this.autoPurchaseSuggestionService.createIfNotExists({
                            productId: product.id,
                            productName: product.name,
                            currentStock: product.stockQuantity,
                            minStock: product.lowStock,
                            suggestedQty: product.reorderPoint || product.lowStock * 2,
                        });
                    }
                }
                else if (product.maxStock && product.stockQuantity >= product.maxStock) {
                    const exists = await this.checkAlertExists(product.id, 'HIGH_STOCK');
                    if (!exists) {
                        const priority = this.determinePriority('HIGH_STOCK', product.stockQuantity, product.maxStock);
                        await this.createAlert({
                            productId: product.id,
                            alertType: 'HIGH_STOCK',
                            currentStock: product.stockQuantity,
                            threshold: product.maxStock,
                            priority
                        });
                        alertCount++;
                        this.logger.warn(`商品 ${product.name} (ID: ${product.id}) 库存超过最大值`);
                    }
                }
                else {
                    await this.autoResolveAlerts(product.id);
                }
            }
            this.logger.log(`库存预警检测完成，新增 ${alertCount} 条预警`);
            return { alertCount, totalProducts: products.length };
        }
        catch (error) {
            this.logger.error('自动检测库存预警失败', error);
            throw error;
        }
    }
    async checkAlertExists(productId, alertType) {
        const count = await this.prisma.stockAlert.count({
            where: {
                productId,
                alertType,
                status: {
                    in: ['PENDING', 'PROCESSING']
                }
            }
        });
        return count > 0;
    }
    async autoResolveAlerts(productId) {
        await this.prisma.stockAlert.updateMany({
            where: {
                productId,
                status: {
                    in: ['PENDING', 'PROCESSING']
                }
            },
            data: {
                status: 'RESOLVED',
                handleNote: '库存已恢复正常（系统自动解决）',
                handledAt: new Date()
            }
        });
    }
    async createAlert(createAlertDto) {
        const dto = createAlertDto;
        const product = await this.prisma.product.findUnique({
            where: { id: dto.productId }
        });
        if (!product) {
            throw new common_1.NotFoundException(`商品ID ${dto.productId} 不存在`);
        }
        const validTypes = ['LOW_STOCK', 'HIGH_STOCK', 'OUT_OF_STOCK'];
        if (!validTypes.includes(dto.alertType)) {
            throw new Error('无效的预警类型');
        }
        const priority = dto.priority || this.determinePriority(dto.alertType, dto.currentStock, dto.threshold);
        const alertNo = await this.generateAlertNo();
        const alert = await this.prisma.stockAlert.create({
            data: {
                alertNo,
                productId: dto.productId,
                alertType: dto.alertType,
                currentStock: dto.currentStock,
                threshold: dto.threshold,
                status: 'PENDING',
                priority,
                alertedAt: new Date()
            },
            include: {
                product: true
            }
        });
        return {
            code: 200,
            message: '创建预警记录成功',
            data: alert
        };
    }
    async findAll(query) {
        const { page = 1, pageSize = 20, status, alertType, priority, startDate, endDate, productId, alertNo, } = query;
        const skip = (page - 1) * pageSize;
        const where = {};
        if (status) {
            where.status = status;
        }
        if (alertType) {
            where.alertType = alertType;
        }
        if (priority) {
            where.priority = priority;
        }
        if (startDate || endDate) {
            where.alertedAt = {};
            if (startDate) {
                where.alertedAt.gte = new Date(startDate);
            }
            if (endDate) {
                where.alertedAt.lte = new Date(endDate);
            }
        }
        if (productId) {
            where.productId = productId;
        }
        if (alertNo) {
            where.alertNo = {
                contains: alertNo
            };
        }
        const [total, items] = await Promise.all([
            this.prisma.stockAlert.count({ where }),
            this.prisma.stockAlert.findMany({
                where,
                skip,
                take: pageSize,
                orderBy: [
                    { priority: 'desc' },
                    { alertedAt: 'desc' }
                ],
                include: {
                    product: true,
                    handler: {
                        select: {
                            id: true,
                            nickname: true
                        }
                    }
                }
            })
        ]);
        return {
            code: 200,
            message: '查询预警列表成功',
            data: {
                items,
                total,
                page,
                pageSize,
                totalPages: Math.ceil(total / pageSize)
            }
        };
    }
    async findOne(id) {
        const alert = await this.prisma.stockAlert.findUnique({
            where: { id },
            include: {
                product: true,
                handler: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        if (!alert) {
            throw new common_1.NotFoundException('预警记录不存在');
        }
        return {
            code: 200,
            message: '查询预警详情成功',
            data: alert
        };
    }
    async handle(id, userId, updateAlertDto) {
        const dto = updateAlertDto;
        let validUserId = userId;
        if (userId) {
            const user = await this.prisma.user.findUnique({ where: { id: userId } });
            if (!user) {
                const tempUser = await this.prisma.user.create({
                    data: {
                        openid: 'admin_temp_' + Date.now(),
                        nickname: '系统管理员',
                        phone: '13800138000',
                        status: 'ACTIVE'
                    }
                });
                validUserId = tempUser.id;
            }
        }
        const alert = await this.prisma.stockAlert.findUnique({
            where: { id }
        });
        if (!alert) {
            throw new common_1.NotFoundException('预警记录不存在');
        }
        const updateData = {};
        if (dto.status) {
            updateData.status = dto.status;
            updateData.handlerId = validUserId;
            updateData.handledAt = new Date();
        }
        if (dto.priority) {
            updateData.priority = dto.priority;
        }
        if (dto.handleNote) {
            updateData.handleNote = dto.handleNote;
        }
        const updated = await this.prisma.stockAlert.update({
            where: { id },
            data: updateData,
            include: {
                product: true,
                handler: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        return {
            code: 200,
            message: '处理预警成功',
            data: updated
        };
    }
    async remove(id) {
        const alert = await this.prisma.stockAlert.findUnique({
            where: { id }
        });
        if (!alert) {
            throw new common_1.NotFoundException('预警记录不存在');
        }
        await this.prisma.stockAlert.delete({
            where: { id }
        });
        return {
            code: 200,
            message: '删除预警记录成功',
            data: null
        };
    }
    async statistics(startDate, endDate) {
        const where = {};
        if (startDate || endDate) {
            where.alertedAt = {};
            if (startDate) {
                where.alertedAt.gte = new Date(startDate);
            }
            if (endDate) {
                where.alertedAt.lte = new Date(endDate);
            }
        }
        const [totalCount, alerts] = await Promise.all([
            this.prisma.stockAlert.count({ where }),
            this.prisma.stockAlert.findMany({
                where,
                select: {
                    status: true,
                    alertType: true,
                    priority: true
                }
            })
        ]);
        const byStatus = alerts.reduce((acc, alert) => {
            if (!acc[alert.status]) {
                acc[alert.status] = 0;
            }
            acc[alert.status] += 1;
            return acc;
        }, {});
        const byType = alerts.reduce((acc, alert) => {
            if (!acc[alert.alertType]) {
                acc[alert.alertType] = 0;
            }
            acc[alert.alertType] += 1;
            return acc;
        }, {});
        const byPriority = alerts.reduce((acc, alert) => {
            if (!acc[alert.priority]) {
                acc[alert.priority] = 0;
            }
            acc[alert.priority] += 1;
            return acc;
        }, {});
        const pendingCount = alerts.filter(a => a.status === 'PENDING').length;
        return {
            code: 200,
            message: '查询预警统计成功',
            data: {
                totalCount,
                pendingCount,
                byStatus,
                byType,
                byPriority
            }
        };
    }
    async manualCheck() {
        return await this.autoCheckStockAlerts();
    }
};
exports.StockAlertService = StockAlertService;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_HOUR),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StockAlertService.prototype, "autoCheckStockAlerts", null);
exports.StockAlertService = StockAlertService = StockAlertService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        auto_purchase_suggestion_service_1.AutoPurchaseSuggestionService])
], StockAlertService);
//# sourceMappingURL=stock-alert.service.js.map