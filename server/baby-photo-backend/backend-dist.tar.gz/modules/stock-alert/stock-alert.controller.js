"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockAlertController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const stock_alert_service_1 = require("./stock-alert.service");
const create_alert_dto_1 = require("./dto/create-alert.dto");
const update_alert_dto_1 = require("./dto/update-alert.dto");
const query_alert_dto_1 = require("./dto/query-alert.dto");
let StockAlertController = class StockAlertController {
    stockAlertService;
    constructor(stockAlertService) {
        this.stockAlertService = stockAlertService;
    }
    create(createAlertDto) {
        return this.stockAlertService.createAlert(createAlertDto);
    }
    findAll(query) {
        return this.stockAlertService.findAll(query);
    }
    statistics(startDate, endDate) {
        return this.stockAlertService.statistics(startDate, endDate);
    }
    manualCheck() {
        return this.stockAlertService.manualCheck();
    }
    findOne(id) {
        return this.stockAlertService.findOne(id);
    }
    handle(id, updateAlertDto) {
        const userId = 1;
        return this.stockAlertService.handle(id, userId, updateAlertDto);
    }
    remove(id) {
        return this.stockAlertService.remove(id);
    }
};
exports.StockAlertController = StockAlertController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建预警记录（通常由系统自动创建）' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '参数错误' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_alert_dto_1.CreateAlertDto]),
    __metadata("design:returntype", void 0)
], StockAlertController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '查询预警列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_alert_dto_1.QueryAlertDto]),
    __metadata("design:returntype", void 0)
], StockAlertController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('statistics'),
    (0, swagger_1.ApiOperation)({ summary: '预警统计' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '统计成功' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], StockAlertController.prototype, "statistics", null);
__decorate([
    (0, common_1.Post)('check'),
    (0, swagger_1.ApiOperation)({ summary: '手动触发预警检测' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '检测成功' }),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], StockAlertController.prototype, "manualCheck", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '查询预警详情' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '预警记录不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], StockAlertController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '处理预警' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '处理成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '预警记录不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_alert_dto_1.UpdateAlertDto]),
    __metadata("design:returntype", void 0)
], StockAlertController.prototype, "handle", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除预警记录' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '删除成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '预警记录不存在' }),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], StockAlertController.prototype, "remove", null);
exports.StockAlertController = StockAlertController = __decorate([
    (0, swagger_1.ApiTags)('库存管理 - 预警管理'),
    (0, common_1.Controller)('stock-alert'),
    __metadata("design:paramtypes", [stock_alert_service_1.StockAlertService])
], StockAlertController);
//# sourceMappingURL=stock-alert.controller.js.map