"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AutoPurchaseSuggestionService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoPurchaseSuggestionService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const purchase_order_service_1 = require("../../supplier/purchase-order.service");
let AutoPurchaseSuggestionService = AutoPurchaseSuggestionService_1 = class AutoPurchaseSuggestionService {
    prisma;
    purchaseOrderService;
    logger = new common_1.Logger(AutoPurchaseSuggestionService_1.name);
    constructor(prisma, purchaseOrderService) {
        this.prisma = prisma;
        this.purchaseOrderService = purchaseOrderService;
    }
    async createIfNotExists(dto) {
        const existing = await this.prisma.autoPurchaseSuggestion.findFirst({
            where: { productId: dto.productId, status: 'PENDING' },
        });
        if (existing)
            return existing;
        return this.prisma.autoPurchaseSuggestion.create({ data: dto });
    }
    async findAll(page = 1, pageSize = 20, status) {
        const where = {};
        if (status)
            where.status = status;
        const skip = (page - 1) * pageSize;
        const [items, total] = await Promise.all([
            this.prisma.autoPurchaseSuggestion.findMany({
                where,
                skip,
                take: pageSize,
                orderBy: { createdAt: 'desc' },
                include: { product: { select: { id: true, name: true, unit: true } } },
            }),
            this.prisma.autoPurchaseSuggestion.count({ where }),
        ]);
        return {
            code: 200,
            message: '查询成功',
            data: {
                items,
                pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
            },
        };
    }
    async markIgnored(id) {
        const suggestion = await this.prisma.autoPurchaseSuggestion.findUnique({ where: { id } });
        if (!suggestion)
            throw new common_1.NotFoundException('采购建议不存在');
        if (suggestion.status !== 'PENDING')
            throw new common_1.BadRequestException('只能忽略待处理的建议');
        return this.prisma.autoPurchaseSuggestion.update({
            where: { id },
            data: { status: 'IGNORED' },
        });
    }
    async convertToPurchaseOrder(id, supplierId) {
        const suggestion = await this.prisma.autoPurchaseSuggestion.findUnique({
            where: { id },
            include: { product: true },
        });
        if (!suggestion)
            throw new common_1.NotFoundException('采购建议不存在');
        if (suggestion.status !== 'PENDING')
            throw new common_1.BadRequestException('只能转换待处理的建议');
        const today = new Date().toISOString().slice(0, 10);
        const result = await this.purchaseOrderService.create({
            supplierId,
            purchaseDate: today,
            items: [
                {
                    productId: suggestion.productId,
                    quantity: suggestion.suggestedQty,
                    unitPrice: Number(suggestion.product.costPrice) || 0,
                },
            ],
            remark: `系统自动生成：库存低于预警值 (当前:${suggestion.currentStock}, 预警:${suggestion.minStock})`,
        });
        await this.prisma.autoPurchaseSuggestion.update({
            where: { id },
            data: { status: 'CONVERTED' },
        });
        return result;
    }
};
exports.AutoPurchaseSuggestionService = AutoPurchaseSuggestionService;
exports.AutoPurchaseSuggestionService = AutoPurchaseSuggestionService = AutoPurchaseSuggestionService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        purchase_order_service_1.PurchaseOrderService])
], AutoPurchaseSuggestionService);
//# sourceMappingURL=auto-purchase-suggestion.service.js.map