export declare class StockAlertModule {
}
