"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockCheckController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const stock_check_service_1 = require("./stock-check.service");
const create_check_dto_1 = require("./dto/create-check.dto");
const update_check_dto_1 = require("./dto/update-check.dto");
const approve_check_dto_1 = require("./dto/approve-check.dto");
const query_check_dto_1 = require("./dto/query-check.dto");
let StockCheckController = class StockCheckController {
    stockCheckService;
    constructor(stockCheckService) {
        this.stockCheckService = stockCheckService;
    }
    create(createCheckDto) {
        const userId = 1;
        return this.stockCheckService.create(userId, createCheckDto);
    }
    findAll(query) {
        return this.stockCheckService.findAll(query);
    }
    statistics(startDate, endDate) {
        return this.stockCheckService.statistics(startDate, endDate);
    }
    findOne(id) {
        return this.stockCheckService.findOne(id);
    }
    update(id, updateCheckDto) {
        return this.stockCheckService.update(id, updateCheckDto);
    }
    remove(id) {
        return this.stockCheckService.remove(id);
    }
    approve(id, approveDto) {
        const userId = 1;
        return this.stockCheckService.approve(id, userId, approveDto.approved, approveDto.note, approveDto.autoAdjust !== false);
    }
};
exports.StockCheckController = StockCheckController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建盘点单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '参数错误' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_check_dto_1.CreateCheckDto]),
    __metadata("design:returntype", void 0)
], StockCheckController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '查询盘点单列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_check_dto_1.QueryCheckDto]),
    __metadata("design:returntype", void 0)
], StockCheckController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('statistics'),
    (0, swagger_1.ApiOperation)({ summary: '盘点统计' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '统计成功' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], StockCheckController.prototype, "statistics", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '查询盘点单详情' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '查询成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '盘点单不存在' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], StockCheckController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新盘点单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '盘点单不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '只能修改待审批状态的盘点单' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_check_dto_1.UpdateCheckDto]),
    __metadata("design:returntype", void 0)
], StockCheckController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除盘点单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '删除成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '盘点单不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '只能删除待审批状态的盘点单' }),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], StockCheckController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)(':id/approve'),
    (0, swagger_1.ApiOperation)({ summary: '审批盘点单' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '审批成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '盘点单不存在' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: '该盘点单已审批' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, approve_check_dto_1.ApproveCheckDto]),
    __metadata("design:returntype", void 0)
], StockCheckController.prototype, "approve", null);
exports.StockCheckController = StockCheckController = __decorate([
    (0, swagger_1.ApiTags)('库存管理 - 盘点管理'),
    (0, common_1.Controller)('stock-check'),
    __metadata("design:paramtypes", [stock_check_service_1.StockCheckService])
], StockCheckController);
//# sourceMappingURL=stock-check.controller.js.map