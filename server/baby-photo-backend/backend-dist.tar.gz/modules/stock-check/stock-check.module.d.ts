export declare class StockCheckModule {
}
