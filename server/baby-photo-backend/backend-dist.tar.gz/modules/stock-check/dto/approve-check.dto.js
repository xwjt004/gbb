"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApproveCheckDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class ApproveCheckDto {
    approved;
    note;
    autoAdjust;
}
exports.ApproveCheckDto = ApproveCheckDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否批准', example: true }),
    (0, class_validator_1.IsNotEmpty)({ message: '是否批准不能为空' }),
    (0, class_validator_1.IsBoolean)({ message: '是否批准必须是布尔值' }),
    __metadata("design:type", Boolean)
], ApproveCheckDto.prototype, "approved", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '审批备注', example: '盘点数据准确，同意调整库存', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '审批备注必须是字符串' }),
    __metadata("design:type", String)
], ApproveCheckDto.prototype, "note", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '是否自动调整库存',
        example: true,
        default: true,
        required: false
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)({ message: '是否自动调整库存必须是布尔值' }),
    __metadata("design:type", Boolean)
], ApproveCheckDto.prototype, "autoAdjust", void 0);
//# sourceMappingURL=approve-check.dto.js.map