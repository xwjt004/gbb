"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateCheckDto = exports.UpdateCheckItemDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class UpdateCheckItemDto {
    id;
    productId;
    systemQuantity;
    actualQuantity;
    remark;
}
exports.UpdateCheckItemDto = UpdateCheckItemDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '明细项ID（更新时需要）', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '明细项ID必须是字符串' }),
    __metadata("design:type", String)
], UpdateCheckItemDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品ID', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)({ message: '商品ID必须是整数' }),
    (0, class_validator_1.Min)(1, { message: '商品ID必须大于0' }),
    __metadata("design:type", Number)
], UpdateCheckItemDto.prototype, "productId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '系统库存数量', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)({ message: '系统库存数量必须是整数' }),
    (0, class_validator_1.Min)(0, { message: '系统库存数量不能为负数' }),
    __metadata("design:type", Number)
], UpdateCheckItemDto.prototype, "systemQuantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '实际盘点数量', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)({ message: '实际盘点数量必须是整数' }),
    (0, class_validator_1.Min)(0, { message: '实际盘点数量不能为负数' }),
    __metadata("design:type", Number)
], UpdateCheckItemDto.prototype, "actualQuantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '备注', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '备注必须是字符串' }),
    __metadata("design:type", String)
], UpdateCheckItemDto.prototype, "remark", void 0);
class UpdateCheckDto {
    remark;
    items;
}
exports.UpdateCheckDto = UpdateCheckDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '备注', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '备注必须是字符串' }),
    __metadata("design:type", String)
], UpdateCheckDto.prototype, "remark", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '盘点明细（可选）', type: [UpdateCheckItemDto], required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)({ message: '盘点明细必须是数组' }),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => UpdateCheckItemDto),
    __metadata("design:type", Array)
], UpdateCheckDto.prototype, "items", void 0);
//# sourceMappingURL=update-check.dto.js.map