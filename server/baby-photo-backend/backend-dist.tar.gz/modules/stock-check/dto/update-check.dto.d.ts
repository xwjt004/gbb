export declare class UpdateCheckItemDto {
    id?: string;
    productId?: number;
    systemQuantity?: number;
    actualQuantity?: number;
    remark?: string;
}
export declare class UpdateCheckDto {
    remark?: string;
    items?: UpdateCheckItemDto[];
}
