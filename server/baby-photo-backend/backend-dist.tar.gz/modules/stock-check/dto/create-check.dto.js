"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateCheckDto = exports.CreateCheckItemDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
class CreateCheckItemDto {
    productId;
    systemQuantity;
    actualQuantity;
    remark;
}
exports.CreateCheckItemDto = CreateCheckItemDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '商品ID', example: 1 }),
    (0, class_validator_1.IsNotEmpty)({ message: '商品ID不能为空' }),
    (0, class_validator_1.IsInt)({ message: '商品ID必须是整数' }),
    (0, class_validator_1.Min)(1, { message: '商品ID必须大于0' }),
    __metadata("design:type", Number)
], CreateCheckItemDto.prototype, "productId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '系统库存数量', example: 100 }),
    (0, class_validator_1.IsNotEmpty)({ message: '系统库存数量不能为空' }),
    (0, class_validator_1.IsInt)({ message: '系统库存数量必须是整数' }),
    (0, class_validator_1.Min)(0, { message: '系统库存数量不能为负数' }),
    __metadata("design:type", Number)
], CreateCheckItemDto.prototype, "systemQuantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '实际盘点数量', example: 95, required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)({ message: '实际盘点数量必须是整数' }),
    (0, class_validator_1.Min)(0, { message: '实际盘点数量不能为负数' }),
    __metadata("design:type", Number)
], CreateCheckItemDto.prototype, "actualQuantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '备注', example: '部分商品损坏', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '备注必须是字符串' }),
    __metadata("design:type", String)
], CreateCheckItemDto.prototype, "remark", void 0);
class CreateCheckDto {
    checkDate;
    checkType;
    items;
    remark;
}
exports.CreateCheckDto = CreateCheckDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '盘点日期', example: '2025-11-05T10:00:00' }),
    (0, class_validator_1.IsNotEmpty)({ message: '盘点日期不能为空' }),
    (0, class_validator_1.IsDateString)({}, { message: '盘点日期格式不正确' }),
    __metadata("design:type", String)
], CreateCheckDto.prototype, "checkDate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '盘点类型', enum: ['FULL', 'PARTIAL', 'SPOT'], example: 'PARTIAL' }),
    (0, class_validator_1.IsNotEmpty)({ message: '盘点类型不能为空' }),
    (0, class_validator_1.IsString)({ message: '盘点类型必须是字符串' }),
    __metadata("design:type", String)
], CreateCheckDto.prototype, "checkType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '盘点明细', type: [CreateCheckItemDto] }),
    (0, class_validator_1.IsNotEmpty)({ message: '盘点明细不能为空' }),
    (0, class_validator_1.IsArray)({ message: '盘点明细必须是数组' }),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => CreateCheckItemDto),
    __metadata("design:type", Array)
], CreateCheckDto.prototype, "items", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '备注', example: '月度盘点', required: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: '备注必须是字符串' }),
    __metadata("design:type", String)
], CreateCheckDto.prototype, "remark", void 0);
//# sourceMappingURL=create-check.dto.js.map