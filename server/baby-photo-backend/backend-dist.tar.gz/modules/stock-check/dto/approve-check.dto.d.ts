export declare class ApproveCheckDto {
    approved: boolean;
    note?: string;
    autoAdjust?: boolean;
}
