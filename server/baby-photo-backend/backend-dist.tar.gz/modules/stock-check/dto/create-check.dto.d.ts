export declare class CreateCheckItemDto {
    productId: number;
    systemQuantity: number;
    actualQuantity?: number;
    remark?: string;
}
export declare class CreateCheckDto {
    checkDate: string;
    checkType: string;
    items: CreateCheckItemDto[];
    remark?: string;
}
