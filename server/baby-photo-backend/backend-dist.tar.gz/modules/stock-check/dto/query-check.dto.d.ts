export declare class QueryCheckDto {
    page?: number;
    pageSize?: number;
    status?: string;
    checkType?: string;
    startDate?: string;
    endDate?: string;
    checkNo?: string;
}
