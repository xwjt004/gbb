"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockCheckService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const library_1 = require("@prisma/client/runtime/library");
let StockCheckService = class StockCheckService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async generateCheckNo() {
        const today = new Date();
        const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
        const count = await this.prisma.stockCheck.count({
            where: {
                createdAt: {
                    gte: new Date(today.setHours(0, 0, 0, 0)),
                    lt: new Date(today.setHours(23, 59, 59, 999))
                }
            }
        });
        const sequence = String(count + 1).padStart(4, '0');
        return `CHK-${dateStr}-${sequence}`;
    }
    async generateTransactionNo() {
        const today = new Date();
        const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
        const count = await this.prisma.stockTransaction.count({
            where: {
                createdAt: {
                    gte: new Date(today.setHours(0, 0, 0, 0)),
                    lt: new Date(today.setHours(23, 59, 59, 999))
                }
            }
        });
        const sequence = String(count + 1).padStart(6, '0');
        return `TXN-${dateStr}-${sequence}`;
    }
    calculateDifference(systemQty, actualQty) {
        if (actualQty === undefined || actualQty === null) {
            return 0;
        }
        return actualQty - systemQty;
    }
    async create(userId, createCheckDto) {
        const dto = createCheckDto;
        let validUserId = userId;
        if (userId) {
            const user = await this.prisma.user.findUnique({ where: { id: userId } });
            if (!user) {
                const tempUser = await this.prisma.user.create({
                    data: {
                        openid: 'admin_temp_' + Date.now(),
                        nickname: '系统管理员',
                        phone: '13800138000',
                        status: 'ACTIVE'
                    }
                });
                validUserId = tempUser.id;
            }
        }
        const validTypes = ['FULL', 'PARTIAL', 'SPOT'];
        if (!validTypes.includes(dto.checkType)) {
            throw new common_1.BadRequestException('无效的盘点类型');
        }
        const itemsData = [];
        let profitQuantity = 0;
        let lossQuantity = 0;
        let profitItems = 0;
        let lossItems = 0;
        let profitAmount = new library_1.Decimal(0);
        let lossAmount = new library_1.Decimal(0);
        for (const item of dto.items) {
            const product = await this.prisma.product.findUnique({
                where: { id: item.productId }
            });
            if (!product) {
                throw new common_1.NotFoundException(`商品ID ${item.productId} 不存在`);
            }
            if (!product.isActive) {
                throw new common_1.BadRequestException(`商品 ${product.name} 已停用`);
            }
            const actualQty = item.actualQuantity !== undefined ? item.actualQuantity : item.systemQuantity;
            const difference = actualQty - item.systemQuantity;
            const unitPrice = product.costPrice;
            const differenceAmount = new library_1.Decimal(unitPrice).mul(Math.abs(difference));
            let differenceType = 'NORMAL';
            if (difference > 0) {
                differenceType = 'PROFIT';
                profitQuantity += difference;
                profitItems += 1;
                profitAmount = profitAmount.add(differenceAmount);
            }
            else if (difference < 0) {
                differenceType = 'LOSS';
                lossQuantity += Math.abs(difference);
                lossItems += 1;
                lossAmount = lossAmount.add(differenceAmount);
            }
            itemsData.push({
                productId: item.productId,
                systemQuantity: item.systemQuantity,
                actualQuantity: actualQty,
                differenceQty: difference,
                unitPrice,
                differenceAmount,
                differenceType,
                remark: item.remark
            });
        }
        const checkNo = await this.generateCheckNo();
        const check = await this.prisma.stockCheck.create({
            data: {
                checkNo,
                checkType: dto.checkType,
                checkDate: new Date(dto.checkDate),
                status: 'PENDING',
                totalItems: itemsData.length,
                profitItems,
                lossItems,
                profitQuantity,
                lossQuantity,
                profitAmount,
                lossAmount,
                remark: dto.remark,
                creatorId: validUserId,
                items: {
                    create: itemsData
                }
            },
            include: {
                items: {
                    include: {
                        product: true
                    }
                },
                creator: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        return {
            code: 200,
            message: '创建盘点单成功',
            data: check
        };
    }
    async findAll(query) {
        const { page = 1, pageSize = 20, status, checkType, startDate, endDate, checkNo, } = query;
        const skip = (page - 1) * pageSize;
        const where = {};
        if (status) {
            where.status = status;
        }
        if (checkType) {
            where.checkType = checkType;
        }
        if (startDate || endDate) {
            where.checkDate = {};
            if (startDate) {
                where.checkDate.gte = new Date(startDate);
            }
            if (endDate) {
                where.checkDate.lte = new Date(endDate);
            }
        }
        if (checkNo) {
            where.checkNo = {
                contains: checkNo
            };
        }
        const [total, items] = await Promise.all([
            this.prisma.stockCheck.count({ where }),
            this.prisma.stockCheck.findMany({
                where,
                skip,
                take: pageSize,
                orderBy: {
                    createdAt: 'desc'
                },
                include: {
                    creator: {
                        select: {
                            id: true,
                            nickname: true
                        }
                    },
                    approver: {
                        select: {
                            id: true,
                            nickname: true
                        }
                    }
                }
            })
        ]);
        return {
            code: 200,
            message: '查询盘点单列表成功',
            data: {
                items,
                total,
                page,
                pageSize,
                totalPages: Math.ceil(total / pageSize)
            }
        };
    }
    async findOne(id) {
        const check = await this.prisma.stockCheck.findUnique({
            where: { id },
            include: {
                items: {
                    include: {
                        product: true
                    }
                },
                creator: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                approver: {
                    select: {
                        id: true,
                        nickname: true
                    }
                },
                transactions: true
            }
        });
        if (!check) {
            throw new common_1.NotFoundException('盘点单不存在');
        }
        return {
            code: 200,
            message: '查询盘点单详情成功',
            data: check
        };
    }
    async update(id, updateCheckDto) {
        const dto = updateCheckDto;
        const check = await this.prisma.stockCheck.findUnique({
            where: { id },
            include: {
                items: true
            }
        });
        if (!check) {
            throw new common_1.NotFoundException('盘点单不存在');
        }
        if (check.status !== 'PENDING') {
            throw new common_1.BadRequestException('只能修改待审批状态的盘点单');
        }
        const updateData = {};
        if (dto.remark !== undefined) {
            updateData.remark = dto.remark;
        }
        if (dto.items && dto.items.length > 0) {
            let newProfitQuantity = 0;
            let newLossQuantity = 0;
            let newProfitItems = 0;
            let newLossItems = 0;
            let newProfitAmount = new library_1.Decimal(0);
            let newLossAmount = new library_1.Decimal(0);
            const newItemsData = [];
            for (const item of dto.items) {
                const product = await this.prisma.product.findUnique({
                    where: { id: item.productId }
                });
                if (!product) {
                    throw new common_1.NotFoundException(`商品ID ${item.productId} 不存在`);
                }
                const actualQty = item.actualQuantity !== undefined ? item.actualQuantity : item.systemQuantity || 0;
                const systemQty = item.systemQuantity || 0;
                const difference = actualQty - systemQty;
                const unitPrice = product.costPrice;
                const differenceAmount = new library_1.Decimal(unitPrice).mul(Math.abs(difference));
                let differenceType = 'NORMAL';
                if (difference > 0) {
                    differenceType = 'PROFIT';
                    newProfitQuantity += difference;
                    newProfitItems += 1;
                    newProfitAmount = newProfitAmount.add(differenceAmount);
                }
                else if (difference < 0) {
                    differenceType = 'LOSS';
                    newLossQuantity += Math.abs(difference);
                    newLossItems += 1;
                    newLossAmount = newLossAmount.add(differenceAmount);
                }
                newItemsData.push({
                    productId: item.productId,
                    systemQuantity: systemQty,
                    actualQuantity: actualQty,
                    differenceQty: difference,
                    unitPrice,
                    differenceAmount,
                    differenceType,
                    remark: item.remark
                });
            }
            updateData.profitQuantity = newProfitQuantity;
            updateData.lossQuantity = newLossQuantity;
            updateData.profitItems = newProfitItems;
            updateData.lossItems = newLossItems;
            updateData.profitAmount = newProfitAmount;
            updateData.lossAmount = newLossAmount;
            updateData.items = {
                deleteMany: {},
                create: newItemsData
            };
        }
        const updated = await this.prisma.stockCheck.update({
            where: { id },
            data: updateData,
            include: {
                items: {
                    include: {
                        product: true
                    }
                },
                creator: {
                    select: {
                        id: true,
                        nickname: true
                    }
                }
            }
        });
        return {
            code: 200,
            message: '更新盘点单成功',
            data: updated
        };
    }
    async remove(id) {
        const check = await this.prisma.stockCheck.findUnique({
            where: { id }
        });
        if (!check) {
            throw new common_1.NotFoundException('盘点单不存在');
        }
        if (check.status !== 'PENDING') {
            throw new common_1.BadRequestException('只能删除待审批状态的盘点单');
        }
        await this.prisma.stockCheck.delete({
            where: { id }
        });
        return {
            code: 200,
            message: '删除盘点单成功',
            data: null
        };
    }
    async approve(id, userId, approved, note, autoAdjust = true) {
        let validUserId = userId;
        if (userId) {
            const user = await this.prisma.user.findUnique({ where: { id: userId } });
            if (!user) {
                const tempUser = await this.prisma.user.create({
                    data: {
                        openid: 'admin_temp_' + Date.now(),
                        nickname: '系统管理员',
                        phone: '13800138000',
                        status: 'ACTIVE'
                    }
                });
                validUserId = tempUser.id;
            }
        }
        return await this.prisma.$transaction(async (tx) => {
            const check = await tx.stockCheck.findUnique({
                where: { id },
                include: {
                    items: {
                        include: {
                            product: true
                        }
                    }
                }
            });
            if (!check) {
                throw new common_1.NotFoundException('盘点单不存在');
            }
            if (check.status !== 'PENDING') {
                throw new common_1.BadRequestException('盘点单已审批，不能重复审批');
            }
            if (approved && autoAdjust) {
                for (const item of check.items) {
                    if (!item.product.isTrackStock) {
                        continue;
                    }
                    if (item.differenceQty === 0) {
                        continue;
                    }
                    await tx.product.update({
                        where: { id: item.productId },
                        data: {
                            stockQuantity: item.actualQuantity
                        }
                    });
                    const transactionNo = await this.generateTransactionNo();
                    await tx.stockTransaction.create({
                        data: {
                            transactionNo,
                            transactionType: item.differenceQty > 0 ? 'CHECK_IN' : 'CHECK_OUT',
                            productId: item.productId,
                            quantity: item.differenceQty,
                            beforeStock: item.systemQuantity,
                            afterStock: item.actualQuantity,
                            refType: 'CHECK',
                            refId: check.id,
                            checkId: check.id,
                            remark: `盘点调整：${check.checkNo} - ${item.remark || '盘点差异调整'}`,
                            operatorId: validUserId
                        }
                    });
                }
                return await tx.stockCheck.update({
                    where: { id },
                    data: {
                        status: 'COMPLETED',
                        approverId: validUserId,
                        approvedAt: new Date(),
                        approvalNote: note
                    },
                    include: {
                        items: {
                            include: {
                                product: true
                            }
                        },
                        creator: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        },
                        approver: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        },
                        transactions: true
                    }
                });
            }
            else if (approved && !autoAdjust) {
                return await tx.stockCheck.update({
                    where: { id },
                    data: {
                        status: 'APPROVED',
                        approverId: validUserId,
                        approvedAt: new Date(),
                        approvalNote: note
                    },
                    include: {
                        items: {
                            include: {
                                product: true
                            }
                        },
                        creator: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        },
                        approver: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        }
                    }
                });
            }
            else {
                return await tx.stockCheck.update({
                    where: { id },
                    data: {
                        status: 'REJECTED',
                        approverId: validUserId,
                        approvedAt: new Date(),
                        approvalNote: note
                    },
                    include: {
                        items: {
                            include: {
                                product: true
                            }
                        },
                        creator: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        },
                        approver: {
                            select: {
                                id: true,
                                nickname: true
                            }
                        }
                    }
                });
            }
        });
    }
    async statistics(startDate, endDate) {
        const where = {};
        where.status = 'COMPLETED';
        if (startDate || endDate) {
            where.checkDate = {};
            if (startDate) {
                where.checkDate.gte = new Date(startDate);
            }
            if (endDate) {
                where.checkDate.lte = new Date(endDate);
            }
        }
        const [totalCount, checks] = await Promise.all([
            this.prisma.stockCheck.count({ where }),
            this.prisma.stockCheck.findMany({
                where,
                select: {
                    profitQuantity: true,
                    lossQuantity: true,
                    checkType: true
                }
            })
        ]);
        const totalDifferenceQty = checks.reduce((sum, check) => sum + check.profitQuantity + check.lossQuantity, 0);
        const byType = checks.reduce((acc, check) => {
            if (!acc[check.checkType]) {
                acc[check.checkType] = {
                    count: 0,
                    profitQuantity: 0,
                    lossQuantity: 0
                };
            }
            acc[check.checkType].count += 1;
            acc[check.checkType].profitQuantity += check.profitQuantity;
            acc[check.checkType].lossQuantity += check.lossQuantity;
            return acc;
        }, {});
        return {
            code: 200,
            message: '查询盘点统计成功',
            data: {
                totalCount,
                totalDifferenceQty,
                byType
            }
        };
    }
};
exports.StockCheckService = StockCheckService;
exports.StockCheckService = StockCheckService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], StockCheckService);
//# sourceMappingURL=stock-check.service.js.map