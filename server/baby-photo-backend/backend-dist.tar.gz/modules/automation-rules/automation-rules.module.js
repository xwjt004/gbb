"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutomationRulesModule = void 0;
const common_1 = require("@nestjs/common");
const automation_rules_service_1 = require("./automation-rules.service");
const automation_rules_controller_1 = require("./automation-rules.controller");
const prisma_module_1 = require("../../shared/prisma/prisma.module");
const notifications_module_1 = require("../notifications/notifications.module");
const stock_alert_module_1 = require("../stock-alert/stock-alert.module");
let AutomationRulesModule = class AutomationRulesModule {
};
exports.AutomationRulesModule = AutomationRulesModule;
exports.AutomationRulesModule = AutomationRulesModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule, notifications_module_1.NotificationsModule, stock_alert_module_1.StockAlertModule],
        controllers: [automation_rules_controller_1.AutomationRulesController],
        providers: [automation_rules_service_1.AutomationRulesService],
        exports: [automation_rules_service_1.AutomationRulesService],
    })
], AutomationRulesModule);
//# sourceMappingURL=automation-rules.module.js.map