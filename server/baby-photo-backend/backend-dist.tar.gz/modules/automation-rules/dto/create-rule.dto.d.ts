export declare class CreateRuleDto {
    name: string;
    description?: string;
    trigger: string;
    conditions?: any[];
    actions: any[];
    enabled?: boolean;
    sortOrder?: number;
}
