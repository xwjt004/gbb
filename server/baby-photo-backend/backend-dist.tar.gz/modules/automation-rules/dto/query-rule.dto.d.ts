export declare class QueryRuleDto {
    page?: number;
    pageSize?: number;
    trigger?: string;
    enabled?: boolean;
}
