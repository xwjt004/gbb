"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AutomationRulesService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutomationRulesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
const notifications_service_1 = require("../notifications/notifications.service");
const stock_alert_service_1 = require("../stock-alert/stock-alert.service");
let AutomationRulesService = AutomationRulesService_1 = class AutomationRulesService {
    prisma;
    notificationsService;
    stockAlertService;
    logger = new common_1.Logger(AutomationRulesService_1.name);
    constructor(prisma, notificationsService, stockAlertService) {
        this.prisma = prisma;
        this.notificationsService = notificationsService;
        this.stockAlertService = stockAlertService;
    }
    async create(dto) {
        return this.prisma.automationRule.create({
            data: {
                name: dto.name,
                description: dto.description,
                trigger: dto.trigger,
                conditions: dto.conditions || undefined,
                actions: dto.actions,
                enabled: dto.enabled ?? true,
                sortOrder: dto.sortOrder || 0,
            },
        });
    }
    async findAll(query) {
        const { page = 1, pageSize = 20, trigger, enabled } = query;
        const skip = (page - 1) * pageSize;
        const where = {};
        if (trigger)
            where.trigger = trigger;
        if (enabled !== undefined)
            where.enabled = enabled;
        const [items, total] = await Promise.all([
            this.prisma.automationRule.findMany({
                where,
                skip,
                take: pageSize,
                orderBy: [{ sortOrder: 'asc' }, { createdAt: 'desc' }],
            }),
            this.prisma.automationRule.count({ where }),
        ]);
        return {
            code: 200,
            message: '查询成功',
            data: {
                items,
                pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
            },
        };
    }
    async findOne(id) {
        const rule = await this.prisma.automationRule.findUnique({ where: { id } });
        if (!rule)
            throw new common_1.NotFoundException('规则不存在');
        return { code: 200, data: rule };
    }
    async update(id, dto) {
        const rule = await this.prisma.automationRule.findUnique({ where: { id } });
        if (!rule)
            throw new common_1.NotFoundException('规则不存在');
        return this.prisma.automationRule.update({ where: { id }, data: dto });
    }
    async remove(id) {
        const rule = await this.prisma.automationRule.findUnique({ where: { id } });
        if (!rule)
            throw new common_1.NotFoundException('规则不存在');
        await this.prisma.automationRule.delete({ where: { id } });
        return { code: 200, message: '删除成功' };
    }
    async toggle(id) {
        const rule = await this.prisma.automationRule.findUnique({ where: { id } });
        if (!rule)
            throw new common_1.NotFoundException('规则不存在');
        return this.prisma.automationRule.update({
            where: { id },
            data: { enabled: !rule.enabled },
        });
    }
    async evaluate(trigger, context) {
        this.logger.log(`评估自动化规则: trigger=${trigger}`);
        const rules = await this.prisma.automationRule.findMany({
            where: { trigger, enabled: true },
            orderBy: { sortOrder: 'asc' },
        });
        for (const rule of rules) {
            try {
                if (!this.evaluateConditions(rule.conditions, context)) {
                    continue;
                }
                await this.executeActions(rule.actions, context);
                this.logger.log(`规则执行成功: ${rule.name} (id=${rule.id})`);
            }
            catch (err) {
                this.logger.error(`规则执行失败: ${rule.name} (id=${rule.id})`, err);
            }
        }
    }
    evaluateConditions(conditions, context) {
        if (!conditions || conditions.length === 0)
            return true;
        return conditions.every((cond) => {
            const actualValue = context[cond.field];
            switch (cond.operator) {
                case '>': return Number(actualValue) > Number(cond.value);
                case '>=': return Number(actualValue) >= Number(cond.value);
                case '<': return Number(actualValue) < Number(cond.value);
                case '<=': return Number(actualValue) <= Number(cond.value);
                case '==': return String(actualValue) === String(cond.value);
                case '!=': return String(actualValue) !== String(cond.value);
                case 'contains': return String(actualValue).includes(String(cond.value));
                default: return true;
            }
        });
    }
    async executeActions(actions, context) {
        for (const action of actions) {
            switch (action.type) {
                case 'SEND_NOTIFICATION': {
                    const params = action.params || {};
                    await this.notificationsService.create({
                        type: 'SYSTEM',
                        title: params.title || '系统通知',
                        content: this.interpolate(params.content, context),
                        recipient: context.wxUser?.openid || context.wxUserId || params.recipient || '',
                    });
                    break;
                }
                case 'UPDATE_ORDER_STATUS': {
                    const params = action.params || {};
                    if (context.order?.id) {
                        await this.prisma.order.update({
                            where: { id: context.order.id },
                            data: { orderStatus: params.status },
                        });
                    }
                    break;
                }
                case 'CREATE_STOCK_ALERT': {
                    const params = action.params || {};
                    if (context.product?.id) {
                        await this.stockAlertService.createAlert({
                            productId: context.product.id,
                            alertType: params.alertType || 'LOW_STOCK',
                            currentStock: context.currentStock || 0,
                            threshold: params.threshold || 0,
                            priority: params.priority || 'MEDIUM',
                        });
                    }
                    break;
                }
                case 'SEND_COUPON': {
                    const params = action.params || {};
                    const wxUserId = context.wxUserId;
                    const couponId = params.couponId;
                    if (wxUserId && couponId) {
                        const coupon = await this.prisma.coupon.findUnique({ where: { id: couponId } });
                        if (coupon?.status === 'ACTIVE') {
                            const count = await this.prisma.userCoupon.count({ where: { wxUserId, couponId } });
                            if (count < (coupon.perUserLimit || 1)) {
                                await this.prisma.userCoupon.create({
                                    data: {
                                        wxUserId,
                                        couponId,
                                        status: 'UNUSED',
                                        expiredAt: coupon.endTime,
                                    },
                                });
                            }
                        }
                    }
                    break;
                }
                default:
                    this.logger.warn(`未知动作类型: ${action.type}`);
            }
        }
    }
    interpolate(template, context) {
        return template.replace(/\{\{(\w+)\}\}/g, (_, key) => {
            return String(context[key] ?? context.order?.[key] ?? `{{${key}}}`);
        });
    }
};
exports.AutomationRulesService = AutomationRulesService;
exports.AutomationRulesService = AutomationRulesService = AutomationRulesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        notifications_service_1.NotificationsService,
        stock_alert_service_1.StockAlertService])
], AutomationRulesService);
//# sourceMappingURL=automation-rules.service.js.map