export declare class AutomationRulesModule {
}
