import { PrismaService } from '../../shared/prisma/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { StockAlertService } from '../stock-alert/stock-alert.service';
import { CreateRuleDto } from './dto/create-rule.dto';
import { UpdateRuleDto } from './dto/update-rule.dto';
import { QueryRuleDto } from './dto/query-rule.dto';
export declare class AutomationRulesService {
    private readonly prisma;
    private readonly notificationsService;
    private readonly stockAlertService;
    private readonly logger;
    constructor(prisma: PrismaService, notificationsService: NotificationsService, stockAlertService: StockAlertService);
    create(dto: CreateRuleDto): Promise<{
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        description: string | null;
        sortOrder: number;
        trigger: string;
        conditions: import("@prisma/client/runtime/library").JsonValue | null;
        actions: import("@prisma/client/runtime/library").JsonValue;
        enabled: boolean;
    }>;
    findAll(query: QueryRuleDto): Promise<{
        code: number;
        message: string;
        data: {
            items: {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                description: string | null;
                sortOrder: number;
                trigger: string;
                conditions: import("@prisma/client/runtime/library").JsonValue | null;
                actions: import("@prisma/client/runtime/library").JsonValue;
                enabled: boolean;
            }[];
            pagination: {
                page: number;
                pageSize: number;
                total: number;
                totalPages: number;
            };
        };
    }>;
    findOne(id: number): Promise<{
        code: number;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            sortOrder: number;
            trigger: string;
            conditions: import("@prisma/client/runtime/library").JsonValue | null;
            actions: import("@prisma/client/runtime/library").JsonValue;
            enabled: boolean;
        };
    }>;
    update(id: number, dto: UpdateRuleDto): Promise<{
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        description: string | null;
        sortOrder: number;
        trigger: string;
        conditions: import("@prisma/client/runtime/library").JsonValue | null;
        actions: import("@prisma/client/runtime/library").JsonValue;
        enabled: boolean;
    }>;
    remove(id: number): Promise<{
        code: number;
        message: string;
    }>;
    toggle(id: number): Promise<{
        id: number;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        description: string | null;
        sortOrder: number;
        trigger: string;
        conditions: import("@prisma/client/runtime/library").JsonValue | null;
        actions: import("@prisma/client/runtime/library").JsonValue;
        enabled: boolean;
    }>;
    evaluate(trigger: string, context: Record<string, any>): Promise<void>;
    private evaluateConditions;
    private executeActions;
    private interpolate;
}
