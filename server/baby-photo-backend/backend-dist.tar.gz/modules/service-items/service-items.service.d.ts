import { PrismaService } from '../../shared/prisma/prisma.service';
import { CreateServiceItemDto } from './dto/create-service-item.dto';
import { UpdateServiceItemDto } from './dto/update-service-item.dto';
import { QueryServiceItemDto } from './dto/query-service-item.dto';
export declare class ServiceItemsService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    create(createDto: CreateServiceItemDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            images: import("@prisma/client/runtime/library").JsonValue | null;
            category: string;
            basePrice: import("@prisma/client/runtime/library").Decimal;
            unitPrice: import("@prisma/client/runtime/library").Decimal | null;
            isActive: boolean;
            serviceNo: string;
            priceUnit: string | null;
            duration: number | null;
            requirements: import("@prisma/client/runtime/library").JsonValue | null;
            isRequired: boolean;
        };
    }>;
    findAll(query: QueryServiceItemDto): Promise<{
        code: number;
        message: string;
        data: {
            list: {
                id: number;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                description: string | null;
                images: import("@prisma/client/runtime/library").JsonValue | null;
                category: string;
                basePrice: import("@prisma/client/runtime/library").Decimal;
                unitPrice: import("@prisma/client/runtime/library").Decimal | null;
                isActive: boolean;
                serviceNo: string;
                priceUnit: string | null;
                duration: number | null;
                requirements: import("@prisma/client/runtime/library").JsonValue | null;
                isRequired: boolean;
            }[];
            pagination: {
                page: number;
                pageSize: number;
                total: number;
                totalPages: number;
            };
        };
    }>;
    findByCategory(category: string): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            images: import("@prisma/client/runtime/library").JsonValue | null;
            category: string;
            basePrice: import("@prisma/client/runtime/library").Decimal;
            unitPrice: import("@prisma/client/runtime/library").Decimal | null;
            isActive: boolean;
            serviceNo: string;
            priceUnit: string | null;
            duration: number | null;
            requirements: import("@prisma/client/runtime/library").JsonValue | null;
            isRequired: boolean;
        }[];
    }>;
    getCategories(): Promise<{
        code: number;
        message: string;
        data: string[];
    }>;
    findOne(id: number): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            images: import("@prisma/client/runtime/library").JsonValue | null;
            category: string;
            basePrice: import("@prisma/client/runtime/library").Decimal;
            unitPrice: import("@prisma/client/runtime/library").Decimal | null;
            isActive: boolean;
            serviceNo: string;
            priceUnit: string | null;
            duration: number | null;
            requirements: import("@prisma/client/runtime/library").JsonValue | null;
            isRequired: boolean;
        };
    }>;
    update(id: number, updateDto: UpdateServiceItemDto): Promise<{
        code: number;
        message: string;
        data: {
            id: number;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            description: string | null;
            images: import("@prisma/client/runtime/library").JsonValue | null;
            category: string;
            basePrice: import("@prisma/client/runtime/library").Decimal;
            unitPrice: import("@prisma/client/runtime/library").Decimal | null;
            isActive: boolean;
            serviceNo: string;
            priceUnit: string | null;
            duration: number | null;
            requirements: import("@prisma/client/runtime/library").JsonValue | null;
            isRequired: boolean;
        };
    }>;
    remove(id: number): Promise<{
        code: number;
        message: string;
    }>;
    getStatistics(): Promise<{
        code: number;
        message: string;
        data: {
            total: number;
            active: number;
            inactive: number;
            byCategory: Record<string, number>;
        };
    }>;
}
