export declare class QueryServiceItemDto {
    category?: string;
    isActive?: boolean;
    isRequired?: boolean;
    keyword?: string;
    page?: number;
    pageSize?: number;
}
