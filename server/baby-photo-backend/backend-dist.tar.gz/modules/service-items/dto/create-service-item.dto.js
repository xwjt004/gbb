"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateServiceItemDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class CreateServiceItemDto {
    serviceNo;
    name;
    category;
    basePrice;
    unitPrice;
    priceUnit;
    description;
    duration;
    requirements;
    images;
    isActive;
    isRequired;
}
exports.CreateServiceItemDto = CreateServiceItemDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: '服务编号', example: 'SRV-STUDIO-01' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: '服务编号不能为空' }),
    (0, class_validator_1.MaxLength)(50, { message: '服务编号最长50个字符' }),
    __metadata("design:type", String)
], CreateServiceItemDto.prototype, "serviceNo", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '服务名称', example: '室内影棚拍摄' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: '服务名称不能为空' }),
    (0, class_validator_1.MaxLength)(100, { message: '服务名称最长100个字符' }),
    __metadata("design:type", String)
], CreateServiceItemDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '服务分类', example: '拍摄场地' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: '服务分类不能为空' }),
    (0, class_validator_1.MaxLength)(50, { message: '服务分类最长50个字符' }),
    __metadata("design:type", String)
], CreateServiceItemDto.prototype, "category", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '基础价格', example: 500.00, required: false, default: 0 }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], CreateServiceItemDto.prototype, "basePrice", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '单价（按次/小时）', example: 200.00, required: false }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], CreateServiceItemDto.prototype, "unitPrice", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '计价单位', example: '小时', required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.MaxLength)(20),
    __metadata("design:type", String)
], CreateServiceItemDto.prototype, "priceUnit", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '服务描述', required: false }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateServiceItemDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '服务时长（分钟）', example: 120, required: false }),
    (0, class_validator_1.IsInt)({ message: '服务时长必须是整数' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateServiceItemDto.prototype, "duration", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '服务要求', required: false, example: { space: '100平米', equipment: ['灯光', '背景布'] } }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], CreateServiceItemDto.prototype, "requirements", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '服务图片数组', required: false, example: ['image1.jpg', 'image2.jpg'] }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], CreateServiceItemDto.prototype, "images", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否启用', example: true, required: false, default: true }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], CreateServiceItemDto.prototype, "isActive", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: '是否必选', example: false, required: false, default: false }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], CreateServiceItemDto.prototype, "isRequired", void 0);
//# sourceMappingURL=create-service-item.dto.js.map