export declare class CreateServiceItemDto {
    serviceNo: string;
    name: string;
    category: string;
    basePrice?: number;
    unitPrice?: number;
    priceUnit?: string;
    description?: string;
    duration?: number;
    requirements?: any;
    images?: any;
    isActive?: boolean;
    isRequired?: boolean;
}
