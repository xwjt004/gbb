export declare class ServiceItemsModule {
}
