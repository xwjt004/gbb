"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ServiceItemsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceItemsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../shared/prisma/prisma.service");
let ServiceItemsService = ServiceItemsService_1 = class ServiceItemsService {
    prisma;
    logger = new common_1.Logger(ServiceItemsService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(createDto) {
        this.logger.log(`创建服务项目: ${createDto.name}`);
        const existing = await this.prisma.serviceItem.findUnique({
            where: { serviceNo: createDto.serviceNo },
        });
        if (existing) {
            throw new common_1.ConflictException(`服务编号 "${createDto.serviceNo}" 已存在`);
        }
        try {
            const serviceItem = await this.prisma.serviceItem.create({
                data: {
                    serviceNo: createDto.serviceNo,
                    name: createDto.name,
                    category: createDto.category,
                    basePrice: createDto.basePrice || 0,
                    unitPrice: createDto.unitPrice,
                    priceUnit: createDto.priceUnit,
                    description: createDto.description,
                    duration: createDto.duration,
                    requirements: createDto.requirements,
                    isActive: createDto.isActive ?? true,
                    isRequired: createDto.isRequired ?? false,
                },
            });
            this.logger.log(`服务项目创建成功: ID=${serviceItem.id}`);
            return {
                code: 200,
                message: '创建成功',
                data: serviceItem,
            };
        }
        catch (error) {
            this.logger.error(`创建服务项目失败: ${error.message}`);
            throw error;
        }
    }
    async findAll(query) {
        const { category, isActive, isRequired, keyword, page = 1, pageSize = 20 } = query;
        const where = {};
        if (category)
            where.category = category;
        if (isActive !== undefined)
            where.isActive = isActive;
        if (isRequired !== undefined)
            where.isRequired = isRequired;
        if (keyword) {
            where.OR = [
                { name: { contains: keyword } },
                { serviceNo: { contains: keyword } },
            ];
        }
        try {
            const [total, list] = await Promise.all([
                this.prisma.serviceItem.count({ where }),
                this.prisma.serviceItem.findMany({
                    where,
                    orderBy: [
                        { category: 'asc' },
                        { createdAt: 'desc' },
                    ],
                    skip: (page - 1) * pageSize,
                    take: pageSize,
                }),
            ]);
            return {
                code: 200,
                message: '查询成功',
                data: {
                    list,
                    pagination: {
                        page,
                        pageSize,
                        total,
                        totalPages: Math.ceil(total / pageSize),
                    },
                },
            };
        }
        catch (error) {
            this.logger.error(`查询服务项目列表失败: ${error.message}`);
            throw error;
        }
    }
    async findByCategory(category) {
        try {
            const services = await this.prisma.serviceItem.findMany({
                where: {
                    category,
                    isActive: true,
                },
                orderBy: { name: 'asc' },
            });
            return {
                code: 200,
                message: '查询成功',
                data: services,
            };
        }
        catch (error) {
            this.logger.error(`按分类查询服务项目失败: ${error.message}`);
            throw error;
        }
    }
    async getCategories() {
        try {
            const categories = await this.prisma.serviceItem.findMany({
                select: { category: true },
                distinct: ['category'],
                orderBy: { category: 'asc' },
            });
            const categoryList = categories.map(item => item.category);
            return {
                code: 200,
                message: '查询成功',
                data: categoryList,
            };
        }
        catch (error) {
            this.logger.error(`获取服务分类失败: ${error.message}`);
            throw error;
        }
    }
    async findOne(id) {
        try {
            const serviceItem = await this.prisma.serviceItem.findUnique({
                where: { id },
            });
            if (!serviceItem) {
                throw new common_1.NotFoundException(`服务项目 ID=${id} 不存在`);
            }
            return {
                code: 200,
                message: '查询成功',
                data: serviceItem,
            };
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException) {
                throw error;
            }
            this.logger.error(`查询服务项目详情失败: ${error.message}`);
            throw error;
        }
    }
    async update(id, updateDto) {
        this.logger.log(`更新服务项目: ID=${id}`);
        const existing = await this.prisma.serviceItem.findUnique({
            where: { id },
        });
        if (!existing) {
            throw new common_1.NotFoundException(`服务项目 ID=${id} 不存在`);
        }
        if (updateDto.serviceNo && updateDto.serviceNo !== existing.serviceNo) {
            const duplicate = await this.prisma.serviceItem.findFirst({
                where: {
                    serviceNo: updateDto.serviceNo,
                    id: { not: id },
                },
            });
            if (duplicate) {
                throw new common_1.ConflictException(`服务编号 "${updateDto.serviceNo}" 已存在`);
            }
        }
        try {
            const serviceItem = await this.prisma.serviceItem.update({
                where: { id },
                data: updateDto,
            });
            this.logger.log(`服务项目更新成功: ID=${id}`);
            return {
                code: 200,
                message: '更新成功',
                data: serviceItem,
            };
        }
        catch (error) {
            this.logger.error(`更新服务项目失败: ${error.message}`);
            throw error;
        }
    }
    async remove(id) {
        this.logger.log(`删除服务项目: ID=${id}`);
        const existing = await this.prisma.serviceItem.findUnique({
            where: { id },
        });
        if (!existing) {
            throw new common_1.NotFoundException(`服务项目 ID=${id} 不存在`);
        }
        try {
            await this.prisma.serviceItem.delete({
                where: { id },
            });
            this.logger.log(`服务项目删除成功: ID=${id}`);
            return {
                code: 200,
                message: '删除成功',
            };
        }
        catch (error) {
            this.logger.error(`删除服务项目失败: ${error.message}`);
            throw error;
        }
    }
    async getStatistics() {
        try {
            const [total, active, byCategory] = await Promise.all([
                this.prisma.serviceItem.count(),
                this.prisma.serviceItem.count({ where: { isActive: true } }),
                this.prisma.serviceItem.groupBy({
                    by: ['category'],
                    _count: true,
                }),
            ]);
            const categoryStats = byCategory.reduce((acc, item) => {
                acc[item.category] = item._count;
                return acc;
            }, {});
            return {
                code: 200,
                message: '查询成功',
                data: {
                    total,
                    active,
                    inactive: total - active,
                    byCategory: categoryStats,
                },
            };
        }
        catch (error) {
            this.logger.error(`获取服务统计失败: ${error.message}`);
            throw error;
        }
    }
};
exports.ServiceItemsService = ServiceItemsService;
exports.ServiceItemsService = ServiceItemsService = ServiceItemsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ServiceItemsService);
//# sourceMappingURL=service-items.service.js.map