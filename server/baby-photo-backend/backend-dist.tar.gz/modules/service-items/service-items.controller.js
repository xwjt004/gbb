"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ServiceItemsController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceItemsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const service_items_service_1 = require("./service-items.service");
const create_service_item_dto_1 = require("./dto/create-service-item.dto");
const update_service_item_dto_1 = require("./dto/update-service-item.dto");
const query_service_item_dto_1 = require("./dto/query-service-item.dto");
let ServiceItemsController = ServiceItemsController_1 = class ServiceItemsController {
    serviceItemsService;
    logger = new common_1.Logger(ServiceItemsController_1.name);
    constructor(serviceItemsService) {
        this.serviceItemsService = serviceItemsService;
    }
    create(createDto) {
        this.logger.log(`创建服务项目: ${createDto.name}`);
        return this.serviceItemsService.create(createDto);
    }
    findAll(query) {
        return this.serviceItemsService.findAll(query);
    }
    getCategories() {
        return this.serviceItemsService.getCategories();
    }
    getStatistics() {
        return this.serviceItemsService.getStatistics();
    }
    findByCategory(category) {
        return this.serviceItemsService.findByCategory(category);
    }
    findOne(id) {
        return this.serviceItemsService.findOne(id);
    }
    update(id, updateDto) {
        this.logger.log(`更新服务项目: ID=${id}`);
        return this.serviceItemsService.update(id, updateDto);
    }
    remove(id) {
        this.logger.log(`删除服务项目: ID=${id}`);
        return this.serviceItemsService.remove(id);
    }
};
exports.ServiceItemsController = ServiceItemsController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '创建服务项目' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '创建成功' }),
    (0, swagger_1.ApiResponse)({ status: 409, description: '服务编号已存在' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_service_item_dto_1.CreateServiceItemDto]),
    __metadata("design:returntype", void 0)
], ServiceItemsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: '获取服务项目列表' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_service_item_dto_1.QueryServiceItemDto]),
    __metadata("design:returntype", void 0)
], ServiceItemsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('categories'),
    (0, swagger_1.ApiOperation)({ summary: '获取所有服务分类' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ServiceItemsController.prototype, "getCategories", null);
__decorate([
    (0, common_1.Get)('statistics'),
    (0, swagger_1.ApiOperation)({ summary: '获取服务统计' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ServiceItemsController.prototype, "getStatistics", null);
__decorate([
    (0, common_1.Get)('by-category/:category'),
    (0, swagger_1.ApiOperation)({ summary: '按分类查询服务项目' }),
    (0, swagger_1.ApiParam)({ name: 'category', description: '服务分类', type: 'string' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    __param(0, (0, common_1.Param)('category')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ServiceItemsController.prototype, "findByCategory", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '获取服务项目详情' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '服务项目ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '获取成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '服务项目不存在' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], ServiceItemsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '更新服务项目' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '服务项目ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '更新成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '服务项目不存在' }),
    (0, swagger_1.ApiResponse)({ status: 409, description: '服务编号已存在' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, update_service_item_dto_1.UpdateServiceItemDto]),
    __metadata("design:returntype", void 0)
], ServiceItemsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '删除服务项目' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '服务项目ID', type: 'number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '删除成功' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '服务项目不存在' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], ServiceItemsController.prototype, "remove", null);
exports.ServiceItemsController = ServiceItemsController = ServiceItemsController_1 = __decorate([
    (0, swagger_1.ApiTags)('service-items'),
    (0, common_1.Controller)('service-items'),
    __metadata("design:paramtypes", [service_items_service_1.ServiceItemsService])
], ServiceItemsController);
//# sourceMappingURL=service-items.controller.js.map