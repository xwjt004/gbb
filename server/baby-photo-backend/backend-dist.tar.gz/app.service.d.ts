import { PrismaService } from './shared/prisma/prisma.service';
export declare class AppService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getHello(): string;
    getHealth(): Promise<{
        status: string;
        message: string;
        timestamp: string;
        uptime: string;
        version: any;
        environment: string;
        services: {
            database: string;
            redis: string;
            disk: {
                total?: string;
                used?: string;
                free?: string;
                usagePercent?: number;
            };
        };
    }>;
    getVersion(): {
        name: any;
        version: any;
        description: any;
        startupTime: string;
        nodeVersion: string;
        platform: NodeJS.Platform;
    };
}
